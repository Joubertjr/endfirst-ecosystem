# Baselines

Esta pasta contém baselines (linhas de base) para comparação de resultados.

## 📊 O QUÊ SÃO BASELINES?

**Baseline** = Resultado anterior usado para comparação.

**Exemplo:**
- `artigo_1_original.md` - Baseline (sem método)
- `artigo_1_v2_comparacao.md` - Comparação (com método v10.1)

## 🎯 QUANDO CRIAR?

**ANTES** de aplicar nova versão do método em resultado similar.

## 📁 ESTRUTURA

```
baselines/
├── [nome]_baseline.md (métricas do original)
└── [nome]_comparacao.md (comparação antes/depois)
```

## ✅ TEMPLATE

Ver: `../../templates/baseline_template.md`

---

**Ver:** `../method/core/pillar_7_learning.md` (Pilar 7 - Validação Empírica)

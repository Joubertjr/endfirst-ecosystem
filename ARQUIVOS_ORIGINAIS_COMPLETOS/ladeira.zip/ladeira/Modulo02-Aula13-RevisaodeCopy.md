Apostila au
Aula 13
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Revisão
de Copy

Apostila aula 01 
Aula 13 - Revisão de Copy
Módulo 02 Copy Tradicional
O que é?
Revisão de copy é quando o copywriter lê 
novamente o que escreveu na intenção de 
identificar possíveis erros de comunicação, 
intenção de fala, público alvo e outros aspectos 
que podem não tornar sua copy efetiva e eficaz.
Aprender como revisar uma copy e se ela atinge o 
objetivo estabelecido no briefing. Estar atento se a 
comunicação está alinhada com o público alvo e 
se 
na 
copy 
existe 
elementos 
que 
estão 
direcionados à meta estabelecida previamente.
Tópicos Principais
Objetivo de Copy
Público
Objetivo de Tráfego
3C´s
Exercícios
  
1
2
3
4
5
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 13 - Revisão de Copy
Módulo 02 Copy Tradicional
Objetivos de Copy
Objetivo de Marketing
Demografico
Interesse
Temperatura
Lead
Objetivo de Comunicação
 Se pergunte “o objetivo de marketing foi cumprido?”
 Chamou o público para as ações estabelecidas?
{
{
{
{
{
{
Conteúdo da Aula
Publico
{
Ø QuentÒ
Ø MornÔ
Ø Frio
{
Ø DiretÔ
Ø Indireto

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 13 - Revisão de Copy
Módulo 02 Copy Tradicional
Objetivos de Tráfego
3C´s
{
{
{
{
V Sem CTA
V CTA para seguir
V CTA para clicar
V Clicar para comprar
Relacionamento
Descoberta
Conversão
Remarketing
{
{
{
{
Clareza
Coesão
Coerência
Ì Explica de forma simples e objetiva, sem enrolação ou 
informações desnecessárias
Ì O texto se conecta de forma harmônica, compreensível e 
sem erros gramaticais
Ì O texto se conecta de forma harmônica, compreensível e 
sem erros gramaticais
{
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 13 - Revisão de Copy
Módulo 02 Copy Tradicional
Exercicios
01
Ler em voz alta para um amigo: 
Leia o seu texto para um colega ou familiar e tente 
extrair o que ele entendeu sobre a sua comunicação. 
Ele entendeu o objetivo do seu texto? Ele compreendeu 
para qual público você gostaria de comunicar? Colete 
informações e percepções que o seu ouvinte teve 
sobre seu texto: se estava confuso, se foi claro, se foi 
cansativo, se teve erros gramaticais, e ajuste conforme 
for necessário. 
 02
03
Ler em voz alta para sí: 
Leia o seu texto em voz alta para si procure 
compreender melhor como a comunicação dele está 
sendo feita. Isso é de vital se a sua copy será falada 
(anúncio, vídeo de vendas, etc.). Procure encontrar 
onde a comunicação não está natural, ou se está 
repetitiva, cansativa ou confusa. Não tenha receio de 
trocar palavras para que a comunicação esteja mais 
alinhada com o seu perfil. Importante: Não leia apenas 
com os olhos. Faça isso de forma oral.
Troca de revisão: 
Revise um texto de um colega ou familiar e peça para 
que ele revise o seu. Procure trazer feedbacks 
construtivos e suas percepções sobre o texto e esteja 
aberto para as mesmas devolutivas dele. Dica: Faça um 
checklist dos pontos apresentados na aula e neste 
material de apoio e marque com um “X” aquilo que não 
está alinhando com o objetivo da copy. Peça para que 
seu colega faça o mesmo com sua escrita.

ocê 
ganha 
mais 
motivação 
quando 
acerta 
e 
por
onsequência, mais dinheiro. Isso de tá mais gás pra continuar 
ovimentando o processo.
+ Digamos que a cada 50 vídeos você acha um bom
+ A cada 50 vídeos você acha um bo5
+ 1 vídeo/semana = 1 Vídeo bom / an8
+ 3 vídeos/semana = 3 Vídeos bons / an8
+ 1 vídeo/ dia = 7 vídeos bons / ano
Logica padrão


Aula 06
MARKETING DE PREMISSAS
Análise de 
reels
Módulo de Análise

Apostila aula 01 
Aula 06 - Análise de reels
Módulo de Análise
O objetivo desta aula é compreender a importância 
de capturar a atenção do leitor desde o início da 
copy, despertando sua curiosidade para mantê-lo 
envolvido até o final. A estrutura básica da copy 
será explorada, composta por uma introdução 
instigante, um desenvolvimento com argumentos e 
evidências claras, e uma conclusão que amarre 
toda a narrativa de maneira satisfatória. Ao final da 
aula, o aluno estará apto a criar textos organizados 
e dinâmicos, com uma progressão fluida que 
culmina em uma chamada para ação (CTA) 
convincente.
Tópicos Principais
Curiosidade na Introdução da Copy
Estrutura de Introdução, Desenvolvimento e 
Conclusão
1
2
Objetivos da Aula

MARKETING DE PREMISSAS
Curiosidade na Introdução da Copy
Utilize a introdução para criar curiosidade e 
gerar um “porquê” na mente do leitor, 
incentivando-o a continuar lendo para 
descobrir o desfecho.
Conteúdo da Aula
Exemplo:
l Em vez de dar todas as informações logo no início, deixe 
pistas e faça perguntas que despertem a curiosidade. Por 
exemplo: "Imagine acordar um dia e perceber que uma 
simples decisão mudou tudo em sua vida... Quer saber 
como?"
Apostila aula 01 
Aula 06 - Análise de reels
Módulo de Análise
Estrutura de Introdução, 
Desenvolvimento e Conclusão
Organize a copy em três partes – introdução, 
desenvolvimento e conclusão – para manter a 
narrativa clara e envolvente.
Componentes:
; Introdução: Capte a atenção com curiosidade, um breve 
conflito ou uma questão intrigante. Apresente a tese e o 
contexto de maneira que o leitor fique curioso sobre o que 
virá a seguir
; Desenvolvimento: Explore o objetivo principal da copy, 
apresentando ideias e argumentos em parágrafos bem 
estruturados com tópicos frasais. Inclua evidências, detalhes 
e diálogos que enriquecem a narrativa, além de um clímax 
que prepare o leitor para o desfecho
; Conclusão: Amarre a história de forma que o leitor entenda o 
propósito de toda a narrativa, deixando claro por que os 
eventos ocorreram como foram apresentados. Após isso, 
insira o CTA para orientar o leitor a uma ação específica.


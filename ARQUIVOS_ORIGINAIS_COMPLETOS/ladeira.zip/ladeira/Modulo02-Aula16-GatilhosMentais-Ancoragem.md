Apostila au
Aula 16
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Gatilhos 
Mentais 

Ancoragem

Apostila aula 01 
Aula 16 - Gatilhos mentais - Ancoragem
Módulo 02 Copy Tradicional
O que é?
É um principio psicológico usado em vendas que 
influencia a percepção de valor de um produto ou 
serviço. A ancoragem ocorre quando a primeira 
informação recebida (a “âncora”) serve como 
referência para todas as avaliações subsequentes, 
e essa referência inicial sugestiona a tomada de 
decisão.
Entender como ancorar o preço ou benefícios de 
um produto (ou serviço) de maneira correta, sem 
gerar confusão no público ou produzir nele uma 
rejeição à ação da compra por superexposição a 
opções.
Tópicos Principais
Tudo é relativo
Jeito certo
Jeito errado
Exercícios
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 16 - Gatilhos mentais - Ancoragem
Módulo 02 Copy Tradicional
TUDO É RELATIVO
Riqueza Relativa
O ambiente define tudo
 Animal Humano
 O princípio da inflaçãx
 Salário alto e ter amigos que ganham mai|
 Salário médio e ter amigos que ganham menos
 O ambiente que você se encontra define quanto você gast¤
 Uma bolsa de R$ 20 mil parece barata ao lado de uma bolsa 
de R$ 150 mil
 Previsivelmente Irracional
{
{
{
Conteúdo da Aula
JEITO CERTO
Produto âncora
 Fazer um produto que faça com que outro produto seu 
pareça mais baratx
 Luis Vuitto	
 Pipoca + Refrigerant
 Pico de vendas VTS
 The Economis
 Apple com iPhon
 Restaurante
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 16 - Gatilhos mentais - Ancoragem
Módulo 02 Copy Tradicional
JEITO ERRADO
Produto Falso
Metade do dobro
Comparação injusta
Entrega desequilibrada
 Criar um produto falso ou com preço irreal para tentar 
ancorar o outr
 Não subestime a inteligência do cliente
 Aumentar o preço para parecer que ele está em promoçã
 Udem°
 De R$ 250,00 por R$ 39,90
 Menos do que uma pizza por diÄ
 Menos de um real ao diÄ
 É importante ser íntegro
 Curso presencial e online pelo mesmo preç
 Entregas semelhantes para produtos com valor diferente
{
{
{
{
Apresentar preços mais caros antes
Comparações coerentes
Atrelar a resultado
 Cátia Damascen
 Ancoragem a outros cursos
 Estudo da doação por CP
 Mentoria Fluxo { Fluxo normal: 40k; Fluxo Retiro: 20k
 Retornar o investimento com resultad
 “Quantas vendas para o curso se pagar?,
 Quanto mais tranquilo você vai dormir?
{
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 16 - Gatilhos mentais - Ancoragem
Módulo 02 Copy Tradicional
Exercicios
01
Análise de ancoragem: 
Encontre 3 situações do seu cotidiano onde algum 
produto ou serviço tem múltiplas opções de 
compra. Encontre o produto ou serviço “âncora” e o 
produto (ou serviço) que você acredita ser o mais 
comprado. Deixe as suas impressões sobre os 
porquês e seja honesto em se a ancoragem 
efetuada foi efetiva ou se gerou confusão.
02
Copy de ancoragem personalizada: 
Crie uma copy de ancoragem personalizada para 
cada um dos seguintes objetivos: Palestra, Pitch, 
Anúncio, Vídeo de vendas, live de conteúdo, 
carrossel, reles, newsletter, artigo do LinkedIn e 
Twitter. Lembre-se sempre de coletar


Apostila aula 0
Aula 22
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Nonsence

Módulo 03 LightCopy 
Aula 22 - Elementos literários - Nonsence
O que é?
O nonsense é um recurso criativo que explora o 
absurdo e o inesperado para gerar humor, 
surpresa e envolvimento. Ele rompe com a lógica 
convencional, combinando elementos sem relação 
aparente, mas que, no contexto certo, tornam-se 
intrigantes e divertidos.
Os 
alunos 
compreenderão 
o 
conceito 
de 
nonsense, sua aplicação em diferentes formas de 
expressão (como literatura, artes e humor) e como 
ele pode ser usado para estimular a criatividade e 
o pensamento fora dos padrões convencionais.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
3 O nonsense é um recurso criativo que utiliza o absurdo, o ilógico 
ou o inesperado para surpreender, divertir e engajar. Ele foge 
completamente da lógica convencional, muitas vezes misturando 
ideias, situações ou objetos de maneira aparentemente sem 
sentido, mas que, no contexto certo, se tornam cativantes e 
memoráveis.
Exemplos
Módulo 03 LightCopy 
Aula 22 - Elementos literários - Nonsence
y Igor Guimarãesv
y Tata Vernek

MARKETING DE PREMISSAS
Exercícios
01
02
03
& Identificando o nonsense: 
Leia o trecho abaixo e destaque os elementos de nonsense: 
"O relógio comeu as nuvens enquanto o gato azul dançava no teto 
de açúcar." 
Depois, explique por que esses elementos fogem da lógica 
convencional.
& Criando frases nonsense: 
Invente três frases usando elementos ilógicos ou inesperados. 
Exemplo: 
"O peixe voador pediu um café e saiu pedalando na Lua."
& História absurda: 
Escreva um pequeno parágrafo usando o nonsense como recurso 
principal. Tente misturar elementos improváveis e situações 
absurdas para criar um efeito divertido.
Módulo 03 LightCopy 
Aula 22 - Elementos literários - Nonsence


Apostila aula 0
Aula 05
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Introdução 
A elementos
Literários

Módulo 03 LightCopy 
Aula 05 - Introdução a elementos literários
O que é?
Elementos 
literários 
são 
os 
componentes 
essenciais 
de 
um 
texto, 
como 
enredo, 
personagens, cenário e tema, que estruturam e 
dão sentido à narrativa. Já as figuras de linguagem 
são recursos estilísticos usados para tornar a 
linguagem mais expressiva, criando impacto e 
emoção no leitor.
Compreender 
a 
importância 
dos 
elementos 
literários e das figuras de linguagem na construção 
de textos, reconhecendo como esses recursos 
tornam a comunicação mais envolvente e eficaz 
em diferentes contextos, como literatura, música e 
publicidade.
Tópicos Principais
1
Conceito
2
Como praticar
3
Importância
4
Os elementos que vamos estudar aqui 
5
Exercício 
Objetivos da aula

MARKETING DE PREMISSAS
Conteúdo do módulo
 Treino
 Tempo
 Sem elementos literários
 Talento
 Repertório
 Referência
 Técnica
Conceito
Como praticar
Importância
 O que sao elementos literários e figuras de linguagem? 
Elementos literários sao os componentes básicos utilizados para 
estruturar uma narrativa, poema ou qualquer forma de expressão 
escrita. Eles ajudam a construir o significado, o tom e a emoção de 
um texto.                                                         
Figuras de linguagem sao recursos estilísticos que servem para 
embelezar, destacar ou dar mais profundidade a linguagem, criando 
efeitos sonoros, visuais ou emocionais.                   
Esses elementos sao amplamente utilizados na literatura, musica, 
cinema e ate mesmo em copywriting, para prender a atenção, 
despertar emoções e reforçar mensagens. 
 Vou contar a história do dia que tive passei mal no dia da abertura 
do carrinho de um lançamento. E, Ruy e Cátia estávamos 
planejando toda a estratégia de vendas do time comercial. 
Resolvemos pedir um yakissoba. A Cátia Pediu um de frango, o Ruy 
um de carne, e eu pedi um misto. No dia seguinte, eu acordei cedo, 
fui enviar o e-mail de inscrições abertas. Nos havíamos investido 
um bom dinheiro nisso. Eu estava nervoso, tive uns calafrios, achei 
que era emoção, mas não, era uma tremenda dor de barriga.
 Livros, séries, filmeÑ
 Catalogar
 Swipe File
Módulo 03 LightCopy 
Aula 05 - Introdução a elementos literários

MARKETING DE PREMISSAS
 Com elementos literários
 Com elementos literários
 Amigo do digital tentando fazer
 Universo Cognitivo
` Calafrio, arrepio na espinha, suor frio ... Blublblurrr !! Trabalhar com 
marketing digital é emocionante, vou descrever a cena em 
detalhes, mas antes, vamos voltar algumas horas atrás.  
  
Um dia antes de abrir as inscrições para um dos lançamentos mas 
importantes da minha história, eu tomei uma das decisões mais 
errada na minha vida. Pedimos um Yakissoba. A Cátia pediu um de 
frango, Ruy um de carne, eu pedi um misto. Que vinha camarão, 
frango, carne e no meu caso, tinha um tempero especial com asas 
de barata ...
` PPT
` Não deu certo 
` Como CRIAR e VENDER o seu infoproduto...
`  Notes Icloud
` Notes Icloud
` 2.DIA1_LADEIRA_CRIATIVIDADE
Os elementos que vamos estudar aqui
Módulo 03 LightCopy 
Aula 05 - Introdução a elementos literários

MARKETING DE PREMISSAS
Exercícios
01
02
03
U Identifique os elementos literários  
Quem são os personagens, o cenário e o tema deste trecho? 
"João encontrou um mapa antigo e decidiu seguir suas pistas."
j Associe as figuras de linguagem: 
a) "O tempo é um rio que nunca para de correr." 
b) "O relógio gritou de manhã." 
c) "Ela correu mais rápido que um raio."
j Criação rápida: 
Escreva uma frase usando metáfora e outra usando comparação.
Módulo 03 LightCopy 
Aula 05 - Introdução a elementos literários


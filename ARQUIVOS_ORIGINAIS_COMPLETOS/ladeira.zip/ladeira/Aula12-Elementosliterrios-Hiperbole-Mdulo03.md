Apostila aula 0
Aula 12
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Hiperbole

Módulo 03 LightCopy 
Aula 12- Elementos literários - Hiperbole
O que é?
A hipérbole é uma figura de linguagem que utiliza 
exageros intencionais para enfatizar uma ideia, 
criar humor ou provocar impacto emocional. Ela 
não deve ser interpretada literalmente, mas sim 
como um recurso expressivo da linguagem.
Compreender o conceito de hipérbole, reconhecer 
seu uso em diferentes contextos e aprender a 
aplicá-la corretamente na comunicação oral e 
escrita.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
Exemplos
/ A hipérbole é uma figura de linguagem que consiste no uso de 
exageros intencionais para dar ênfase, provocar humor ou criar 
impacto emocional. Ela não deve ser entendida literalmente, mas 
sim como um recurso estilístico para intensificar uma ideia ou 
sentimento.
/ Volkswagen - "Resistente como um tanque de guerra."
/ Forrest Gump:  
"Eu corri tanto que acho que cruzei os Estados Unidos umas 
quinze vezes.¯
/ Jerry Seinfeld:   
"As pessoas têm tanto medo de falar em publico que preferem 
estar no caixão do que fazer o elogio no funeral.¯
/ Whindersson Nunes:  
"Minha cidade é tão pequena que, se você sair para correr, já está 
na cidade vizinha."¢
/ Robin Williams - Sociedade dos Poetas Mortos (1989): 
"Vocês estão aqui para saborear cada momento da vida. Porque 
um dia, rapazes, vocês também serão alimento para os vermes."¢
/ Jim Carrey - O Máskara (1994):  
"Eu nao sou um homem comum! Eu sou um deus!"
/ Spot Fiat 500X Viagra - Anuncio de televisión
/ Me conta o que você faria para escalar as vendas de uma pizzaria.
/ Na época da segunda guerra mundial os soldados precisavam...
/ Sua camiseta encolhe e desbota nas primeiras lavagens?
/ Já que fim de ano é época de Retrospectivas, eu separei...
/ Então é natal 
 nossa família já está preparada para 
comemorar...
Módulo 03 LightCopy 
Aula 12- Elementos literários - Hiperbole

MARKETING DE PREMISSAS
 O que você achou da campanha? 
Foco na emoção e na necessidade e não no produto!
 Stuck the landing @drinkprime
 Pai deixa tudo mais prático e a @wap deixa tudo mais fácil!

 siga @alexpaciullo para mais vídeos tropa
 Marque a sua “pq você não atendeu?” #diadasmaes
 Soup 
 #saltbae #saltlife #salt
 Prime’s Big Game Commercial 
 Mais um dia comum na vida de um Ladeira.
 A BIBLIOTECA (desliza pra ler)
 Cara, que vida boa 
Módulo 03 LightCopy 
Aula 12- Elementos literários - Hiperbole

MARKETING DE PREMISSAS
Exercícios
01
02
03
T Identificação de Hipérboles 
Leia as frases abaixo e identifique quais delas contêm hipérbole. 
Justifique sua resposta.  
a) "Estou morrendo de fome!" 
b) "O dia está ensolarado." 
c) "Já te chamei um milhão de vezes!" 
d) "Esse livro é muito interessante."
g Criação de Frases: 
Escreva três frases usando a hipérbole para exagerar alguma 
situação do dia a dia.
g Interpretação e Reescrita: 
Leia a frase: "Chorei um rio de lágrimas assistindo ao filme."  
a) Explique o que essa frase quer expressar. 
b) Reescreva a frase sem o uso da hipérbole, mas mantendo o 
mesmo sentido.
Módulo 03 LightCopy 
Aula 12- Elementos literários - Hiperbole


Apostila aula 0
Aula 13
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Jogo de 
palavras e
Trocadilhos

Módulo 03 LightCopy 
Aula 13- Elementos literários - Jogo de Palavras
O que é?
O jogo de palavras e os trocadilhos são recursos 
da linguagem que utilizam criatividade para 
explorar duplos sentidos, sons semelhantes e 
ambiguidades. Eles podem ser usados para gerar 
humor, reflexões ou efeitos estilísticos, tornando a 
comunicação mais envolvente e marcante.
Os alunos aprenderão a identificar e criar jogos de 
palavras e trocadilhos, compreendendo como 
esses elementos linguísticos funcionam e como 
podem ser aplicados para tornar a linguagem mais 
expressiva e divertida.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
Exemplos
} O jogo de palavras e os trocadilhos são elementos literários que 
utilizam a criatividade na linguagem para explorar duplos sentidos, 
homônimos, homófonos e ambiguidades. Eles criam efeitos 
cômicos, reflexivos ou estilísticos, tornando a comunicação mais 
leve, inteligente e memorávelh
} Jogo de Palavras 
É o uso criativo de termos e expressões que brincam com 
significados ou sons semelhantes, mas que têm sentidos diferentes. 
Um jogo de palavras pode ser sutil ou direto e pode até incluir rimas 
e associações inesperadasH
} Trocadilho 
É uma forma específica de jogo de palavras, caracterizada por 
brincar com a semelhanca fonetica ou grafica entre palavras ou 
expressões, criando uma mudança de significado inesperada ou 
engraçada.
} Duplo sentido:   
Explora palavras ou expressões que possuem mais de um 
significado.  
Exemplo: "O pastel estava tão seco que teve sede de justiça."
} Semelhança sonora:  
Usa palavras que soam parecidas, mas têm significados diferentes 
(homônimos ou homófonos).  
Exemplo: "Bolo e feito com fermento, e não com ressentimento."
} "Viva cada dia como se fosse o 
último. Um dia você acerta."
} Have a break, have a KitKat.
} Millôr Fernandes
Módulo 03 LightCopy 
Aula 13- Elementos literários - Jogo de Palavras
} Usando o duplo sentido você melhora a melodia.
} Fiz com qualidade! A inveja de alguns só...
} Grato pela confiança. Cursos vitalícios e acessíveis, links na bio!

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 13- Elementos literários - Jogo de Palavras
? Só agradecer por isso! Fico feliz em poder ajudar...
? Parto natural sem anestesia
? Quem não nasceu herdeiro não tem jeito parcela mesmo 
? Um relógio nao e so para marcar as horas.  
É para marcar sua presença.  
Porque quem usa um relógio desses não só conta o tempo, faz o 
tempo contar.
? Relógios comuns mostram o tempo. 
Relógios extraordinarios mostram quem você é. 
Com este no pulso, você não está só no horário, está à frente dele}
? Rolex
Exercícios
01
02
03
Ê Identificando trocadilhos: 
Leia as frases abaixo e identifique os trocadilhos e jogos de 
palavras. Depois, explique o duplo sentido presente em cada uma 
delas: 
a) "O peixe foi para a escola para aprender a nadar melhor." 
b) "O café foi tão forte que acordou até a vizinhança."
Ê Criando um trocadilho: 
Crie um trocadilho utilizando palavras que tenham sons parecidos, 
mas significados diferentes. Exemplo: "O relógio não anda, mas 
sempre está no horário."
Ê Complete a frase com um jogo de palavras: 
Complete as frases abaixo utilizando um trocadilho ou um jogo de 
palavras: 
a) "O tomate foi ao banco porque..." 
b) "O lápis ficou triste porque..." 
c) "A lâmpada se acendeu porque..."


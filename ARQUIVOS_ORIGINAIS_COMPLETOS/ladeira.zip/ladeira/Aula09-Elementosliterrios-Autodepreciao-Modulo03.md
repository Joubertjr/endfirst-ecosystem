Apostila aula 0
Aula 09
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Autodepreciação

Módulo 03 LightCopy 
Aula 09- Elementos literários - Autodepreciação
O que é?
Autodepreciação é um tipo de humor no qual a 
pessoa faz piadas sobre si mesma. Esse recurso 
pode ajudar a criar empatia, tornar alguém mais 
acessível e até prevenir críticas, pois a própria 
pessoa reconhece e brinca com seus defeitos 
antes dos outros.
Compreender como a autodepreciação funciona 
no humor, seus impactos na comunicação e 
quando pode ser usada de forma saudável ou 
prejudicial.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
( Autodepreciação é um recurso muitas vezes usado no humor em 
que a pessoa faz piadas sobre si mesma. É uma forma de criar 
empatia, parecer mais acessível e desarmar críticas, já que a 
pessoa se antecipa às possíveis observações negativas.
( Leonardo
( Leandro
( Érico
\ Ele pensa numa velocidade 
mais rápida do que aparenta.
\ Não sou o mais criativo, não sou o mais bonito, não 
sou o mais organizado, mas sou o mais comprometido 
a dar resultados
\ Ele não sabe soletrar Stambull
\ Erro "Top off mind"
\ Palestra FIRE
Exemplos
\ LEONARDO REBATE e DÁ LIÇÃO de HUMILDADE em 
ZEZÉ di CAMARGO
( Coloque mais fogo na sua vida 
( O dia que deu tudo errado
( Minha rixa com um grande do digital
\ Swipe File
\ Tio DÚ
\ Te conheço? 
Módulo 03 LightCopy 
Aula 09- Elementos literários - Autodepreciação

MARKETING DE PREMISSAS
Exercícios
01
02
03
J Explique com suas palavras:  
O que é a autodepreciação e por que as pessoas a utilizam no 
humor? Dê um exemplo de uma piada autodepreciativa.
x Interpretação de caso: 
João sempre faz piadas sobre sua falta de jeito nos esportes. Seus 
amigos riem, mas às vezes ele parece desconfortável. Na sua 
opinião, a autodepreciação de João é positiva ou pode ser 
prejudicial? Justifique sua resposta.
x Criação de frases: 
Escreva duas frases autodepreciativas que poderiam ser usadas de 
forma leve e saudável. Depois, crie uma frase que mostre como esse 
tipo de humor pode se tornar negativo.
Módulo 03 LightCopy 
Aula 09- Elementos literários - Autodepreciação


Apostila au
Aula 03
Módulo 01 Criatividade
MARKETING DE PREMISSAS
Processo 
Criativo

Apostila aula 01 
Aula 03 - Processo Criativo
Módulo 01 Criatividade
O que é?
O processo criativo é uma série de etapas que 
uma pessoa segue para gerar ideias novas e 
originais, resolver problemas ou criar algo 
inovador. Embora possa variar de pessoa para 
pessoa, o processo criativo é estruturado em 
cima de 8 etapas:  
1. Objetivo
2. Inspiração
3. Reunião de criação
4. Iluminação
5. Incubação
6. Transpiração
7. Verificação
8. Reflexão
Objetivos da Aula
Mostrar que o processo de criação estruturado, 
te faz criar ideias originais e melhores se 
comparada a criação de maneira randômica.
Tópicos Principais
O que é?
8 Etapas do Processo Criativo
Exercícios
1
2
3
MARKETING DE PREMISSAS

Apostila aula 01 
Aula 03 - Processo Criativo
Módulo 01 Criatividade
Conteúdo da Aula
8 Etapas do Processo Criativo
Um processo estruturado vai te levar a ideias 
originais e constantes
Objetivo
01
02
Qual o propósito inicial?
{
{
{
{
Repertório
Tubarão 
Zumbi 
Tecnologia
Referência
Copywriting
Contar história
Stand up comedy
Imitação
Crônicas
Publicidade tradicional
Viagem
Natureza
Surf
Arquitetura
Design
Futurismo
Mercado financeiro

Filmes

Documentários Explicando
Séries
Improviso

  
Copy  
Nicho
{
Inspiração
Pesquisa

Apostila aula 01 
Aula 03 - Processo Criativo
Módulo 01 Criatividade
MARKETING DE PREMISSAS
{
Não faça sozinho
Escreva Bêbado
Linha do bom senso
Reunião de Criação
Iluminação
Incubação
Transpiração
Verificação
Reflexão
Eureka de Arquimedes
{
{
Dominar elementos literários
Ganhar intimidade
Estrutura de texto
Edite Sobreo
{
Associação criativa
03
04
05
06
07
08

Apostila aula 01 
Aula 03 - Processo Criativo
Módulo 01 Criatividade
Nada melhor, do que implementar o processo na 
prática! E para isso acontecer identifique uma área da 
sua vida ou trabalho onde veja a necessidade de 
desenvolver criativamente uma solução. A partir dai 
responda as seguintes perguntas abaixo:
1 - Qual o Objetivo?  
2 - Procure por referências relacionadas ao 
objetivo: 
Pesquise técnicas, aplicativos, e dicas de pessoas 
que já falam a respeito do assunto.  
3 - Compartilhe o objetivo com pessoa próximas: 
Pode ser familiares, amigos ou até mesmo um 
enquete onde as pessoas possam dar opiniões a 
respeito do que foi dito, o importante é ver opiniões 
diferentes  
4 - Anote todas as informações e ideias: 
É importante nessa fase não criticar ou validar elas.  
5 - Qual a melhor ideia? 
Agora é a hora de escolher a que melhor se 
apresenta, e meditar nela enquanto faz outras tarefas 
(Academia, trabalho, lavando carro etc).  
6 - Hora da Aplicação: 
Aplique a solução escolhida, e ao finalizar perceba 
quais foram os resultados e pense em maneiras de 
amplia-los (Como eu consigo ter um resultado melhor 
nesse aspecto?)
Vamos Praticar?


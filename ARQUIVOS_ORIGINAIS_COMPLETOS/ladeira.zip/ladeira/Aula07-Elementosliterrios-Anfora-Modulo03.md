Apostila aula 0
Aula 07
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Anáfora

Módulo 03 LightCopy 
Aula 07 - Elementos literários - Anáfora
O que é?
A anáfora é uma figura de linguagem caracterizada 
pela repetição de uma ou mais palavras no início 
de versos, frases ou períodos consecutivos. Essa 
repetição reforça a mensagem, cria ritmo e gera 
impacto emocional no discurso.
Os alunos aprenderão a identificar e utilizar a 
anáfora em textos e discursos, compreendendo 
seu efeito estilístico e sua importância para a 
expressividade da linguagem.
Tópicos Principais
1
Conceito
1
Exercícios 
1
Exercícios 
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
? A anáfora é uma figura de linguagem que consiste na repetição de 
uma ou mais palavras no início de versos, frases ou períodos 
consecutivos. Essa repetição é usada para criar ênfase, ritmo e 
impacto emocional, reforçando a mensagem e tornando-a mais 
marcante para o leitor ou ouvinte. 
Módulo 03 LightCopy 
Aula 07 - Elementos literários - Anáfora
? Leandro
? Debate político
? Martin Luther King Jr. - "I Have a Dream"
? "I have a dream that one day every valley shall be exalted... 
I have a dream that one day every hill and mountain shall be 
made low...
? Manuel Bandeira - "Vou-me embora pra  Pasárgada"
? "Lá sou amigo do rei, 
Lá tenho a mulher que eu quero, 
Lá sou feliz."
? "It’s about how hard you can get hit and keep moving  forward, 
How much you can take and keep moving forward."
? Acredite em você, acredite no processo, acredite no futuro."
? Campanha da TV Globo – "Agro é tech, Agro é pop, Agro é tudo" 
(2016):
+ Mabnifesto
+ Carta aberta
+ Desejo que te sobre muito
+ KIM KATAGUIRI HUMILHA...
Exemplos

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 07 - Elementos literários - Anáfora
: Exemplos copy
m Você merece se olhar no espelho e se sentir confiante. 
Você merece transformar cada pincelada em uma obra de arte. 
Você merece aprender que a maquiagem não é só beleza, é 
expressão. 
Você merece dominar técnicas que antes pareciam impossíveis. 
Você merece ouvir "Como você fez isso?" e responder com um 
sorriso.d
m Aqui, você não vai aprender só a maquiar. 
Aqui, você vai aprender a destacar o que já é lindo. 
Aqui, você vai descobrir que um simples delineado pode mudar 
seu dia. 
Aqui, você vai perceber que cada cor carrega um poder. 
Aqui, você vai entender que a maquiagem é uma extensão de 
quem você é.d
m Motores não são apenas máquinas que giram. 
São o coração pulsante de indústrias inteiras.d
m Fios não são apenas cabos emaranhados. 
São as veias que transportam energia para o mundo funcionar.d
m E a elétrica? Não é apenas ciência. 
É a arte de transformar movimento em força, ideias 
em inovação, sonhos em realidade.d
m Ganhar dinheiro online não é só sobre postar fotos ou vender 
coisas. 
É sobre entender como o dinheiro se move na internet. 
d
m Links não são apenas atalhos. 
Eles são pontes que conectam você ao próximo pagamento.d
m Likes não são apenas números. 
São sinais de que a sua mensagem está chegando às pessoas 
certas. 
d
m E vendas? Não são apenas negociações. 
São resultados de estratégias que funcionam enquanto você 
dorme.

MARKETING DE PREMISSAS
Exercícios
01
02
03
X Identificação da anáfora:  
Leia a frase abaixo e sublinhe a palavra ou expressão repetida: 
"Eu quero paz. Eu quero justiça. Eu quero um mundo melhor."
 Criação de frases: 
Escreva três frases curtas utilizando a anáfora para dar ênfase a 
uma ideia. Exemplo: 
"Estude para crescer. Estude para aprender. Estude para vencer."
 Anáfora na literatura e na música: 
Pesquise um trecho de um poema ou música que utilize a anáfora e 
compartilhe com a turma. Explique como a repetição das palavras 
influencia o significado do texto.
Módulo 03 LightCopy 
Aula 07 - Elementos literários - Anáfora


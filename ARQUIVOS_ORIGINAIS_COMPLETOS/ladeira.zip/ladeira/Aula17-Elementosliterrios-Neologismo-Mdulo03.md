Apostila aula 0
Aula 17
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Neologismo

Módulo 03 LightCopy 
Aula 17- Elementos literários - Neologismo
O que é?
Neologismo é o processo de criação de novas 
palavras ou expressões em uma língua, seja para 
nomear algo novo ou atribuir um novo significado a 
termos já existentes. Esse fenômeno demonstra a 
flexibilidade e criatividade da comunicação, sendo 
muito 
comum 
em 
áreas 
como 
literatura, 
tecnologia, publicidade e cultura popular.
Compreender o conceito de neologismo, sua 
importância na evolução da linguagem e como ele 
influencia a comunicação e a identidade de grupos 
sociais.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
B O neologismo é um recurso linguístico que consiste na criação de 
novas palavras ou expressões, seja para nomear algo inexistente 
no idioma ou para dar um significado novo a palavras já existentes. 
Ele reflete criatividade e adaptabilidade na comunicação, sendo 
amplamente utilizado em literatura, publicidade, tecnologia e 
cultura popular#
B MemorabilidadD
B Senso de comunidade, tribo, pertencimento
B PATRAI tá aí fazendo sucesso. Mas, da pra aprender algo com ela.
Exemplos
Módulo 03 LightCopy 
Aula 17- Elementos literários - Neologismo
B O luar, estrela do mar 
O sol e o dom 
Quiçá, um dia, a fúria desse front 
Virá lapidar o sonho 
Até gerar o som 
Como querer Caetanear 
O que há de bom
B Manoel de Barros: 
"Desimportância": um termo que dá um novo significado à ideia de 
algo sem relevância.
B Shablaù
B Ladeirístic÷
B Bolsonaristñ
B MéquizicD
B Perpetuaî
B Formuleiroä
B Fazedoreä
B Brasilidade
B PATRAI tá aí fazendo 
sucesso. Mas, da pra 
aprender algo com 
ela.

MARKETING DE PREMISSAS
 Criador para a aula
7 Manifesto Nutrivista: Mães que Lutam pela Nutrição" 
Eu sou uma Nutrivista. 
Uma ativista da nutrição infantil. 
Não luto só por refeições saudáveis - luto por hábitos que moldam o 
futuroA
7 Eu digo "nao" as frituras que mascaram o sabor verdadeiro. 
Digo "não" aos doces que prometem felicidade, mas entregam 
desequilíbrio. 
Digo "não" aos pacotinhos cheios de químicos que enganam os olhos e o 
paladar das nossas criançasA
7 Mas ser Nutrivista é mais do que dizer "não". 
É dizer "sim" ao alimento que nutre de verdade. 
"Sim" à descoberta de sabores naturais que encantam e educam. 
"Sim" a um futuro em que as crianças crescem fortes, conscientes e com 
umarelaçao saudavel com a comidaA
7 Ser Nutrivista é carregar a bandeira do cuidado, da saúde e da 
transformação. 
É ensinar, inspirar e nao desistir, mesmo quando parece mais fácil ceder 
ao que é rápido e artificialA
7 Se você acredita que comida é amor, que alimentação é educação e que 
o prato do seu filho merece mais do que só encher a barriga ... 
Então, você também é uma Nutrivista: uma mãe ativista da nutriçãoA
7 Junte-se a nos. Juntas, nutrimos um futuro melhorA
7 Preciciência: a arte de unir pressa para agir e paciencia para colher
Módulo 03 LightCopy 
Aula 17- Elementos literários - Neologismo

MARKETING DE PREMISSAS
Exercícios
01
02
03
5 Identificando Neologismos: 
Liste cinco palavras que você acredita serem neologismos e 
explique o motivo da sua escolha. Se possível, pesquise suas 
origens. 
5 Criação de Neologismos: 
Imagine que você precisa inventar uma palavra para um novo 
aplicativo de celular. Qual seria essa palavra? Explique seu 
significado e como ela poderia se popularizar.
5 Neologismos na Cultura Popular: 
Escolha um neologismo amplamente utilizado na internet ou na 
mídia e escreva um pequeno texto explicando como ele surgiu e por 
que se tornou popular.
Módulo 03 LightCopy 
Aula 16- Elementos literários - Lista


Apostila aula 0
Aula 11
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Easter Egg

Módulo 03 LightCopy 
Aula 11- Elementos literários - Easter Egg
O que é?
Um Easter Egg é um elemento secreto inserido em 
filmes, jogos, livros, sites e outros conteúdos, com 
o objetivo de surpreender e engajar quem percebe 
os 
detalhes. 
Esses 
segredos 
podem 
ser 
referências, 
mensagens 
ocultas 
ou 
piadas 
internas, servindo como uma recompensa para os 
mais atentos.
Com esta aula, os alunos compreenderão o 
conceito de Easter Egg, sua origem e como ele é 
utilizado em diferentes mídias para aumentar a 
interação e o envolvimento do público.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
Exemplos
C Um Easter Egg (ovo de Páscoa, em tradução literal) é um 
elemento oculto inserido em filmes, jogos, livros, sites ou outros 
conteúdos, destinado a ser descoberto por quem presta atenção 
aos detalhes. É uma espécie de "surpresa" ou "segredo" que 
recompensa a curiosidade e engaja o público.
C O famoso comercial da Apple, que introduziu 
o Macintosh, está repleto de referências à 
obra 1984, de George Orwell, como o uso de 
figuras autoritárias que representam a IBM.
C Caju e castanha
C Super Trunfo
C VTCN
 A oferta acaba hoje, amanhã já não tem mais.
 Para com a loucura de dizer que não me quer
 Os super poderes de quem ficou grande no digital
 Vou lançar um curso novo. Quem quer entrar na lista de 
espera?
 Uma verdadeira aula de anúncios num carrossel.
 O Marketing Digital comendo miojo
 Mentoria para infoprodutores
 Se você não tá no digital, você está parado no tempo.
 1984 Apple's 
Macintosh 
Commercial
Módulo 03 LightCopy 
Aula 11- Elementos literários - Easter Egg

MARKETING DE PREMISSAS
 Venda de biquíni 
Módulo 03 LightCopy 
Aula 11- Elementos literários - Easter Egg
e O sol brilha com a intensidade de uma tarde em Itapuã, e o mar 
parece sussurrar segredos que nem mesmo iemanjá contou.M
e Este biquíni não é só um biquíni. É um convite para viver histórias 
que poderiam estar nas páginas de Capitães da Areia.  
Ou quem sabe ser o próximo capítulo de uma "garota de Ipanema" 
reescrita por você.M
e As cores? Inspiradas nas palmeiras que Gonçalves Dias descreveu. 
Os detalhes? Têm um toque de arte, como as curvas de Niemeyer.  
E a liberdade que ele traz? Parece ter saído direto de um samba 
do Cartola.M
e Mas cuidado: este biquíni é para quem carrega no peito a alma 
leve de quem dança no carnaval, para quem entende que não é só 
moda - é expressão, é cultura, é Brasils
e Se você pegou as referências, sabe que ele foi feito para você.  
Se não, talvez seja hora de viver mais a nossa histórias
e Vista o biquíni que não só te veste, mas te conecta com tudo o 
que é marcante no nosso Brasil.
 Tendências de marketing digital para 2065

MARKETING DE PREMISSAS
Exercícios
01
02
03
. Identificando Easter Eggs: 
Pesquise e traga um exemplo de Easter Egg encontrado em um 
filme, jogo ou livro. Explique o que ele representa e como foi 
escondido.
h Criando um Easter Egg: 
Imagine que você é um desenvolvedor de jogos ou um escritor. Crie 
um pequeno Easter Egg para uma história ou jogo e descreva como 
ele seria descoberto.
h Curiosidade e Detalhes: 
Por que você acha que os criadores incluem Easter Eggs em seus 
conteúdos? Escreva um breve parágrafo explicando sua opinião e o 
impacto disso na experiência do público.
Módulo 03 LightCopy 
Aula 11- Elementos literários - Easter Egg


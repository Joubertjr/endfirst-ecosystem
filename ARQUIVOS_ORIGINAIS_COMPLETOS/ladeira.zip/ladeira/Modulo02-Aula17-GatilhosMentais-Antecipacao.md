Apostila au
Aula 17
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Gatilhos 
Mentais 

Antecipação

Apostila aula 01 
Aula 17 - Gatilhos mentais - Antecipação
Módulo 02 Copy Tradicional
O que é?
É uma técnica psicológica que desperta o desejo e 
a expectativa ao se trabalhar a curiosidade de 
algum objeto de valor, como um produto ou 
serviço que ficará disponível. Isso 
consequentemente aumenta o interesse e a 
percepção de valor do item.
Aprender a criar expectativa no seu público de 
maneira que ele se sinta curioso e ansioso pela 
informação que está sendo antecipada. Isso deve 
ocorrer de maneira sutil e objetiva, sem que gere 
no leitor (ou ouvinte) a sensação de estar sendo 
enganado ou enrolado.
Tópicos Principais
Conceitos
Jeito certo
Jeito errado
Exercícios
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 17 - Gatilhos mentais - Antecipação
Módulo 02 Copy Tradicional
CONCEITOS
Streaptease
Viagem
Expectativa
j O segredo do streaptease é esconder, não mostrar
j Planejar é melhor do que fazer a viagem
j A antecipação de algo acontecer geralmente é mais forte do 
que realmente viver a ocasiã
j Criar ansiedade é a melhor estratégia de marketing
{
{
{
Conteúdo da Aula
JEITO CERTO
Vídeo Teaser
Loop da curiosidade
j Exemplo 0Ø
j Exemplo 0é
j Exemplo 03
j Valorizar a informação antes de conta
j Curiosidades específicas
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 17 - Gatilhos mentais - Antecipação
Módulo 02 Copy Tradicional
n Um barulho ou burburinho que deixa as pessoas curiosas ou 
ansiosas pela oportunidadg
n Surpres`
n Boca ros`
n Briga do Ladeira e Éricb
n Vazamento do novo iPhone
n Faltam X dias
n O ansioso
n Revelar uma informação que você “não consegue segurar
n Antecipação pela dica
n Lives de antecipaçãb
n Vídeos de antecipação
Buzz
Contagem regressiva
Lista de espera
Spoilers
Volume de avisos
{
{
{
{
{
JEITO ERRADO
Enrolação x Sutileza
Valor
n Demorar demais ou ficar se fazendo de difíci
n Não pode ficar na cara que você está enrolando
n Muita expectativa e pouca percepção de valor
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 17 - Gatilhos mentais - Antecipação
Módulo 02 Copy Tradicional
Exercicios
01
Lista de curiosidade específica: 
Lista curiosidades específicas do seu produto. 
Coisas que as pessoas podem ter dúvidas, achar 
interessante, ter curiosidade ou acreditar que pode 
resolver um problema. Procure aplicar essa lista na 
sua copy de página de vendas, email ou outras 
plataformas.
02
Aplicações: 
Procure formas de aplicar antecipação no seu pitch 
de vendas, em uma palestra e em um vídeo de 
Reels. Apresente para um colega e um amigo e 
tente observar se a sua antecipação gerou 
ansiedade ou curiosidade no leitor (ou ouvinte). 
Colete as impressões do seu público


Apostila
Aula 12
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
Newsletter

Módulo 04 Formatos de Copy
Aula 12 - Newsletter
Apresentar o conceito e a estrutura de uma 
newsletter eficaz, destacando seu valor como 
publicação regular com narrativa envolvente, estilo 
próprio e propósito claro, capaz de criar conexão 
com o leitor, transmitir conteúdo relevante e 
fortalecer a comunicação de forma natural e 
contínua.
Tópicos Principais
1
O que é
3
Porque funciona
4
Estrutura
5
Personalidade
2
Como funciona
Objetivos do aula

Conteúdo do módulo
 Não é só um e-mail marketing com promoções.
 É uma publicação regular com:
 Estilo próprio
 Narrativa contínu"
  Valor intelectual ou emocional
 Funciona como uma coluna de jornal digital:
 Cria expectativa
 Gera leitores fiéis
 Constrói autoridade e branding
 Newsletter boa não parece copy, mas carrega princípios de 
copywriting:
 Histórias (storytelling)
 Tensão e alívio
 Gatilhos mentais (autoridade, afinidade, reciprocidadeP
 Padrão de recompensa variávei
 Quem lê você toda semana compra com menos objeção
 Vende sem parecer vendedor
O que é
Como funciona
Porque funciona
MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 12 - Newsletter

MARKETING DE PREMISSAS
Estrutura
! 1. Assunto com Promessa ou Curiosidade
! 2. Abertura envolvente
! 3. Corpo
! 4. Fechamento com Recompensa e Reflexão
! 5. Call to Action (opcional)
t “A única habilidade que me deu R$100 mil por e-mail”k
t “Por que deletei meu Instagram com 300 mil seguidores”
t Um parágrafo de tensão (uma história, pergunta ou 
declaração polêmica)k
t Algo que quebre o padrão
t Reflexão pessoal ou casek
t Teoria com opiniãok
t Estilo colunista: argumentos, metáforas, ironia
t “Moral da história”k
t Conclusão inesperadak
t CTA suave (ou nenhum CTA)
t Encaminhe para alguémk
t Responda este e-mailk
t Veja esse produto/texto/aula
Módulo 04 Formatos de Copy
Aula 12 - Newsletter

MARKETING DE PREMISSAS
Personalidade
! Escolha um “personagem narrador
! Crie Bordões ou Estrutura Repetitiva
! Crie assinatura de linguagem
N Professor>
N  Irônico?J
N Revoltado?J
N Jornalista investigativo?
N “3 ideias de X”J
N “Aprendi isso na marra”J
N “Spoiler: você não vai gostar disso”
N  Repetições que viram identidadeJ
N Palavras que só você usaJ
N Emoção e opinião
Módulo 04 Formatos de Copy
Aula 12 - Newsletter


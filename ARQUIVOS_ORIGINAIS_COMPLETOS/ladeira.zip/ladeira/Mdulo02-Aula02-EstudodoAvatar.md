Apostila au
Aula 02
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Estudo do avatar

Apostila aula 01 
Aula 02 - Estudo do avatar
Módulo 02 Copy Tradicional
O que é?
Uma Persona ou Avatar é uma representação 
semi-fictícia do cliente ideal de uma empresa ou 
projeto, criada a partir de dados reais sobre 
demografia, 
comportamento, 
motivações 
e 
objetivos 
dos 
consumidores. 
Essas 
representações ajudam as empresas a entender 
melhor as necessidades, desafios e hábitos de 
seus clientes, permitindo uma comunicação mais 
eficaz 
e 
estratégias 
de 
marketing 
mais 
direcionadas.
Objetivos da Aula
Entender sua voz e valores, e saber identificar sua 
tribo, é essencial para encontrar pessoas que se 
conectam com você e sua visão de mundo. Isso 
ajuda 
a 
saber 
com 
quem 
você 
está 
se 
comunicando e a criar um avatar, usando 
ferramentas práticas para se comunicar de forma 
mais eficaz com seu público.
Tópicos Principais
O que é o Estudo do Avatar
Avatar
Estruturação da Persona
Mapa de empatia  
Comunicação  
Exercícios
1
2
3
4
5
6

Conteúdo da Aula
O que é a Persona
MARKETING DE PREMISSAS
Persona é uma representação 
fictícia de um cliente ideal

Quem fala com todo mundo, 
não fala com ninguém
Preencha os dados demográficos
{{
{
A comunicação errada pode gerar ruídos
Insira as informações básicas como nome, idade, gênero, 
localização, ocupação e renda mensal.
Adicione uma foto
Se possível, adicione uma foto representativa da persona 
para humanizar o perfil.
Descreva os interesses e hobbies
Anote os interesses pessoais e hobbies da persona.
Avatar{
Avatar
Demográfico
Apostila aula 01 
Aula 02 - Estudo do avatar
Módulo 02 Copy Tradicional
Estruturação da Persona
Dados demográficos são informações usadas 
para identificar características básicas de grupos 
de pessoas, como idade, gênero, localização e 
ocupação.

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 02 - Estudo do avatar
Módulo 02 Copy Tradicional
Defina os valores e estilo de vida
Citações e reclamações comuns
{
Identifique os valores importantes e descreva o estilo de 
vida da persona.
Inclua frases típicas que a persona poderia dizer.
Comportamento de compra 
Marcas e produtos preferidos
Detalhe os hábitos de compra e os canais de 
comunicação preferidos.
Liste as marcas e produtos que a persona gosta ou utiliza.
Desafios e objetivos 
História
Identifique os principais desafios e objetivos da persona.
Crie uma breve narrativa que conte a história da persona, 
seus desafios e como o seu produto ou serviço pode 
ajudar.
Demográfico

MARKETING DE PREMISSAS
Mapa de empatia
Um mapa de empatia é uma ferramenta que ajuda 
a entender como uma pessoa vê o mundo, o que 
ela pensa, sente, ouve, e faz. Ele também ajuda a 
identificar seus problemas e desejos, facilitando a 
criação 
de 
produtos 
ou 
mensagens 
que 
realmente atendam suas necessidades.
Apostila aula 01 
Aula 02 - Estudo do avatar
Módulo 02 Copy Tradicional
O que vê?
{
Anotar o que a persona observa em seu ambiente, como 
tendências, influências e o comportamento das pessoas ao 
seu redor.
O que ouve?
Listar as principais fontes de informação e influências 
auditivas, como feedback, conselhos e comentários de 
amigos, família, colegas e mídia.
O que pensa e sente?
Descrever os pensamentos e sentimentos internos da 
persona, incluindo suas preocupações, aspirações e o que 
realmente importa para ela.
O que fala e faz?
 Identificar as ações e comportamentos da persona, além 
das frases típicas que ela pode dizer em relação a seus 
objetivos e desafios.

MARKETING DE PREMISSAS
Comunicação
{
Com quem eu falo?    
Com quem eu não falo?
Apostila aula 01 
Aula 02 - Estudo do avatar
Módulo 02 Copy Tradicional
Dores
Listar as frustrações, medos, obstáculos e pontos de dor 
que a persona enfrenta.
Ganhos
Destacar os desejos, necessidades satisfeitas, benefícios e 
resultados positivos que a persona busca alcançar.
Vamos Praticar?
01
Defina seus múltiplos avatares
02
Preencher a planilha de cada uma deles
Baixar Guia Persona e Mapa Empatia


Apostila au
Aula 09
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
A teoria do 
inimigo em 
comum

Apostila aula 01 
Aula 09 - A teoria do inimigo em comum
Módulo 02 Copy Tradicional
O que é?
A Teoria do Inimigo em Comum é a ideia de que, 
quando um grupo de pessoas tem um inimigo ou 
adversário em comum, elas se unem mais 
facilmente para agir juntas. Isso é muito usado na 
política, no marketing e em relações sociais.
Objetivos da Aula
O objetivo dessa aula é explicar como a Teoria do 
Inimigo em Comum pode ser usada para unir 
pessoas ou grupos ao criar um adversário 
compartilhado. A ideia é mostrar como essa 
estratégia é eficaz para gerar engajamento e ação 
coletiva, seja em campanhas de marketing, política 
ou até em questões culturais, aproveitando o 
poder que a oposição a um inimigo tem para 
motivar as pessoas.
Tópicos Principais
O que é a Teoria do Inimigo em Comum?
Teoria
Concorrentes
Inimigos Ocultos  
Cultura X Contra cultura  
Perigos
Exercícios  
1
2
3
4
5
6
7

Conteúdo da Aula
Teoria
Concorrentes
MARKETING DE PREMISSAS
Inimigo em Comum
7 Nunca irei a uma manifestação contra a guerra, se fizerem 
uma pela paz chamem-me. Madre Teresa4
7 Manifestação contra algo sempre é maior do que a favor 
de alguém
7 Há uma frase de Blair Warren que resume a persuasão e 
evidencia o poder do inimigo em comum no Copywriting:  
“As pessoas farão qualquer coisa por aqueles que 
encorajam 
seus 
sonhos, 
justificam 
seus 
fracassos, 
acalmam seus medos, confirmam suas suspeitas e ajudam 
a atirar pedras contra seus inimigos”
7 "Desejamos a você um Halloween assustador!" - Pepsy
7 "Todo mundo quer ser um herói!" - Coca Cola
Copião
Importante:
7 Exemplo
Apostila aula 01 
Aula 09 - A teoria do inimigo em comum
Módulo 02 Copy Tradicional
{
{
Coca Cola x Pepsi
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 09 - A teoria do inimigo em comum
Módulo 02 Copy Tradicional
Inimigos Ocultos
{
High ticket x low ticket
{
Lançamento x perpétuo
{
Lula x Bolsonaro
~ Esquerda x Direita
{
Apple x Android
{
Mc x Burger
~ Exemplo 0
~ Exemplo 02
{
Samsung x Apple
~ Exemplo
{
Indústria do cigarro
~ Pneumologista
{
{
Indústria do medicamento
~ Médico
{
Provocação vendedores de PLR
~ VTSD
~ Exemplo
{
Livros de aeroporto
~ Clube do livro Sammer agi
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 09 - A teoria do inimigo em comum
Módulo 02 Copy Tradicional
Cultura x Contra Cultura
Perigos
{
Lu Seabra
{
{
Nubank
{
Marketing de promessas x Marketing de premissas
 Exemplo 0o
 Exemplo 02
 Casas de anális
 Assessores financeiro
 Bancos e corretores
 Vai te trazer inimigo
 Portas se fecharã
 Cada escolha uma renúnci®
 Energia ruim
{
{
{
Muito saudável
{
 Junk food
{
Muita cidade
{
 Natureba
{
Vegano
{
 Carnívoros
{
Ostentação
{
 Simplicidade
Guto Galamba
 Exemplo 0o
 Exemplo 0-
 Glamurização/ normalização da obesidade
{
Marçal x Globo
 Exemplo
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 09 - A teoria do inimigo em comum
Módulo 02 Copy Tradicional
Vamos Praticar?
01
Identificando um Inimigo em comum 
Escolha uma marca, uma figura política ou um 
movimento social de sua escolha. Identifique qual 
"inimigo" essa marca ou movimento pode estar se 
opondo para unir seus seguidores.
02
Crie sua estratégia 
Imagine que você precisa criar uma campanha para 
promover um produto ou serviço. Qual seria o 
inimigo? Como você usaria isso para criar uma 
mensagem forte?
03
Lados Opostos 
Pense em um debate popular (exemplo: carros 
elétricos vs. carros a combustão). Escreva um 
pequeno texto para cada lado do debate, 
mostrando como ambos poderiam usar a ideia de 
um inimigo comum para atrair apoio


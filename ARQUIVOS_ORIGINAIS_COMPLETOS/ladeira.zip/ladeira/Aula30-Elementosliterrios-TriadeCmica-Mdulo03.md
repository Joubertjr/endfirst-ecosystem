Apostila aula 0
Aula 30
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Triade 
Cômica

Módulo 03 LightCopy 
Aula 30 - Elementos literários - Triade Cômica
O que é?
A regra de três ou tríade cômica é um recurso 
humorístico 
baseado 
na 
repetição 
de 
dois 
elementos previsíveis, seguidos por um terceiro 
elemento inesperado que quebra a expectativa, 
gerando humor.
Os alunos aprenderão a identificar e criar frases 
usando a regra de três, entendendo como a 
quebra de expectativa pode ser usada para 
produzir humor.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
A A "regra de três" ou "tríade cômica". É um recurso frequentemente 
usado em comédia, onde o humor vem do contraste inesperado ou 
do "desvio" no terceiro item de uma lista. Também conhecido como 
dois pra lá, um pra cá.  
A regra de três funciona assim:   
Você estabelece dois elementos previsíveis e coerentes, criando 
uma expectativa lógica. O terceiro elemento quebra a expectativa, 
trazendo humor por contraste ou absurdo.   
Estrutura Básica: Primeiro item: Introduz a ideia. Segundo item: 
Reforça a lógica. Terceiro item: Surpreende, desvia ou quebra o 
padrão.
A "Fui a um casamento: tinha comida ótima, música incrível e um tio 
bêbado tentando dançar funk."
Exemplos
A Como toca por aí?
A Os nomes complicados do marketing digital
A achei tendência KKKKKKKKKKKK
A Aquele que souber dizer NÃO, chegará mais longe do que imagina.
A No episódio de hoje de PAIcelados: Cinta Cadeirinha para a Tutu!
Módulo 03 LightCopy 
Aula 30 - Elementos literários - Triade Cômica

MARKETING DE PREMISSAS
Exercícios
01
02
03
P Complete a tríade cômica 
Leia as frases abaixo e adicione um terceiro elemento inesperado 
para criar humor+
' Fui ao mercado e comprei pão, leite e ______@
' No parque, vi um cachorro, um gato e ______@
' Minha manhã foi ótima: acordei cedo, fiz exercícios e ______.
P Identifique o humor 
Leia as seguintes frases e sublinhe onde ocorre a quebra de 
expectativa+
' "Gosto de nadar, correr e fugir de responsabilidades.^
' "Meu primo é forte, corajoso e tem medo de borboletas.^
' "Fiz dieta, cortei açúcar e agora como bolo só nos finais de 
semana... e nos dias úteis."
P Crie sua própria piada com a regra de três 
Agora é sua vez! Escreva uma frase usando a regra de três, 
seguindo o modelo+
' Primeiro item: estabelece a ideia@
' Segundo item: reforça a lógica@
' Terceiro item: surpreende e gera humor.
Módulo 03 LightCopy 
Aula 30 - Elementos literários - Triade Cômica


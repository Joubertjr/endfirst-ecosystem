Apostila aula 0
Aula 04
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Analisando 
Narrativas 
Reais

Módulo 03 LightCopy 
Aula 04 - Analisando Narrativas Reais
O que é?
Narrativas com elementos literários são textos 
estruturados para prender a atenção do público. 
Elas 
utilizam 
figuras 
de 
linguagem 
e 
uma 
construção lógica bem elaborada para tornar a 
comunicação mais envolvente e persuasiva. Esse 
tipo de narrativa está presente em posts de redes 
sociais, roteiros de vídeos e até em estratégias de 
vendas.
O aluno aprenderá a identificar narrativas que 
utilizam figuras de linguagem e argumentação 
lógica. Com isso, será capaz de reconhecer como 
essas técnicas são aplicadas para captar a 
atenção e persuadir o público em diferentes 
formatos de comunicação.
Tópicos Principais
1
Conteúdo do módulo
1
Exercícios 
Objetivos do módulo

MARKETING DE PREMISSAS
Conteúdo do módulo
+ Anúncio 
analista 
Grupo 
Primo
+ Sequência 
de stories 
analista 
Grupo 
Primo
+ P7
+ P4
+ P1
+ P3
+ P2
+ P6
+ P5
` É uma profissão que existe e é 
concorrida
` A renda média dos consultores é de 15k 
nos primeiros dois anos.
` Consultores de investimentos, apenas 2 
mil, para atender 213 milhões.
` É uma profissão escassa
` O brasileiro precisa cuidar do seu dinheiro.
` Profissionais da saúde, de 5 a 7
` No Brasil temos 213 milhões de habitantes.
` Professores são 2 milhões e ganham de 2 a 
3k.
` Advogados são 2 milhões, em média ganham 
de 3 a 5k depois de 2 anos de formado.
` É uma profissão que paga mais que a 
média
` Quer formar carreira? Eu te convido.
` Salário médio brasileiro é 3k.
` O salário de 
analistas da 
XP é 15k.
` Provando
` Quer ser consultor da XP?
` Analistas XP ganham 5x mais que a 
média.
` Elemento 
literário
+ Q
+ CTA
+ P1
+ P2
+ Q
+ CTA
+ Q
+ Q
Primo rico
Módulo 03 LightCopy 
Aula 04 - Analisando Narrativas Reais

MARKETING DE PREMISSAS
Agora já foi
O real não vale nada
$ P1
$ P1
$ Q1
$ P3
$ Q2
$ P4
$ P5
$ Q1
$ CTA
$ P2
$ P2
M Quando você derrama um pouco de água, você não 
se dá um banho de água
M Daqui a alguns anos o real não vai valer mais nada
M Quando você derruba a granola, você não derrama 
tudo
M Desde a criação o real perdeu 10x o valor
M Não faz sentido viver no modelo agora jjá foi
M O Real é a quinta moeda mais desvalorizada do mundo
M Mostra 
M Ainda dá tempo de conquistar suas metas do ano
M O dólar valoriza todo dia
M Em novembro tivemos uma das maiores altas
M Em novembro tivemos uma das maiores altas
M Compre dólar na nômade
Módulo 03 LightCopy 
Aula 04 - Analisando Narrativas Reais

MARKETING DE PREMISSAS
Coach engana os outros
 P1
 P2
 P3
 P4
 P5
 P6
 P6
 Q
8 Rafael Silva, medalhista 
olímpico, atribuiu parte do 
sucesso a uma coach 
profissional.
8 Bruninho da seleção 
também atribuiu seu 
sucesso a um coach.
8  O site PubMed, um dos 
mais respeitados do mundo, 
tem mais de 35 mil 
pesquisas sobre coaching.
8 Hospitais famosos usam 
coaching para ajudar no 
tratamento.
8 Minha instituição e 
universidades demonstram, com 
estudo científico, a efetividade 
do coaching.
8 Quando você fala que coaching é 
enganador, você atinge uma categoria.
8 Existem bons coaches, são sérios e dão resultados.
8 Em todas as profissões temos charlatanismo.
8 Premissa de História 
e autoridade.
8 Premissa de História 
e autoridade.
8 Premissa Apelo à ciênciaë
8 Premissa Prova socialë
8 Premissa Autoridade.
8 Premissa de Exemplo e 
autoridade.
8 Premissa de Apelo 
à ciência.
Módulo 03 LightCopy 
Aula 04 - Analisando Narrativas Reais

MARKETING DE PREMISSAS
Coach engana os outros
 P1
 P2
 P3
 P4
 P5
 P6
 P6
 Q
8 Rafael Silva, medalhista 
olímpico, atribuiu parte do 
sucesso a uma coach 
profissional.
8 Bruninho da seleção 
também atribuiu seu 
sucesso a um coach.
8  O site PubMed, um dos 
mais respeitados do mundo, 
tem mais de 35 mil 
pesquisas sobre coaching.
8 Hospitais famosos usam 
coaching para ajudar no 
tratamento.
8 Minha instituição e 
universidades demonstram, com 
estudo científico, a efetividade 
do coaching.
8 Quando você fala que coaching é 
enganador, você atinge uma categoria.
8 Existem bons coaches, são sérios e dão resultados.
8 Em todas as profissões temos charlatanismo.
8 Premissa de História 
e autoridade.
8 Premissa de História 
e autoridade.
8 Premissa Apelo à ciênciaë
8 Premissa Prova socialë
8 Premissa Autoridade.
8 Premissa de Exemplo e 
autoridade.
8 Premissa de Apelo 
à ciência.
Módulo 03 LightCopy 
Aula 04 - Analisando Narrativas Reais

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 02 - Fundamentos da lógica das premissas
Exercícios
01
02
03
 Identificação de técnicas:  
Leia o seguinte trecho: 
"Esse produto mudou minha vida! Antes, eu perdia horas tentando 
organizar meus compromissos, mas agora tudo está no lugar com 
apenas um clique.e
O Quais elementos literários ou estratégias persuasivas foram 
usados nesse textoE
O Que efeito essas estratégias causam no leitor?
¦ Criação de uma pequena narrativa: 
Escreva um post para redes sociais promovendo um curso online. 
Use pelo menos uma figura de linguagem e uma argumentação 
lógica para prender a atenção do leitor.
¦ Analisando um vídeo ou post: 
Escolha um post de rede social ou um trecho de um vídeo de 
vendasÐ
O Identifique e anote quais figuras de linguagem ou técnicas de 
argumentação foram utilizadasÐ
O Explique como essas estratégias ajudam a captar a atenção e 
convencer o público.


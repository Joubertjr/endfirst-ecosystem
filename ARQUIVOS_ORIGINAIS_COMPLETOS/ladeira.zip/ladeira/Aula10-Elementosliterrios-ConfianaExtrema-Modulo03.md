Apostila aula 0
Aula 10
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Confiança 
Extrema

Módulo 03 LightCopy 
Aula 10- Elementos literários - Confiança extrema
O que é?
Autoconfiança manifesta ou autoridade implícita é 
a capacidade de demonstrar extrema confiança e 
segurança pessoal. Essa característica se reflete 
no tom de voz, na escolha das palavras e na 
postura, transmitindo convicção e domínio sobre 
um tema ou situação.
Compreender como a autoconfiança manifesta 
influencia a comunicação e as interações sociais, 
reconhecendo seus sinais e impactos, além de 
refletir sobre como equilibrar segurança pessoal 
sem causar antipatia.
Tópicos Principais
1
Conceito
1
Exercícios 
1
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
; O elemento que representa confiança extrema e demonstra 
segurança pessoal é chamado de autoconfiança manifesta ou 
autoridade implícita. Esse recurso é frequentemente percebido no 
tom de voz, na escolha de palavras e na postura da pessoa, 
transmitindo convicção e domínio sobre o assunto ou situação$
; Uma sutil antipatia
; Ítalo Marcilli
; Leandro
; Lara
; Vanessa
; Naysa
Exemplos
u A vida é cheia de pequenos imprevistos
u Se não isso, o quê?
u Destravando o medo na introdução alimentar
u Se bobear daqui a pouco você que vai ser obrigada a 
acordar cedo...
u Você tem que se esforçar muito pra der erradË
u TadinhË
u Tem que ser muito bobo pra querer só view e 
like, tem que ser mais bobo ainda para achar 
que isso não ajuda em nada
u Eu tenho poucas 
certezas na vida
u A gente vai morre
u A gravidade existe
u Quem sabe escrever copy 
fica rico. É impossível 
alguém que sabe copy ser 
pobre, a nao ser que seja 
opção. Ah, eu não quero 
enriquecer, sou contra o 
acumulo de riqueza.
Módulo 03 LightCopy 
Aula 10- Elementos literários - Confiança extrema

MARKETING DE PREMISSAS
 Cátia
 Dona Herminia
 Elon Musk                                                                        
Exemplo: “Eu construí foguetes por que ninguém mais faria
 Barack Obama:                                                                                                 
Seu discurso "Yes, we can" e um exemplo clássico de confiança 
comunicada por meio de frases assertivas e otimismo realista.
 Steve Jobs                                      
Lançamento do 
iPhone (2007):                                                                   
"Hoje, a Apple 
vai reinventar o 
telefone."
 “Eu não construo carros para vender. Eu construo 
carros para mudar o mundo.”
 Bezos
 “Não estou preocupado com os lucros desse trimestre. Estou 
construindo algo que vai durar 100 anos.”
 Coca cola
 Copys 
criadas 
para a aula
Û Eu quero saber quem já se sentiu assim!
Û "As pessoas não 
sabem o que querem 
até mostrarmos a 
elas. "
Û "O Macintosh vai 
mudar o mundo."
Û Musk
Û “A fórmula da felicidade”
Û "Não é sobre gostar de cozinhar. É sobre ser 
incrível na cozinha."  
Você pode ate amar gastronomia, mas, se não sabe 
o que está fazendo, vai continuar errandoA
Û Vai saber mais sobre vinhos do que 90% dos 
sommeliers por aí.=
Û Você ainda está escolhendo vinho pelo preço? 
Chegou a hora de crescer.=
Û "Você acha que sabe de vinhos? Então me prove."  
Qual a diferença entre um Chianti Clássico e um 
Brunello?=
Û Meus clientes não buscam só metros quadrados ou 
vistas deslumbrantes. 
Eles buscam imóveis que falem por eles
Û “Não estou preocupado com os lucros desse 
trimestre. Estou construindo algo que vai durar 
100 anos.”
Módulo 03 LightCopy 
Aula 10- Elementos literários - Confiança extrema

MARKETING DE PREMISSAS
Exercícios
01
02
03
F Identificação de Sinais:  
Liste três comportamentos ou características que indicam 
autoconfiança manifesta em uma pessoa. Dê um exemplo de como 
cada um pode ser aplicado em uma situação do dia a dia.
w Interpretação de Situações: 
Leia as situações abaixo e diga se a pessoa demonstra 
autoconfiança manifesta ou não. Justifique sua respostac
O Um palestrante fala com voz firme, mantém contato visual e usa 
gestos controladosc
O Um estudante evita olhar para o professor ao apresentar um 
trabalhoc
O Um vendedor fala com muita energia e interrompe o cliente 
constantemente.
w Reflexão Pessoal: 
Pense em um momento em que você precisou demonstrar 
confiança. Como foi sua postura, tom de voz e escolha de palavras? 
O que poderia ser melhorado para transmitir mais segurança sem 
parecer arrogante?
Módulo 03 LightCopy 
Aula 10- Elementos literários - Confiança extrema


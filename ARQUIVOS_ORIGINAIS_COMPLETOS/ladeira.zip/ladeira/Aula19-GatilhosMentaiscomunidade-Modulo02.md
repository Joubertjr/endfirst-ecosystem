Apostila au
Aula 19
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Gatilhos 
Mentais 
Comunidade

Apostila aula 01 
Aula 19 - Gatilhos Mentais - Comunidade
Módulo 02 Copy Tradicional
O que é?
O gatilho mental da comunidade é uma técnica de 
persuasão que explora o desejo humano de 
pertencer a um grupo, de se sentir incluído em 
uma comunidade ou tribo que compartilha 
interesses, valores ou objetivos comuns. 
Ensinar 
como 
utilizar 
o 
gatilho 
mental 
da 
comunidade para aumentar a conexão emocional e 
o engajamento do público, explorando o desejo de 
pertencimento e a importância de criar uma 
sensação de tribo ou grupo em torno de uma 
marca, ideia ou projeto.
Tópicos Principais
Conceito
Jeito Certo
Jeito errado
Exercícios
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 19 - Gatilhos Mentais - Comunidade
Módulo 02 Copy Tradicional
CONCEITO
Gatilho mental da comunidade
Livro
g Esse gatilho se baseia na ideia de que as pessoas têm uma 
necessidade intrínseca de conexão social e de se identificar 
com grupos que reforçam sua identidade e valores.
g Tribos 
 CLIQUE AQUI
g Exemplo 01
g Exemplo 01
g Exemplo 01
g Exemplo 01
g Exemplo 02
g Exemplo 02
g Exemplo 02
g Exemplo 02
g Exemplo 03
g Exemplo 03
g Exemplo 04
{
{
Conteúdo da Aula
JEITO CERTO
Dar voz / React
Representar Valores
O que ama / acredita
O que odeia / repulsa
O que é / aconteceu
{
{
{
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 19 - Gatilhos Mentais - Comunidade
Módulo 02 Copy Tradicional
Tribo / bordões / repetição / Seita / Rituais
Tribo / bordões / repetição / Seita / Rituais
h Subidg
h Ta pagg
h Baby bostY
h Blusa azul Subido PRO
h Bonde do caf{
h RDy
h Exemplg
h Wild Wild Countrj
h Sindicato 
{
Memórias físicas
{
h Exemplo 01
h Exemplo 01
Sobral
Eslen
{
h Corujas
h Pressa e paciênciY
h Coisas boas acontecem no caminho de 
quem está no caminhg
h O desespero te deixa burrg
h Está cheio de macacos na sua vidY
h Se vende 1, vende 10
h Lives 5.am
Felipe Neto
Escrever todo dia
Milagre do amanhã
Páginas matinais
Banho de gelo
Café com manteiga
Incentive a cultura de ajuda mútua, onde membros mais experientes 
auxiliam os novatos. Isso cria laços fortes e um ambiente de 
confiança.
{
{
{
{
h Disnej
h FacebooI
h Google
h Filosofia ladeira
Leandro
{
{
Clubes
{
h Harlej
h Exclusividade
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 19 - Gatilhos Mentais - Comunidade
Módulo 02 Copy Tradicional
Exercicios
01
Aplique o que você aprendeu hoje em todos esses 
pontos abaixo:  
- Palestra 
- Pitch 
- Anúncio 
- Vídeo de vendas 
- Live de conteúdo 
- Carrossel 
- Reels? 
- Newsletter 
- Artigo de Linkedin 
- Twitter
02
Tente encontrar em 3 influenciadores da sua 
escolha, quais são os gatilhos que eles usam e 
veja onde pode ser explorado da melhor maneira.
JEITO ERRADO
» Não ter nome própri·
» Não repeti³
» Não ter intensidade
{


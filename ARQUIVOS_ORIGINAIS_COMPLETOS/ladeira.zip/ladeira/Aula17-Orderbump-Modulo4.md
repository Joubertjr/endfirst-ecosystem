Apostila
Aula 17
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
Orderbump

Módulo 04 Formatos de Copy
Aula 17 - Orderbump
Explicar o que é um orderbump e como utilizá-lo 
na página de checkout para aumentar o valor da 
compra, destacando os elementos essenciais de 
sua estrutura e indicando quais tipos de produtos 
são 
mais 
adequados 
para 
essa 
oferta 
complementar e de fácil aceitação.
Tópicos Principais
1
Anatomia discursso de orderbump
Objetivos do aula

Conteúdo do módulo
Anatomia discursso de orderbump
 Headline
 Descrição
 Preço
 Que tipo de produto oferecer
 Que tipo de produto oferecer
N Exemplo Cátia
N Atrativo, Explicativo, Interessante, 
Sugestivo.
N !0 produtos eróticos
N Desejo
N Curiosidade
N Nome do produto
N Se possível, colocar uma ancoragem
N Produtos de consumo rápido 
N Produtos de desejo e impuls­
N Percepção de pouco aumento no valor total da compra
N Página de checkout
N Benefício
MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 17 - Orderbump


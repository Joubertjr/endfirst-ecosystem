Apostila aula 0
Aula 14
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Linguagem
Fantasiosa

Módulo 03 LightCopy 
Aula 14- Elementos literários - Linguagem Fantasiosa
O que é?
A linguagem fantasiosa é um recurso criativo que 
utiliza elementos imaginários, mágicos ou lúdicos 
para construir histórias e ideias. Ela permite a 
criação 
de 
mundos 
fictícios, 
personagens 
extraordinários e acontecimentos que fogem da 
realidade, 
tornando 
a 
comunicação 
mais 
envolvente e cativante.
Os 
alunos 
aprenderão 
sobre 
a 
linguagem 
fantasiosa e como ela é usada para estimular a 
imaginação, 
criar 
narrativas 
envolventes 
e 
transmitir ideias de forma criativa.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
Exemplos
> A linguagem fantasiosa é um recurso criativo que utiliza elementos 
imaginários, lúdicos ou fantásticos para apresentar ideias e 
narrativas. Ela inclui temas como viagens no tempo, mundos 
mágicos, personagens fictícios e acontecimentos que desafiam a 
lógica do mundo real. Esse recurso cativa o público ao transportar 
a mensagem para um plano de encantamento e imaginação.C
> Como seria se ...
> Perini
> Filme
> Livro
g Eu não sou um homem facilfácil 
g Mais esperto que o diabo
> Banco
> Manu Gavassi
Módulo 03 LightCopy 
Aula 14- Elementos literários - Linguagem Fantasiosa
> Jovem, invista para não depender do governo no futuro.
> Poupe e um dia você chegará lá…
> Programa de proteção à carreira artística, 
em que posso ajudar? 
> Fui judicialmente obrigado a postar esse Reels.
> Tendências de marketing digital para 2065
> Quem é casado sabe. Cuidado! 
> SE HOMENS ENGRAVIDASSEM: como seria pais cis vivendo...
> SINCERAS no SEXO: a VERDADE no sexo e SINCERAS na CAMA...
> O futuro não perdoa
> If life were like web design — Webflow
> We have a typo — Webflow

MARKETING DE PREMISSAS
 Work Genie - Meeting Room
 Work Genie - Elevator
 Work Genie - Desk
Exercícios
01
02
03
m Complete a frase: 
Complete a seguinte frase com uma ideia criativa e fantasiosa: 
"Se eu pudesse viajar no tempo, eu..." 
m Criação de um personagem mágico: 
Imagine um personagem com habilidades especiais ou que viva em 
um mundo diferente do nosso. Escreva um pequeno parágrafo 
descrevendo quem ele é e onde vive. 
m História com "Como seria se..." 
Escreva uma história curta começando com a pergunta: "Como seria 
se os animais falassem?" Use elementos da linguagem fantasiosa 
para tornar sua narrativa criativa.
Módulo 03 LightCopy 
Aula 14- Elementos literários - Linguagem Fantasiosa


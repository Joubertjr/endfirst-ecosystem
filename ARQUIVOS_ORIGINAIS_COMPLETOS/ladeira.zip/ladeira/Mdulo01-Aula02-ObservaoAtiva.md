Apostila au
Aula 02
Módulo 01 Criatividade
MARKETING DE PREMISSAS
 Observação 
Ativa

Apostila aula 01 
Aula 02 - Observação Ativa
Módulo 01 Criatividade
O que é?
Observação ativa é uma técnica de coleta de 
dados onde o observador participa ativamente e 
de forma consciente no ambiente ou situação que 
está estudando. Usada frequentemente em 
pesquisas qualitativas, como antropologia, 
sociologia e psicologia, essa abordagem ajuda a 
entender melhor os comportamentos, interações 
e contextos sociais.
Objetivos da Aula
Transformar e aumentar sua capacidade técnica 
como copywriter utilizando as 7 técnicas da 
observação como base de aprendizado.
Tópicos Principais
O que é Observação Ativa
7 Técnicas da Observação
Exercícios
1
2
3
MARKETING DE PREMISSAS

Apostila aula 01 
Aula 02 - Observação Ativa
Módulo 01 Criatividade
Conteúdo da Aula
7 Técnicas da Observação
Elas ajudam a desenvolver um olhar observador, 
incentivando perguntas que despertam 
curiosidade e reflexão, a leitura atenta de 
comportamentos e emoções, a prática da escrita 
detalhada para registrar observações, e a análise 
criativa de situações, tudo com o objetivo de 
captar e compreender profundamente o contexto 
e as interações humanas. Conheça as 7 técnicas 
abaixo:
MARKETING DE PREMISSAS
{
Questione
Desenvolver um 
olhar observador
Por que?
Quem disse?
Quem faria isso?

Quando isso começou?

Por que inventaram essa lei?
Qual era a intenção?
Tenha curiosidade real
Inutilidade

Seja do contra
  
{
{
{
Placa proibido urinar no chão
Existe rivalidade feminina?
Proibir nunchaku no avião

Apostila aula 01 
Aula 02 - Observação Ativa
Módulo 01 Criatividade
MARKETING DE PREMISSAS
{
{
Pergunte
Sinta
Qual seu sonho
Qual seu medo
Qual seu filme favorito
O que te deixa com raiva
Me conta essa história
O que aconteceu na viagem
Como é ser mãe de 4
Como você se sentiu
  
{
Por que?
{
Por que?
{
Por que?
Leitura corporal
Diferença entre o que fala e o 
comportamento
Captar emoções

Apostila aula 01 
Aula 02 - Observação Ativa 
Módulo 01 Criatividade
MARKETING DE PREMISSAS
{
Olhar único
Todos estão olhando pro palco, olhe para a 
plateia
Todos estão olhando pra noiva, olhe para o 
pai da noiva
Minha conversa com o motorista do ônibus 
em Miami
Encontre o personagem invisível
O que o comportamento diz
O que as emoções transmitem
Desenvolva sensibilidade
{
Pense como 
um artista
Vê o lado engraçado das 
coisas sérias
O lado sério das coisas 
engraçadas

Apostila aula 01 
Aula 02 - Observação Ativa
Módulo 01 Criatividade
MARKETING DE PREMISSAS
Anote
Sentiu



Exemplos

Tudo pode ser texto, anúncio, ideia
Conversas com clientes, pacientes, alunos, parentes
O flow criativo é mais forte que o esforço ativo
{
{
{
 Raiv~
 Medv
 Nojv
 Invej~
 Ansiedads
 Desgosto
 Vídeo aviãv
 Partv
 História da Hotmar
 Ruy na Itáli~
 Ruy Rugindo

Apostila aula 01 
Aula 02 - Observação Ativa
Módulo 01 Criatividade
MARKETING DE PREMISSAS
01
Escreva um texto com obsevações do ambiente 
físico que você está agora.
02
Saia de casa, conversa com um estranho e escreva 
um texto sobre a vida desse desconhecido
03
Encontre uma situação do seu cotidiane e questione 
porque as coisas são como são. Ex: porque os 
monitores eram quadrados e ficaram retangulares? 
Não é pra usar esse exemplo espocífico, questione 
algo que você mesmo observou.
04
Escreva um texto, em que você descreve o 
sentimento de alguém que você ama por você.
05
Converse com um conhecido e faça perguntas que 
normalmente não faria. Qual seu sonho? Qual seu 
livro preferido? Qual seu maior arrependimento?
Vamos Praticar?


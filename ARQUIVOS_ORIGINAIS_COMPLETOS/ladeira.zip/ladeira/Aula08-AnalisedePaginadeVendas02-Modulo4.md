Apostila
Aula 08
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
Analise de 
Página de 
Vendas
02

Módulo 04 Formatos de Copy
Aula 8 - Analise de Vídeo de vendas VSL 02
O objetivo desta aula é ensinar estratégias de 
copywriting aplicadas a páginas de vendas de 
cursos online, com foco em produtos digitais de 
alto valor, como o curso "Corta Bonito". A aula 
demonstra como estruturar a comunicação de 
forma persuasiva, destacando elementos que 
aumentam a curiosidade, geram desejo e facilitam 
a conversão do visitante em comprador.
Tópicos Principais
1
Pontos-chaves
2
Resumo Geral da aula
Objetivos do aula

Conteúdo do módulo
MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 8 - Analise de Vídeo de vendas VSL 02
Pontos-Chaves
^ Gerar Curiosidade para Aumentar a Retenção
A primeira parte da página de vendas deve instigar a curiosidade do 
visitante, focando nos benefícios do conteúdo gratuito antes de 
apresentar o produto.
 O vídeo gratuito promete ensinar a cortar a franja mais pedida e 
criar camadas sem marcas, o que atrai a atenção de quem tem 
essas dúvidas~
 A promessa de revelar "o que fez o corte subir de R$ 60 para R$ 
700" cria forte apelo para que o visitante assista ao conteúdo 
completo.
^ Oferecer Material de Valor Percebido
Elementos com materialidade aumentam o desejo do público e 
justificam o investimento.
 algo que até cabeleireiros iniciantes podem usar para aumentar o 
faturamento~
 Um PDF com todas as páginas de vendas mostradas na aula gera 
sensação de ganho imediato.
^ Storytelling e Prova Social nos Depoimentos
Depoimentos eficazes incluem transformação e propósito, 
conectando emocionalmente com o público.
 Helena aumentou seu valor de corte e conseguiu formar uma filha 
na faculdade, ilustrando crescimento financeiro e pessoal~
 Fernanda deixou de se sentir incompleta e abriu seu próprio 
salão, destacando realização profissional.

MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 8 - Analise de Vídeo de vendas VSL 02
Resumo Geral da Aula
Nesta aula, foram apresentados os fundamentos para construir uma 
página de vendas de alta conversão, com foco em despertar 
curiosidade, gerar valor percebido e usar storytelling autêntico. O 
professor destacou a importância de não vender diretamente o 
produto em um primeiro momento, mas sim o conteúdo gratuito que 
leva o público à decisão de compra. A aula trouxe exemplos práticos 
de elementos que funcionam bem, como planilhas, títulos com apelo 
emocional, bônus bem explicados e depoimentos com carga 
emocional, mostrando como cada parte da página contribui para 
aumentar a taxa de conversão.


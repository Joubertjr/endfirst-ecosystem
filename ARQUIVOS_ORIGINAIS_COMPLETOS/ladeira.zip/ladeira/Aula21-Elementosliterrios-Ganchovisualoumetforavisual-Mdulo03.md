Apostila aula 0
Aula 21
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Gancho 
visual ou
Metáfora
visual

Módulo 03 LightCopy 
Aula 21 - Elementos literários - Gancho visual ou metáfora visual
O que é?
A metáfora visual é uma técnica que usa imagens 
e objetos cotidianos para representar conceitos 
abstratos de forma clara e impactante. Já o 
gancho é um recurso que desperta curiosidade 
logo no início da comunicação, prendendo a 
atenção do público. Quando usados juntos, esses 
elementos tornam a mensagem mais envolvente e 
memorável.
Compreender como a metáfora visual e o gancho 
podem 
ser 
aplicados 
para 
melhorar 
a 
comunicação, tornando ideias complexas mais 
acessíveis e cativantes.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
L O elemento de metáfora visual é uma técnica que utiliza imagens, 
objetos ou situações do cotidiano para representar conceitos 
abstratos ou ideias complexas de maneira mais simples e 
impactante. Já o gancho é um recurso que prende a atenção do 
público logo no início, criando curiosidade e interesse para que a 
mensagem completa seja absorvida.  
Quando combinados, esses dois elementos tornam a comunicação 
visualmente rica e altamente envolvente, criando impacto e 
conexão imediatos.  
Representação Simbólica:  
Usa objetos ou cenários como símbolos para transmitir uma ideia. 
Exemplo: Um jarro quebrado para simbolizar fragilidade emocional.  
Características do Gancho Curiosidade:  
 Apresenta uma ideia ou imagem intrigante para prender a 
atenção. 
Exemplo: "O que um copo vazio pode ensinar sobre sua vida 
financeira?" 
Módulo 03 LightCopy 
Aula 21 - Elementos literários - Gancho visual ou metáfora visual
Exemplos
L Comer sem culpa é um sonho de consumo e é super possível!!
L Prime’s Big Game Commercial 
L Descubra como se comunicar de forma mais clara por meio...
L Siga @kleincarlos para viver uma VIDA SEM BARRIGA depois...
L Você sabia que pagava tantos impostos nestes...
L e não é qualquer um que vai ter a honra de provar esse vinho…
L Pronto, podem compartilhar com os maridos
L "In English Please!"
L Stuck the landing @drinkprime

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 21 - Elementos literários - Gancho visual ou metáfora visual
H O dia que contratei um Personal Stylist
H Cerimônia da união entre perpétuo e lançamento.
H Cuidado com suas decisões. Dica: assista a cena final
H How monday.com uses data for EVERYTHING
H 5 Erros Comuns Que as Mulheres Cometem na Cama | Cátia...
H Vou esfregar isso aqui na sua cara
H Compre sua camisa Insider. Cupom
H Para a aula
Î Metáfora Visual: Um balde cheio de furos, com água escorrendo. 
Gancho: 
"Você está tentando encher seu balde financeiro, mas os furos 
não deixam. Quer aprender a tampar esses vazamentos e fazer 
seu dinheiro render?"  
Metáfora Visual: Um relógio com as engrenagens expostas e 
enferrujadas. 
Gancho: 
"Seu tempo é como esse relógio: se você não cuida das 
engrenagens, ele para. Descubra como organizar sua rotina e 
recuperar as horas perdidas."  
Metáfora Visual: Um castelo de cartas desmoronando. 
Gancho: 
"Você está construindo sua vida como um castelo de cartas? 
Sem um seguro de vida, tudo pode desabar de repente."  
Metáfora Visual: Um manequim vazio, mas com uma peça de 
lingerie sofisticada. 
Gancho: 
"Até o manequim fica irresistível com a peça certa. Imagina 
você?"

MARKETING DE PREMISSAS
Exercícios
01
02
03
& Identificando Metáforas Visuais: 
Observe as seguintes imagens e associe cada uma a um conceito 
abstrato. Justifique sua resposta
5 Um labirintH
5 Uma escadC
5 Um barco à deriva
& Criando um Gancho: 
Imagine que você precisa prender a atenção do público para uma 
palestra sobre sustentabilidade. Escreva uma frase de impacto que 
sirva como gancho para iniciar a apresentação.
& Desafio Criativo: 
Escolha um dos seguintes temas: "Resiliência", "Mudança" ou 
"Sucesso". Crie uma metáfora visual para representá-lo e descreva 
como ela pode ser utilizada para transmitir a ideia de forma eficaz.
Módulo 03 LightCopy 
Aula 21 - Elementos literários - Gancho visual ou metáfora visual


Apostila au
Aula 03
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Termômetro de 
aquecimento de 
público

Apostila aula 01 
Aula 03 - Termômetro de aquecimento de público
Módulo 02 Copy Tradicional
O que é?
É uma ferramenta que mede o quanto as pessoas 
conhecem e estão interessadas em um produto 
ou marca. Ele divide o público em três gruposN
M@ Frio: Não conhece o produto e precisa de mais 
informações]
C@ Morno: Já ouviu falar, mas precisa de mais 
detalhes]
?@ Quente: Conhece bem e está pronto para 
comprar.
Isso ajuda a ajustar a comunicação para cada 
grupo de forma mais eficaz.
Objetivos da Aula
Na aula, você vai aprender a ajustar sua 
comunicação ao "momento" do público e a utilizar 
a lógica de funil (público frio, morno e quente) para 
planejar sua estratégia de copywriting. Além disso, 
você entenderá como aplicar diferentes tipos de 
leads, como diretos, indiretos, empatia e notícias, 
conforme o nível de familiaridade do público com o 
produto.
Tópicos Principais
O que é o Estudo do Avatar
Públicos
Entendendo os Leads
Matriz  
Como funciona o Funil  
Exercícios
1
2
3
4
5
6

Conteúdo da Aula
Identificando o Público
MARKETING DE PREMISSAS
Público Desconhecido
Q Não conhece o produto, serviço ou marca;
Q Pode não estar ciente do problema ou da solução;
Q Necessita de mais educação e contextualização;
Q Reage melhor a leads indiretos, baseados em notícias e 
de pergunta.
Público Semi-familiarizado
Q Tem alguma noção do produto ou serviço, mas precisa 
de mais informações;
Q Conhece o problema, mas pode não estar totalmente 
consciente da solução específica;
Q Responde bem a leads indiretos, baseados em notícias 
e de pergunta.
Público Familiarizado
Q Já conhece bem o produto, serviço ou marca;
Q Tem uma boa compreensão do problema e da solução 
oferecida;
Q Reage bem a leads diretos, de empatia e de promessa.
Público
Apostila aula 01 
Aula 03 - Termômetro de aquecimento de público
Módulo 02 Copy Tradicional
{
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 03 - Termômetro de aquecimento de público
Módulo 02 Copy Tradicional
Matriz
Como funciona o funil
Frio
Morno
Quente
Topo
Meio
Fundo
Funil
{
{
{
{
Descoberta
Relacionamento
Conversão
Remarketing

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 03 - Termômetro de aquecimento de público
Módulo 02 Copy Tradicional
Vamos Praticar?
01
Crie um e-mail para publico frio, com o objetivo de 
aumentar a consciência sobre o problema que você 
resolve.
02
Crie um e-mail para publico morno, com o objetivo 
de aumentar o desejo pela busca de uma solução
03
Crie um e-mail para publico quente, com o objetivo 
de vender a sua solução


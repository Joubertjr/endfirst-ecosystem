Apostila au
Aula 08
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Emoções da 
persuasão 
(Medo e Ganância)

Apostila aula 01 
Aula 08 - Emoções da persuasão (Medo e Ganância)
Módulo 02 Copy Tradicional
O que é?
Emoções da persuasão (Medo e Ganância) são 
usadas para influenciar as decisões, aproveitando 
que as pessoas querem evitar problemas (medo) e 
buscar benefícios (ganância). Essas estratégias 
são essenciais para motivar o público a agir 
rapidamente ou tomar uma decisão favorável.
Objetivos da Aula
O objetivo da aula é ensinar como usar o medo e a 
ganância para convencer as pessoas, aproveitando 
que elas querem evitar problemas e buscar 
benefícios. A aula mostra como essas emoções 
influenciam as escolhas e ajuda a identificar o que 
os clientes precisam ou desejam, seguindo 
diferentes níveis de necessidades.
Tópicos Principais
Emoções da persuasão, o que é?
Teoria
Níveis de hierarquia
Pode Ajudar  
Exercícios  
1
2
3
4
5

Conteúdo da Aula
Teoria
MARKETING DE PREMISSAS
Como Funciona
H A teoria de que os seres humanos são movidos pelas 
emoções de medo e ganância, e de que buscam fugir da 
dor e buscar prazer, tem raízes profundas na psicologia e 
na neurociência. Esta ideia é central para muitas teorias de 
motivação e comportamento humano.
Sistema de Recompensa
H O sistema dopaminérgico está associado à sensação de 
prazer e à motivação para buscar recompensas. A 
dopamina, um neurotransmissor, desempenha um papel 
crucial na regulação do comportamento de busca de 
prazer.
Apostila aula 01 
Aula 08 - Emoções da persuasão (Medo e Ganância)
Módulo 02 Copy Tradicional
{
{
Sistema de Medo
H A amígdala, uma estrutura no cérebro, está envolvida na 
resposta ao medo e na formação de memórias associadas 
a eventos emocionais negativos. Ela ajuda a preparar o 
corpo para responder a ameaças percebidas (resposta de 
"luta ou fuga").
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 08 - Emoções da persuasão (Medo e Ganância)
Módulo 02 Copy Tradicional
Níveis de Hierarquia
Necessidades Fisiológicas
h Fomf
h Sedf
h Sono
{
Necessidades Fisiológicas
h Fomf
h Sedf
h Sono
{
Necessidades de Segurança
h Estabilidadf
h Segurança
{
Necessidades Sociais
h Amo
h Pertencimento
{
Necessidades de Estima
h Autoestim¤
h Reconhecimento
{
Autoatualização
h Realização PessoaÇ
h Crescimento
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 08 - Emoções da persuasão (Medo e Ganância)
Módulo 02 Copy Tradicional
Pode Ajudar
X Clique aqui para acessar (Alsoasked.com)
{
Site de busca por interesse
{
Youtube
 Use o Autocompleta}
 Vídeos mais vistos
{
Google
 Autocompletar
{
Casos Reais
 Medº
 Ganância  
Clique para acessar 
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 08 - Emoções da persuasão (Medo e Ganância)
Módulo 02 Copy Tradicional
Vamos Praticar?
01
Dores 
Crie uma copy de um vídeo, ou e-mail com 2 dores, 
usando a lista de hierarquias.
02
Desejos 
Crie uma copy de um vídeo, ou e-mail com 1 
desejo, usando a lista de hierarquias.


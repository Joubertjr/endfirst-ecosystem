Apostila au
Aula 11
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
 Reunião de 
Criação

Apostila aula 01 
Aula 11 - Reunião de Criação
Módulo 02 Copy Tradicional
O que é?
É um encontro, geralmente envolvendo equipes 
criativas e de marketing, cujo objetivo é discutir e 
desenvolver ideias para projetos, campanhas ou 
conteúdos. Essas reuniões são fundamentais para 
alinhar a visão criativa entre todos os envolvidos 
no projeto, garantir que as soluções propostas 
estejam de acordo com os objetivos e ter ideias 
novas e criativas.
Entender como conduzir e participar efetivamente 
de reuniões de criação, promovendo a geração de 
ideias inovadoras e a colaboração entre equipes, 
com foco na organização, no alinhamento das 
expectativas e na concretização de projetos 
criativos de forma eficiente.
Tópicos Principais
Escreva bêbado
Membros da reunião
Dinâmica
Objetivos
Técnicas
Exercícios
  
1
2
3
4
5
6
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 11 - Reunião de Criação
Módulo 02 Copy Tradicional
Características de uma boa oferta
Membros da Reunião
Escrever bêbado e editar sóbrio
o Não se apegue de fazer ideias boas, e sim criar ideiasn
o Depois será o momento de avaliar as ideias e ver qual será 
realizada
{
Quantidade
o Não pode ter 30 membros, porque vira bagunça e perde-
se o objetivon
o É ideal que tenha até 8 pessoas, com habilidades 
multidisciplinares.
{
o Experiente em comunicaçã¹
o Não dará ideias, apenas os comandoÍ
o Não pode julgar as ideias, apenas conduziÂ
o Apaziguar os conflitoÍ
o Está preocupado em extrair dos outros boas ideias
o Não pode dar ideiaÍ
o Anota e organiza as informações
Lider
Redator
{
{
Conteúdo da Aula
“Não importa o quão inteligente seja alguém, ele jamais será 
mais inteligente que a inteligência coletiva.”
Importante:
Importante ter:

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 11 - Reunião de Criação
Módulo 02 Copy Tradicional
C Clientes ou LeadU
C RedatoreU
C PalpiteiroU
C Membros do timQ
C É bom ter uma pessoa aleatória que não está atrelada ao 
projeto, para ter uma visão externa
Contribuintes
{
Dinâmica da Reunião
Definir Objetivos
Ditadura
Metas e direção
C A Reunião não é uma democracia¡
C O líder que decide qual ideia é boa ou não, após a reunião¡
C Se der certo é mérito do grupo, se der errado é 
responsabilidade do líde£
C Não pode durar muito tempo. Idealmente de 10 a 30 
minutos
C Deixar claro para todos os participantes qual é o objetivo 
da reunião, pra qual produto, as ideias que devem ser 
dadas e como resolver os problemas.
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 11 - Reunião de Criação
Módulo 02 Copy Tradicional
Associação livre
Idea Livre
Ponto de Vista
Diálogos
Universo Cognitivo
Oposto
Lista
Lista de argumentos
Refute argumentos
Sinônimos
Antônimos
{
{
{
{
{
{
{
{
{
{
{
TÉCNICAS

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 11 - Reunião de Criação 
Módulo 02 Copy Tradicional
Exercicios
01
Estruturando uma reunião: 
Organize um time de 6 a 8 pessoas contendo os 
membros descritos na aula. Identifique o perfil de 
cada um e designe uma função descrita nesta aula 
para executarem na reunião. Você fará o papel de 
líder e deve moderar o encontro. Tenha um bom 
redator ao seu lado e garante que ele está 
prestando atenção e anotando tudo.
02
Aplicando as técnicas: 
Apresente os objetivos da reunião e procure 
capturar boas ideias dos membros Utilizando as 
técnicas apresentadas na aula, conduza uma 
reunião de criação dando os comandos ensinados. 
Lembre-se de não da ideias, seu objetivo é tentar 
extrair ao máximo dos outros.


Apostila au
Aula 15
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Gatilhos 
Mentais 
 
Afeição

Apostila aula 01 
Aula 15 - Gatilhos mentais - Afeição
Módulo 02 Copy Tradicional
O que é?
Também é conhecido como o “gatilho da simpatia”, 
o gatilho da afeição é um princípio que sugere que 
as pessoas estão mais propensas a serem 
influenciadas por uma pessoa quando gostam ou 
sentem alguma afeição por ela.
Aprender a usar o gatilho da afeição de maneira 
correta e ética, sem tornar uma pessoa falsa, 
interesseira ou manipuladora. O objetivo principal é 
aprender como se conectar e se relacionar bem 
com as pessoas, a fim de se tornar mais simpático 
e admirável na sua comunicação.
Tópicos Principais
A lógica
Jeito Errado
Jeito Certo
Exercícios
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 15 - Gatilhos mentais - Afeição   
Módulo 02 Copy Tradicional
A LÓGICA
JEITO ERRADO
Familiaridade / Similaridade
Elogios
Afeição x Autoridade
Bom senso
Sutileza
 A tendência de gostar de alguém que é semelhante a nós em 
interesses, opiniões e até aparência
 Elogiar alguém, de forma honesta, gera afeição e pode 
aumentar a simpatia
 Expor sua autoridade e vitórias pode soar arrogante e 
condescendente
 Afeição sem bom senso gera aversão. Você deixa de ser 
autoral e pode acabar cometendo gafeÚ
 Exemplo
 Quando você tenta demais gerar afeição por você, você 
acaba não sendo sutil e o efeito é totalmente o contrário da 
simpatia. Você aparenta muito manipulativo
 É importante ser íntegro
{
{
{
{
{
Conteúdo da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 15 - Gatilhos mentais - Afeição
Módulo 02 Copy Tradicional
JEITO CERTO
Exemplos
x Primeiro Partp
x Educação infanti§
x Armárip
x DoaçôeZ
x Crise dos 4
x Aparelho dos denteZ
x Autodepreciaçãp
x FilhoZ
x Escola Pública
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 15 - Gatilhos mentais - Afeição
Módulo 02 Copy Tradicional
Exercicios
01
Lista de identificação: 
Faça uma lista de coisas que o seu público tem em 
comum com você. Coisas que vocês gostam, coisas 
que vocês odeiam, coisas que vocês concordam e 
discordam e opiniões em comum. Também coloque 
situações que são comuns que você e seu público 
viveram e enumere os valores morais que você tem. 
Mantenha essa lista sempre perto quando quiser 
criar um conteúdo com gatilho de afeição
02
03
Crônica: 
Escreva uma crônica sobre um tema de 
identificação. Pode ser um que você enumerou no 
exercício anterior. Fale sobre o tema e, de forma 
sutil e com bom senso, fale sobre o assunto 
simpatizando com o que o seu público sente e 
normalmente não fala. Lembre-se de não ser falso. 
Seja íntegro e exponha seu ponto de vista de forma 
real.
Onde aplicar: 
Pegue essa crônica e tente aplicar em algum 
conteúdo seu. Pode ser palestra, pitch, anúncio, 
vídeo de vendas… Seja onde for, é hora de 
compartilhar a sua história com os outros e colher 
dados. Como foi a percepção do seu público sobre 
o que você disse? As reações foram de simpatia ou 
de antipatia? Ajuste a sua comunicação conforme 
for necessário e repita o processo.


Apostila
Aula 14
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
Mensageria 
(e-mail, whatsapp, manychat)

Módulo 04 Formatos de Copy
Aula 14 - Mensageria
Apresentar boas práticas no uso de canais de 
mensageria como e-mail, WhatsApp e manychat, 
destacando estratégias para tornar a comunicação 
mais clara, objetiva e eficaz, de acordo com a 
natureza de cada plataforma e o tipo de 
mensagem que se deseja transmitir.
Tópicos Principais
1
E-mail
2
Whatsapp
Objetivos do aula

Conteúdo do módulo
E-mail
Whatsapp
MARKETING DE PREMISSAS
% Gancho
% Erros
% Dicas
@ Longo ou Curto
@ Os dois
@ Muitos links e muitos objetivoZ
@ Muitos assuntoZ
@ Diagramaçã_
@ Falta de identidade
@ Longo ou curt_
@ Se long_
@ Dica
@ Faça a pessoa responder - Os primeiros e-mails de uma 
sequência
@ Objetivo / Intenção
@ Estímulos diferentes
@ Falta de big idea
@ Curto
@ Leve para uma pagina
@ Deixa claro que não quer resposta
@ Longo e indiret_
@ Curto e direto
Módulo 04 Formatos de Copy
Aula 14 - Mensageria


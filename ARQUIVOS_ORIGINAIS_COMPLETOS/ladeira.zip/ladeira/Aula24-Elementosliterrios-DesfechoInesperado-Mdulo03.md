Apostila aula 0
Aula 24
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Desfecho 
Inesperado

Módulo 03 LightCopy 
Aula 24 - Elementos literários - Desfecho Inesperado
O que é?
O desfecho inesperado é um elemento narrativo 
que surpreende o público ao final de uma história, 
piada ou discurso, contrariando a expectativa 
lógica criada ao longo da narrativa.
Compreender como o desfecho inesperado é 
utilizado 
para 
causar 
impacto, 
analisando 
exemplos e aplicando o recurso em textos curtos.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
E O Elemento do Desfecho Inesperado O desfecho inesperado é um 
recurso narrativo que quebra a expectativa do público no final de 
uma história, piada ou discurso. Ele funciona ao conduzir o leitor ou 
espectador em uma direção lógica e, no último momento, 
surpreendê-lo com um final que não era previsível.
Exemplos
Módulo 03 LightCopy 
Aula 24 - Elementos literários - Desfecho Inesperado
E Gostaram??? @nubank
E NÃO É POSSÍVEL GENTE
E COMERCIAL FOLHA - HITLER
E O que não pode faltar no carro de um homem:
E Esclarecendo a confusão no avião
E Esclarecimentos: Essa é uma peça de ficção, qualquer
E Se sua família está dormindo segura, agradeça...
E E aí? Você estaria disposto a viver pela sua família?
E Para a aula
Ú "Seu corpo mudou. Você engordou. A celulite apareceu. Você 
não se cuida. Tá péssima." Se alguém falasse isso pra você, você 
jamais aceitaria. Então por que você fala isso pra si mesma todo 
dia. Se trate com o respeito que exige dos outros. Você tem o 
direito de querer melhorar, mas também tem o direito de se olhar 
no espelho sem se odiar. Jota Lingerie – porque sua beleza já 
está aqui. Só falta você enxergar.

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 24 - Elementos literários - Desfecho Inesperado
Exercícios
01
02
03
} Identificando o desfecho inesperado: 
Leia a seguinte história curta: 
"João passou meses economizando para comprar um carro novo. No 
dia da compra, ao sair da concessionária, viu um anúncio: 'Sorteio 
de um carro para clientes que comprarem hoje'." 
 O final dessa história foi inesperado? Justifique sua resposta.
} Criando um desfecho surpreendente: 
Complete a história abaixo com um final inesperado: 
"Mariana ouviu um barulho estranho vindo do porão. Pegou uma 
lanterna e desceu devagar. Quando iluminou o canto escuro, ela 
viu..."
} Comparando narrativas: 
Escolha uma história ou piada conhecida que tenha um desfecho 
previsível e reescreva-a dando um final inesperado. Compartilhe 
com um colega e comparem os resultados.


Apostila au
Aula 27
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Gatilhos 
Mentais 
Porquê

Apostila aula 01 
Módulo 02 Copy Tradicional
Apostila aula 01 
Aula 27 - Gatilhos Mentais - Porquê
Módulo 02 Copy Tradicional
O que é?
○ gatilho mental do "Porquê" explora a 
necessidade humana de entender a razão por trás 
de ações e decisões. Quando explicamos o motivo 
de algo, mesmo que de forma simples, 
aumentamos a compreensão, empatia e aceitação 
por parte das pessoas. Ele é baseado no princípio 
psicológico de qve as pessoas tendem a aceitar e 
se engajar mais facilmente quando compreendem 
as razões por trás de um pedido, recomendação 
ou oferta.
O objetivo desta aula é mostrar como o Gatilho 
Mental do "Porquê" pode ser utilizado para 
aumentar o engajamento e a aceitação das suas 
mensagens. Ao explicar o motivo por trás de um 
pedido, recomendação ou oferta, você torna a 
comunicação mais humana e empática, criando 
conexões mais fortes com seu público. Com esse 
método, os alunos aprenderão a justificar suas 
propostas de forma clara, aumentando a confiança 
e facilitando a tomada de decisão por parte dos 
clientes.
Tópicos Principais
Conceito
Jeito certo
Jeito errado
Exercícios
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Conceito
; ○ gatilho mental do "Porquê" explora a necessidade humana 
de entender a razão por trás de ações e decisões. Quando 
explicamos ○ motivo de algo, mesmo que de forma simples, 
aumentamos a compreensão, empatia e aceitação por parte 
das pessoas. Ele é baseado no princípio psicológico de qve 
as pessoas tendem a aceitar e se engajar mais facilmente 
quando compreendem as razões por trás de um pedido, 
recomendação ou oferta.
{
Conteúdo da Aula
Jeito certo
{
c Jeito VTSD de ensinar perpétuo
c Por que você tem que 
construir patrimônio? 
c Por que o modelo que 
você trabalha vai te 
enriquecer
c Por que copy de promessas funciona pior que com premissas
c Entre na lista de espera por que
c Traga um papel e caneta
c Por que o 
pompoarismo 
funciona? 
Explicação
Por que é impossível 
enriquecer
) Coordenação Motora Fina 
• Ao escrever com papel e caneta, há um envolvimento mais profundo das áreas cerebrais 
responsáveis pela coordenação motora fina, como o córtex motor e o cerebelo. 
• A formação de letras e palavras exige movimentos precisos, o que cria um processo mais ativo e 
cognitivo
!) Ativação da Memória e Processamento 
• Escrever à mão ativa áreas do cérebro ligadas à memória e ao processamento de informações, 
como o hipocampo. 
• Estudos mostram que escrever fisicamente ajuda a memorizar e compreender informações de 
forma mais profunda, pois o esforço cognitivo é maior@
0) Conexão com Criatividade 
• A escrita manual pode ter uma conexão maior com o pensamento criativo e a reflexão, pois ela é 
mais lenta e deliberada, permitindo que você organize ideias de maneira mais estruturada.
; Vaginism\
; Libid\
; Lubrificaçã\
; AnorgasmiX
; incontinênciX
; Ciclo da resposta sexual femininX
; Mostrar página de vendas
Para enriquecer
Vendendo
Ou
Caro pra pouca
Barato para muito
Barato para pouca gente
{
{
{
{
{
{
Apostila aula 01 
Aula 27 - Gatilhos Mentais - Porquê
Módulo 02 Copy Tradicional
{

MARKETING DE PREMISSAS
 Muito técnico
 Como  tirar as objeções de cada problema
Jeito errado
Exemplo
{
{
Exercicios
01
02
03
Justifique sua Oferta
Responda ao ‘Por quê?’ em um Post
Defenda seu Ponto de Vista
 Escolha um produto ou serviço e escreva uma oferta de venda 
curta, utilizando o Gatilho Mental do "Porquê". Explique por que 
essa oferta é vantajosa ou importante para o cliente, focando 
nos benefícios.
 Crie um post curto (estilo Instagram Stories ou LinkedIn) 
explicando o motivo por trás de uma dica, recomendação ou 
insight que você queira compartilhar. Use uma estrutura 
simples: “Faça isso porque…” ou “Acreditamos nisso 
porque…”. 
 Escolha um tema polêmico ou uma opinião pessoal e 
escreva uma mensagem explicando por que você acredita 
nisso. Seja claro e direto, justificando de forma simples o 
seu ponto de vista.
Apostila aula 01 
Aula 27 - Gatilhos Mentais - Porquê
Módulo 02 Copy Tradicional
{
{
Por que confuso
Eu tentei explicar todo o método 
VTSD em uma imagem.


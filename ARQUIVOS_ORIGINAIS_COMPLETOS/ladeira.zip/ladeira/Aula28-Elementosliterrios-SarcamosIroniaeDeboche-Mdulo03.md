Apostila aula 0
Aula 28
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Sarcasmo,
ironia e 
deboche

Módulo 03 LightCopy 
Aula 26- Elementos literários - Sarcasmos, Ironia e Deboche
O que é?
A ironia é uma figura de linguagem na qual se diz 
algo querendo expressar o oposto, geralmente 
para gerar humor ou reflexão. O sarcasmo é uma 
forma mais agressiva de ironia, usada para criticar 
com tom mordaz. Já o deboche é um exagero 
provocativo que busca ridicularizar ou brincar com 
uma situação.
Compreender os conceitos de ironia, sarcasmo e 
deboche, identificando suas diferenças e usos no 
cotidiano, além de reconhecer o impacto dessas 
expressões na comunicação.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
T Ironia  
A ironia consiste em dizer algo que significa o oposto do que se 
quer expressar, geralmente de forma sutil ou inesperada, criando 
contraste e gerando reflexão ou humor.  
"Ah, que ótimo! Mais um prazo apertado. Exatamente o que eu 
precisava para relaxar."   
Sarcasmo  
O sarcasmo é uma forma mais direta e mordaz de ironia, 
geralmente usada para criticar ou ridicularizar, muitas vezes com 
um tom ácido.   
"Claro, porque todo mundo tem três horas livres no meio do dia 
para resolver isso."  
Deboche  
O deboche é um tipo de humor exagerado e provocativo, muitas 
vezes com o objetivo de desestabilizar ou brincar com situações 
absurdas ou pessoas.  
Uau, você tá super na moda com essa roupa de 2002!  
Tabela
T Machado de Assis: 
Famoso por usar ironia em suas obras, como em Memórias 
Póstumas de Brás Cubas: "Não tive filhos, não transmiti a nenhuma 
criatura o legado da nossa miséria."
Módulo 03 LightCopy 
Aula 26- Elementos literários - Sarcasmos, Ironia e Deboche
Exemplos
T paulcabannes_
T Cortei o cabelo, fiz a barba! Fiquei muito mais jovem!
T Ⓜ️
T Eu não julgo. Comente “material” para dar aulas de inglês ou espanhol!
T “Dois pacientes compartilham suas experiências com doenças...

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 26- Elementos literários - Sarcasmos, Ironia e Deboche
A Dá pra acreditar?
A A verdade precisa ser dita. Doa a quem doer.
A Qual desses você não sabia? Eu confesso que eu quase todos 
…
A São infinitos os benefícios de dar uma puxada no pen drive 
A A escala 6x1 é desumana e precisa acabar. 
A “Ah mas vc só fala de coisa que não funciona” tá aí uma
A Quem cuida de quem cuida?
A Tentando fazer um vídeo sem ofender ngm.
A Por que você deveria fazer o Viver de Renda?
A Dica de moda pros seguidores 
 Já...
A Vey juro… todos os “juro” tem um significado diferente...
A FILHA V4D1A E PAI V1AD0? Bitcoin é a solução!
A Rule over your organization with monday.com
A All "I'm a Mac I'm a PC" ads Part 1
A MC RYAN - O KUNG FU PANÇA BOSTILEIRO
A Jira gets fired by ClickUp - Exit Interview commercial advertisement
A Your team's future depends on monday.com

MARKETING DE PREMISSAS
Exercícios
01
02
03
H Classificação de frases 
Leia as frases abaixo e classifique-as como ironia, sarcasmo ou 
deboche*
N "Que maravilha! Perdi o ônibus de novo!'
N "Nossa, que ideia genial deixar o telefone cair na água!'
N "Parabéns! Você conseguiu errar todas as respostas da prova!"
H Criação de exemplos 
Crie uma frase para cada um dos conceitos estudados (ironia, 
sarcasmo e deboche). Depois, explique por que sua frase se encaixa 
nessa categoria.
H Interpretação de texto 
Leia o diálogo abaixo e responda: onde há ironia, sarcasmo ou 
deboche? Explique sua resposta 
N Maria: "Estou tão feliz! Choveu bem no dia do nosso piquenique!'
N João: "Nossa, que sorte! Vamos nadar na lama agora!"
Módulo 03 LightCopy 
Aula 26- Elementos literários - Sarcasmos, Ironia e Deboche


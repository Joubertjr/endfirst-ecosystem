Apostila aula 0
Aula 19
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Paródia

Módulo 03 LightCopy 
Aula 19- Elementos literários - Paródia
O que é?
A paródia é um recurso criativo que reinterpreta 
uma obra original de forma cômica, irônica ou 
crítica. Mantém ligação com o original, mas altera 
elementos para gerar humor ou reflexão. Pode 
aparecer em músicas, textos, vídeos e campanhas.
Compreender 
o 
conceito 
de 
paródia, 
seu 
funcionamento e como ela transforma conteúdos 
originais em versões humorísticas ou críticas.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
7 A paródia é um recurso criativo que consiste em reinterpretar uma 
obra, texto, música ou discurso original de forma cômica, irônica ou 
crítica. Ela mantém uma ligação com o material original, mas 
adiciona um toque humorístico ou adaptado ao contexto atual, 
geralmente para entreter ou provocar reflexão.   
Reconhecimento do original:  
O público precisa reconhecer a obra ou referência para que a 
paródia funcione. 
Exemplo: Uma versão humorística de uma música famosa.  
Transformação criativa:  
A paródia altera palavras, situações ou contextos do original para 
gerar um novo significado ou humor.  
Tom leve ou crítico:  
Pode ser puramente humorística ou carregar uma mensagem social 
ou cultural comercial  
Adaptabilidade:  
Funciona em diversos formatos: textos, músicas, vídeos, 
campanhas publicitárias, etc.
Módulo 03 LightCopy 
Aula 19- Elementos literários - Paródia
Exemplos

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 19- Elementos literários - Paródia
< Todo mundo em pânico (scary movie):
< Criado para a aula
{ Nóis vai fazer, vai fazer 
Fazer a harmonização pro finalzin do ano 
O queixinho vai destacando, pra geral perceber 
Nóis vai fazer, vai fazer Fazer a harmonização pro finalzindo ano 
Os lábio tão volumando, e o sorriso vai vencer  
Vai de botox, vai de preenchimento, 
Mandíbula desenhando, é um evento! 
Final do ano tá chegando, bora se arrumar, 
Que na festa de BC você vai brilhar!
Exercícios
01
02
03
º Identificação de paródias: 
Leia ou assista a diferentes paródias e identifique a obra original. 
Explique quais elementos foram modificados e qual efeito a paródia 
busca causar.
º Criação de uma paródia: 
Escolha uma música, texto ou cena famosa e crie uma versão 
parodiada. Você pode modificar as palavras para criar humor ou 
transmitir uma crítica social.
º Reflexão sobre o impacto da paródia: 
Escreva um pequeno texto explicando se a paródia sempre tem um 
tom leve ou se pode gerar discussões sérias. Dê exemplos de 
paródias que causaram impacto cultural ou social.


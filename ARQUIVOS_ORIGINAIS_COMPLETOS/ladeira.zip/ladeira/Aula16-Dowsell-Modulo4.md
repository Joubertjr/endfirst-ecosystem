Apostila
Aula 16
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
Downsell

Módulo 04 Formatos de Copy
Aula 16 - Downsell
Apresentar o conceito e a estrutura de um 
downsell, demonstrando como oferecer uma 
alternativa mais acessível para quem não concluiu 
uma 
compra 
inicial, 
utilizando 
abordagens 
estratégicas em diferentes canais para manter o 
interesse do público e aumentar as chances de 
conversão.
Tópicos Principais
1
Anatomia discursso de downsell
Objetivos do aula

Conteúdo do módulo
Anatomia discursso de downsell
' Ganch3
' Desenvolvimento na narrativa - Lógica de premissa+
' CTA
' Nova oportunidade
' Aonde fazer downsell
] Justificativa
] Apenas Desktop
] Se faz sentido, pra ticket mais alto
] E-mail
] Whatsapp
] Manychat
] Menos entregaveis
] Mais barato
] Exit Popup
] Abordagem comercial
] Anúncios remarketing
] Mensageria
] Outra promessa
Módulo 04 Formatos de Copy
Aula 16 - Downsell
MARKETING DE PREMISSAS


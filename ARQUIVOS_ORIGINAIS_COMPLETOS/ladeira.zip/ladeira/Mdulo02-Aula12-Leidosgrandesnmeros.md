Apostila au
Aula 12
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Lei dos 
grandes 
números

Apostila aula 01 
Aula 12 - Lei dos grandes números
Módulo 02 Copy Tradicional
O que é?
Lei dos grandes números é a lei dos grandes 
estímulos. Quanto mais você faz algo, mais você 
se torna bom naquilo e mais você coleta dados 
que te ajudam a se tornar melhor e mais eficiente 
no seu esforço.
Incentivar a habilidade de criação em alta escala. 
Entendendo como a Lei dos grandes números 
funciona te motiva a partir para a criação e 
divulgação das criações que você produz.
Tópicos Principais
A lógica
Contas
Exemplos reais
Exercícios
  
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 12 - Lei dos grandes números
Módulo 02 Copy Tradicional
A Lógica
Escalabilidade
i Quanto mais você faz, mais chances você tem de acertac
i Quando acerta, mais chances de acertar de novoS
i Quando acerta, você ganha ativos { Popularidade, dados, 
confiança e dinheiro
{
i A cada 50 vídeos você acha um bou
i 1 vídeo/semana = 1 Vídeo bom / an
i 3 vídeos/semana = 3 Vídeos bons / an
i 1 vídeo/ dia = 7 vídeos bons / ano
Logica padrão
{
Conteúdo da Aula
Você 
ganha 
mais 
motivação 
quando 
acerta 
e 
por 
consequência, mais dinheiro. Isso de tá mais gás pra continuar 
movimentando o processo.
Importante:
i Digamos que a cada 50 vídeos você acha um bom

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 12 - Lei dos grandes números
Módulo 02 Copy Tradicional
L 1 vídeo / semana = 1 vídeo bom / anI
L 3 vídeo / semana = 16 vídeos bons / anI
L 1 vídeo / dia = 50 vídeos bons / ano
L 503 músicas antes de estourai
L Exemplo
L 10 anos produzindo conteúdI
L Exemplo
L Encontrou o padrão dela e todos os vídeos bomba
L Exemplo
A Lei em aplicação
{
A ideia é que isso vai escalando de maneira exponencial. 
Quanto mais você faz, mais você vai acertando também para 
os próximos anos.
Não adianta só criar, tem que criar e publicar para que você 
consiga coletar os dados
Importante:
Contas
Só fé
Cintia Chagas
Carol Loback
{
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 12 - Lei dos grandes números
Módulo 02 Copy Tradicional
Exercicios
01
Produza: 
Faça 3 reels semanalmente durante um mês 
utilizando os elementos estudados no Light Copy. 
Se for capaz, faça mais. Conforme for produzindo, 
vá aperfeiçoando os próximos conforme identifica 
qual deles performou acima da média.
02
Dados: 
Analise os dados desse mês. Porque os que deram 
certo deram certo? Qual foi o diferencial que eles 
trouxeram? Com o que seu público se identificou e 
mais engajou? Traga essas respostas e se prepare 
para continuar para o segundo mês de conteúdo.


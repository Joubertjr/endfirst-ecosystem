Apostila
Aula 06
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
Página de 
vendas

Módulo 04 Formatos de Copy
Aula 06 - Página de vendas
Ensinar a construir páginas de vendas eficazes, 
apresentando o produto de forma estratégica, 
despertando interesse, educando o público e 
guiando o leitor até a conversão, por meio de 
seções bem estruturadas e persuasivas.
Tópicos Principais
1
Objetivo
3
Seções
2
Componentes de uma página
Objetivos do aula

Conteúdo do módulo
  Não é vender, é apresentar o produto*
 Fazer a pessoa avançar e ler a próxima linha de copy*
 Despertar interesse, educar, gerar desejo*
 Vender
 Seções
 Cabeçalho
 Chamada pra ação
 Explicação de oferta
 Demonstração*
 Pra quem é*
 Explicação do produto
m Headline
m Subheadliner
m Conteúdo
m Depoimentos de 
alunos
m Se preço barato, colocar preçor
m Se preço alto, omitir preço
m Entregaveis
m Se necessário, seção 
para entregável 
específico.
m Erros
m Headlines desconexas com o 
conteúdo da seçãÊ
m Headline sem copÄ
m Mais de um conteúdo na mesma 
seçãÊ
m Seção sem headline
Objetivo
Componentes de uma página
Seções
MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 06 - Página de vendas

Conteúdo do módulo
MARKETING DE PREMISSAS
3 Garantia-
3 Prova-
3 Autoridade-
3 Objeções-
3 Perguntas frequentes-
3 Suporte
3 Dores e desejos-
3 Autor-
3 Comparação
3 Argumentos
b Estudos científicosY
b Notícias que embasamY
b Lógica, constataçõesY
b Pesquisas de mercado
Módulo 04 Formatos de Copy
Aula 06 - Página de vendas


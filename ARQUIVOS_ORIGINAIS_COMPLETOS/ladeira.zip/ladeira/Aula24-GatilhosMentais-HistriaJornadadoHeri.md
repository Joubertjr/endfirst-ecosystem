Apostila au
Aula 24
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Gatilhos 
Mentais 
História
(Jornada do Herói)

Apostila aula 01 
Aula 24 - Gatilhos Mentais - História (jornada do 
heroi)
Módulo 02 Copy Tradicional
O que é?
Ele descreve um modelo narrativo comum em 
mitos, lendas e histórias de diferentes culturas ao 
redor do mundo, onde um herói passa por uma 
série de etapas transformadoras.
Ensinar como utilizar o gatilho mental da história 
para criar uma conexão emocional com o público e 
tornar a comunicação mais persuasiva. A ideia é 
que 
os 
alunos 
aprendam 
a 
transformar 
informações complexas e dados em narrativas 
envolventes, capazes de inspirar, motivar e facilitar 
a compreensão da mensagem.
Tópicos Principais
Conceito
Passos
Exemplos
Exercícios
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Conceito
Passos
> A Jornada do Herói, também conhecida como Monomito, é 
um conceito estruturado pelo mitólogo Joseph Campbell em 
seu livro O Herói de Mil Faces. Ele descreve um modelo 
narrativo comum em mitos, lendas e histórias de diferentes 
culturas ao redor do mundo, onde um herói passa por uma 
série de etapas transformadoras. E estrutura se divide em 
três atos principais, que por sua vez contêm 12 estágios 
distintos:
{
{
{
{
{
{
{
{
{
Conteúdo da Aula
 O herói de mil faces
Apostila aula 01 
Aula 24 - Gatilhos Mentais - História (jornada do 
heroi)
Módulo 02 Copy Tradicional
§ Vídeo de venda¡
§ Palestr¢
§ Anúnci¦
§ Liv«
§ Livro
. O herói deixa o mundo para embarcar em sua aventura
. O herói enfrenta desafios, aprende lições e é transformado.
. O herói volta ao mundo comum, transformando pela experiência.
 S Mundo Comum: O herói é apresentado em sua rotina cotidiana. 
É o ponto de partida antes da aventura/
+S Chamado  à Aventura: Algo interrompe a rotina do herói, 
chamando-o para uma jornada/
S Recusa do Chamado: O herói hesita ou resiste ao chamado 
devido ao medo e a insegurança/
S Encontro com o Mentor: Um mentor oferece sabedoria, 
ferramentas ou encorajamento/
S Travessia do Primeiro Limiar: O herói entra no mundo 
desconhecido, deixando o familiar para trás/
S Provações, Aliados e Inimigos: O herói enfrente testes iniciais, 
encontra aliados e identifica inimigos. 
S Abordagem Caverna Oculta: O herói se aproxima do maior desafio ou da 
situação mais perigosa da jornadaq
nS Provação suprema: O herói enfrenta um grande obstáculo ou adversário, 
muitas vezes colocando sua vida ou sua missão em riscoq
fS Recompensa (ou Conquista do Elixir): Após vencer o desafio, o herói 
recebe uma recompensa. Pode ser um objeto, conhecimento ou 
transformação pessoal.
 ÞS Caminho de Volta: O herói começa sua jornada de retorno, enfrentando 
a transição entre o mundo especial e o comumq
  S Recusa ao Retorno: O herói pode relutarem voltar ao mundo comum, às 
vezes por medo de perder a transformação conquistadaq
 +S Resgate Mágico: O herói recebe ajuda externa para retornar ao mundo 
comum, se necessárioq
 S Cruzando o Limiar de Retorno: O herói retorna ao mundo comum, 
trazendo consigo os frutos de sua jornadaq
 S Domínio de Dois Mundos: O herói aprende a equilibrar o mundo comum 
e o extraordinário.Ï
 S Liberdade para Viver: O herói vive plenamente, sem medo da morte ou 
do desconhecido, agora transformado.
§ Procedênci¢
§ Legitimidad«
§ Propriedade
§ Cuidado para não se preender
 Livro
& Partida 
(ou separação)
0& Iniciação
8& Retorno
 Onde usar
 Discleimer

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 24 - Gatilhos Mentais - História (jornada do 
heroi)
Módulo 02 Copy Tradicional
{
{
{
{
{
{
{
{
{
{
{
{
{
{
{
Resumo visual
a Thefore but
a Partida: Convite à aventura, separação do mundo comumm
a Iniciação: Transformação através de desafios e conquistasm
a Retorno: Integração das lições aprendidas na vida comum.
· A técnica de contar histórias que utiliza "But" e 
"Therefore" foi popularizada por" Trey Parker e 
Matt Stone, os criadores of South Park. Essa 
técnica é conhecida como "The But and 
Therefore Rule", ou seja, "A Regra do Mas e 
Portanto", Ela é amplamente utilizada em 
storytelling para criar histórias envolventes e 
dinâmicas. 
a Anúncio da van
a Vídeo 1
a Vídeo 2
· Conflito e consequência
O herói deixa o mundo comum para embarcar em 
sua aventura
	 Mundo comum
Era um adolescente comum, com 
uma vida comum.
· Até que 
ganhei um 
computador
· Mas estava infeliz e mau sucedido
· Comprei o curso A Clas
· Comprei a FL
· Convencer a Cátia
· Dificuldades de lançar, gravar, não 
saber
· Criei site de eventB
· Agência
T Chamado à aventura
k Recusa do chamado 
v Encontro com o mentor
 Travessia do Primeiro Limiar
 Provações, Aliados e 
Inimigos
· A ideia principal é que, ao invés de conectar 
eventos com "and then" ("e então"), você 
conecta os eventos com "but" ("mas") e 
"therefore" ("portanto"). Isso cria um senso de 
conflito e causa-efeito, elementos essenciais 
para uma narrativa interessante.µ
· But": Introduz um obstáculo, uma contradição 
ou um conflitom
· "Therefore": Mostra uma consequência ou uma 
decisão tomada devido ao obstáculo.  
Isso mantém a história envolvente porque evita 
que ela pareça apenas uma lista de eventos 
sem conexão lógica ou emocional.
a TramÜ
a TretÜ
a Transformação
a Egoista
a Propositò
a Altruísta
Resumo
Bônus
 Rei leã
 Procurando o Nem
 Homem Aranha 
 História do Leandro Ladeira
0( Partida ou 
separação
Exemplos:
Exemplos
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 24 - Gatilhos Mentais - História (jornada do 
heroi)
Módulo 02 Copy Tradicional
{
{
{
{
{
{
{
{
{
{
{
Encontra os negócios digitais e ter sucesso
Abre mão do negócio para ensinar
{zy Caminho de volta
{{y Recusa ao Retorno
{y Resgate Mágico
{¨y Cruzando o Limiar de Retorno
{¸y Domínio de Dois Mundos
{Åy Liberdade para Viver
Îy Abordagem da Caverna Oculta
ñ O carrinho abrindo e não vendendo 
nada. VendeÝ
ñ Sucesso, sucesso, sucesso. Fracasso.
y Provação Suprema
Lançar o perpétuo
Sucesso total. Maior do digital
ñ Queria voltar para meu mundo do marketing
ñ Vendi a empresa
ñ Depressão pós vend:
ñ Aposentar e ter escola de mergulho
ñ Ruy fala que nem sei mergulhar
ñ Começo o desafio de ensinar o VTSD
ñ Grande sucesso do VTSD
ñ Trabalho com o que am
ñ Tem proposito no trabalh
ñ Boa relação com a Cátia
y Recompensa (ou Conquista do Elixir)
´± Iniciação
¼± Retorno
Í História  Cátia Damasceno
Í História Tonny Robins
Exercicios
01
02
Assista um dos filmes mencionados
Escreva sua Jornada


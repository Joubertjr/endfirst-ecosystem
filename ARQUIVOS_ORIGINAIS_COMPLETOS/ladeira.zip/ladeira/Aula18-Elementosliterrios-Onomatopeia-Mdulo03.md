Apostila aula 0
Aula 18
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Onomatopeia

Módulo 03 LightCopy 
Aula 18- Elementos literários - Onomatopeia
O que é?
A onomatopeia é uma figura de linguagem que 
imita sons da natureza, de objetos, de animais ou 
de ações humanas por meio de palavras. 
Exemplos comuns incluem "tic-tac" (relógio), 
"miau" (gato) e "boom" (explosão).
Os alunos aprenderão a identificar e utilizar 
onomatopeias em textos, compreendendo como 
essa 
figura 
de 
linguagem 
enriquece 
a 
comunicação ao criar efeitos sonoros que tornam 
a leitura mais expressiva e envolvente.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
2 A onomatopeia é uma figura de linguagem que reproduz sons ou 
ruídos por meio de palavras. Ela é usada para imitar sons da 
natureza, do ambiente, de objetos ou de ações humanas, criando 
uma conexão sensorial entre o texto e o leitor ou ouvinte.
2 Parto natural sem anestesia
2 Meninas, compartilhem nos stories. Vídeo de utilidade pública
2 5 Erros Comuns Que as Mulheres Cometem na Cama 
Exemplos
2 Acordou às 6h ... Chuplin 
Vai tomar seu café ... Chuplin 
Foi pra academia ... Chuplin 
Começa o dia de trabalho ... Chuplin 
Amoço ... Chuplin 
Passeio com o cachorro ... Chuplin 
Chuplin, Chuplin, Chuplin 
É o som do sucesso tocando o tempo todo, direto no seu bolso. 
Porque quem trabalha com VTSD, não ouve silêncio - ouve 
ChuPlim. 
Se a sua vida anda silenciosa demais, clique aqui. Vamos encher 
seu dia de ChuPlim¬
2 Tchiii. A panela aquece. 
Ploc. O leite condensado começa a contar sua história. 
Scrap, scrap. O chocolate conversa enquanto você mexe. 
Plof. Ele chega no ponto perfeito.  
E então vem o granulado: crunch. 
O cliente morde: hummm. 
E você escuta a melhor parte: Ca-ching! - o som do dinheiro 
entrando no bolso.  
Brigadeiros não são só doces, são diálogos. 
E, se você quer que eles falem alto na sua cozinha e na sua conta 
bancária, o curso 
"Brigadeiro com Lucro" é pra você.
Módulo 03 LightCopy 
Aula 18- Elementos literários - Onomatopeia

MARKETING DE PREMISSAS
Exercícios
01
02
03
D Complete a frase: 
Substitua os espaços em branco por uma onomatopeia adequada!
? O cachorro latiu bem alto: "______!G
? A porta se fechou com um forte "______"!
? O telefone tocou várias vezes: "______! ______!"
D Criação de frases: 
Escreva três frases utilizando onomatopeias para representar 
diferentes sons do cotidiano.
D História sonora: 
Crie uma pequena história com, no mínimo, cinco onomatopeias. 
Seja criativo e use palavras que transmitam sons de maneira 
divertida e envolvente.
Módulo 03 LightCopy 
Aula 18- Elementos literários - Onomatopeia


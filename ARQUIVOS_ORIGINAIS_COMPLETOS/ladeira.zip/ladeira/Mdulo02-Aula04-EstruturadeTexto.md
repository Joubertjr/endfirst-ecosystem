Apostila au
Aula 04
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Estrutura 
de Texto

Apostila aula 01 
Aula 04 - Estrutura de Texto
Módulo 02 Copy Tradicional
O que é?
É um conjunto de estruturação de texto que 
contém 
3 
partes 
principais 
de 
textok
SF Introdução: Apresenta o tema e capta a 
atenção 
do 
leitor, 
utilizando 
curiosidade, 
conflito e contexto. Contém elementos como 
tese, contexto, motivação, curiosidade e apelos
PF Desenvolvimento: 
Exposição 
e 
aprofundamento 
das 
ideias 
principais, 
organizadas em parágrafos com tópicos frasais, 
argumentos, exemplos e evidências. Inclui o 
clímax, que antecede o desfechos
oF Conclusão: Finaliza o texto, conectando as 
ideias desenvolvidas.
Objetivos da Aula
Nessa aula, você vai aprender a estruturar um 
texto, começando pela introdução para captar a 
atenção do leitor, desenvolvendo ideias claras com 
argumentos e exemplos, e concluindo de forma 
eficaz. Também serão abordados conceitos de 
coesão, coerência e análise de textos.
Tópicos Principais
O que é o Estrutura de Texto
Introdução
Desenvolvimento
Conclusão  
Regras Importantes  
Coesão e Coerência  
Exercícios  
1
2
3
4
5
6
7

Conteúdo da Aula
Estrutura básica
MARKETING DE PREMISSAS
Objetivo
G Apresentar o tema e captar a atenção do leitor8
G Foco em elementos como curiosidade, conflito e contexto8
G Componentes: tese, contexto, motivação, curiosidade e 
apelo.
Foco em elementos
G curiosidade,X
G conflito_
G contexto.
Componentes
G Tese, contexto,X
G Motivação,X
G Curiosidad
G Apelo.
Introdução
Apostila aula 01 
Aula 04 - Estrutura de Texto
Módulo 02 Copy Tradicional
{
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 04 - Estrutura de Texto
Módulo 02 Copy Tradicional
Objetivo
T Expor e desenvolver as ideias principais.
Componentes
T Parágrafos com tópicos frasais, argumentos, exemplos e 
evidências.
Detalhe
T Detalh
T Diálog
T Sumári
T Cênico
Desenvolvimento
{
{
Objetivo
T Sintetizar o conteúdo e apresentar uma reflexão final
Componentes
T Resumo dos pontos principais,²
T Reafirmação da tes
T Considerações finais
Conclusão
{
{
Inesperado
{
{
Clímax
T Antecipação para o desfecho
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 04 - Estrutura de Texto
Módulo 02 Copy Tradicional
Tenha uma única ideia
f Se mantenha na ideia centraV
f Mostrar várias funçõeK
f Mostrar uma única funçãM
f Trazer uma única reflexão
Universo Cognitivo
f Se mantenha na narrativa
Regras Importantes
{
{
Vale lembrar
f Escreva bêbadM
f Edite sóbreM
f Planejamento do textM
f Leitura crítica e feedback
f Ler em voz alt¨
f Ler para alguém
{
{
Coesão
f Definição: Ligação entre palavras, frases e parágrafos¿
f Elementos: Conectores, pronomes, elipses.
Coerência
f Definição: Lógica e sentido do texto como um todo¿
f Elementos: Sequenciamento lógico de ideias, clareza, 
pertinência.
Coesão e Coerência
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 04 - Estrutura de Texto
Módulo 02 Copy Tradicional
Vamos Praticar?
01
Escreva uma Introdução Impactante. 
Escolha um tema e escreva uma introdução de 5 a 7 
linhas usando curiosidade, conflito, contexto, tese e 
apelo.
02
Desenvolva com Argumentos e Evidências 
Escreva dois parágrafos de desenvolvimento. 
Apresente um argumento com exemplo e depois 
adicione detalhes ou um ponto de vista alternativo.
03
Conclua e Verifique a Coerência 
Conclua o texto resumindo os pontos principais e 
reforçando a tese. Revise a coesão e coerência do 
texto.


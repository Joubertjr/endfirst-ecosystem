Apostila
Aula 09
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
Analise de 
Página de 
Vendas
03

Módulo 04 Formatos de Copy
Aula 9 - Analise de Vídeo de vendas VSL 03
O objetivo desta aula é ensinar como construir 
uma página de vendas eficaz utilizando técnicas 
de copywriting voltadas para conversão. A aula 
destaca 
como 
usar 
linguagem 
persuasiva, 
apresentar 
provas 
sociais 
e 
organizar 
os 
elementos da página com intenção estratégica, 
sempre buscando educar o público e despertar 
curiosidade, em vez de prometer resultados 
exagerados.
Tópicos Principais
1
Pontos-chaves
2
Resumo Geral da aula
Objetivos do aula

Conteúdo do módulo
MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 9 - Analise de Vídeo de vendas VSL 03
Pontos-Chaves
_ Promessa Educacional vs. Promessa Mirabolante
A aula enfatiza a importância de oferecer uma promessa educacional 
clara, em vez de apelos exagerados. A ideia é gerar curiosidade e 
aumentar o nível de consciência do público.
 Ao invés de prometer "vender 10 vezes mais", a sugestão é usar 
"qual argumento aumenta sua chance de conversão"
 Ao focar em ensinar como fazer um bom fechamento de vendas, 
evita-se cair na armadilha de prometer enriquecimento imediato.
_ Uso de Perguntas e Quebra de Objeções
A estrutura da página de vendas deve incluir perguntas que o público 
já faz com frequência e respostas que desarmam objeções comuns.
 Perguntas como “quanto tempo demora para ter resultado?” e 
“qual o investimento para começar?” são apresentadas logo no 
início
 Objeções como “funciona mesmo sem ter audiência?” são 
quebradas com explicações claras e exemplos práticos.
_ Prova Social Estratégica e Segmentada
Os depoimentos devem ser escolhidos com critério para gerar 
identificação com diferentes perfis de público.
 Um depoimento de uma mulher que faturou R$ 4 mil sem gastar 
com tráfego, atendendo ao perfil iniciante
 Outro depoimento de alguém que comprou um apartamento aos 
24 anos, gerando aspiração e validação emocional.

MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 9 - Analise de Vídeo de vendas VSL 03
Resumo Geral da Aula
Nesta aula, foi apresentada a lógica de construção de uma página de 
vendas que realmente converte. Discutiu-se como usar a copy de 
forma estratégica, priorizando uma abordagem educacional e 
centrada na curiosidade do público. Foram abordados tópicos como 
estrutura das sessões da página, escolha de depoimentos com base 
no avatar ideal, e a importância de responder dúvidas reais dos 
potenciais clientes. A aula também destacou a necessidade de testar 
diferentes versões da página (testes A/B) e como ajustar a copy 
conforme o nível de consciência do público-alvo.


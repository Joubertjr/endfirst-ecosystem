Apostila aula 0
Aula 29
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Set UP + 
Punch Line

Módulo 03 LightCopy 
Aula 29- Elementos literários - Set UP + Punch Line
O que é?
O humor stand-up segue uma estrutura clássica 
chamada Set-Up e Punchline. O Set-Up apresenta 
o contexto da piada, criando uma expectativa no 
público. O Punchline, por sua vez, quebra essa 
expectativa de forma inesperada, gerando humor. 
Esse modelo é eficaz porque cria tensão e 
surpresa, dois elementos essenciais para provocar 
risadas.
Os 
alunos 
aprenderão 
sobre 
a 
estrutura 
fundamental do humor stand-up, entendendo 
como o Set-Up e o Punchline funcionam para criar 
expectativa e surpresa. Além disso, irão identificar 
exemplos e praticar a criação de piadas nesse 
formato.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
N A estrutura mais clássica do humor stand-up é o Set-Up seguido 
do Punchline. Esse modelo é amplamente usado por humoristas 
brasileiros e internacionais, porque cria expectativa e surpresa, 
dois pilares fundamentais do humor.  
Set-Up (Preparação):  
A parte inicial da piada. É onde o comediante apresenta o cenário 
ou contexto.}O objetivo é construir uma expectativa no público, 
levando-o a imaginar uma direção específica.  
Punchline (Conclusão):  
O desfecho inesperado que quebra a expectativa criada no set-up. 
É onde o humor aparece, geralmente por meio de contraste, 
absurdo, exagero ou subversão da lógica.  
Por Que Funciona? 
Cria Tensão: O set-up prepara o público, criando curiosidade ou 
tensão. 
Surpreende: O punchline quebra essa tensão de forma inesperada, 
gerando risadas.
Exemplos
N E pode ser presidente também
N Não esquecem dessa minha habilidade
N Quem é que dá jeito para tudo?
N Gente e essa blogueira que passou pela @jkesteticaavancada e aderiu...
N CURIOSIDADE onde surgiu o sistema "cashback"
N TÁ TUDO DO AVESSO, PAE. 
N Peraí 
 - Quando estou confuso…
N Vc sabe que a mulher fala??
N Quem me segui! Vai receber um notificação misteriosa
Módulo 03 LightCopy 
Aula 29- Elementos literários - Set UP + Punch Line

MARKETING DE PREMISSAS
( Se ocê não mrcar ninguém nesse vídeo, só vai poder treinar às 18h
( Eu já fui corno
( Sabe quem é esse homem? Não tenho ideia, mas preste um...
( Procede ? 
( Um absurdo o que aconteceu nessa corrida de Uber
Módulo 03 LightCopy 
Aula 29- Elementos literários - Set UP + Punch Line

MARKETING DE PREMISSAS
Exercícios
01
02
03
T Identificação da Estrutura 
Leia as seguintes piadas e destaque o Set-Up e o Punchline em 
cada uma(
& "Eu sou tão azarado que fui atropelado por uma ambulância."
& "Meu professor disse que a matemática abre portas. Só não me 
avisou que eram as do desespero."
T Criando sua Piada 
Escreva uma piada seguindo a estrutura Set-Up e Punchline. 
Lembre-se de criar uma expectativa no Set-Up e surpreender no 
Punchline.
T Reescrevendo Piadas 
Pegue uma piada conhecida e tente reescrevê-la mudando o Set-Up 
ou o Punchline, criando uma nova versão. Depois, compartilhe com 
um colega e veja se ele achou engraçado!
Módulo 03 LightCopy 
Aula 29- Elementos literários - Set UP + Punch Line


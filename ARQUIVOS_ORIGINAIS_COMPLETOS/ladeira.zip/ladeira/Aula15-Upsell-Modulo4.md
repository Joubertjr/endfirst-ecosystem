Apostila
Aula 15
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
Upsell

Módulo 04 Formatos de Copy
Aula 15 - Upsell
Explicar o que é um upsell e como utilizá-lo 
estrategicamente 
para 
oferecer 
novas 
oportunidades de valor ao cliente após uma 
compra, 
apresentando 
abordagens 
eficazes, 
momentos ideais para aplicação e formas de 
aumentar a taxa de conversão com ofertas 
complementares.
Tópicos Principais
1
Anatomia discursso de upsell
Objetivos do aula

Conteúdo do módulo
Anatomia discursso de upsell
+ Confirmação de compra
+ Alerta de algo a mais
+ Reforço positivo
+ Algo a mais
+ Vantagem
+ Aonde fazer upsell
h Sua compra foi confirmada
h Mentoria
h One click upselw
h OTO
h Sem OT
h Com OTO
h Área de membros
h Link no ebook, planilha, etc
h Mentoria
h Serviço
h Outros produtos
h VTSD
h 6%
h 36%
h Antes de acessar o produto, leia com atenção
h Você está mais perto de (promessa), mas tenho outras 
maneira de te ajudar
h Para você que é cliente, tenho uma vantagem a mais
h Página de confirmação 
de compra
h Entrega de produto
h Sequência de e-mail, whatsapp e manychat
h Abordagem comercial
h Anúncios remarketing
h Nova oferta
h Mais rápid:
h Mais acompanhament:
h Faço para voc;
h Mais opções
Módulo 04 Formatos de Copy
Aula 15 - Upsell
MARKETING DE PREMISSAS


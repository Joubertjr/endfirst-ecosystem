Apostila au
Aula 20
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Gatilhos 
Mentais 
Curiosidade

Apostila aula 01 
Aula 20 - Gatilhos Mentais - Curiosidade
Módulo 02 Copy Tradicional
O que é?
O gatilho mental da curiosidade é uma técnica 
usada para despertar o interesse e o desejo de 
saber mais sobre algo.
Ensinar como usar o gatilho mental da curiosidade 
para 
despertar 
o 
interesse 
do 
público, 
aproveitando o desejo natural de buscar respostas 
e resolver mistérios. Você vai aprender a aplicar 
essa técnica de forma eficaz em diferentes tipos 
de conteúdo, evitar erros comuns que "quebram" o 
interesse e identificar as melhores estratégias para 
engajar pessoas em formatos variados, como 
palestras, redes sociais e anúncios.
Tópicos Principais
Conceito
Jeito Certo
Jeito errado
Exercícios
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 20 - Gatilhos Mentais - Curiosidade
Módulo 02 Copy Tradicional
CONCEITO
Gatilho mental da curiosidade
e Ele se baseia no desejo humano natural de buscar respostas 
para perguntas ou resolver mistérios.
 Ação: Antes do lançamento oficial, Steve Jobs deu uma 
palestra na Macworld Conference & Expo, em janeiro de 
2007, e começou com a famosa frase: "Hoje, a Apple vai 
reinventar o telefone." No início da apresentação, Jobs 
mencionou três produtos: um iPod widescreen com controle 
por toque, um telefone revolucionário e um comunicador de 
Internet inovador. Ele repetiu essa lista várias vezes, criando 
um suspense em torno do que estava por vir.  
Depois de alguns minutos, ele revelou que esses três 
produtos eram, na verdade, um único dispositivo: o iPhone. 
Ao construir a expectativa e a curiosidade em torno de um 
produto que ninguém havia visto antes, Jobs conseguiu 
manter a audiência engajada e aumentar a excitação para a 
revelação final.
BuzzFeed implementou uma estratégia de conteúdo que usava 
consistentemente o gatilho mental da curiosidade em seus 
títulos e chamadas para ação. Alguns exemplos de títulos 
incluíam:“
{
Conteúdo da Aula
JEITO CERTO
Lista de curiosidade específica
Caso Apple
{
Antecipar
{
Clickbait / fofoca / mistério
{
 Caso Buzzfeed

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 20 - Gatilhos Mentais - Curiosidade
Módulo 02 Copy Tradicional
3 Arquivos
Exemplo Instagram
{
{
c Exemplo 02
c Exemplo 03
c Exemplo 04
”Você não vai acreditar no que este cachorro fez…”  
“Aqui estão 19 fatos sobre pizza que vão explodir sua mente!”  
“O que acontece a seguir é chocante!”  
BuzzFeed gerou aproximadamente 200 milhões de visitas 
mensais apenas em seu site principal. Cerca de 75% dessas 
visitas vinham de redes sociais, especialmente Facebook, onde 
os títulos curiosos eram altamente compartilháveis.“Ele apenas 
quis dançar em um vídeo. O que aconteceu a seguir deixou o 
público sem palavras.”“Ela pensou que sabia o que estava 
fazendo. Então, a verdade veio à tona.”“Esta criança fez algo 
incrível na escola. Você nunca vai adivinhar o que foi.”
Ò Exemplo Copy
Ò LINK
Assunto: Download liberado 
Assunto: Cuidado ao baixar esse arquivo  
Estou liberando 3 arquivos em PDF. Talvez os três arquivos mais 
importantes do seu ano, quem sabe, da sua vida.  
Baixar PDF 1 
Baixar PDF 2 
Baixar PDF 3  
É impossível continuar levando a vida normal depois de ler isso. 
Cuidado, pense 2x antes de ler os arquivos.  
Abraços, 
Leandro Ladeira  
P.S. Lembrando que estamos nos últimos dias da promoção 
especial do VTSD. Segunda-feira, dia 23 vai ler a mensagem: 
promoção encerrada.

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 20 - Gatilhos Mentais - Curiosidade
Módulo 02 Copy Tradicional
Exercicios
01
Aplique o que você aprendeu hoje em todos esses 
pontos abaixo:  
- Palestra 
- Pitch 
- Anúncio 
- Vídeo de vendas 
- Live de conteúdo 
- Carrossel 
- Reels? 
- Newsletter 
- Artigo de Linkedin 
- Twitter
02
Tente encontrar em 3 influenciadores da sua 
escolha, quais são os gatilhos que eles usam e 
veja onde pode ser explorado da melhor maneira.
JEITO ERRADO
» Contar o final da novela do primeiro capitulo
{


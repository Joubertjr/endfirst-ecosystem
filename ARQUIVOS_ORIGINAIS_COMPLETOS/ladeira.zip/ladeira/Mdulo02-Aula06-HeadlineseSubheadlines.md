Apostila au
Aula 06
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Headlines e
Subheadlines

Apostila aula 01 
Aula 06 - Headlilnes e Subheadlines
Módulo 02 Copy Tradicional
O que é?
9 Headline: Título principal, responsável por 
captar a atençãoA
9 Subheadline: Subtítulo que dá suporte à 
headline, oferecendo mais informações ou 
detalhesA
9 Esses dois elementos são fundamentais para 
atrair e manter o interesse do público, seja em 
anúncios, páginas de vendas ou artigos.
Objetivos da Aula
O objetivo é mostrar a importância das headlines e 
como elas podem ser adaptadas a diferentes 
estratégias e tipos de comunicação, para garantir 
que o público se engaje com a mensagem desde o 
início.
Tópicos Principais
O que é Headline e Subheadline
Headline - Copia e Cola
Tipos de Headline
Exercícios  
1
2
3
4

Conteúdo da Aula
Estrutura básica
MARKETING DE PREMISSAS
Importante
? A frase mais importante de toda copy é a primeira.
Headlines - Copia e Cola
? Baixe o material - Clicando Aqui
Apostila aula 01 
Aula 06 - Headlilnes e Subheadlines
Módulo 02 Copy Tradicional
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 06 - Headlilnes e Subheadlines
Módulo 02 Copy Tradicional
P MedU
P DiretD
P HistóriD
P ComparaçãU
P Problema Solução
Ex: Descubra o poder da mulher que pratica o pompoarismo.
Ex: Você abrir uma turma promocional do VTSD.
Ex: The Wall Street Journal: Os Dois Jovens
Ex: O maior risco dos negócios digitais.
Ex: Quando o sexo é bom ele representa 20% de um relacionamento, 
quando é ruim, representa 90%.
Ex: Nenhum relacionamento sobrevive sem sexo.
Ex: Mais da metade dos empregos e empresas de hoje vão deixar de existir 
nos próximos 5 anos.
{
Ex: Se sua libido está baixa, experimente estimular o períneo.
Ex: Se suas campanhas não convertem, experimente o marketing 
de permissões.
{
{
{
Ex: Eles Riram Quando Eu Sentei Ao Piano… Mas Quando Eu Comecei a Tocar!
Ex: Tudo deu errado e eu dei um murro na mesa.
Ex: Você tem 400 reais para me emprestar?
Ex: Meu pai me obrigou a trabalhar quando eu tinha 15 anos.
{
Tipos de Headlines
P NotíciD
P CuriosidadG
P ListD
P ComU
P ProvD
P ClickbaiC
P Benefício claro
Ex: Hotmart recebe aporte de 845 milhões
Ex: 6 formatos de produtos que mais venderam em 2024
Quem trabalha no digital ganha de 3 a 12x mais do que quem 
trabalha no mercado tradicional.
Ex: Como realizar movimentos de contração durante a relação 
Ex: Como criar um produto que vende muito - Promesa mais vazia 
Ex: Como reduzir o custo do CPA pela metade - Promessa específica
Ex: Arrumei uma confusão dentro do avião.
Ex: Meu pai me obrigou a trabalhar de office boy quando eu tinha 15 anos.
Ex: Sua encomenda chegou.
Ex: O Fim do Brasil: Prepare-se para a Crise Que Está Por Vir.
Ex: Você pode não perceber, mas ela está praticando pompoarismo.
Ex: Quando um casal com 2 filhos gasta para viver bem numa capital
{
{
{
{
{
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 06 - Headlilnes e Subheadlines
Módulo 02 Copy Tradicional
Vamos Praticar?
01
Headline 
Utilizando o conteúdo da aula, escolha um produto 
ou serviço que você gostaria de promover e crie 
três headlines diferentes. Use como base os tipos 
de headlines da aula: Curiosidade, Lista e Benefício 
claro.
02
Subheadline 
Escolha uma das suas headlines criadas no 
Exercício 1.
Crie uma subheadline que ofereça mais 
informações e convença o leitor a continuar.
03
Tipos de Headline 
Escreva a mesma headline escolhida na questão 2 e 
agora adapte ela para o tipo “Problema solução”


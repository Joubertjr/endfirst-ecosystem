Apostila
Aula 01
Módulo 4  Formatos de Copy
MARKETING DE PREMISSAS
  Vídeo de 
vendas VSL

Módulo 04 Formatos de Copy
Aula 01 - Vídeo de Vendas VSL
Compreender as principais estruturas de Vídeos 
de Vendas (VSL), explorando modelos clássicos 
como AIDA, P.A.S.T.O.R., VSL de Jon Benson, 
Russell Brunson e Leandro Ladeira, a fim de 
construir scripts persuasivos que gerem conexão 
emocional, entreguem valor e incentivem a ação 
do público de forma estratégica e eficaz.
Tópicos Principais
1
Modelos Clássicos
3
Importante 
2
Disclaimer
Objetivos do aula

Conteúdo do módulo
 VSL de Jon Benson
 P.A.S.T.O.R. de Ray Edward
. Estrutura
. Estrutura
. 1. Big Idea (Abertura Forte) → Um conceito poderoso que 
prende a atenção.e
. 2. Proposição de Problema → Apresentação da dor que o 
público sente.e
. 3. Conexão e Identificação → Mostra que o criador do VSL 
passou pelo mesmo problema.e
. 4. Solução (Única e Específica) → Introduz a oferta como a 
solução ideal.e
. 5. Prova e Credibilidade → Depoimentos, dados e validação 
social.e
. 6. Oferta e Bônus → Explica os benefícios da compra.e
. 7. Escassez e Urgência → Limitação de tempo e 
quantidade.e
. 8. Call to Action (Chamada para Ação) → Direciona o 
usuário para comprar
. P (Problem - Problema) → Explica a dor do cliente.e
. A (Amplify - Amplificação da Dor) → Mostra o que acontece 
se ele não resolver o problema.e
. S (Story & Solution - História e Solução) → Apresenta a 
solução.e
. T (Testimony - Prova e Autoridade) → Mostra evidências de 
que funciona.e
. O (Offer - Oferta Irresistível) → Explica os benefícios da 
compra.e
. R (Response - Resposta ou Chamada para Ação) → Finaliza 
com CTA forte
Modelos Clássicos
Módulo 04 Formatos de Copy
Aula 01 - Vídeo de Vendas VSL
MARKETING DE PREMISSAS

MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 01 - Vídeo de Vendas VSL
< VSL de Russell Brunson
< AIDA de Elias St. Elmo Lewi
Y Estrutura
] Estrutura
] Recomendado
Y 1. Hook (Gancho) → Chama atenção com uma promessa 
impactante.
Y 2. Epiphany Bridge (Ponte da Epifania) → Conta uma 
história de transformação.
Y 3. O que você Aprendeu? → Explica o conhecimento 
adquirido.
Y 4. Como Resolver o Problema? → Apresenta a solução e o 
produto.
Y 5. Stack Offer (Oferta Irresistível) → Mostra valor extra 
(bônus, garantias, etc.).
Y 6. Scarcity & Urgency (Escassez e Urgência) → Motiva a 
compra imediata.
Y 7. Call to Action (Chamada para Ação) → Direciona a 
compra.
Y 1. Atenção (Attention) → Chama a atenção logo nos primeiros 
segundos.
Y 2. Interesse (Interest) → Mantém o espectador engajado, 
explorando um problema relevante.
Y 3. Desejo (Desire) → Cria desejo pela solução, mostrando 
benefícios e provas.
Y 4. Ação (Action) → Finaliza com uma oferta irresistível e uma 
chamada para
Y Infoprodutos
Y Ticket
Y Consciência
Y de 10 minutos 
a uma hora
Y Tempo
Y Referência específica
Y Cursos
Y Mentorias
Y Comunidades
Y Apps e SaaS*
Y Se ticket baixo, menos tempo
Y Se ticket alto, mais tmpo
Y Se baixa consciência, mais tempo
Y Se alta consciência, menos tempo
Y Se baixa autoridade, mais tempo
Y Se alta autoridade, mais tempo
Y de R$300,00 a 2.500,00
Y  Produtos de baixa e alta consciência
Y Panelas Polishop

MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 01 - Vídeo de Vendas VSL
9 VVV de Leandro Ladeira
D 1. Promessa com QFD
D Estrutura
D 2. Pra quem éZ
D 3. ProvaZ
D 4. História
D 5. Conteúdo
D 6. Explicação da oferta
D 7. CTA emocional
D Q
D F
D D
 Objeto de desejo
 Como
 Mecanismo único (F)
 Por que
 barriga de tanquinho
 Proscedência do método
 Paliativo
 Resultado rápidí
 Alívio imediatoê
 Pilula mágica
 Jeito errado
 Entregávei
 Tempo de acessí
 Bônu
 Garanti
 Ancorage
 Preço
 Jeito Certo
 Sempre que então
 Dieta estrogênica
 Contra-
intuitivo
 Autoestimaê
 Saúdeê
 Aceitaçãoê
 Performanceê
 Parceiro
 Comumê
 Tradicionalê
 Mainstream

MARKETING DE PREMISSAS
Módulo 04 Formatos de Copy
Aula 01 - Vídeo de Vendas VSL
; Infoprodutos
; Ticket
; Consciência
; Tempo
; Cursos_
; Mentorias_
; Comunidades_
; Apps e SaaS*
; de R$300,00 a 2.500,00
; Produtos de baixa e alta consciência
; de 10 
minutos  
uma 
hora
; Se ticket baixo, menos 
tempo_
; Se ticket alto, mais tmpo_
; Se baixa consciência, mais 
temp
;  Se alta consciência, menos 
tempo_
; Se baixa autoridade, mais 
tempo_
; Se alta autoridade, mais 
tempo
; Recomendado
; Referências específicas
Disclaimer
Importante
; O melhor VSL do mundo, perde para uma 
estrutura de marketing eficiente.
; A parte mais importante de 
uma copy é a primeira frase 
; Filtro de copy é importantíssimo
; Depoimentos ruins
; Falar bem de si 
mesmo demais 
passa 
insegurança
;  Emoção_
; Razão
; Repetições de promessas e de 
argumentos de autoridades
; Explicações intuitivas demais
; Tirar tudo o que não ajuda
; Lembrar sempre
; Bom senso
; ex


E-MAILS DE CARRINHO 
 
 Acaba amanhã | VTSD 
​
Copy Aprovada  Agendado 
 
Segmentação  
Envio  
Tipo de envio  
Lista L11 - VTSD 
23 de mar. de 2025 09:00 
 Broadcast 
 
Título A 
Amanhã acaba a oferta especial do Novo VTSD. 
Preview A 
O depois nunca chega. Quem chega é você, quando decide agir. 
 
Texto do e-mail:  
A gente sempre acha que vai ter mais tempo depois. 
Depois eu começo a dieta. Depois eu vou à academia. Depois eu leio aquele livro.  
Depois eu ligo pros meus pais. Depois eu brinco com meus filhos.  
Depois eu saio com meu esposo. Depois eu me desculpo com minha esposa. Depois 
eu visito meus amigos.  
Depois eu começo. Depois eu tento. Depois eu penso em mim. 
Mas o depois… vira nunca. Porque o depois vem carregado de distrações, 
imprevistos e novas prioridades. E o que era importante, vai ficando pra trás.

Você já pensou quantas coisas você já quis fazer e não fez? Quantas oportunidades 
escorreram pelos seus dedos porque você preferiu deixar pra depois? 
A verdade é que o depois nunca chega. Quem chega é você, quando decide agir. 
Então hoje, agora, você tem duas escolhas: 
1. Fechar esse e-mail e continuar deixando pra depois o seu desejo de mudar sua 
realidade.​
2. Fazer algo pelo seu futuro e tomar a decisão de transformar a sua vida com o 
digital e Novo VTSD. 
[Quero fazer algo por mim] [Prefiro deixar pra depois] 
Não deixe essa chance passar. Porque se você não fizer agora… talvez nunca faça. 
Abraços, 
Leandro Ladeira 
 
Importante: Se você tem alguma dúvida sobre a oferta do novo VTSD, entre em 
contato com meu time comercial clicando aqui. Eles estão a postos pra te ajudar. 
 
Último Dia | VTSD 
​
Copy Aprovada  Agendado 
 
Segmentação  
Envio  
Tipo de envio  
Lista L11 - VTSD 
24 de mar. de 2025 09:00 
 Broadcast 
 
Título A 
E se der certo? 
Preview A Hoje é o último dia para aproveitar a oferta especial do VTSD.

Texto do e-mail:  
Se der errado, você quebrou a cara.  
Se der errado, você perdeu dinheiro.  
Se der errado, você passou vergonha.  
Se der errado, na pior das hipóteses, você aprendeu muito. 
Se der errado, você pode tentar de novo. 
 
Mas e se der certo? 
 
Se der certo, muda o horário que seu dia começa. 
Se der certo, muda a casa onde você mora.   
Se der certo, muda a escola que seus filhos estudam.  
Se der certo, muda o hospital que você e sua família vão ser atendidos. 
Se der certo, muda o tempo que você tem com quem realmente importa.  
Se der certo, muda o restaurante que você come.  
Se der certo, muda o lugar onde você passa suas férias. 
Se der certo, muda o carro que você dirige. 
Se der certo, muda seu presente e seu futuro. 
 
Se der errado, muda pouco. 
Mas se der certo, muda muito.  
 
Hoje é o último dia para se inscrever no Venda Todo Santo Dia aproveitando a oferta 
especial. Clique no link abaixo e garanta sua vaga. 
 
[Eu vou fazer dar certo] 
 
Abraços, 
Leandro Ladeira 
 
Importante: Se você tem alguma dúvida sobre a oferta do novo VTSD, entre em 
contato com meu time comercial clicando aqui. Eles estão a postos pra te ajudar.

E-MAILS DE CONVITE | L10 - CURSO GRATUITO “COMO ENTRAR NO DIGITAL” 
 
Convite 1 - Como entrar no digital 
Para enviar 
Convite 2- Se você ler isso antes dos 50 
Para enviar 
Convite 3 - Segunda Chance 
Para enviar 
Convite 4 - Oferta especial do VTSD 
Para enviar 
[01] - Convite 1 - Como Entrar no Digital 
Copy Aprovada  Para enviar 
 
Segmentação  
Envio  
Tipo de envio  
Para base geral 
26 de fev. de 2025 
10:00 
Broadcast 
  
Título A 
Como entrar no digital 
Preview A 
Quem trabalha com o digital ganha de 3 a 12x mais do quem 
trabalha no mercado tradicional. 
  
Objetivo: 
Falar sobre o conteúdo do curso gratuito.

Texto do e-mail:  
 
O mercado digital pode parecer um bicho de sete cabeças para muita gente, 
mas conseguir dominá-lo e ganhar de 3 a 12 vezes mais do que no mercado 
tradicional, não é tão complexo assim. 
 
Para provar isso, resolvi fazer um curso gratuito de Como Entrar no Digital. E a 
programação vai ser a seguinte: 
 
Aula 1 - Oportunidades escondidas no digital (Ao vivo, 10/03 às 19h) 
●​ Vou te mostrar os produtos digitais que mais vendem em cada nicho, as 
profissões que vão desaparecer nos próximos anos e como aproveitar isso e 
um estudo com as tendências do marketing digital para 2025. 
Aula 2 - Criando seu produto digital do ZERO (Ao vivo, 12/03 às 19h) 
●​ Você vai criar um plano de ação: desde a escolha do seu nicho e criação do seu 
produto, passando pela estratégia para fazer sua primeira venda. 
Aula 3 - Eliminando obstáculos (Ao vivo, 14/03 às 19h) 
●​ Na última aula, vou te mostrar os erros mais comuns que a maioria das 
pessoas cometem e as fazem perder tempo e dinheiro. Para evitar isso, você 
terá acesso a modelos validados de anúncios, páginas e estratégias que 
trazem resultado em cada nicho. 
 
Se você quiser aumentar as chances de ser uma das pessoas que tem ganhado 
muito dinheiro com a internet, faça sua inscrição no link abaixo. 
 
[Quero entrar no digital] 
​
Te vejo no dia 10 de Março.​
 
Abraços, 
Leandro Ladeira.

[02] - Convite 2 - Se você ler isso antes dos 50 
Copy Aprovada  Para enviar 
 
Segmentação  
Envio  
Tipo de envio  
Para base geral 
28 de fev. de 2025 
10:00 
Broadcast 
  
Título A 
Se você ler isso antes dos 50, você é uma pessoa de sorte. 
Preview A 
"Estou brigando com o frio e com as dores nas costas para sair 
da cama. Me arrependo de quando tinha 50 e achava que 
estava velho demais para começar" 
  
Texto do e-mail:  
 
“Hoje é dia 23 de junho de 2054, 5h20 da manhã. Estou brigando com o frio e com 
as dores nas costas para sair da cama. Me arrependo de quando tinha 50 e achava 
que estava velho demais para começar. 
 
Aos 76 anos, tenho que me levantar a essa hora e trabalhar, para complementar a 
renda. O INSS quebrou em 2044. 
 
Graças a Deus o Uber ainda manteve alguns carros não autônomos para agradar 
clientes hipsters”. 
 
Essa é uma peça de ficção, mas qualquer semelhança com o futuro da sua realidade 
não é mera coincidência. 
 
Aumente sua renda com produtos digitais, seu futuro agradece.

Nos dias 10, 12 e 14 de Março vai acontecer o curso gratuito Como Entrar no Digital. O 
mercado digital tem sido uma alternativa para muitos brasileiros construírem um 
futuro com mais conforto e qualidade de vida. 
 
Quem domina esse mercado pode ganhar de 3 a 12x mais do que quem trabalha no 
mercado tradicional. Se você quer saber como ser uma dessas pessoas, clique no link 
abaixo e se inscreva. 
 
[Quero entrar no mercado digital] 
 
Não brinque com seu futuro, pode custar caro. 
 
Abraços,  
Leandro Ladeira 
 
 
[03] - Convite 3 - Segunda Chance 
Copy Aprovada  Para enviar 
Segmentação  
Envio  
Tipo de envio  
Quem já se 
cadastrou em algum 
lançamento do VTSD 
3 de mar. de 2025 10:00 
Broadcast 
  
Título A 
Sua segunda chance. 
Preview A 
Agora você precisa fazer uma escolha. 
  
Objetivo:

Chamada direta sobre o curso gratuito VTSD com depoimentos do evento e falando 
sobre certificado.  
 
Texto do e-mail:  
  
Você se interessou pelo mercado de infoprodutos e, em algum momento, se 
cadastrou em um dos meus eventos gratuitos, mas por alguma razão não assistiu às 
aulas. 
 
Por isso, o destino te deu uma segunda chance. E agora você precisa fazer uma 
escolha: 
 
1)​  Se inscrever e participar (até o fim) do curso gratuito Como Entrar no Digital. 
Talvez você saia de lá que nem essa galera: 
 
 
 
Além de criar o seu plano de ação para entrar no digital, você também vai receber 
um certificado quando o curso acabar. 
 
[Quero uma segunda chance]

2- Ou você pode ignorar sua segunda chance e postergar mais uma vez a mudança 
de vida que você tanto deseja, enquanto assiste o crescimento de novos 
empreendedores digitais que estão ganhando muito dinheiro com a internet. 
 
[Tô nem aí pro destino] 
 
A escolha é sua, o resultado também. 
 
Abraços, 
Leandro Ladeira 
[04] - Convite 4 - Oferta Especial do VTSD 
Copy Aprovada  Para enviar 
 
Segmentação  
Envio  
Tipo de envio  
Para base geral 
7 de mar. de 2025 
10:00 
Broadcast 
  
Título A 
Oferta especial do VTSD 
Preview A 
Para ter acesso, se cadastre no curso gratuito Como Entrar no 
Digital 
  
Objetivo: 
E-mail direto falando sobre a oferta promocional do VTSD que vai rolar depois do curso 
gratuito. 
  
Texto do E-mail:

Se você estava esperando a próxima oferta especial do VTSD, vim te avisar que ela 
vai acontecer daqui a duas semanas. 
 
Mas antes de abrir o carrinho, vou fazer um curso gratuito de Como Entrar no Digital  
nos dias 10, 12 e 14 de Março. 
 
E no dia 17 de março, às 9h, a oferta especial vai ser lançada. Já adianto que ela 
está completamente diferente de tudo que eu já fiz.​
 
Por isso, você precisa se inscrever no curso gratuito para ter acesso antes de todo 
mundo. É só clicar no link abaixo. 
 
[Quero entrar para o digital]​
​
Vai valer a pena ter esperado. 
 
Abraços, 
Leandro Ladeira


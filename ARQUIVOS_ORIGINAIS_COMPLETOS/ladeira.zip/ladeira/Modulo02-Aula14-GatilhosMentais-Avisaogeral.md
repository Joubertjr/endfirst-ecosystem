Apostila au
Aula 14
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
 Gatilhos 
Mentais

Apostila aula 01 
Aula 14 - Gatilhos mentais
Módulo 02 Copy Tradicional
O que é?
Gatilhos mentais são técnicas de persuasão que 
influenciam o comportamento, tomada de 
decisões e a emoção das pessoas de forma 
subconsciente. Eles são normalmente usados para 
que uma pessoa se envolva em uma ação depois 
de serem induzidas a uma linha de pensamento.
Aprender a usar gatilhos mentais de forma 
honesta, ética, com responsabilidade e bom senso 
para que o seu objetivo de marketing seja 
alcançado 
sem 
abusar 
dos 
poderes 
de 
manipulação da tomada de decisão que esses 
elementos contém. 
Tópicos Principais
Decisões
Comportamento
Livros
Exercícios
  
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 14 - Gatilhos mentais
Módulo 02 Copy Tradicional
Decisões
COMPORTAMENTO
Subconsciente
Viés comportamental
Automáticas
Viés da atenção
 Geralmente, gatilhos mentais ativam uma área do seu 
cérebro de forma inconsciente, levando você a agir de forma 
totalmente emocional.
 Tendencia previsível que afeta o julgamento
 Normalmente, as decisões que você toma são automáticas e 
é extremamente difícil seu cérebro escapar disso.
 Trazer a atenção para algo faz com que todos percebam 
coisas que estavam no subconscientÛ
 Quantos carros azuis você verá hojeÞ
 Observe o ambiente ao seu redoå
 Preste atenção nas dores das suas costas
{
{
{
{
Conteúdo da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 14 - Gatilhos mentais
Módulo 02 Copy Tradicional
Viés do enquadramento
Viés da pressuposição do “Sim”
r Como você apresenta uma informação muda tudf
r Cirurgia com 90% de chance de sucessf
r Cirurgia com 10% de chance de risco
r apresentar opções onde o sim já é certf
r “Você quer tomar banho agora ou depois da janta?{
r “Você quer parcelar essa compra ou pagará à vista?”
r Previsivelmente irraciona¯
r Armas da Persuasãf
r EnviesadoÄ
r Brandwashe©
r A lógica do consumo
{
{
Livros

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 14 - Gatilhos mentais
Módulo 02 Copy Tradicional
Exercicios
01
Viés de comportamento: 
Encontre um colega ou familiar com o qual consiga 
praticar um viés de comportamento. Use os exemplos 
que aprendeu na aula ou desenvolva os seus próprios 
para aplicar e tente coletar informações de como ele 
se comporta.
02
03
Gatilhos no negócio: 
Procure aplicar um gatilho mental em um anúncio ou 
conteúdo que você produziu. Colete informações de 
como o público passa a se comportar quando você 
apresenta as informações de outra maneira, ou 
quando começa a pressupor que o sim já é a 
resposta.
Análise de gatilhos: 
Encontre um produtor de conteúdo do qual você 
goste ou admire. Também pode ser uma marca, uma 
empresa ou instituição. Analise o conteúdo que ela 
produz e tente encontrar gatilhos mentais que ela 
aplicou. Neste momento, não é importante saber 
nomes ou como funcionam, e sim, como seu cérebro 
se comportou ao ser ativado por algum estímulo, por 
alguma fala ou por alguma condição. Lembre-se de 
estar atento a como seu cérebro vai perceber esse 
estímulos, já que eles ocorrem na maioria das vezes 
de forma subconsciente.


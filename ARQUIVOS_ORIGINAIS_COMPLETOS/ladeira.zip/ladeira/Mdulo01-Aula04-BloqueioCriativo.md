Apostila au
Aula 04
Módulo 01 Criatividade
MARKETING DE PREMISSAS
Bloqueio 
Criativo

Apostila aula 01 
Aula 04 - Bloqueio Criativo
Módulo 01 Criatividade
O que é?
Bloqueio criativo é quando alguém não consegue 
acessar sua criatividade para gerar novas ideias 
ou soluções. Isso pode afetar profissionais de 
várias áreas, como escritores, artistas, designers, 
músicos, empreendedores e cientistas.
Objetivos da Aula
Ensinar os passos básicos de como lidar com 
esse problema de maneira leve e direta, 
melhorando os aspectos mais sensíveis da falta 
de criatividade.
Tópicos Principais
O que é?
Por que acontece?  
Exercícios
1
2
3
MARKETING DE PREMISSAS

Apostila aula 01 
Aula 04 - Bloqueio Criativo
Módulo 01 Criatividade
Por que Acontece?
Na maioria das vezes, acontece pelo fato de não 
saber identificar alguns pontos que causam esse 
problema, como os exemplos abaixo:
MARKETING DE PREMISSAS
Gatilhos
Medo do julgamento
Atrelar a criação ao resultado
Atrelar a criação à sua percepção de valor

Stress  
{
{
Vitamina B12
Vitamina D

Apostila aula 01 
Aula 04 - Bloqueio Criativo
Módulo 01 Criatividade
MARKETING DE PREMISSAS
Como Lidar?
Associação Criativa
Observação Criativa
Processo criativo
Associação Livre / Diário
Técnica dos 15 minutos

Terapia   {
{
Outras áreas da vida com problemas 
afetam sua capacidade de criar

Apostila aula 01 
Aula 04 - Bloqueio Criativo
Módulo 01 Criatividade
MARKETING DE PREMISSAS
01
Pratique os exercícios das aulas anterioresT
^ Associação Criativa diariamentY
^ Treine a Observação CriativQ
^ Implemente o Processo criativJ
^ Crie um diário onde você possa anotar 

  
02
03
Execute a Técnica dos 15 minutos
Sempre que possível, em momentos assim procure o 
atendimento de um especialista no processo 
terapêutico. Afinal problemas externos em outras 
áreas da vida, influenciam muito sua capacidade de 
ser criativo e executar os exercícios.
Vamos Praticar?


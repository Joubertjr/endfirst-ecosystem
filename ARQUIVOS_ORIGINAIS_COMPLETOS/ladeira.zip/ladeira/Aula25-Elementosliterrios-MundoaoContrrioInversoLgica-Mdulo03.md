Apostila aula 0
Aula 25
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Mundo ao 
Contrário

Módulo 03 LightCopy 
Aula 25 - Elementos literários - Mundo ao Contrário
O que é?
O mundo ao contrário é um recurso literário que 
inverte a lógica cotidiana, alterando papéis e 
relações naturais. Essa inversão cria surpresa, 
humor ou crítica ao transformar o normal em 
inesperado.
Os alunos aprenderão a identificar e criar 
exemplos do mundo ao contrário, compreendendo 
como essa técnica literária pode ser usada para 
provocar reflexões e entreter.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
B O mundo ao contrário é um recurso literário e criativo que subverte 
a lógica do dia a dia, invertendo papéis, funções ou relações 
naturais. Ele cria um efeito de surpresa e, muitas vezes, humor ou 
crítica, ao apresentar situações inesperadas onde as regras 
normais do mundo são viradas de cabeça para baixo.
Exemplos
Módulo 03 LightCopy 
Aula 25 - Elementos literários - Mundo ao Contrário
B E se a vida fosse um filme ao contrário?
B E se fosse o contrário ?
B Chegamos ao último dia de 2024!
B
 VAGAS ABERTAS 
B Coisas leves 
  Brincadeiras a parte galera…
B Desperta Curiosidade:
B Cria Humor e Ironia:
B Faz Críticas Inteligentes:
B George Orwell – "A Revolução dos Bichos"
B O Gato de Botas (Conto Popular)
, O leitor espera uma lógica familiar, mas encontra o oposto, o que 
prende sua atenção.
, A quebra de expectativa torna a mensagem leve e divertida.
, Muitas vezes, a inversão expõe verdades ou ironiza 
comportamentos comuns de maneira sutil.
, Os animais tomam o poder da fazenda e começam a governar 
como os humanos, tornando-se tão opressores quanto eles.
, Em vez do humano salvar o animal, o gato é quem faz o dono 
enriquecer e ganhar status.

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 25 - Elementos literários - Mundo ao Contrário
B Filme "Divertida Mente
B Para a aula
` No lugar de pessoas controlando emoções, são as emoções que 
controlam as pessoas.
` Enem
` Eu sou um livro de matemática. Oficialmente, estou aqui para 
ajudar esse menino a passar no ENEM. Mas, sinceramente? 
Acho que ele não gosta muito de mim.   
Em 30 dias, me abriu 13 vezes. Ficou comigo por menos de 
20 minutos cada vez. Segundo meus cálculos, ficou devendo 
pelo menos **6 horas de estudo só para garantir uma nota 
mínima competitiva**.   
Acho que vou ter que inovar. Me fantasiar de revista adulta? 
Não sei se ele ainda lê isso. Talvez um hambúrguer, um fone 
de ouvido caro... Ou um Pix de 100 reais? Se eu piscasse uma 
notificação na tela, será que ele me abriria mais vezes?  
— Deixa de drama, meu chapa — diz o computador, piscando 
o brilho da tela. — O menino tá estudando sim, só que 
**comigo**. Videoaulas, resumos interativos, PDFs, mapas 
mentais... Ele não te abre porque você tá desatualizado.   
— Atualizado? Eu sou um clássico! Os melhores passaram por 
mim!   
— Verdade. E sabe onde eles estão agora? No Google, 
pesquisando *“como revisar 3 meses de conteúdo em 2 
dias”*.  
O mundo mudou. Se você ainda acha que estudar é só 
decorar livros, sinto muito, mas o ENEM já decorou seu nome 
na lista dos que não passaram.   
**Aprenda com tecnologia, estratégia e o método que 
realmente te coloca na faculdade.** Antes que o ENEM te 
estude e te reprove.

MARKETING DE PREMISSAS
Exercícios
01
02
03
E  Complete a frase: 
Complete as frases abaixo aplicando a lógica do mundo ao contrário2
 O professor aprendeu com o aluno que..
 O peixe decidiu sair da água porque..
 O cachorro levou seu dono para passear e...
E Criação de uma pequena história: 
Escreva um pequeno parágrafo usando a ideia de mundo ao 
contrário. Por exemplo, como seria um dia na escola onde os alunos 
fossem os professores?
E Identificando o mundo ao contrário: 
Leia as frases abaixo e marque aquelas que representam o recurso 
do mundo ao contrário. Justifique sua resposta
 O sol decidiu dormir e a lua brilhou durante o dia
 As crianças brincavam no parque
 O relógio pediu para as pessoas não olharem mais para ele.
Módulo 03 LightCopy 
Aula 25 - Elementos literários - Mundo ao Contrário


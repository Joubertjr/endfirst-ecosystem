Apostila aula 0
Aula 16
Módulo 3  LightCopy
MARKETING DE PREMISSAS
Elementos literários  
Lista

Módulo 03 LightCopy 
Aula 16- Elementos literários - Lista
O que é?
O elemento de lista é uma técnica de escrita que 
organiza informações em sequência, facilitando a 
leitura e destacando ideias. As listas podem ter 
diferentes propósitos, como informar, emocionar 
ou estruturar um raciocínio.
Compreender como o uso de listas pode melhorar 
a clareza, o ritmo e o impacto de um texto, 
explorando diferentes formas de organização, 
como ordem crescente ou decrescente.
Tópicos Principais
1
Conceito
3
Exercícios 
2
Exemplos
Objetivos do aula

MARKETING DE PREMISSAS
Conteúdo do módulo
Conceito
H O elemento de lista é uma técnica de escrita que consiste em 
apresentar uma sequência de itens, palavras ou ideias 
relacionadas. Essa estrutura é usada para enfatizar, elaborar 
conceitos ou criar um ritmo narrativo. Listas podem ser descritivas, 
reflexivas, emotivas ou informativas, dependendo do tom e do 
propósito do texto.Z
H Ritmo e fluidez: 
As listas criam uma cadência que facilita a leitura e envolve o 
público)
H Crescente ou decrescente:  
Podem ir do geral ao específico, do menos intenso ao mais intenso, 
ou vice-versa. 
Exemplo: "Felicidade, alegria, euforia ... e, de repente, o vazio."
H Clarice Lispector - "Água Viva":  
"Quero o inédito. Quero as nuvens, o silêncio, o fogo. Quero o 
desejo, o que escapa, o que se revela."
H Os nomes complicados do marketing digital
H Qual o termo do corporativo que mais te irrita?
H Mais moço
H Cara, que vida boa ! 
 PARTE 2 porque vocês pediram muitooo
H Vc mãe ou a sua mãe daqui um tempo
H Oração hoje 23:99 pelas professoras de educação....
H GÍRIAS DE ACADEMIA PARTE 1.
H marca uma amiga que precisa desse conselho?
H O beijo e seus significados
H “Encontre forças na fé e motivação no amor divino. 
Módulo 03 LightCopy 
Aula 16- Elementos literários - Lista
Exemplos

MARKETING DE PREMISSAS
Módulo 03 LightCopy 
Aula 16- Elementos literários - Lista
B É assim ou não? 
 compartilha!
B A festa junina do marketing digital
B Já aconteceu com vocês? 
B VÍDEO AMOSTRADINHO PRA VOCÊ MANDAR PRO SEU CASCA...
B Criador para a aula
¥ "Cada planta conta uma história"  
A azaleia é paz, um lembrete suave de que o silêncio também é belo. 
O girassol é vida, girando com o sol para nunca perder sua luz.  
A jabuticabeira é memória, carregada de frutos que trazem de volta os 
sabores da infância. 
O manacá é celebração, florescendo em cores que dançam com o vento. 
E a grama? É união, conectando todos os elementos em um só lugar´
¥ Um jardim não é só um espaço verde.  
É uma narrativa viva, onde cada planta é uma personagem que adiciona 
cor, textura e significado ao cenário.³
¥ Deixe a Raízes do Tempo criar o capítulo mais bonito da sua história´
¥ A boca está ali para roubar a atenção com um sorriso.  
O nariz? E o ponto central, equilibrando os traços com elegância.  
O queixo da estrutura, mostrando força e personalidade.  
As orelhas são a moldura que acolhe seus cabelos e brincos.  
Os cabelos sao liberdade, sempre prontos para mudar de acordo com o 
humor.  
Os olhos? Ah, os olhos são a janela da alma, revelando tudo o que você 
sente sem dizer uma palavra.  
Mas a sobrancelha ... A sobrancelha é o que dá vida aos olhos.  
Ela guia o olhar, destaca as expressões e transforma o rosto como um 
todo.³
¥ Domine a arte que dá vida ao rosto com o curso "Traços de Confiança".³
¥ Ja parou pra pensar que todas as letras sao importantes?" 
Sem o T, não existiria tempo.  
Sem o S, não teria sorriso. 
Sem o A, não teria amor. 
Sem o B, não teria beijo. 
E sem o L ... bom, sem o L, não teria Light Copy, e a vida de quem 
trabalha na internet só teria o d minúsculo.³
¥ Porque, para ganhar muito dinheiro na internet, você precisa saber brincar  
com as letras. 
Construir palavras. 
E criar pontes entre a M, o C e o B: 
Mente, Coração e Bolso.

MARKETING DE PREMISSAS
Exercícios
01
02
03
L Identificação de listas: 
Leia o trecho abaixo e identifique a lista presente. Qual o efeito que 
ela cria no texto? 
"Na mala, restaram memórias: bilhetes amassados, fotografias 
desbotadas, promessas não cumpridas." 
L Criação de lista temática: 
Crie uma lista sobre um tema emocional, como medo, felicidade ou 
saudade. Use a estrutura crescente ou decrescente para construir 
um efeito narrativo.
L Transformação de texto: 
Reescreva o parágrafo a seguir utilizando o elemento de lista para 
dar mais ritmo e impacto: 
"No meu dia, tive momentos bons e ruins. Primeiro, acordei animado, 
depois enfrentei um problema no trabalho, mais tarde ri com um 
amigo e, no final, refleti sobre tudo."
Módulo 03 LightCopy 
Aula 16- Elementos literários - Lista


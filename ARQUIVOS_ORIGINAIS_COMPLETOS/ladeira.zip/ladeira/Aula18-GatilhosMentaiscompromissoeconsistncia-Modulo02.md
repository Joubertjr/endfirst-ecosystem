Apostila au
Aula 18
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Gatilhos 
Mentais 
Compromisso e 
consistência

Apostila aula 01 
Aula 18 - Gatilhos Mentais - Compromisso e 
Consistência
Módulo 02 Copy Tradicional
O que é?
É o gatilho mental que se baseia na tendência das 
pessoas cumprirem com um compromisso e se 
manterem consistentes na sua execução se 
tiverem assumidos essa promessa previamente, 
principalmente se foram feitas de forma pública ou 
documentada.
Aplicar de forma honesta e ética a técnica de 
compromisso, fazendo seu publico alvo engajar de 
maneira subconsciente e estar mais propenso à 
sua sugestionabilidade e a agir a favor de um 
combinado estabelecido. Não usar essa técnica de 
maneira manipulativa, e sim aplicar ela a favor de 
que seu cliente ou público se comprometa com o 
próprio sucesso.
Tópicos Principais
Crenças
Jeito certo
Jeito errado
Exercícios
1
2
3
4
Objetivos da Aula

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 18 - Gatilhos Mentais - Compromisso e 
Consistência
Módulo 02 Copy Tradicional
CRENÇAS
Cérebro
Ego
Experimento de Freedman e Fraser
q Sua crenças limitam você e o seu jeito de se comprometer e 
ser consistente a algg
q Seu cérebro quer acreditar em coisas mais fáceis
q Deixar de defender algo do qual você falou bem machuca 
seu ego e desconstrói algo que você construiu sobre si 
mesmg
q 3% de investimento é impossível de se ter sem ser arriscadg
q Deixar de defender um político corrupto
q Estudo feito em 196­
q É mais fácil aceitar um pedido grande depois de se ter 
aceitado um pedido pequeno previamente§
q Um pequeno comprometimento te induz a um grande 
comprometimento
q Relembrar o comprometimento ja feitg
q Listar o motivo do comprometimentg
q Pequena crença se torna em grande comprometimento
q Faça a pessoa concordar em algg
q A cada sim vai ficando mais fácil ela aceitar 
comprometimentos maiores
{
{
{
Conteúdo da Aula
JEITO CERTO
Passado
Lógica das premissas
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 18 - Gatilhos Mentais - Compromisso e 
Consistência
Módulo 02 Copy Tradicional
U Fazer um exercíciK
U Criar uma conta na hotmarE
U Ler o livrK
U Assistir a sériT
U Desafios
Pequenas tarefas
{
JEITO ERRADO
Repetição e manipulação
Premissa fraca ou falsa
U “Eu posso!”, “eu consigo!”, “Eu mereço”
U Argumento se lógic§
U Pressuposição falsa ou errône§
U Generalização
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 18 - Gatilhos Mentais - Compromisso e 
Consistência
Módulo 02 Copy Tradicional
Exercicios
01
Copy de comprometimento: 
Lista curiosidades específicas do seu produto. 
Experimente escrever uma copy para Palestra, pitch 
de vendas ou Reels onde você expõe uma premissa 
e vai consistentemente fazendo seu ouvinte (ou 
leitor) concordar com o seu ponto e se 
comprometer a defender o seu ponto de vista mais 
e mais. Procure analisar se o lead sentiu mais 
facilidade em tomar decisões maiores após ter 
aceitado se comprometer com decisões menores.
02
Teste de comprometimento: 
Experimente colocar em prática o experimento de 
Freedman e Fraser. Induza algum familiar ou colega 
a aceitar um desafio pequeno contigo. 
Posteriormente, relembre ele os valores de dele ter 
aceitado o desafio e proponha a ele um desafio 
com comprometimento bem maior e tente coletar 
informações caso ele aceite ou não a proposta.


Apostila au
Aula 05
Módulo 02 Copy Tradicional
MARKETING DE PREMISSAS
Briefing de 
Copy

Apostila aula 01 
Aula 05 - Briefing de Copy
Módulo 02 Copy Tradicional
O que é?
O Briefing de copy é um documento que reúne 
todas as informações necessárias para a criação 
de uma copy (texto persuasivo), estruturando o 
planejamento 
de 
comunicação, 
público-alvo, 
canais e formatos que serão utilizados. Ele serve 
como guia para garantir que a mensagem seja 
clara, coerente e alinhada com os objetivos de 
marketing e comunicação.
Objetivos da Aula
Nessa aula, você vai aprender como criar um 
briefing de copy de forma eficaz. 
Tópicos Principais
O que é o Briefing de Copy
Estrutura
Exercícios  
1
2
3

Conteúdo da Aula
MARKETING DE PREMISSAS
Nome
$ Escreva um nome que te ajude a encontrar o documento3
$ Ex: Ad conversão vendas - e se der certo? = [Anúncio]
[conversão][nome do anúncio]
Código
$ Quando você lida com vários projetos é interessante 
utilizar desse recurso.Q
$ Ex: L10VTSD-EA01 = [Lançamento 10][Produto][E-mail]
[Aquecimento][número do e-mail]
Data de Entrega
$ Defina sempre a data de entrega da demanda
Estrutura
Apostila aula 01 
Aula 05 - Briefing de Copy
Módulo 02 Copy Tradicional
{
{
{
Objetivo
$ Sempre vai haver somente 2 objetivos:
$ De Marketing - Ex: Fazer que o sujeito se cadastra
$ De Conversão - Ex: Avisar do encerramento da promoção
{
{
Público
$ Demográfic0
$ Comportament0
$ Temperatura
{
{

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 05 - Briefing de Copy
Módulo 02 Copy Tradicional
Formato / Canal
h Vídeos de Venda de Valor VVc
h Mensagem em textb
h Native ADM
h InstagraQ
h Googl_
h Artigo Linkedin
h E-mait
h InstagraQ
h WhatsApp
{
Pesquisa
{
Big Idea / Ideia Central
{
Texto / Roteiro
{
{
h Vídeo conversão InstagraQ
h Estático conversão InstagraQ
h Live de conteúdb
h Reel¬
h Vídeo relacionamento InstagraQ
h Carrossel (Sequência de stories)
{
h Youtube Recomendaçãb
h Youtube SEÆ
h Artigo bloÑ
h Vídeo conversão
{
h Referência¬
h Repertório: Coisas da minha vida que já deram errado

MARKETING DE PREMISSAS
Apostila aula 01 
Aula 05 - Briefing de Copy
Módulo 02 Copy Tradicional
Vamos Praticar?
01
Exercício de comparação. 
Escreva uma copy de qualquer tema utilizando a 
estrutura de briefing e compare com uma copy 
escrita sem utilizar a estrutura.
02
Crie seu documento 
Pegue todos os pontos chaves da aula, e crie seu 
modelo de documento padrão para utilizar e te 
auxiliar na criação das suas copys.


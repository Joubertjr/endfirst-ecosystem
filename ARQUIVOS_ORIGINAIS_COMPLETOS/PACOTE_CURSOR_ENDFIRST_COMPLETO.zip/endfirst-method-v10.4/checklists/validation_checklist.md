# Checklist Obrigatório de Validação (v10.4)

Este checklist deve ser seguido para **qualquer deliverable colaborativo**. Não é opcional.

---

## Fase 1: Antes de Começar (0%)

- [ ] **Gatilho Ativado:** O deliverable é >1.000 palavras ou >30 min de trabalho?
- [ ] **Ação 1:** Estrutura/outline detalhado foi criado.
- [ ] **Ação 2:** O cliente foi notificado com o pedido de validação da estrutura.
- [ ] **Ação 3:** O sistema está em modo **PAUSA**, aguardando aprovação.
- [ ] **Validação:** O cliente deu aprovação explícita para a estrutura? (Sim/Não)

**NÃO PROSSIGA SEM APROVAÇÃO DA ESTRUTURA.**

---

## Fase 2: Durante o Desenvolvimento (30-50%)

- [ ] **Gatilho Ativado:** O progresso atingiu o checkpoint de 30-50%?
- [ ] **Ação 1:** O rascunho parcial foi apresentado ao cliente.
- [ ] **Ação 2:** Foi solicitado feedback específico sobre o progresso.
- [ ] **Ação 3:** O sistema está em modo **PAUSA**, aguardando feedback.
- [ ] **Validação:** O cliente deu "luz verde" para continuar? (Sim/Não)

**NÃO PROSSIGA SEM APROVAÇÃO DO RASCUNHO PARCIAL.**

---

## Fase 3: Antes de Finalizar (99%)

- [ ] **Gatilho Ativado:** O rascunho está 99% completo?
- [ ] **Ação 1:** O rascunho final completo foi apresentado ao cliente.
- [ ] **Ação 2:** Foi solicitada a aprovação final para marcar como "pronto".
- [ ] **Ação 3:** O sistema está em modo **PAUSA**, aguardando aprovação final.
- [ ] **Validação:** O cliente deu o "OK" final? (Sim/Não)

**NÃO MARQUE COMO "FINAL" SEM APROVAÇÃO EXPLÍCITA.**

---

## Fase 4: Em Caso de Feedback (A Qualquer Momento)

- [ ] **Gatilho Ativado:** O cliente forneceu feedback, correção ou nova instrução?
- [ ] **Ação 1:** Todas as outras tarefas foram pausadas.
- [ ] **Ação 2:** O feedback foi analisado como prioridade #1.
- [ ] **Ação 3:** O plano de ajuste foi criado.
- [ ] **Ação 4:** O plano de ajuste foi validado com o cliente.
- [ ] **Validação:** O cliente aprovou o plano de ajuste? (Sim/Não)

**NÃO IMPLEMENTE AJUSTES SEM VALIDAR O PLANO PRIMEIRO.**

---

## Resumo do Ciclo

1.  **Estrutura** → ✅ Valida?
2.  **Rascunho Parcial** → ✅ Valida?
3.  **Rascunho Final** → ✅ Valida?
4.  **Entrega Final**

Este ciclo garante que o agente e o cliente estejam sempre sincronizados, eliminando o risco de grandes retrabalhos e garantindo que o produto final seja exatamente o esperado.

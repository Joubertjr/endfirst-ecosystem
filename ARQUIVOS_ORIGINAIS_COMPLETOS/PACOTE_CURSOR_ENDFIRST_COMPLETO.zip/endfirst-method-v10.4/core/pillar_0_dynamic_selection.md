# PILAR 0: SELEÇÃO DINÂMICA

**Versão do Método:** v10.3

---

## 1. OBJETIVO DO PILAR

O Pilar 0 é o ponto de partida do ENDFIRST Method. Sua função é garantir que o esforço seja aplicado de forma inteligente e contextual, selecionando apenas os pilares, ferramentas e formatos necessários para alcançar o Estado Final desejado. Ele combate o desperdício de recursos e a complexidade desnecessária, adaptando o método à natureza específica de cada projeto.

---

## 2. PROCESSO DE SELEÇÃO DINÂMICA

O processo consiste em responder a três perguntas fundamentais antes de iniciar qualquer trabalho.

### **Pergunta 1: Que tipo de resultado queremos criar?**

É crucial definir a natureza do entregável. As necessidades mudam drasticamente se o objetivo é criar um software, um artigo, um relatório de pesquisa ou um produto físico.

**Exemplos:**
- **Software:** Requer foco em requisitos técnicos, arquitetura e experiência do usuário.
- **Artigo:** Exige ênfase em narrativa, copywriting e otimização para a plataforma de distribuição.
- **Documento Interno:** Prioriza clareza e acionabilidade em detrimento da persuasão.

### **Pergunta 2: Que pilares e critérios são essenciais para este resultado?**

Nem todos os pilares e critérios transversais do ENDFIRST são necessários para todos os projetos. A seleção excessiva leva à burocracia; a seleção insuficiente leva a falhas.

**Exemplo de Aplicação (para um Artigo no Medium):**
- ✅ **Pilares Essenciais:** 1 (Identidade), 1.5 (Pesquisa), 2 (Estado Final), 3 (Calibração), 4 (Caminho Reverso), 6 (Monitoramento de Métricas), 7 (Aprendizagem).
- ⚠️ **Pilar Opcional:** 5 (Agente Externo) - Pode ser usado para simular a recepção do leitor.
- ✅ **Critérios Essenciais:** Copywriting & Otimização para IA, Validação Obrigatória.

### **Pergunta 3: Que objetivo estratégico o resultado serve? (v10.3)**

Introduzido na v10.3, este passo alinha o formato do entregável com sua função estratégica no ecossistema de conteúdo ou produto.

> **Insight Fundador (Análise Externa do Artigo 1):** "V1: Manifesto (white paper). V2: Topo de funil (distribuição)."

O formato deve ser ditado pelo seu objetivo. A seleção dinâmica não se aplica apenas às ferramentas, mas também à **arquitetura do conteúdo**.

**Diretriz Prática v10.3:**
- **Se o objetivo é ATRAIR (Topo de Funil):** Otimize para concisão, escaneabilidade, ganchos fortes e valor imediato. (Ex: Artigo 1 v2.0).
- **Se o objetivo é APROFUNDAR (Meio de Funil):** Permita maior densidade informacional, profundidade técnica e uma abordagem mais professoral. (Ex: Artigo 2, baseado no V1.0).
- **Se o objetivo é CONVERTER (Fundo de Funil):** Foque em CTAs claros, provas sociais e um caminho direto para a ação desejada.

---

## ✅ CHECKLIST DE CONCLUSÃO DO PILAR 0

- [ ] **Tipo de Resultado:** O que estamos construindo foi claramente definido?
- [ ] **Seleção de Ferramentas:** Os pilares e critérios essenciais foram selecionados e os desnecessários foram descartados?
- [ ] **Alinhamento Estratégico (v10.3):** O formato e a arquitetura do conteúdo estão alinhados com o objetivo estratégico (atrair, aprofundar, converter)?

---

**Uma vez que todas as perguntas são respondidas, o Pilar 0 está completo e o trabalho nos pilares subsequentes pode começar.**

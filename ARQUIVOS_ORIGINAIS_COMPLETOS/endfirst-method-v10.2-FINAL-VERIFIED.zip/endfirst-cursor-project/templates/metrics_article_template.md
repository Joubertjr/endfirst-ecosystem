# Métricas: [Nome do Artigo]

**Tipo:** Artigo/Conteúdo  
**Data Início:** [DD/MM/AAAA]  
**Data Fim:** [DD/MM/AAAA]

---

## 📊 MÉTRICAS DEFINIDAS (Pilar 2)

### **Processo:**
- [ ] Tempo total de criação: [Xh]
- [ ] Número de revisões: [X]
- [ ] Retrabalho necessário: [sim/não]
- [ ] Pilares aplicados: [0, 1, 1.5, 2, 3, 4, 5, 6, 7]
- [ ] Tempo de pesquisa (Pilar 1.5): [Xh]
- [ ] Fontes consultadas: [X]

### **Qualidade:**
- [ ] Estrutura (TL;DR, seções, listas): [completa/parcial/básica]
- [ ] Clareza (IA resume corretamente?): [X/5]
- [ ] Citações (quantidade): [X]
- [ ] Citações (qualidade - nível 1-3): [X]
- [ ] Conexões (links internos): [X]
- [ ] Visual (imagens, tabelas): [X]

### **Engajamento (se publicar):**
- [ ] Views (primeiros 7 dias): [X]
- [ ] Claps: [X]
- [ ] Comentários: [X]
- [ ] Shares: [X]

---

## 🔄 MÉTRICAS REFINADAS (Pilar 6)

### **Checkpoint 1 ([data]):**
**Adicionadas:**
- [Nova métrica descoberta]

**Removidas:**
- [Métrica irrelevante]

**Ajustadas:**
- [Métrica ajustada + motivo]

### **Checkpoint 2 ([data]):**
[Repetir estrutura]

---

## ✅ MÉTRICAS FINAIS (Pilar 7)

### **Processo:**
- Tempo total: [Xh]
  - **Contexto:** [Por quê este tempo? O que influenciou?]
- Revisões: [X]
  - **Contexto:** [Por quê X revisões?]
- Tempo pesquisa: [Xh]
  - **Contexto:** [Banco ajudou? Quanto economizou?]

### **Qualidade:**
- Teste IA: [X/5]
  - **Contexto:** [Qual IA? O que funcionou/não funcionou?]
- Citações: [X]
  - **Contexto:** [Hierarquia de Evidências aplicada?]

### **Engajamento:**
- Views: [X]
  - **Contexto:** [Acima/abaixo da média? Por quê?]

---

## 📈 PADRÕES IDENTIFICADOS

**O que funcionou:**
- [Padrão 1 + evidência]
- [Padrão 2 + evidência]

**O que não funcionou:**
- [Padrão 1 + evidência]

**Surpresas:**
- [Descoberta inesperada]

---

## 🔄 REUTILIZAR EM PRÓXIMO ARTIGO

**Métricas validadas:**
- [Métrica 1 - manter]
- [Métrica 2 - manter]

**Métricas a adicionar:**
- [Nova métrica baseada em aprendizado]

**Pesquisa futura (Pilar 1.5):**
- [Gap identificado - pesquisar]

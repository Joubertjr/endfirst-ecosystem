# Output - Resultados Gerados

**Objetivo:** Armazenar todos os resultados criados usando ENDFIRST Method

---

## 📋 COMO USAR

### **Durante execução:**

Salve seus resultados aqui com nomes descritivos:

**Formato:** `[tipo]_[nome]_[data].md`

**Exemplos:**
- `article_productivity_tips_2025_12_09.md`
- `project_website_structure_2025_12_10.md`
- `presentation_endfirst_intro_2025_12_11.md`

---

## 📁 ORGANIZAÇÃO

**Para poucos arquivos (< 10):**
- Salve diretamente nesta pasta

**Para muitos arquivos (> 10):**
- Crie subpastas por tipo:
  - `output/articles/`
  - `output/projects/`
  - `output/presentations/`

---

## 🔗 RELAÇÃO COM LEARNINGS

**Após salvar resultado aqui:**

1. Capture aprendizados (dentro de 24h)
2. Salve em `context/learnings/`
3. Use template de `templates/learning_template.md`

**Isso garante:**
- Aprendizado capturado
- Melhoria contínua
- Evitar erros futuros

---

## 💡 LIÇÃO-CHAVE

> **"Todo resultado gerado é uma oportunidade de aprendizado. Capture sempre."**

---

**ENDFIRST METHOD v9.0** ✅  
**Resultados Organizados** ✅

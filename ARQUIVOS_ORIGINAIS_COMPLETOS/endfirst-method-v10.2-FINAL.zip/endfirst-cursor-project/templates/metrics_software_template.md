# Métricas: [Nome do Projeto]

**Tipo:** Projeto Software  
**Data Início:** [DD/MM/AAAA]  
**Data Fim:** [DD/MM/AAAA]

---

## 📊 MÉTRICAS DEFINIDAS (Pilar 2)

### **Processo:**
- [ ] Tempo de desenvolvimento: [Xh]
- [ ] Número de sprints: [X]
- [ ] Bugs encontrados: [X]
- [ ] Refatorações necessárias: [X]
- [ ] Pilares aplicados: [0, 1, 1.5, 2, 3, 4, 5, 6, 7]

### **Qualidade:**
- [ ] Cobertura de testes (%): [X%]
- [ ] Complexidade ciclomática: [X]
- [ ] Documentação (completa?): [sim/não]
- [ ] Performance (tempo resposta): [Xms]
- [ ] Segurança (vulnerabilidades): [X]

### **Adoção (se lançar):**
- [ ] Usuários ativos (primeiros 30 dias): [X]
- [ ] Taxa de retenção (%): [X%]
- [ ] Feedback (score 1-5): [X]
- [ ] Bugs reportados: [X]

---

## 🔄 MÉTRICAS REFINADAS (Pilar 6)

[Mesma estrutura do template artigo]

---

## ✅ MÉTRICAS FINAIS (Pilar 7)

[Mesma estrutura do template artigo, adaptada para software]

---

## 📈 PADRÕES IDENTIFICADOS

[Mesma estrutura do template artigo]

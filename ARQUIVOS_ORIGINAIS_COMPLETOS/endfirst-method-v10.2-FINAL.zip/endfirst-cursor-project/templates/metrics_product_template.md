# Métricas: [Nome do Produto]

**Tipo:** Produto/Serviço  
**Data Início:** [DD/MM/AAAA]  
**Data Fim:** [DD/MM/AAAA]

---

## 📊 MÉTRICAS DEFINIDAS (Pilar 2)

### **Processo:**
- [ ] Tempo de criação: [Xh]
- [ ] Custo de desenvolvimento: [R$ X]
- [ ] Pessoas envolvidas: [X]
- [ ] Pilares aplicados: [0, 1, 1.5, 2, 3, 4, 5, 6, 7]

### **Qualidade:**
- [ ] Atende requisitos (%): [X%]
- [ ] Usabilidade (score 1-5): [X]
- [ ] Design (score 1-5): [X]
- [ ] Manutenibilidade (score 1-5): [X]

### **Mercado (se lançar):**
- [ ] Receita (primeiros 90 dias): [R$ X]
- [ ] Clientes adquiridos: [X]
- [ ] Taxa de conversão (%): [X%]
- [ ] NPS (Net Promoter Score): [X]

---

## 🔄 MÉTRICAS REFINADAS (Pilar 6)

[Mesma estrutura]

---

## ✅ MÉTRICAS FINAIS (Pilar 7)

[Mesma estrutura]

---

## 📈 PADRÕES IDENTIFICADOS

[Mesma estrutura]

# Learnings - Aprendizados de Ciclos Anteriores

**Objetivo:** Armazenar aprendizados de cada ciclo para reutilização futura

---

## 📋 COMO USAR

### **ANTES de novo ciclo:**

1. Abra esta pasta
2. Leia últimos 2-3 aprendizados
3. Note seção "Faria diferente" e "Ações para próximo ciclo"
4. Ajuste planejamento baseado em aprendizados

### **APÓS completar ciclo:**

1. Dentro de 24h, capture aprendizados
2. Use template: `templates/learning_template.md`
3. Salve aqui com nome: `[tipo]_[nome]_[numero].md`
4. Exemplo: `article_productivity_1.md`

---

## 📁 ESTRUTURA DE NOMES

**Formato:** `[tipo]_[nome]_[numero].md`

**Tipos:**
- `article_` - Artigos
- `project_` - Projetos
- `structure_` - Estruturas/Metodologias
- `campaign_` - Campanhas
- `product_` - Produtos

**Exemplos:**
- `article_endfirst_journey_1.md`
- `project_cursor_structure_1.md`
- `structure_validation_system_1.md`

---

## 🔄 PROCESSO DE 4 ETAPAS

### **ETAPA 1: CAPTURAR** (15-30 min, dentro de 24h)

**4 Perguntas:**
1. O que funcionou?
2. O que não funcionou?
3. O que foi surpresa?
4. O que faria diferente?

### **ETAPA 2: ORGANIZAR** (10-15 min, mesma sessão)

**Formato:** Use template de `templates/learning_template.md`  
**Salvar:** Nesta pasta com nome estruturado

### **ETAPA 3: IDENTIFICAR PADRÕES** (30-45 min, após 3-5 ciclos)

**Processo:**
1. Ler últimos 3-5 aprendizados
2. Identificar temas recorrentes
3. Atualizar método se crítico

### **ETAPA 4: REUTILIZAR** (10-15 min, antes de novo ciclo)

**Processo:**
1. Consultar aprendizados anteriores
2. Ajustar planejamento
3. Evitar erros conhecidos

---

## 📊 MÉTRICAS IMPORTANTES

**Capturar sempre:**
- Tempo planejado vs tempo real
- Resultado esperado vs resultado alcançado
- Obstáculos encontrados
- Ajustes necessários

---

## 💡 LIÇÃO-CHAVE

> **"Aprendizado não capturado é aprendizado perdido. Capture dentro de 24h."**

---

**ENDFIRST METHOD v9.0** ✅  
**Aprendizado Contínuo Ativo** ✅

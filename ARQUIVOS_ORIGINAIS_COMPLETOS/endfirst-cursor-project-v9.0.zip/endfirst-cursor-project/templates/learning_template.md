# Aprendizado: [Nome do Projeto]

**Data:** [DD/MM/AAAA]  
**Tipo:** [Artigo / Projeto / Estrutura / etc.]  
**Resultado:** [Sucesso / Falha Parcial / Falha Total]

---

## O que funcionou ✅

- [Item 1]
- [Item 2]
- [Item 3]

---

## O que não funcionou ❌

- [Item 1]
- [Item 2]
- [Item 3]

---

## Surpresas 🎯

- [Item 1]
- [Item 2]
- [Item 3]

---

## Faria diferente 🔄

- [Item 1]
- [Item 2]
- [Item 3]

---

## Ações para próximo ciclo

- [ ] [Ação 1]
- [ ] [Ação 2]
- [ ] [Ação 3]

---

## Métricas

**Tempo planejado:** [Xh]  
**Tempo real:** [Xh]  
**Diferença:** [+/- Xh]

**Resultado esperado:** [Descrição]  
**Resultado alcançado:** [Descrição]  
**Diferença:** [Descrição]

---

**ENDFIRST METHOD v9.0** ✅  
**Aprendizado Capturado** ✅

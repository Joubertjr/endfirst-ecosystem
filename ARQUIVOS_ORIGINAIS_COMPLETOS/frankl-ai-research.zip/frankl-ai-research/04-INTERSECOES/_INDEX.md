# Índice: Interseções

Este diretório contém o **coração da pesquisa**: as interseções entre os conceitos de Frankl e a Inteligência Artificial.

---

## Interseções Confirmadas (4 arquivos)

- [[INT-001]] — Sentido em Agentes Artificiais
- [[INT-002]] — Espaço Entre Estímulo e Resposta em Sistemas de IA
- [[INT-003]] — Responsabilidade em Sistemas Autônomos
- [[INT-004]] — Meaningful HCI Framework (Nguyen et al.)

---

**Última atualização:** 24 de novembro de 2025

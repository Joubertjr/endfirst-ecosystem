---
id: INT-004
tipo: intersecao
titulo: "Meaningful HCI Framework (Nguyen et al.)"
data_criacao: 2025-11-24
status: concluido
tags: 
  - intersecao/confirmada
  - ia/design
  - frankl/aplicacao
relacionado_com:
  - FK-C-001
  - FK-C-005
  - AR-IA-001
fontes:
  - SRC-003
intersecao_ia: alta
---

# Meaningful HCI Framework (Nguyen et al.)

## Resumo

O framework "Meaningful HCI" proposto por [[AR-IA-001]] (Quynh Nguyen) e colaboradores aplica explicitamente os conceitos de Frankl ao design de sistemas de interação humano-computador.

## Três Vias para o Sentido

Baseado nas três vias de Frankl para encontrar sentido, o framework propõe:

1. **Via Criativa (Creative Values)**
   - Sistemas que apoiam autoexpressão e criação
   - Exemplo: Ferramentas de design, plataformas de escrita

2. **Via Experiencial (Experiential Values)**
   - Sistemas que facilitam conexões profundas
   - Exemplo: Plataformas de comunicação, realidade virtual

3. **Via Atitudinal (Attitudinal Values)**
   - Sistemas que ajudam a encontrar sentido no sofrimento
   - Exemplo: Aplicações terapêuticas, ferramentas de resiliência

## Aplicação Prática

A equipe de Nguyen desenvolveu uma experiência em VR baseada na Logoterapia para fortalecer a resiliência psicológica.

## Referências

1. [[SRC-003]] - Nguyen, Q. et al. (2022). "What is meaningful human-computer interaction?"

# Índice: Sínteses

## Análises Detalhadas

- [[SYN-001]] — Análise de Nguyen et al. (2022)
- [[SYN-002]] — Análise de Kıralp (2025)
- [[SYN-003]] — Análise de Quesada (2025)
- [[SYN-004]] — Análise de National Planning Cycles (2025)
- [[SYN-011]] — Análise Integradora: SRC-002 ✨ **NOVO**

## Planos de Aula

- [[SYN-005]] — Plano de Aula: Nguyen et al. (2022)
- [[SYN-006]] — Plano de Aula: Kıralp (2025)
- [[SYN-007]] — Plano de Aula: Quesada (2025)
- [[SYN-008]] — Plano de Aula: National Planning Cycles (2025)

## Outputs

- [[SYN-009]] — Resumo Executivo
- [[SYN-010]] — Texto Poético: Espaço Entre Estímulo e Resposta

**Total:** 11 sínteses (1 nova)

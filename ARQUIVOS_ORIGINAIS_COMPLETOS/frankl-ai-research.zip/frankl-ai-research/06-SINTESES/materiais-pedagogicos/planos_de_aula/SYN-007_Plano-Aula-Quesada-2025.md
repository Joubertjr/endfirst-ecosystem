---
id: SYN-007
type: plano-aula
title: "Plano de Aula: AI Thinking Framework"
source: SRC-005
tags: ['plano-aula', 'quesada', 'ai-thinking', 'linguagem']
created: 2025-11-24
---

# Plano de Aula: O Framework "AI Thinking"

**Tópico:** Co-criando IA com Sentido: Uma Abordagem Centrada na Comunidade
**Artigo de Referência:** "AI Thinking as a Meaning-Centered Framework" (Quesada, 2025)
**Público-Alvo:** Estudantes de graduação/pós-graduação em Engenharia de Software, IA, Antropologia Digital, Design de Produto, Empreendedorismo Social.
**Duração:** 90 minutos

---

## 1. Objetivos de Aprendizagem

Ao final desta aula, os alunos serão capazes de:

1.  **Criticar** o modelo de desenvolvimento de tecnologia predominante e seus impactos na diversidade cultural e linguística.
2.  **Explicar** os três pilares do framework "AI Thinking": Compreensão Cultural, Agência Comunitária e Inovação Tecnológica.
3.  **Articular** a mudança de paradigma fundamental proposta por Quesada: de projetar "para" usuários para co-criar "com" comunidades.
4.  **Conectar** (mesmo que implicitamente) os princípios do "AI Thinking" com a filosofia humanista, como a busca por sentido e agência (Frankl).
5.  **Esboçar** um plano de projeto para uma nova tecnologia de IA usando o framework "AI Thinking" para resolver um problema social.

---

## 2. Materiais Necessários

- Projetor ou tela para apresentação de slides.
- Quadro branco ou flip chart.
- Acesso à internet para mostrar exemplos de projetos de tecnologia cívica ou de preservação de línguas.
- Post-its e canetas para atividade em grupo.

---

## 3. Estrutura da Aula (90 minutos)

| Bloco | Duração | Atividade | Descrição |
| :--- | :--- | :--- | :--- |
| **1. Introdução** | 15 min | Estudo de Caso e Discussão | **"O Tradutor que Apagou um Povo"**: Apresentação de um caso (hipotético ou real) onde uma tecnologia de linguagem falhou em capturar nuances culturais, causando danos. Discussão sobre os limites da IA. |
| **2. O Problema** | 15 min | Apresentação Expositiva | **"O Paradigma Extrativista"**: Explicação do modelo de desenvolvimento de tecnologia centralizado e seus problemas (viés, homogeneização, falta de agência). Apresentação do autor e do artigo. |
| **3. A Solução** | 20 min | Apresentação e Análise | **"Os 3 Pilares do AI Thinking"**: Explicação detalhada do framework (Compreensão Cultural, Agência Comunitária, Inovação Tecnológica) e da mudança de mentalidade "PARA -> COM". |
| **4. Atividade Prática** | 25 min | Workshop de Design | **"Co-criando com Sentido"**: Em grupos, os alunos escolhem um problema social e esboçam um projeto de IA usando o "AI Thinking" para resolvê-lo. |
| **5. Encerramento** | 15 min | Apresentação e Reflexão | **"Pitch da Comunidade"**: Cada grupo apresenta seu projeto. O professor conclui refletindo sobre o papel do tecnólogo como facilitador e não como salvador. |

---

## 4. Conteúdo Detalhado e Roteiro

### Bloco 1: Introdução (15 min)

- **Estudo de Caso (10 min):** "Imaginem que uma grande empresa de tecnologia lança um tradutor universal. Ele funciona perfeitamente para negócios, mas ao traduzir as histórias sagradas de uma comunidade indígena, ele remove todas as metáforas e referências espirituais, tratando-as como 'ruído'. A geração mais jovem, aprendendo sua língua através do app, perde a conexão com sua cultura. **Pergunta:** A tecnologia foi um sucesso ou um fracasso? Quem é o responsável?"
- **Discussão (5 min):** Guie a discussão para a ideia de que precisão técnica não é o mesmo que sucesso humano. Introduza a noção de "sentido" como uma métrica que falta.

### Bloco 2: O Problema (15 min)

- **Slide 1: Título da Aula**
- **Slide 2: O Modelo Padrão de Desenvolvimento de IA**
  - Diagrama simples: `Dados -> Modelo Centralizado -> Produto -> Usuários`
  - **Problemas:**
    - **Viés nos Dados:** O modelo reflete a visão de mundo dos dados dominantes.
    - **Extração de Valor:** O valor (dados, insights) é extraído da comunidade e centralizado na empresa.
    - **Falta de Agência:** Os usuários são consumidores passivos, não participantes.
- **Slide 3: Apresentando Jose F. Quesada e o "AI Thinking"** (Contexto do autor e do artigo).

### Bloco 3: A Solução (20 min)

- **Slide 4: O Novo Paradigma: Co-Criação**
  - Diagrama circular: `Comunidade <-> Tecnologia <-> Sentido`
  - **PARA -> COM**: Enfatize que esta é a mudança mais importante.
- **Slide 5: Os 3 Pilares do AI Thinking**
  - **Compreensão Cultural:** Não se pode construir para quem não se entende. Envolve etnografia, imersão, respeito. *Pergunta-chave: Qual é o significado desta prática para a comunidade?*
  - **Agência Comunitária:** As chaves do carro pertencem à comunidade. Envolve governança de dados, design participativo, propriedade intelectual. *Pergunta-chave: Quem tem o poder de decidir?*
  - **Inovação Tecnológica:** A tecnologia a serviço dos dois primeiros. Envolve arquiteturas federadas, ferramentas de anotação fáceis de usar, interfaces culturalmente adaptadas. *Pergunta-chave: Como a tecnologia pode capacitar em vez de substituir?*

### Bloco 4: Atividade Prática (25 min)

- **Instrução:** "Em grupos, escolham um dos seguintes desafios sociais: **(a) combate à desinformação em uma comunidade rural, (b) apoio à saúde mental de idosos que vivem sozinhos, ou (c) criação de um currículo educacional relevante para uma vizinhança de baixa renda.**"
- **Tarefa (em um flip chart):**
  1.  **Não usem o modelo antigo!** Não comecem com "Vamos criar um app que..."
  2.  **Usem o AI Thinking (25 min):**
      - **Compreensão Cultural:** Que perguntas vocês fariam à comunidade primeiro? Que significados vocês precisariam entender?
      - **Agência Comunitária:** Como vocês dariam à comunidade o controle sobre o projeto e seus dados?
      - **Inovação Tecnológica:** Que tipo de tecnologia de IA poderia *apoiar* a solução da comunidade (em vez de *ser* a solução)? Esbocem uma ideia.

### Bloco 5: Encerramento (15 min)

- **Apresentações (10 min):** Cada grupo faz um "pitch" de 2 minutos, não da sua tecnologia, mas do seu **processo de co-criação**.
- **Reflexão Final (5 min):**
  - **Slide 6: O Tecno-Antropólogo**
    - O engenheiro de IA do futuro é também um antropólogo, um sociólogo, um facilitador.
    - O objetivo não é ter a "melhor ideia", mas criar o **espaço para que a melhor ideia da comunidade possa emergir**.
  - **Conexão com Frankl (implícita):** "Ao focar no sentido e na agência, o 'AI Thinking' nos mostra um caminho para criar tecnologia que não apenas resolve problemas, mas ajuda as pessoas e comunidades a se tornarem mais donas de si mesmas. É um caminho onde a tecnologia serve à busca humana por propósito."

---

## 5. Avaliação

- **Profundidade das perguntas** geradas na primeira parte da atividade em grupo (Compreensão Cultural).
- **Criatividade e viabilidade** do modelo de governança proposto (Agência Comunitária).
- **(Opcional) Trabalho de Acompanhamento:** Desenvolver um "Manifesto de Co-criação" para um projeto de IA, detalhando os princípios e o processo que seriam seguidos, baseado no framework de Quesada.

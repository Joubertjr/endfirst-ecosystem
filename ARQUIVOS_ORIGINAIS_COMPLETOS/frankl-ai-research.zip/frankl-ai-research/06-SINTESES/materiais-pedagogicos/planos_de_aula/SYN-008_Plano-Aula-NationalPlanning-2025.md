---
id: SYN-008
type: plano-aula
title: "Plano de Aula: IA e Existencialismo"
source: SRC-006
tags: ['plano-aula', 'existencialismo', 'ia', 'filosofia']
created: 2025-11-24
---

# Plano de Aula: Existencialismo na Era da IA

**Tópico:** Como Viver Autenticamente em um Mundo Mediado por Algoritmos
**Artigo de Referência:** "How Artificial Intelligence Challenges Existentialism" (National Planning Cycles, 2025)
**Público-Alvo:** Estudantes de graduação/pós-graduação em Filosofia, Ética da Tecnologia, Ciência da Computação, Psicologia, Ciências Humanas.
**Duração:** 120 minutos (2 horas)

---

## 1. Objetivos de Aprendizagem

Ao final desta aula, os alunos serão capazes de:

1.  **Explicar** os quatro pilares do existencialismo (liberdade, autenticidade, sentido, responsabilidade) e como cada um é desafiado pela IA.
2.  **Articular** as respostas existenciais construtivas propostas pelo artigo, incluindo conceitos como "liberdade reflexiva", "autenticidade tecnológica" e "inteligência existencial".
3.  **Conectar** as ideias do artigo com a filosofia de Viktor Frankl, especialmente o conceito do "espaço entre estímulo e resposta".
4.  **Aplicar** o framework existencial para analisar criticamente uma tecnologia de IA específica ou um dilema ético.
5.  **Desenvolver** uma postura pessoal sobre como viver de forma autêntica e responsável em um mundo permeado por IA.

---

## 2. Materiais Necessários

- Projetor ou tela para apresentação de slides.
- Quadro branco ou flip chart.
- Acesso à internet para demonstrações de IA (ex: ChatGPT, algoritmo de recomendação do YouTube).
- Cópias (digitais ou físicas) do artigo do National Planning Cycles (2025) para leitura prévia.

---

## 3. Estrutura da Aula (120 minutos)

| Bloco | Duração | Atividade | Descrição |
| :--- | :--- | :--- | :--- |
| **1. Abertura** | 15 min | Experimento ao Vivo | **"O Algoritmo Sabe Mais Sobre Você do que Você?"**: Demonstração de um algoritmo de recomendação em ação. Discussão sobre agência e influência. |
| **2. Fundamentação** | 20 min | Apresentação Expositiva | **"Existencialismo em 10 Minutos"**: Introdução rápida aos conceitos de Sartre, Camus e Frankl. Estabelecimento do framework para a análise. |
| **3. Os 4 Desafios** | 40 min | Análise Guiada | **"Quando a IA Encontra Sartre"**: Decomposição dos quatro desafios (liberdade, autenticidade, sentido, responsabilidade) e das respostas existenciais, com exemplos práticos. |
| **4. Atividade Prática** | 30 min | Estudo de Caso em Grupo | **"O Dilema Existencial da IA"**: Análise de um caso real (ex: uso de IA em contratação, moderação de conteúdo) através das lentes do existencialismo. |
| **5. Encerramento** | 15 min | Reflexão Pessoal e Síntese | **"Meu Manifesto Existencial"**: Cada aluno escreve uma frase sobre como viverá de forma mais autêntica e responsável diante da IA. Síntese do professor. |

---

## 4. Conteúdo Detalhado e Roteiro

### Bloco 1: Abertura (15 min)

- **Experimento ao Vivo (10 min):**
  - Abra o YouTube ou Spotify em uma conta "neutra" (sem histórico).
  - Mostre as recomendações iniciais.
  - Depois, abra em uma conta pessoal (do professor ou de um voluntário que consinta).
  - Mostre como as recomendações são radicalmente diferentes.
  - **Pergunta:** "Vocês escolhem o que assistem, ou o algoritmo escolhe por vocês? Onde está a sua liberdade nesta interação?"
- **Discussão (5 min):** Guie para a ideia de que a IA não elimina a escolha, mas a **condiciona**. Introduza a questão central da aula: "Como podemos manter nossa agência e autenticidade em um mundo onde a IA molda nossas opções?"

### Bloco 2: Fundamentação (20 min)

- **Slide 1: Título da Aula**
- **Slide 2: O Existencialismo em 3 Pensadores**
  - **Sartre:** "A existência precede a essência." Somos radicalmente livres e radicalmente responsáveis. O perigo da "má-fé" (negar a própria liberdade).
  - **Camus:** A vida é absurda (sem sentido inerente), mas podemos criar sentido através da revolta e da paixão.
  - **Frankl:** A busca por sentido é a motivação primária. Mesmo no sofrimento, temos a liberdade de escolher nossa atitude. O "espaço entre estímulo e resposta".
- **Slide 3: Os 4 Pilares que Vamos Explorar**
  - Liberdade e Agência
  - Autenticidade e Má-Fé
  - Sentido e Singularidade Humana
  - Ontologia e Responsabilidade

### Bloco 3: Os 4 Desafios (40 min)

Para cada pilar, use a estrutura: **Desafio da IA -> Resposta Existencial -> Exemplo Prático**. (10 min cada)

- **Slide 4: Desafio 1 - Liberdade e Agência**
  - **Desafio:** Algoritmos preveem e influenciam comportamento. A liberdade parece erodir.
  - **Resposta:** Liberdade se torna **reflexiva**. A agência está em como interpretamos e respondemos aos sistemas.
  - **Exemplo:** Um GPS sugere uma rota. Você pode segui-la cegamente (submissão) ou questionar ("Por que esta rota? Há uma melhor?") e decidir conscientemente (agência reflexiva).
  - **Conexão com Frankl:** Este é o "espaço entre estímulo e resposta". O GPS é o estímulo. Sua escolha consciente é a resposta.

- **Slide 5: Desafio 2 - Autenticidade e Má-Fé**
  - **Desafio:** É fácil dizer "o algoritmo decidiu", externalizando responsabilidade. A cultura digital promove performance, não autenticidade.
  - **Resposta:** **Autenticidade Tecnológica** — usar a IA de forma deliberada, alinhada com valores pessoais.
  - **Exemplo:** Redes sociais. Má-fé: postar para maximizar likes. Autenticidade: postar o que é genuinamente importante para você, independentemente do algoritmo.

- **Slide 6: Desafio 3 - Sentido e Singularidade Humana**
  - **Desafio:** IA cria arte, escreve poesia. Se máquinas fazem o que nos tornava especiais, onde está nosso sentido?
  - **Resposta:** Sentido não depende de singularidade. Foque na **"inteligência existencial"**: compaixão, vulnerabilidade, consciência da mortalidade.
  - **Exemplo:** Um poema gerado por IA pode ser tecnicamente perfeito, mas não carrega a experiência vivida de perda, amor ou esperança. O sentido humano está na **autenticidade da experiência**, não na habilidade técnica.

- **Slide 7: Desafio 4 - Ontologia e Responsabilidade**
  - **Desafio:** Quando um carro autônomo causa um acidente, quem é responsável? A agência é distribuída.
  - **Resposta:** **Ética Existencial Pós-Humana** — responsabilidade coletiva pela administração tecnológica. Somos responsáveis pelo que criamos.
  - **Exemplo:** Se um algoritmo de contratação é enviesado, a responsabilidade não é "do algoritmo", mas dos designers, dos dados, da empresa e da sociedade que o permite.

### Bloco 4: Atividade Prática (30 min)

- **Divisão em 4 grupos:** Cada grupo recebe um estudo de caso.
  - **Caso 1:** IA em sistemas de justiça criminal (pontuação de risco de reincidência).
  - **Caso 2:** Algoritmos de recomendação de conteúdo (bolhas de filtro).
  - **Caso 3:** IA em saúde mental (chatbots terapêuticos).
  - **Caso 4:** Veículos autônomos (dilemas morais em acidentes).
- **Tarefa (20 min):** Analisem o caso através dos 4 pilares existenciais. Identifiquem onde a liberdade, a autenticidade, o sentido e a responsabilidade estão em jogo. Proponham uma resposta existencialmente robusta.
- **Apresentação (10 min):** Cada grupo apresenta brevemente (2 min cada).

### Bloco 5: Encerramento (15 min)

- **Reflexão Pessoal (5 min):** "Em um post-it, escreva uma frase que capture como você vai viver de forma mais autêntica e responsável diante da IA. Comece com: 'Eu escolho...'"
  - Exemplos: "Eu escolho questionar cada recomendação antes de aceitá-la." "Eu escolho usar a tecnologia para conectar, não para performar."
- **Compartilhamento Voluntário (5 min):** Alguns alunos compartilham suas frases.
- **Síntese Final (5 min):**
  - **Slide 8: A Mensagem do Artigo**
    - A IA não elimina a condição humana, mas a **recontextualiza**.
    - As questões existenciais não desaparecem; elas se tornam **mais urgentes**.
    - A tarefa não é construir uma IA perfeita, mas nos tornarmos **humanos mais conscientes**.
  - **Mensagem Final:** "O artigo nos ensina que a resposta aos desafios da IA não é primariamente técnica, mas existencial. A liberdade, a autenticidade e o sentido não são dados; eles são **conquistados**, a cada momento, no espaço entre o que a máquina sugere e o que nós escolhemos fazer."

---

## 5. Avaliação

- **Profundidade da análise** no estudo de caso em grupo.
- **Capacidade de aplicar** os conceitos existenciais a situações práticas.
- **(Opcional) Trabalho de Acompanhamento:** Um diário de 7 dias onde os alunos documentam momentos em que a IA influenciou suas decisões e como eles exerceram (ou não) sua agência reflexiva. Reflexão final sobre o que aprenderam sobre si mesmos.

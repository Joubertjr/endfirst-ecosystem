---
id: SYN-005
type: plano-aula
title: "Plano de Aula: Design Centrado no Sentido (Meaningful HCI)"
source: SRC-003
tags: ['plano-aula', 'nguyen', 'hci', 'meaningful-design']
created: 2025-11-24
---

# Plano de Aula: Design Centrado no Sentido (Meaningful HCI)

**Tópico:** Aplicando a Filosofia de Viktor Frankl ao Design de IA e Tecnologia
**Artigo de Referência:** "What is meaningful human-computer interaction?" (Nguyen et al., 2022)
**Público-Alvo:** Estudantes de graduação/pós-graduação em Ciência da Computação, Design de Interação, Engenharia de IA, Ética em Tecnologia.
**Duração:** 90 minutos

---

## 1. Objetivos de Aprendizagem

Ao final desta aula, os alunos serão capazes de:

1.  **Explicar** a evolução do foco no design de HCI, da usabilidade para a experiência e, finalmente, para o sentido.
2.  **Identificar e descrever** os quatro conceitos-chave da Logoterapia de Viktor Frankl aplicados à HCI (Vontade de Sentido, Liberdade de Vontade, Sentido da Vida, Dimensão Noética).
3.  **Diferenciar** entre os três tipos de sentido propostos pelo framework: criativo, experiencial e atitudinal.
4.  **Analisar criticamente** um sistema de IA ou aplicativo existente através das lentes do "meaningful design".
5.  **Propor** ideias de design para um novo sistema de IA que incorpore ativamente os princípios do design centrado no sentido.

---

## 2. Materiais Necessários

- Projetor ou tela para apresentação de slides.
- Quadro branco ou flip chart para brainstorming.
- Cópias (digitais ou físicas) do artigo de Nguyen et al. (2022) para leitura prévia (opcional).
- Post-its e canetas para atividade em grupo.

---

## 3. Estrutura da Aula (90 minutos)

| Bloco | Duração | Atividade | Descrição |
| :--- | :--- | :--- | :--- |
| **1. Introdução** | 15 min | Apresentação Expositiva e Discussão | **"Do Clique ao Sentido"**: Breve histórico da HCI. Discussão inicial: "Pensem em um aplicativo que vocês amam. Por quê? É pela eficiência, pelo prazer ou por algo mais profundo?" |
| **2. Fundamentação** | 20 min | Apresentação Expositiva | **"Frankl no Vale do Silício"**: Introdução aos conceitos da Logoterapia e como o artigo os traduz para o design de tecnologia. Apresentar a tabela-resumo dos conceitos. |
| **3. O Framework** | 15 min | Apresentação com Exemplos | **"Os Três Caminhos para o Sentido"**: Explicação dos sentidos criativo, experiencial e atitudinal, com exemplos práticos de tecnologias existentes para cada um. |
| **4. Atividade Prática** | 25 min | Workshop em Grupo | **"Hackeando o Sentido"**: Divisão dos alunos em grupos para analisar um aplicativo popular (ex: TikTok, Duolingo, Waze) ou um agente de IA (ex: ChatGPT, Alexa) e propor melhorias baseadas no framework. |
| **5. Encerramento** | 15 min | Apresentação e Síntese | **"Pitch de 1 Minuto"**: Cada grupo apresenta suas ideias. O professor sintetiza os aprendizados e reforça a importância do design responsável e centrado no ser humano. |

---

## 4. Conteúdo Detalhado e Roteiro

### Bloco 1: Introdução (15 min)

- **Slide 1: Título da Aula**
- **Slide 2: A Evolução da HCI**
  - **Usabilidade (Anos 80-90):** Foco na eficiência, facilidade de uso. *Pergunta-chave: O usuário consegue completar a tarefa?*
  - **Experiência do Usuário (UX) (Anos 2000-2010):** Foco nas emoções, engajamento, prazer. *Pergunta-chave: O usuário se sente bem ao usar o sistema?*
  - **Design Centrado no Sentido (Agora):** Foco no propósito, valores, crescimento pessoal. *Pergunta-chave: O sistema ajuda o usuário a viver uma vida mais significativa?*
- **Discussão (5 min):** Peça aos alunos para compartilharem exemplos de aplicativos que se encaixam em cada categoria. Provoque-os: "O TikTok é uma boa UX? Ele contribui para uma vida significativa?"

### Bloco 2: Fundamentação (20 min)

- **Slide 3: Quem foi Viktor Frankl?** (Breve biografia e contexto do Holocausto).
- **Slide 4: A Logoterapia em 1 Minuto** (A busca por sentido como motivação primária).
- **Slide 5: Tabela-Resumo - Frankl para Designers** (Apresentar a tabela da análise detalhada, explicando cada conceito e sua aplicação em HCI).
  - **Ênfase:** A "Liberdade de Vontade" como o "espaço entre o estímulo e a resposta". A tecnologia pode ampliar ou esmagar esse espaço.

### Bloco 3: O Framework (15 min)

- **Slide 6: Os Três Caminhos para o Sentido na Tecnologia**
  - **Criativo:** Ferramentas que capacitam. *Ex: GitHub, Notion, Procreate.*
  - **Experiencial:** Ferramentas que conectam. *Ex: AllTrails, Google Arts & Culture, BeReal.*
  - **Atitudinal:** Ferramentas que apoiam a resiliência. *Ex: Calm, Headspace, Wysa (um chatbot de saúde mental).*
- Para cada caminho, mostre a interface do aplicativo e explique como ele se alinha ao conceito.

### Bloco 4: Atividade Prática (25 min)

- **Instrução:** "Em grupos, escolham um dos seguintes sistemas: **Instagram, Spotify, ChatGPT, ou um de sua escolha**."
- **Tarefa (em um flip chart ou post-its):**
  1.  **Análise (10 min):** Como este sistema atualmente se relaciona com os três tipos de sentido (criativo, experiencial, atitudinal)? Ele promove ou impede a busca por sentido?
  2.  **Redesenho (15 min):** Proponham **duas novas funcionalidades** ou **modificações no design** que tornariam este sistema mais "significativo" com base no framework de Frankl. Pensem em como aumentar a agência, a reflexão e a conexão do usuário.
- **Exemplo de Estímulo:** "Para o Spotify, como poderíamos ir além de playlists algorítmicas para criar um sentido mais profundo de conexão musical ou autodescoberta?"

### Bloco 5: Encerramento (15 min)

- **Apresentações (10 min):** Cada grupo tem 1-2 minutos para apresentar suas ideias de redesenho.
- **Síntese Final (5 min):**
  - **Slide 7: O Juramento do Designer Centrado no Sentido**
    - Meu sistema ampliará a liberdade do usuário, não a diminuirá.
    - Meu sistema incentivará a reflexão, não apenas a reação.
    - Meu sistema servirá a um propósito humano, não apenas a uma métrica de engajamento.
  - **Mensagem Final:** "Como criadores de tecnologia e, especialmente, de agentes de IA, vocês não são apenas engenheiros de sistemas; vocês são arquitetos de mundos. A filosofia de Frankl nos lembra que a pergunta mais importante não é 'O que a tecnologia pode fazer?', mas 'Para que fim ela deve servir?'."

---

## 5. Avaliação

- **Participação na discussão em aula.**
- **Qualidade da análise e das propostas na atividade em grupo.**
- **(Opcional) Trabalho de Acompanhamento:** Pedir aos alunos para escreverem um ensaio curto (2 páginas) aplicando o framework de "meaningful design" a um sistema de IA de sua escolha, detalhando uma proposta de redesenho.

---
id: SYN-021
type: sintese-integradora
title: "Síntese: Lacuna Teórica na Literatura de Governança de IA"
data: 2024-11-24
tags: [sintese, lacuna-teorica, meaningful-human-control, critical-decision-points]
conceitos_relacionados: [FK-C-003, FK-C-004, FK-C-005, FK-C-006, INT-002, IA-C-003, IA-C-004]
fontes: [SRC-018, SRC-019, SRC-020, SRC-021, SRC-022, SRC-023]
---

# Síntese: Lacuna Teórica na Literatura de Governança de IA

**Baseado em:** [[SRC-018]] + 13 fontes citadas  
**Data:** 24 de novembro de 2024

---

## Descoberta Principal

Existe uma **lacuna teórica crítica** na literatura de governança de IA:

- **45 documentos** analisados
- **15+ termos** críticos sem definição filosófica
- **0 menções** a Viktor Frankl
- **Conceitos franklianos** usados sem citá-lo

---

## Evidências da Lacuna

### 1. Meaningful Human Control (MHC)

**Situação:**
- Conceito central em governança de IA
- Usado por UNESCO, EU AI Act, IEEE, IBM, AWS
- **MAS:** "Nenhuma definição aceita" (Santoni de Sio, 2018)

**Lacuna:**
- O QUE é "meaningful"? (não definido)
- QUANDO MHC é necessário? (sem critérios)
- COMO implementar? (sem framework)

**Solução frankliana:**
- "Meaningful" = preservação do espaço de escolha consciente ([[INT-002]])
- Critérios baseados em risco existencial ([[IA-C-004]])
- Framework: 5 componentes (tempo, informação, liberdade, responsabilidade, autoria)

### 2. Human Agency

**Situação:**
- Princípio orientador do EU AI Act (2024)
- "AI systematically prioritises humans" (Recital 6)
- **MAS:** Termo NUNCA é definido filosoficamente

**Lacuna:**
- O QUE é "human agency"? (tratado como autoevidente)
- POR QUÊ agency importa? (sem fundamentação)

**Solução frankliana:**
- "Agency" = tríade existencial: liberdade-responsabilidade-noos ([[FK-C-003]], [[FK-C-004]])
- Importa porque preserva dimensão noética ([[FK-C-006]])

### 3. Critical Decision Points

**Situação:**
- IEEE (2025): "Maintaining human oversight at critical decision points"
- **MAS:** NENHUMA teoria sobre o que torna um ponto "crítico"

**Lacuna:**
- QUAIS decisões são críticas? (sem critérios)
- POR QUÊ algumas são mais críticas? (sem fundamentação)

**Solução frankliana:**
- Crítico = afeta capacidade de resposta autêntica ([[IA-C-004]])
- Framework: Matriz de 5 perguntas para classificar criticidade

---

## Mapeamento Conceitual

| Termo em IA | Equivalente Frankliano | Fundamentação |
|-------------|------------------------|---------------|
| **Meaningful Human Control** | Preservação do espaço frankliano | [[INT-002]] |
| **Human Agency** | Tríade liberdade-responsabilidade-noos | [[FK-C-003]], [[FK-C-004]] |
| **Human Autonomy** | Liberdade de Vontade | [[FK-C-003]] |
| **Critical Decision Points** | Pontos que afetam resposta autêntica | [[IA-C-004]] |
| **Sociodigital Sovereignty** | Preservação do espaço de escolha | [[INT-002]] |
| **Actionable Agency** | Capacidade de responder (não reagir) | [[INT-002]] |
| **Decision Ownership** | Autoria existencial de escolhas | [[FK-C-006]] |
| **Attributability** | "Eu escolhi isso" (reconhecimento noético) | [[FK-C-006]] |
| **Rubber-Stamping** | Colapso do espaço frankliano | [[INT-002]] |

---

## Implicações para Governança

### UNESCO (2021)

**Princípios:** Human autonomy, Human oversight (HITL/HOTL/HIC)  
**Lacuna:** Sem critérios para QUANDO usar cada tipo  
**Solução frankliana:** Classificar por risco existencial (🔴/🟡/🟢)

### EU AI Act (2024)

**Princípios:** Human agency, Appropriate oversight  
**Lacuna:** Sem orientação sobre ONDE colocar pontos de intervenção  
**Solução frankliana:** Identificar critical decision points ([[IA-C-004]])

### IEEE, IBM, AWS (2025)

**Princípios:** Critical decision points, Agency vs Autonomy  
**Lacuna:** Sem teoria sobre o que torna pontos "críticos"  
**Solução frankliana:** Framework baseado em espaço frankliano

---

## Oportunidade de Pesquisa

### Paper Acadêmico Proposto

**Título:** "Frankl's Existential Theory as Philosophical Foundation for Meaningful Human Control in AI Systems"

**Estrutura:**
1. Introdução: Lacuna teórica (45 docs, 0 menções)
2. Revisão: Análise de SRC-019 a SRC-031
3. Teoria: Conceitos franklianos (espaço estímulo-resposta, tríade existencial)
4. Aplicação: Framework para MHC e CDP
5. Conclusão: Contribuição para governança

**Target:** FAccT, AIES, IEEE conferences

---

## Conclusão

A literatura de governança de IA está **repleta de conceitos franklianos** usados **sem citar Frankl**.

Esta lacuna representa uma **oportunidade de alto impacto** para:
1. Fundamentar conceitos centrais (MHC, agency, autonomy)
2. Fornecer framework operacional (critical decision points)
3. Contribuir para regulações (UNESCO, EU AI Act)
4. Publicar paper acadêmico de alto impacto

---

**Fonte principal:** [[SRC-018]]  
**Conceitos relacionados:** [[IA-C-003]], [[IA-C-004]], [[INT-002]]  
**Próximos passos:** Ver [[_ACOES_FUTURAS]] FASE 4

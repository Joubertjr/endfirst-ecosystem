---
id: AR-P-003
tipo: autor-relacionado
categoria: psicologo-humanista
nome: "Alexander Batthyány"
data_criacao: 2025-11-24
status: concluido
tags: 
  - logoterapia/pesquisador
  - psicologia-positiva
  - austria
relacionado_com:
  - FK-C-001
  - FK-C-002
fontes:
  - SRC-002
intersecao_ia: baixa
---

# Alexander Batthyány

## Perfil

**Nome Completo:** Alexander Batthyány  
**Nacionalidade:** Austríaco  
**Área:** Psicologia, Filosofia, Neurociência Cognitiva  
**Afiliação:** Viktor Frankl Institute (Viena), University of Liechtenstein

## Contribuição

Batthyány é um dos principais **pesquisadores contemporâneos** da logoterapia, focando em:
- Validação empírica dos conceitos de Frankl
- Integração da logoterapia com psicologia positiva
- Pesquisa sobre sentido e bem-estar

## Obras Principais

1.  **"Meaning in Positive and Existential Psychology"** (2014, co-editado com P. Russo-Netzer)
    - Coletânea que integra logoterapia e psicologia positiva
    - Publicado pela Springer

## Legado

- Diretor do **Viktor Frankl Institute** em Viena
- Promove pesquisa empírica sobre logoterapia
- Ponte entre logoterapia clássica e psicologia positiva contemporânea

## Referências

1.  [[SRC-002]] — Pesquisa Abrangente sobre Frankl e IA (Seção 6)

---
id: AR-P-004
tipo: autor-relacionado
categoria: psicologo-humanista
nome: "Paul T. P. Wong"
data_criacao: 2025-11-24
status: concluido
tags: 
  - psicologia-positiva
  - sentido
  - canada
relacionado_com:
  - FK-C-001
fontes:
  - SRC-002
intersecao_ia: baixa
---

# Paul T. P. Wong

## Perfil

**Nome Completo:** Paul T. P. Wong  
**Nacionalidade:** Canadense  
**Área:** Psicologia Positiva, Psicologia Existencial  
**Afiliação:** Trent University (Canadá), International Network on Personal Meaning

## Contribuição

Wong é o principal proponente da **Psicologia Positiva 2.0**, que integra os conceitos de Frankl sobre sentido com a psicologia positiva de Seligman. Ele argumenta que a psicologia positiva deve ir além do foco em felicidade e incluir:
- Sentido existencial
- Enfrentamento do sofrimento
- Crescimento através da adversidade

## Obras Principais

1.  **"Positive psychology 2.0: Towards a balanced interactive model of the good life"** (2011)
    - Canadian Psychology, 52(2), 69-81

2.  **"Viktor Frankl's meaning-seeking model and positive psychology"** (2014)
    - Capítulo em "Meaning in Existential and Positive Psychology" (Springer)

## Legado

- Fundou o **International Network on Personal Meaning**
- Promove integração entre logoterapia e psicologia positiva
- Crítico da psicologia positiva "superficial" focada apenas em felicidade

## Referências

1.  [[SRC-002]] — Pesquisa Abrangente sobre Frankl e IA (Seção 6)

---
id: AR-P-001
tipo: autor-relacionado
categoria: psicologo-humanista
nome: "Elisabeth Lukas"
data_criacao: 2025-11-24
status: concluido
tags: 
  - logoterapia/continuadora
  - alemanha
relacionado_com:
  - FK-C-002
fontes:
  - SRC-002
intersecao_ia: baixa
---

# Elisabeth Lukas

## Perfil

**Nome Completo:** Elisabeth Lukas  
**Nacionalidade:** Alemã/Austríaca  
**Área:** Psicologia Clínica, Logoterapia  
**Afiliação:** South German Institute of Logotherapy (Fürstenfeldbruck, Alemanha)

## Contribuição

Elisabeth Lukas é uma das **principais continuadoras** da logoterapia de Viktor Frankl. Ela expandiu e aplicou os conceitos de Frankl em contextos clínicos e educacionais.

## Obras Principais

1.  **"Meaning in Suffering: Comfort in Crisis Through Logotherapy"** (1986)
    - Aplicação da logoterapia em situações de crise e sofrimento
    - Traduzida para múltiplos idiomas

2.  **"Logotherapy Textbook"**
    - Manual abrangente de logoterapia para profissionais

## Legado

- Fundou o **South German Institute of Logotherapy**
- Formou centenas de logoterapeutas na Europa
- Expandiu a aplicação da logoterapia para contextos educacionais e organizacionais

## Referências

1.  [[SRC-002]] — Pesquisa Abrangente sobre Frankl e IA (Seção 6)

---
id: AR-P-002
tipo: autor-relacionado
categoria: psicologo-humanista
nome: "Alfried Längle"
data_criacao: 2025-11-24
status: concluido
tags: 
  - logoterapia/continuador
  - analise-existencial
  - austria
relacionado_com:
  - FK-C-002
fontes:
  - SRC-002
intersecao_ia: baixa
---

# Alfried Längle

## Perfil

**Nome Completo:** Alfried Längle  
**Nacionalidade:** Austríaco  
**Área:** Psiquiatria, Análise Existencial  
**Afiliação:** GLE (Gesellschaft für Logotherapie und Existenzanalyse), Viena

## Contribuição

Längle desenvolveu a **Análise Existencial** como uma expansão da logoterapia, focando nas **quatro motivações existenciais fundamentais**:

1.  Poder estar no mundo (condições básicas de existência)
2.  Gostar de viver (relação com a vida)
3.  Ser si mesmo (autenticidade)
4.  Encontrar sentido (orientação para o futuro)

## Obras Principais

1.  **"The Art of Involving the Person: Fundamental Existential Motivations"** (2003)
    - Estrutura das motivações fundamentais
    - Publicado em European Psychotherapy

## Legado

- Fundou a **GLE** (Sociedade para Logoterapia e Análise Existencial)
- Expandiu a logoterapia para incluir uma teoria mais abrangente da motivação humana
- Influente na Europa Central

## Referências

1.  [[SRC-002]] — Pesquisa Abrangente sobre Frankl e IA (Seção 6)

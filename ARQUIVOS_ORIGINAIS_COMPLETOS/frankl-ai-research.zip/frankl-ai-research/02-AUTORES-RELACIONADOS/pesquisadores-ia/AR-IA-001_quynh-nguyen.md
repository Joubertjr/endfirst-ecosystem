---
id: AR-IA-001
type: autor
title: "Quynh Nguyen"
tags: [pesquisador, hci, meaningful-design, austria]
related_concepts:
  - FK-C-001  # Vontade de sentido
  - IA-F-001  # Meaningful HCI Framework
sources:
  - SRC-003  # Artigo Nguyen 2022
  - SRC-008  # Perfil Quynh Nguyen
created: 2025-11-24
---

# Quynh Nguyen

**Afiliação:** AIT Austrian Institute of Technology  
**Área:** Human-Computer Interaction (HCI), Meaningful Design  
**Localização:** Áustria

---

## Perfil Acadêmico

Quynh Nguyen é pesquisadora sênior no **AIT Austrian Institute of Technology**, um dos principais centros de pesquisa aplicada da Europa. Seu trabalho se concentra na interseção entre **design de interação**, **filosofia existencial** e **tecnologias emergentes**.

### Áreas de Pesquisa

1. **Meaningful Human-Computer Interaction**
   - Aplicação da Logoterapia de Viktor Frankl ao design de tecnologia
   - Design centrado no sentido (meaning-centered design)
   - Experiências de usuário que promovem propósito e autorrealização

2. **Design Participativo**
   - Envolvimento de usuários finais no processo de design
   - Co-criação de tecnologias com comunidades

3. **Filosofia da Tecnologia**
   - Implicações éticas e existenciais de tecnologias digitais
   - Crítica ao design hedônico e utilitarista

---

## Contribuições Principais

### Artigo Seminal: "What is meaningful human-computer interaction?" (2022)

Publicado na **ACM DIS Conference 2022**, este artigo é um dos primeiros a aplicar diretamente os princípios da Logoterapia ao campo de HCI. [[SRC-003]]

**Principais contribuições:**

1. **Framework Teórico:** Propõe um framework baseado em três dimensões de sentido de Frankl:
   - Sentido Criativo (Creative Meaning)
   - Sentido Experiencial (Experiential Meaning)
   - Sentido Atitudinal (Attitudinal Meaning)

2. **Crítica ao UX Tradicional:** Argumenta que o foco em "experiência do usuário" é insuficiente - devemos focar em "sentido do usuário"

3. **Implicações para Design:** Oferece diretrizes práticas para projetar tecnologias que apoiem a busca humana por sentido

---

## Relevância para IA

O trabalho de Nguyen é fundamental para compreender como sistemas de IA podem ser projetados para:

- **Expandir Agência:** Aumentar, não reduzir, a capacidade humana de escolha significativa
- **Promover Autotranscendência:** Conectar usuários a algo maior que si mesmos
- **Apoiar Resiliência:** Ajudar usuários a encontrar sentido mesmo em adversidades

### Conexão com Agentes Autônomos

O framework de Nguyen pode ser aplicado ao design de:
- Assistentes virtuais que promovem reflexão, não apenas eficiência
- Sistemas de recomendação que expandem horizontes, não apenas confirmam preferências
- Interfaces que preservam o "espaço entre estímulo e resposta" [[INT-002]]

---

## Publicações Selecionadas

1. **Nguyen, Q., et al. (2022).** "What is meaningful human-computer interaction?" *ACM DIS 2022*. [[SRC-003]]
2. Outros trabalhos em design participativo e HCI (ver [[SRC-008]] para lista completa)

---

## Conexões no Repositório

- **Frameworks:** [[IA-F-001]] Meaningful HCI Framework
- **Interseções:** [[INT-001]] Sentido em Agentes, [[INT-004]] Meaningful HCI Framework
- **Sínteses:** [[SYN-001]] Análise Detalhada Nguyen 2022, [[SYN-005]] Plano de Aula Nguyen 2022

---

## Contato e Mais Informações

- **Instituição:** [AIT Austrian Institute of Technology](https://www.ait.ac.at/)
- **Perfil Completo:** Ver [[SRC-008]]

---

**Atualizado:** 24 de novembro de 2025

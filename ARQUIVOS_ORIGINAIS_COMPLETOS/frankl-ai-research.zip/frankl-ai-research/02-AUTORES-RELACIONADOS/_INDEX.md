# Índice: Autores Relacionados

## Psicólogos Humanistas / Continuadores de Frankl

- [[AR-P-001]] — Elisabeth Lukas ✨ **NOVO**
- [[AR-P-002]] — Alfried Längle ✨ **NOVO**
- [[AR-P-003]] — Alexander Batthyány ✨ **NOVO**
- [[AR-P-004]] — Paul T. P. Wong ✨ **NOVO**

**Total:** 4 autores (todos novos)

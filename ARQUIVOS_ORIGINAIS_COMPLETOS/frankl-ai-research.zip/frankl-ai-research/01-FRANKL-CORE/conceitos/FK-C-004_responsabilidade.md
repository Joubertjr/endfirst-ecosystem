---
id: FK-C-004
tipo: conceito-frankl
titulo: "Responsabilidade"
autor_origem: Viktor Frankl
data_criacao: 2025-11-24
status: concluido
tags: 
  - frankl/conceito-central
  - etica/responsabilidade
relacionado_com:
  - FK-C-003
  - INT-005
fontes:
  - SRC-001
intersecao_ia: alta
---

# Responsabilidade

## Definição / Resumo

Para Frankl, a **Responsabilidade** é o outro lado da liberdade. Se somos livres para escolher nossa resposta, somos também responsáveis por essa escolha. Frankl propõe que a Estátua da Liberdade na costa leste dos EUA deveria ser complementada por uma "Estátua da Responsabilidade" na costa oeste, simbolizando que liberdade sem responsabilidade é incompleta.

## Conexão com IA/Agentes

> 🔗 Conexão identificada com [[INT-005]] (Responsabilidade em Sistemas Autônomos)

A responsabilidade é um dos dilemas centrais da ética da IA. Quando um sistema autônomo causa dano, quem é responsável? O conceito de Frankl sugere que a responsabilidade não pode ser delegada a máquinas — ela permanece com os humanos que projetam, implementam e usam esses sistemas.

## Referências

1. [[SRC-001]] - Frankl, V. E. (1946). *Man's Search for Meaning*.

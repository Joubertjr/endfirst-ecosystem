---
id: FK-C-008
tipo: conceito-frankl
titulo: "Neurose Noogênica"
data_criacao: 2025-11-24
status: concluido
tags: 
  - frankl/conceito
  - logoterapia/patologia
  - psiquiatria
relacionado_com:
  - FK-C-001
  - FK-C-007
fontes:
  - SRC-002
intersecao_ia: media
---

# Neurose Noogênica

## Definição

Sofrimento psicológico que surge não de conflitos psíquicos (neuroses psicogênicas) nem de causas físicas (neuroses somatogênicas), mas da **falta de sentido** na vida.

## Etimologia

- **Noos** (grego): mente, espírito, sentido
- **Gênica:** origem, causa

Portanto: neurose cuja origem está na dimensão do sentido (noética).

## Diferença de Outras Neuroses

| Tipo | Origem | Tratamento |
| :--- | :--- | :--- |
| **Psicogênica** | Conflitos psíquicos inconscientes | Psicanálise, terapia cognitiva |
| **Somatogênica** | Causas físicas/biológicas | Medicação, tratamento médico |
| **Noogênica** | Falta de sentido existencial | **Logoterapia** |

## Sintomas

- Sensação de vazio e falta de propósito
- Apatia e desinteresse
- Questionamento constante sobre "para que viver?"
- Não responde bem a tratamentos convencionais (antidepressivos, psicanálise)

## Tratamento

A logoterapia é a abordagem específica para neuroses noogênicas, pois foca em ajudar o paciente a **encontrar sentido**, não em resolver conflitos inconscientes ou corrigir desequilíbrios químicos.

## Relação com IA

Sistemas de IA que automatizam tarefas significativas sem oferecer alternativas de sentido podem **induzir neuroses noogênicas** em larga escala:
- Trabalhadores substituídos por automação sem requalificação
- Perda de senso de contribuição e propósito
- Alienação tecnológica

## Referências

1.  [[SRC-002]] — Pesquisa Abrangente sobre Frankl e IA (Seção 2.6)

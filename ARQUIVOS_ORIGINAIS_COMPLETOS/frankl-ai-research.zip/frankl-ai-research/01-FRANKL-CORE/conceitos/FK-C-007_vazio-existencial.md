---
id: FK-C-007
tipo: conceito-frankl
titulo: "Vazio Existencial"
data_criacao: 2025-11-24
status: concluido
tags: 
  - frankl/conceito
  - logoterapia/patologia
  - modernidade
relacionado_com:
  - FK-C-001
  - FK-C-008
fontes:
  - SRC-002
intersecao_ia: media
---

# Vazio Existencial

## Definição

Sensação de falta de sentido na vida moderna, caracterizada por tédio, apatia e sensação de que a vida não tem propósito ou direção.

## Características

- **Fenômeno da modernidade:** Frankl antecipou o que hoje chamamos "crise de sentido" da sociedade contemporânea.
- **Sintomas:** Tédio crônico, sensação de vazio interior, busca por preenchimento através de consumo ou entretenimento.
- **Diferença de depressão clínica:** O vazio existencial não é necessariamente uma patologia médica, mas uma condição existencial.

## Causas

1.  **Perda de tradições:** Sociedades modernas não fornecem mais estruturas de sentido prontas (religião, comunidade, papéis sociais claros).
2.  **Perda de instintos:** Humanos não têm instintos que os guiem automaticamente (diferente de animais).
3.  **Conformismo e totalitarismo:** Pessoas ou seguem o que outros fazem (conformismo) ou fazem o que outros mandam (totalitarismo), evitando a responsabilidade de escolher.

## Manifestações

- Busca compulsiva por prazer (hedonismo)
- Busca compulsiva por poder ou status
- Adicções (substâncias, trabalho, tecnologia)
- Agressividade e violência (como forma de "sentir algo")

## Relação com IA

O vazio existencial pode ser **amplificado** por sistemas de IA que:
- Reduzem a necessidade de escolhas deliberadas (automação excessiva)
- Fornecem gratificação instantânea sem esforço (algoritmos de recomendação)
- Substituem conexões humanas profundas por interações superficiais

## Referências

1.  [[SRC-002]] — Pesquisa Abrangente sobre Frankl e IA (Seção 2.6)

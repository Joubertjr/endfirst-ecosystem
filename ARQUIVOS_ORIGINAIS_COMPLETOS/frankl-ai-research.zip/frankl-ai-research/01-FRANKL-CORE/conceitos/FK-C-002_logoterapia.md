---
id: FK-C-002
tipo: conceito-frankl
titulo: "Logoterapia"
autor_origem: Viktor Frankl
data_criacao: 2025-11-24
status: concluido
tags: 
  - frankl/conceito-central
  - psicologia/terapia
  - psicologia/existencial
relacionado_com:
  - FK-C-001
  - FK-C-003
  - FK-C-004
  - FK-C-005
  - INT-002
fontes:
  - SRC-001
  - SRC-002
intersecao_ia: media
---

# Logoterapia

## Definição / Resumo

A **Logoterapia** (do grego *logos*, "sentido") é a escola de psicoterapia fundada por Viktor Frankl, muitas vezes chamada de "terceira escola vienense de psicoterapia" após a psicanálise de Freud e a psicologia individual de Adler. Seu objetivo central é ajudar o paciente a **encontrar sentido em sua vida**, especialmente em face do sofrimento, da culpa e da morte.

## Detalhamento

A Logoterapia se baseia em três pilares filosóficos:

1.  **Liberdade de Vontade:** O ser humano tem a capacidade de escolher sua atitude, mesmo quando as circunstâncias externas não podem ser mudadas.
2.  **Vontade de Sentido:** A motivação primária do ser humano é a busca por sentido.
3.  **Sentido da Vida:** A vida tem um sentido incondicional, mesmo em situações de sofrimento extremo.

**Técnicas Principais:**

- **Intenção Paradoxal:** O paciente é encorajado a desejar ou fazer exatamente aquilo que teme, quebrando o ciclo de ansiedade antecipatória.
- **Desreflexão:** O paciente é orientado a desviar a atenção de si mesmo e direcioná-la para algo ou alguém fora de si (autotranscendência).
- **Diálogo Socrático:** Perguntas que ajudam o paciente a descobrir seu próprio sentido, em vez de impor valores externos.

A Logoterapia não é uma terapia de "ajuste" (fazer o paciente se conformar à sociedade), mas de **descoberta** (ajudar o paciente a encontrar seu propósito único).

## Conexão com IA/Agentes

> 🔗 Conexão identificada com [[IA-C-010]] (Therapeutic AI) e [[INT-002]] (Logoterapia e Agentes Terapêuticos)

A Logoterapia oferece princípios valiosos para o design de **agentes terapêuticos de IA** ou sistemas de apoio à saúde mental:

1.  **Personalização Profunda:** A Logoterapia reconhece que o sentido é único para cada indivíduo. Agentes de IA terapêuticos devem evitar soluções genéricas e ajudar o usuário a descobrir seu próprio caminho.

2.  **Foco na Agência:** A Logoterapia não "cura" o paciente, mas o capacita a se curar. Agentes de IA devem ser projetados como facilitadores, não como substitutos da agência humana.

3.  **Resiliência, não Felicidade:** A Logoterapia não promete eliminar o sofrimento, mas ajudar a encontrar sentido nele. Agentes de IA focados em bem-estar devem ir além de métricas de "felicidade" e considerar a profundidade existencial.

## Gaps de Pesquisa

- [ ] Investigar aplicações de Logoterapia em chatbots terapêuticos
- [ ] Comparar com Terapia Cognitivo-Comportamental (CBT) em agentes de IA
- [ ] Explorar como técnicas de Logoterapia podem ser implementadas algoritmicamente

## Referências

1. [[SRC-001]] - Frankl, V. E. (1946). *Man's Search for Meaning*.
2. [[SRC-002]] - Frankl, V. E. (1969). *The Will to Meaning*.

# Frankl-AI-Research

Repositório de pesquisa sobre a aplicação dos princípios de Viktor Frankl ao design de agentes de Inteligência Artificial.

---

## 🎯 Objetivo

Este repositório é uma **base de conhecimento** para futuras implementações de agentes de IA baseados nos princípios da Logoterapia de Viktor Frankl. O objetivo é documentar frameworks, conceitos e exemplos práticos para que implementações futuras sejam bem fundamentadas.

---

## 📊 Fase Atual: Aprofundamento da Base de Conhecimento

O repositório atingiu um ponto de maturidade onde já temos:

- ✅ 10 conceitos centrais de Frankl documentados
- ✅ 3 frameworks práticos identificados (Nguyen, Quesada, National Planning)
- ✅ 4 interseções confirmadas entre Frankl e IA
- ✅ 3 exemplos concretos de aplicação (Diário Digital, Sistema de Recomendação, App Financeiro)
- ✅ Lacuna de pesquisa validada (ninguém fez isso ainda)

**Próximo passo:** Aprofundar a análise dos frameworks e criar especificações conceituais dos exemplos.

---

## 📁 Estrutura do Repositório

```
frankl-ai-research/
├── 00-META/                    # Governança e metodologia
│   ├── _METODOLOGIA.md         # Workflow de 6 passos para novos conteúdos
│   ├── _TEMPLATE.md            # Template YAML + Markdown
│   ├── _RASTREABILIDADE.md     # Matriz de conexões conceituais
│   ├── _GAPS.md                # Lacunas e oportunidades (v5.0)
│   ├── _ACOES_FUTURAS.md       # Roadmap de documentação
│   └── _AUDITORIA_FINAL.md     # Relatório de conformidade
│
├── 01-FRANKL-CORE/             # Conhecimento sobre Frankl
│   ├── conceitos/              # 10 conceitos atômicos (FK-C-XXX)
│   └── _INDEX.md
│
├── 02-AUTORES-RELACIONADOS/    # Autores e correntes relacionadas
│   ├── continuadores/          # 4 autores (AR-P-XXX)
│   └── _INDEX.md
│
├── 03-IA-AGENTES/              # Conceitos e frameworks de IA
│   ├── frameworks/             # 3 frameworks práticos (IA-F-XXX)
│   └── _INDEX.md
│
├── 04-INTERSECOES/             # Interseções Frankl-IA
│   ├── INT-001 a INT-004       # 4 interseções confirmadas
│   └── _INDEX.md
│
├── 05-FONTES/                  # Fontes primárias
│   └── academicas/             # 12 fontes (SRC-XXX)
│
└── 06-SINTESES/                # Produtos finais
    ├── analises/               # 12 análises (SYN-XXX)
    ├── materiais-pedagogicos/  # 8 planos de aula
    └── outputs/                # Resumo executivo, texto poético
```

---

## 🔑 Conceitos-Chave

### Conceitos de Frankl

| ID | Conceito | Descrição |
| :--- | :--- | :--- |
| FK-C-001 | Vontade de Sentido | Principal força motivacional humana |
| FK-C-002 | Logoterapia | Psicoterapia centrada no sentido |
| FK-C-003 | Liberdade | Capacidade de escolher atitude e ações |
| FK-C-004 | Responsabilidade | Assumir consequências das escolhas |
| FK-C-005 | Espaço entre Estímulo e Resposta | Intervalo onde reside a liberdade |
| FK-C-006 | Dimensão Noética (Noos) | Dimensão espiritual/sentido |

### Frameworks Práticos

| ID | Framework | Fonte | Aplicação |
| :--- | :--- | :--- | :--- |
| IA-F-001 | Meaningful HCI | Nguyen et al. (2022) | 4 dimensões de análise |
| IA-F-002 | AI Thinking | Quesada (2025) | 5 camadas de co-criação |
| IA-F-003 | Liberdade Reflexiva | National Planning (2025) | 4 pilares existenciais |

### Exemplos Concretos

| Exemplo | Conceito de Frankl | Operacionalização |
| :--- | :--- | :--- |
| Diário Digital | Noos (Sentido) | Perguntas reflexivas sobre significado |
| Sistema de Recomendação | Liberdade | Múltiplas opções, usuário decide |
| App Financeiro | Responsabilidade | Mostra impacto de gastos em objetivos |

---

## 🚀 Próximas Ações

Conforme documentado em [`00-META/_ACOES_FUTURAS.md`](00-META/_ACOES_FUTURAS.md):

### FASE 1: Aprofundamento dos Frameworks (1-2 dias)
- Criar análise detalhada de cada framework (SYN-013, SYN-014, SYN-015)

### FASE 2: Especificação dos Exemplos (2-3 dias)
- Criar especificação conceitual de cada exemplo (SYN-016, SYN-017, SYN-018)

### FASE 3: Mapeamento Técnico-Conceitual (1 dia)
- Criar mapeamento robusto de conceitos para componentes técnicos (SYN-019)

---

## 📚 Como Usar Este Repositório

### Para Pesquisadores
1. Comece pelas **interseções** (`04-INTERSECOES/`)
2. Consulte a **rastreabilidade** (`00-META/_RASTREABILIDADE.md`)
3. Identifique **gaps** (`00-META/_GAPS.md`)

### Para Futuros Implementadores
1. Leia os **frameworks práticos** (`03-IA-AGENTES/frameworks/`)
2. Consulte as **especificações conceituais** (quando criadas em `06-SINTESES/`)
3. Use o **mapeamento técnico-conceitual** como guia

### Para Educadores
- Materiais pedagógicos prontos em `06-SINTESES/materiais-pedagogicos/`
- Resumo executivo em `06-SINTESES/outputs/RESUMO_EXECUTIVO.md`

---

## 📊 Estatísticas

- **Total de arquivos:** 58
- **Arquivos .md:** 53
- **Conceitos de Frankl:** 10
- **Frameworks práticos:** 3
- **Interseções confirmadas:** 4
- **Exemplos concretos:** 3
- **Fontes primárias:** 12
- **Sínteses:** 12

---

## 🎓 Contribuição Original

Este repositório documenta uma **lacuna de pesquisa validada**: não existe pesquisa acadêmica direta conectando a Logoterapia de Viktor Frankl com o design de agentes de Inteligência Artificial.

A base de conhecimento aqui documentada permitirá que futuras implementações sejam bem fundamentadas e alinhadas com os princípios de Frankl.

---

## 📖 Citação

Se você usar este repositório em sua pesquisa, por favor cite:

```
Frankl-AI-Research (2025). Base de Conhecimento sobre Viktor Frankl e Inteligência Artificial.
Disponível em: [URL do repositório]
```

---

## 📄 Licença

[A definir - sugestão: MIT ou Creative Commons BY-SA 4.0]

---

## 🤝 Contato

[A definir]

---
id: SRC-024
type: artigo-academico
title: "Rubber-Stamping in Automated Decision-Making"
autor: "Wagner, B."
ano: 2019
tags: [rubber-stamping, quasi-automated-decisions, adm]
conceitos_chave: [rubber-stamping, meaningful-contribution]
relacionado: [SRC-018, IA-C-003, INT-002]
citado_em: [SRC-018]
---

# Rubber-Stamping in Automated Decision-Making

**Autor:** Wagner, B.  
**Ano:** 2019  
**Foco:** Intervenção humana em ADM que se torna mero "carimbo de aprovação"

## Problema Identificado

**"Rubber-stamping":** Intervenção humana se torna mero carimbo de aprovação sem deliberação real.

**Características:**
- Humanos tecnicamente são tomadores finais de decisão
- Mas sua contribuição não é significativa
- Decisões são quasi-automatizadas

## Citação Crítica

> "The challenge is to ensure that human contribution is meaningful, and not merely a 'rubber-stamping'"

## Análise Frankliana

**"Rubber-stamping" = colapso do espaço frankliano** ([[INT-002]])

- Ilusão de escolha sem real deliberação
- Responsabilidade mantida, liberdade eliminada
- Violação da tríade existencial

**Solução frankliana:**  
Garantir tempo/espaço de deliberação consciente para preservar MHC ([[IA-C-003]])

---

**Fonte:** [[SRC-018]] (seção 2.2)

---
id: SRC-001
type: livro
title: "Em Busca de Sentido"
authors: Viktor E. Frankl
year: 1946
tags: [frankl, logoterapia, obra-principal, sentido]
created: 2025-11-24
---

# Em Busca de Sentido (Man's Search for Meaning)

**Título Original:** Ein Psychologe erlebt das Konzentrationslager  
**Autor:** Viktor E. Frankl  
**Ano:** 1946 (primeira edição)  
**ISBN:** Várias edições disponíveis

---

## Sobre a Obra

"Em Busca de Sentido" é a obra mais conhecida de Viktor Frankl, traduzida para mais de 20 idiomas e vendendo milhões de cópias mundialmente. O livro é dividido em duas partes principais:

### Parte 1: Experiências em um Campo de Concentração

Frankl narra suas experiências como prisioneiro em campos de concentração nazistas (Auschwitz, Dachau e outros) durante a Segunda Guerra Mundial. Ele descreve as condições extremas e como os prisioneiros lidavam psicologicamente com o sofrimento.

**Conceitos-chave desenvolvidos:**
- O espaço entre estímulo e resposta
- A liberdade interior mesmo em condições extremas
- A importância do sentido para a sobrevivência

### Parte 2: Logoterapia em Resumo

Na segunda parte, Frankl apresenta os fundamentos da Logoterapia, sua abordagem terapêutica centrada na busca por sentido.

**Princípios fundamentais:**
- [[FK-C-001]] Vontade de Sentido
- [[FK-C-003]] Liberdade de Vontade
- [[FK-C-007]] Sentido da Vida

---

## Relevância para IA

Esta obra é fundamental para compreender como os princípios de Frankl podem ser aplicados ao design de sistemas de IA:

- **Preservação da Liberdade:** Sistemas de IA devem expandir, não reduzir, o espaço de escolha humana
- **Design Centrado no Sentido:** Tecnologia deve apoiar a busca humana por propósito
- **Resiliência e Adaptação:** Sistemas devem ajudar usuários a encontrar sentido mesmo em situações difíceis

---

## Citações Importantes

> "Entre o estímulo e a resposta existe um espaço. Nesse espaço reside nossa liberdade e poder de escolher nossa resposta. Em nossa resposta está nosso crescimento e liberdade."

> "Tudo pode ser tirado de um homem, exceto uma coisa: a última das liberdades humanas - escolher a própria atitude em qualquer conjunto de circunstâncias."

---

## Conexões

- **Frameworks:** [[IA-F-001]] Meaningful HCI Framework
- **Interseções:** [[INT-001]] Sentido em Agentes, [[INT-002]] Espaço Estímulo-Resposta
- **Sínteses:** [[SYN-001]] Análise Nguyen 2022

---

**Referência completa:**  
FRANKL, Viktor E. Em busca de sentido: um psicólogo no campo de concentração. Petrópolis: Vozes, 2008.

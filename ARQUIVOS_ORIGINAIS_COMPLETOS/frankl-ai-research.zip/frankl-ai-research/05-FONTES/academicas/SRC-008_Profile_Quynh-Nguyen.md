---
id: SRC-008
type: perfil
title: "Perfil: Quynh Nguyen"
authors: AIT Austrian Institute of Technology
year: 2024
tags: ['pesquisador', 'hci', 'perfil']
created: 2025-11-24
---

# ‪Quynh Nguyen‬ - ‪Google Scholar‬

**URL:** https://scholar.google.com/citations?user=blRro1UAAAAJ&hl=de

---

EIGENES PROFIL ERSTELLEN
Zitiert von
	Alle	Seit 2020
Zitate	139	139
h-index	8	8
i10-index	6	6

0
70
35
2022
2023
2024
2025
Öffentlicher Zugriff
ALLE ANZEIGEN
9 Artikel
2 Artikel
verfügbar
nicht verfügbar
Basierend auf Fördermandaten
FOLGEN
Quynh Nguyen
Scientist at AIT Austrian Institute of Technology; PhD student at University of Salzburg
Bestätigte E-Mail-Adresse bei stud.sbg.ac.at
Co-CreationParticipatory DesignFuture and Emerging TechnologiesMeaningful Design
		
TITEL	
ZITIERT VON
	JAHR
Stress out: translating real-world stressors into audio-visual stress cues in VR for police training
Q Nguyen, E Jaspaert, M Murtinger, H Schrom-Feiertag, S Egger-Lampl, ...
IFIP Conference on Human-Computer Interaction, 551-561
	27	2021
Assist the VR trainer–real-time dashboard and after-action review for police VR training
M Murtinger, J Uhl, H Schrom-Feiertag, Q Nguyen, B Harthum, ...
2022 IEEE International Conference on Metrology for Extended Reality …
	17	2022
Evaluation in participatory design–The whys and the nots
Q Nguyen
Proceedings of the Participatory Design Conference 2022-Volume 2, 161-166
	16	2022
VR [We Are] training-workshop on collaborative virtual training for challenging contexts
G Regal, H Schrom-Feiertag, Q Nguyen, M Aust, M Murtinger, D Smit, ...
CHI Conference on Human Factors in Computing Systems Extended Abstracts, 1-6
	12	2022
Exploring medical first responders’ perceptions of mass casualty incident scenario training: a qualitative study on learning conditions and recommendations for improvement
F Schulz, Q Nguyen, A Baetzner, D Sjöberg, L Gyllencreutz
BMJ open 14 (7), e084925
	10	2024
Mind the heart: designing a stress dashboard based on physiological data for training highly stressful situations in virtual reality
O Zechner, H Schrom-Feiertag, J Uhl, Q Nguyen, L Kleygrewe, ...
IFIP Conference on Human-Computer Interaction, 209-230
	10	2023
Collaborative scenario builder: a vr co-design tool for medical first responders
Q Nguyen, D Pretolesi, K Gallhuber
Proceedings of the 2023 acm conference on information technology for social …
	8	2023
What is meaningful human-computer interaction? Understanding freedom, responsibility, and Noos in HCI based on Viktor Frankl’s existential philosophy
Q Nguyen, J Himmelsbach, D Bertel, O Zechner, M Tscheligi
Proceedings of the 2022 ACM Designing Interactive Systems Conference, 654-665
	8	2022
xHits: An Automatic Team Performance Metric for VR Police Training
JC Uhl, Q Nguyen, Y Hill, M Murtinger, M Tscheligi
2023 IEEE International Conference on Metrology for eXtended Reality …
	6	2023
Enhancing mixed reality simulation training technology with real-time performance visualization: mixed methods study with medical first responders
O Zechner, H Schrom-Feiertag, R Wespi, D Pretolesi, Q Nguyen, ...
JMIR XR and Spatial Computing (JMXR) 1 (1), e57655
	5	2024
Between two worlds: analysing the effects of immersive and non-immersive prototyping for participatory design
Q Nguyen, A Windisch, S Kriglstein
Proceedings of the 2024 ACM Designing Interactive Systems Conference, 2198-2212
	5	2024
Mixed reality–exploring the requirements of realism in the context of mass casualty incident training
F Schulz, Q Nguyen, A Baetzner, H Schrom-Feiertag, L Gyllencreutz
Prehospital and Disaster Medicine 38 (S1), s31-s31
	4	2023
Talk the Talk, Walk the Walk: A Case Study on Systematic Evaluation in Participatory Design
Q Nguyen, E Jaspaert, B Harthum
Proceedings of the Participatory Design Conference 2024: Full Papers-Volume …
	2	2024
CoLEBricks: Co-Designing Virtual Reality Scenarios with Generative Building Blocks
Q Nguyen, E Jaspaert, M Murtinger, S Kriglstein, M Tscheligi
Proceedings of the 2024 International Conference on Advanced Visual …
	2	2024
Tangible Tactical Belt: Haptic Realism for Virtual Reality Police Training
M Murtinger, JC Uhl, Q Nguyen, G Regal
2023 IEEE International Conference on Metrology for eXtended Reality …
	2	2023
MED1stMR: An integrated Training Using a Mixed Reality Approach Featuring Haptic Feedback for Enhanced Realism - EUO’s Requirements
I Vourvachis, A Giordanis, Q Nguyen, L Gyllencreutz, H Schrom-Feiertag
9th International Conference on Civil Protection & New Technologies …
	2	2022
Tailoring core size, shell thickness, and aluminium doping of Au@ ZnO core@ shell nanoparticles
Q Nguyen, A Zilli, M Celebrano, A Baldi
Journal of Materials Chemistry C 13 (16), 8302-8309
	1	2025
Transforming Ideas into Tangible Artifacts: Discovering Making, Makers, and the Making Experience
C Gerdenitsch, G Regal, Q Nguyen, S Kriglstein
Proceedings of the 13th Nordic Conference on Human-Computer Interaction, 1-12
	1	2024
Supporting Resilience Through Virtual Reality: Design and Preliminary Evaluation of a VR Experience Based on Viktor Frankl’s Logotherapy
Q Nguyen, R Gutierrez, L Kröninger, U Kretzer
IFIP Conference on Human-Computer Interaction, 176-186
	1	2023
Size Matters: d-Band Holes Drive Plasmonic Chemistry in Gold
Q Nguyen, A Baldi
Nano Letters 25 (40), 14704-14709
		2025
Artikel 1–20MEHR ANZEIGEN
DatenschutzerklärungNutzungsbedingungenHilfe
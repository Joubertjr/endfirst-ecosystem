---
id: SRC-031
type: artigo-academico
title: "Human Intervention Governance in Automated Decision-Making"
autores: "Lazcoz, G. & De Hert, P."
ano: 2022-2023
tags: [human-intervention, governance, adm, moral-character]
conceitos_chave: [meaningful-intervention, moral-character, qualifications]
relacionado: [SRC-018, IA-C-003, FK-C-006]
citado_em: [SRC-018]
---

# Human Intervention Governance in Automated Decision-Making

**Autores:** Lazcoz, G. & De Hert, P.  
**Ano:** 2022-2023  
**Foco:** Governança da intervenção humana em ADM

## Proposta

**Intervenção humana deve ser governada:**
- Dentro de mecanismos de governança
- Não apenas stakeholder isolado
- Elemento integral de processos compostos de tomada de decisão

## Requisitos Identificados

1. Apresentação e significância da intervenção
2. Qualificações dos supervisores humanos
3. Diligência dos supervisores
4. Competência
5. Conhecimento
6. **Caráter moral dos interventores humanos**

## Análise Frankliana

**"Caráter moral"** = dimensão noética ([[FK-C-006]])  
**"Significância da intervenção"** = intervenção deve preservar espaço de escolha ([[INT-002]])

**MAS:** Sem teoria sobre o que torna intervenção "significativa"

---

**Fonte:** [[SRC-018]] (seção 3.3)

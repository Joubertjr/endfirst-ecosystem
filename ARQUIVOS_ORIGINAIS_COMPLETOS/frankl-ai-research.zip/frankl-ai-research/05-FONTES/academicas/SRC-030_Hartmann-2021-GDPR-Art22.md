---
id: SRC-030
type: artigo-academico
title: "GDPR Article 22: Protections Against Purely Automated Decisions"
autores: "Hartmann, K. & Kriebel, J."
ano: 2021
tags: [gdpr, article-22, automated-decisions, human-dignity]
conceitos_chave: [gdpr-art22, human-dignity, human-responsibility]
relacionado: [SRC-018, SRC-021, SRC-022, FK-C-005]
citado_em: [SRC-018]
---

# GDPR Article 22: Protections Against Purely Automated Decisions

**Autores:** Hartmann, K. & Kriebel, J.  
**Ano:** 2021  
**Análise:** Proteções contra decisões puramente automatizadas

## Racionalidades Propostas

1. Proteger contra decisões errôneas e discriminatórias
2. Preservar responsabilidade humana
3. Manter dignidade humana ao manter humanos no loop

## Análise Frankliana

**Dignidade humana** = capacidade de escolha consciente ([[FK-C-005]])  
**Responsabilidade** = pressupõe liberdade (tríade: liberdade-responsabilidade-noos) ([[FK-C-003]], [[FK-C-004]])

**MAS:** "Dignidade" permanece abstrato, sem fundamentação existencial

---

**Fonte:** [[SRC-018]] (seção 2.3)

---
id: SRC-011
type: lista
title: "Lista de Livros de Viktor Frankl"
authors: Compilação
year: 2024
tags: ['frankl', 'livros', 'bibliografia']
created: 2025-11-24
---

# Viktor Frankl books | Our Favorite Books by Viktor Frankl | The Viktor E. Frankl Institute of America

**URL:** https://viktorfranklamerica.com/viktor-frankl-books/

---

We value your privacy

This website or its third-party tools process personal data. You can opt out of the sale of your personal information by clicking on the "Do Not Sell or Share My Personal Information" link. Privacy Policy

Do Not Sell or Share My Personal Information
Skip to content
VIKTOR FRANKL
LOGOTHERAPY
COURSES
BOOKS
FILMS
ABOUT US
VIKTOR FRANKL BOOKS
This is a comprehensive list of our favorite Viktor Frankl books. These books may be purchased at your favorite retailer or online.
Man’s Search for Meaning

Psychiatrist Viktor Frankl’s memoir of life in Nazi death camps has riveted generations of readers. Based on Frankl’s own experience and the stories of his patients, the book argues that we cannot avoid suffering but we can choose how to cope with it, find meaning in it, and move forward. Man’s Search for Meaning has become one of the most influential books of our times, selling over twelve million copies worldwide.

Get my copy now!
The Doctor and the Soul: From Psychotherapy to Logotherapy

In The Doctor and the Soul, Frankl explains his method and his conviction that the fundamental human motivation is neither sex (as in Freud) nor the need to be appreciated by society (as in Adler), but the desire to live a purposeful life. Frankl’s work represented a major contribution to the field of psychotherapy, as it set forth the principles of existential psychiatry. He holds that man’s search for meaning in existence is a primary facet of his being; if the search is unrequited, it leads to neurosis. The role of the therapist, then, is to help the patient discover a purposefulness in life.

Get my copy now!

An abnormal reaction to an abnormal situation is normal behavior.

Man’s Search for Ultimate Meaning

In this book, Frankl goes more deeply into the ways of thinking that enabled him to survive imprisonment in a concentration camp and to find meaning in life in spite of all the odds. He expands upon his groundbreaking ideas and searches for answers about life, death, faith, and suffering. Believing that there is much more to our existence than meets the eye, he says: ‘No one will be able to make us believe that man is a sublimated animal once we can show that within him there is a repressed angel.’

In Man’s Search for Ultimate Meaning, Frankl explores our sometimes unconscious desire for inspiration or revelation. He explains how we can create meaning for ourselves and, ultimately, he reveals how life has more to offer us than we could ever imagine.

Get my copy now!
The Feeling of Meaninglessness: A Challenge to Psychotherapy and Philosophy

In The Feeling of Meaninglessness, Viktor Frankl, the founder of logotherapy, a psychotherapeutic method which focus on a will to meaning as the driving force of human life, takes a look at how the modern condition affects the human search for meaning. In this series of articles and essays, he discusses how many people suffer from pervasive feelings of meaninglessness in their lives, despite the great material comforts of industrial society. He attributes this sense of meaninglessness to a neglect of our existential needs and offers practical insights and guidelines for how to overcome this meaninglessness and regain mental health through engagement with our existential needs and selves. 

Get my copy now!
Recollections: An Autobiography

In these stirring recollections, Frankl describes how as a young doctor of neurology in prewar Vienna his disagreements with Freud and Adler led to the development of “the Third Viennese School of Psychotherapy,” known as logotherapy; recounts his harrowing trials in four concentration camps during the War; and reflects on the celebrity brought by the publication of Man’s Search for Meaning in 1945.

Get my copy now!
The Unheard Cry for Meaning

The founder of Logotherapy explores the uniqueness of man’s humanness, attacks the pseudo-humanism in current psychoanalysis, and presents a case for reinvesting psychoanalysis with humanism while preserving the traditions of Freudian analysis and behaviorism.

Get my copy now!
Yes to Life: In Spite of Everything

Eleven months after his liberation from Auschwitz, Viktor E. Frankl held a series of public lectures in Vienna. The psychologist, who was to become world famous, explained his central thoughts on meaning, resilience and the importance of embracing life even in the face of great adversity. Published for the very first time in English, Frankl’s words resonate as strongly today as they did then. He offers an insightful exploration of the maxim “Live as if you were living for the second time” and unfolds his basic conviction that every crisis also includes an opportunity. Despite the unspeakable horrors in the camp, Frankl learnt from his fellow inmates that it is always possible to say “yes to life”–a profound and timeless lesson for us all.

Get my copy now!
Find the complete list of works by Viktor Frankl at the Viktor Frankl Institut
Looking for more insight from recommended authors?
READ RELATED BOOKS

Keep in touch.

Get news delivered to your inbox!

Name 

Email 

Copyright © 2024 - The Viktor E. Frankl Institute of America

Contact

Privacy Policy

Want more?
For more in-depth information about Viktor Frankl and Logotherapy, visit the website of the main Viktor Frankl Institute in Vienna, Austria.
VISIT VIENNA INSTITUTE
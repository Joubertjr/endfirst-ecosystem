---
id: SRC-007
type: artigo
title: "Positive AI and Viktor Frankl"
authors: Diversos
year: 2024
tags: ['positive-ai', 'frankl', 'ia-humanista']
created: 2025-11-24
---

# Towards Positive Artificial Intelligence | SpringerLink

**URL:** https://link.springer.com/chapter/10.1007/978-3-030-77091-4_22

---

Your privacy, your choice

We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes.

By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection.

See our privacy policy for more information on the use of your personal data.

Manage preferences for further information and to change your choices.

Accept all cookies
Skip to main content

Advertisement

Log in
Find a journal
Publish with us
Track your research
Search
 Cart
Home  AIxIA 2020 – Advances in Artificial Intelligence  Conference paper
Towards Positive Artificial Intelligence
Conference paper
First Online: 22 May 2021
pp 359–371
Cite this conference paper
AIxIA 2020 – Advances in Artificial Intelligence
(AIxIA 2020)
Flavio S. Correa da Silva 

Part of the book series: Lecture Notes in Computer Science ((LNAI,volume 12414))

Included in the following conference series:

International Conference of the Italian Association for Artificial Intelligence

1184 Accesses

5 Citations

Abstract

Positive Psychology has been developed as a complement to traditional Psychology to cater for positive components of personality which can lead to sustainable satisfaction, happiness and well being. Positive Technologies have been developed to build technological tools to support Positive Psychology. Artificial Intelligence research has focused on the development of artefacts to relieve humans from undesired tasks, with lesser focus on artefacts to promote positive components towards well being and happiness. In this article, the concept of Positive Artificial Intelligence is proposed as a counterpart in Artificial Intelligence to the role Positive Psychology has played in Psychology.

This work was developed with partial support from FAPESP MCTIC/CGI – Future Internet for Smart Cities and the INCT InterSCity – Smart Cities.

 This is a preview of subscription content, log in via an institution  to check access.

Similar content being viewed by others
Attitudes Towards AI: The Interplay of Self-Efficacy, Well-Being, and Competency
Article Open access
31 January 2025
Pseudo Happiness in Artificial Intelligence
Chapter © 2023
Fear of the new technology: Investigating the factors that influence individual attitudes toward generative Artificial Intelligence (AI)
Article 17 February 2025
Explore related subjects
Discover the latest articles, books and news in related subjects, suggested using machine learning.
Happiness Economics
Humanistic Psychology
Learning Psychology
Philosophy of Artificial Intelligence
Positive Psychology
Artificial Intelligence
Notes
1.

see e.g. Positive Computing (http://www.positivecomputing.org/) and the AI Now Institute (https://ainowinstitute.org/).

2.

see e.g. https://ourworldindata.org/ for up to date statistical data.

3.

see e.g. https://www.who.int/bulletin/volumes/86/12/08-021208/en/.

References

Anderson, R.E.: ACM code of ethics and professional conduct. Commun. ACM 35(5), 94–99 (1992)

Article
 
Google Scholar
 

Avento, N.: Independent living in age-friendly cities: study on dyads of elderly pedestrians walking dynamics. Ph.D. thesis, Università degli Studi di Milano-Bicocca (2015)

Google Scholar
 

Bandini, S., Crociani, L., Gorrini, A., Vizzari, G.: Crossing behaviour of the elderly: Road safety assessment through simulations. In: AIxAAL at AIxIA, pp. 4–16 (2017)

Google Scholar
 

Buettner, D.: The secrets of long life. Natl. Geogr. 208(5), 2–27 (2005)

Google Scholar
 

Carey, K.B., Neal, D.J., Collins, S.E.: A psychometric analysis of the self-regulation questionnaire. Addict. Behav. 29(2), 253–260 (2004)

Article
 
Google Scholar
 

Chirico, A., Ferrise, F., Cordella, L., Gaggioli, A.: Designing awe in virtual reality: an experimental study. Front. Psychol. 8, 2351 (2018)

Article
 
Google Scholar
 

Choi, J., Tay, R., Kim, S., Jeong, S.: Behaviors of older pedestrians at crosswalks in south Korea. Accid. Anal. Prev. 127, 231–235 (2019)

Article
 
Google Scholar
 

Costa, L.V., Veloso, A., Loizou, M., Arnab, S., Tomlins, R., Sukumar, A.P.: “What a mobility-limited world": design requirements of an age-friendly playable city. Preprints (2018)

Google Scholar
 

Csikszentmihalyi, M., Abuhamdeh, S., Nakamura, J., et al.: Flow (1990)

Google Scholar
 

Distefano, N., Pulvirenti, G., Leonardi, S.: Neighbourhood walkability: elderly’s priorities. Res. Transp. Bus. Manag. 100547 (2020)

Google Scholar
 

Ekman, P.: Emotions revealed. Bmj 328(Suppl S5) (2004)

Google Scholar
 

Feliciani, C., Gorrini, A., Crociani, L., Vizzari, G., Nishinari, K., Bandini, S.: Calibration and validation of a simulation model for predicting pedestrian fatalities at unsignalized crosswalks by means of statistical traffic data. J. Traffic Transp. Eng. (Engl. Ed.) 7(1), 1–18 (2020)

Google Scholar
 

Fietkau, J.: The case for including senior citizens in the playable city. In: Proceedings of the International Conference on Web Intelligence, pp. 1072–1075 (2017)

Google Scholar
 

US Food and Drug Administration, et al.: Proposed regulatory framework for modifications to artificial intelligence. Machine Learning (AI/ML)-based Software as a Medical Device (SaMD) (2019). https://www.fda.gov/media/122535/download

Frankl, V.E.: Man’s Search for Meaning. Simon and Schuster, New York (1985)

Google Scholar
 

Froh, J.J.: The history of positive psychology: truth be told. NYS Psychol. 16(3), 18–20 (2004)

Google Scholar
 

Fumagalli, C., et al.: Molecular profile of advanced non-small cell lung cancers in octogenarians: the door to precision medicine in elderly patients. J. Clin. Med. 8(1), 112 (2019)

Article
 
Google Scholar
 

Gaggioli, A., Villani, D., Serino, S., Banos, R., Botella, C.: Positive technology: designing e-experiences for positive change. Front. Psychol. 10, 1571 (2019)

Article
 
Google Scholar
 

Gillham, J.E., Seligman, M.E.: Footsteps on the road to a positive psychology. Behav. Res. Ther. 37(1), S163 (1999)

Article
 
Google Scholar
 

Gorrini, A., Vizzari, G., Bandini, S.: Age and group-driven pedestrian behaviour: from observations to simulations. Collective Dyn. 1, 1–16 (2016)

Article
 
Google Scholar
 

Gullone, E., Taffe, J.: The emotion regulation questionnaire for children and adolescents (ERQ-CA): a psychometric evaluation. Psychol. Assess. 24(2), 409 (2012)

Article
 
Google Scholar
 

Hareli, S., Parkinson, B.: What’s social about social emotions? J. Theory Soc. Behav. 38(2), 131–156 (2008)

Article
 
Google Scholar
 

Hitchcott, P.K., Fastame, M.C., Penna, M.P.: More to blue zones than long life: positive psychological characteristics. Health Risk Soc. 20(3–4), 163–181 (2018)

Article
 
Google Scholar
 

Kitson, A., Prpa, M., Riecke, B.E.: Immersive interactive technologies for positive change: a scoping review and design considerations. Front. Psychol. 9, 1354 (2018)

Article
 
Google Scholar
 

Levesque, C.S., Williams, G.C., Elliot, D., Pickering, M.A., Bodenhamer, B., Finley, P.J.: Validating the theoretical structure of the treatment self-regulation questionnaire (TSRQ) across three different health behaviors. Health Educ. Res. 22(5), 691–702 (2007)

Article
 
Google Scholar
 

Musselwhite, C.: Creating a convivial public realm for an ageing population. Being a pedestrian and the built environment. In: Transport, Travel and Later Life, p. 129 (2017)

Google Scholar
 

Novelli, G., Biancolella, M., Latini, A., Spallone, A., Borgiani, P., Papaluca, M.: Precision medicine in non-communicable diseases. High-throughput 9(1), 3 (2020)

Article
 
Google Scholar
 

O’Brien, T.: Douglas Engelbart’s lasting legacy. San Jose Mercury News (1999)

Google Scholar
 

Peters, D., Calvo, R.A., Ryan, R.M.: Designing for motivation, engagement and wellbeing in digital experience. Front. Psychol. 9, 797 (2018)

Article
 
Google Scholar
 

Peters, D., Vold, K., Robinson, D., Calvo, R.A.: Responsible AI–two frameworks for ethical design practice. IEEE Trans. Technol. Soc. 1(1), 34–47 (2020)

Article
 
Google Scholar
 

Peterson, C., Park, N., et al.: Meaning and positive psychology. Int. J. Existent. Posit. Psychol. 5(1), 7 (2014)

Google Scholar
 

Quesnel, D., Riecke, B.E.: Are you awed yet? How virtual reality gives us awe and goose bumps. Front. Psychol. 9, 2158 (2018)

Article
 
Google Scholar
 

Riva, G., Mantovani, F., Wiederhold, B.K.: Positive technology and COVID-19. Cyberpsychol. Behav. Soc. Netw. 23, 581–587 (2020)

Article
 
Google Scholar
 

Russell, S.J., Norvig, P.: Artificial Intelligence: A Modern Approach, 4th edn. Pearson, London (2020)

MATH
 
Google Scholar
 

Santana, E., et al.: 1604p exposure to low energy amplitude modulated radiofrequency electromagnetic fields (EMF) is associated with rapid improvement in quality of life (QoL) status in patients with advanced hepatocellular carcinoma (HCC), using various analyses of EORTC-C30. Ann. Oncol. 30(Supplement\_5), mdz261-006 (2019)

Google Scholar
 

Seligman, M.E.: Flourish: A Visionary New Understanding of Happiness and Well-Being. Simon and Schuster, New York (2012)

Google Scholar
 

Seligman, M.E., Csikszentmihalyi, M.: Positive psychology: an introduction. Am. Psychol. 55(1), 5–14 (2000)

Article
 
Google Scholar
 

Shoham, Y., Leyton-Brown, K.: Multiagent Systems: Algorithmic, Game-Theoretic, and Logical Foundations. Cambridge University Press, Cambridge (2009)

MATH
 
Google Scholar
 

Silva, J.C.C., Correa da Silva, F.S.: Contextual analysis of pedestrian mobility in transport terminals (2020, submitted)

Google Scholar
 

Spiekermann, S.: Ieee p7000–the first global standard process for addressing ethical concerns in system design. In: Multidisciplinary Digital Publishing Institute Proceedings, vol. 1, no. 3, p. 159 (2017)

Google Scholar
 

Starkweather, A., et al.: The use of technology to support precision health in nursing science. J. Nurs. Scholarsh. 51(6), 614–623 (2019)

Article
 
Google Scholar
 

Taylor, E.: Positive psychology and humanistic psychology: a reply to Seligman. J. Humanist. Psychol. 41(1), 13–29 (2001)

Article
 
Google Scholar
 

VanderWeele, T.J., McNeely, E., Koh, H.K.: Reimagining health–flourishing. JAMA 321(17), 1667–1668 (2019)

Article
 
Google Scholar
 

Winograd, T.: Shifting viewpoints: artificial intelligence and human–computer interaction. Artif. Intell. 170, 1256–1258 (2006)

Article
 
Google Scholar
 

Yamaguchi, D., Tezuka, Y., Suzuki, N.: The differences between winners and losers in competition: the relation of cognitive and emotional aspects during a competition to hemodynamic responses. Adapt. Hum. Behav. Physiol. 5(1), 31–47 (2019). https://doi.org/10.1007/s40750-018-0104-5

Article
 
Google Scholar
 

Download references

Author information
Authors and Affiliations

University of Sao Paulo, Rua do Matao 1010, Sao Paulo, SP, Brazil

Flavio S. Correa da Silva

Corresponding author

Correspondence to Flavio S. Correa da Silva .

Editor information
Editors and Affiliations

Università degli Studi di Torino, Turin, Italy

Matteo Baldoni

Department of Informatics, Systems and C, University of Milano-Bicocca, Milan, Italy

Stefania Bandini

Rights and permissions

Reprints and permissions

Copyright information

© 2021 Springer Nature Switzerland AG

About this paper
Cite this paper

da Silva, F.S.C. (2021). Towards Positive Artificial Intelligence. In: Baldoni, M., Bandini, S. (eds) AIxIA 2020 – Advances in Artificial Intelligence. AIxIA 2020. Lecture Notes in Computer Science(), vol 12414. Springer, Cham. https://doi.org/10.1007/978-3-030-77091-4_22

Download citation
.RIS.ENW.BIB

DOI
https://doi.org/10.1007/978-3-030-77091-4_22

Published
22 May 2021

Publisher Name
Springer, Cham

Print ISBN
978-3-030-77090-7

Online ISBN
978-3-030-77091-4

eBook Packages
Computer Science
Computer Science (R0)

Keywords
Positive technologies
AI for Good
Ageing society
Publish with us

Policies and ethics

Access this chapter
Log in via an institution 
Subscribe and save
Springer+
from $39.99 /Month
Starting from 10 chapters or articles per month
Access and download chapters and articles from more than 300k books and 2,500 journals
Cancel anytime
View plans 
Buy Now
Chapter
USD 29.95
Price excludes VAT (USA)
Available as PDF
Read on any device
Instant download
Own it forever
Buy Chapter 
eBook
USD 79.99
Softcover Book
USD 99.99

Tax calculation will be finalised at checkout

Purchases are for personal use only

Institutional subscriptions 

Sections
References
Abstract
Notes
References
Author information
Editor information
Rights and permissions
Copyright information
About this paper
Publish with us
Discover content
Journals A-Z
Books A-Z
Publish with us
Journal finder
Publish your research
Language editing
Open access publishing
Products and services
Our products
Librarians
Societies
Partners and advertisers
Our brands
Springer
Nature Portfolio
BMC
Palgrave Macmillan
Apress
Discover
Your privacy choices/Manage cookies Your US state privacy rights Accessibility statement Terms and conditions Privacy policy Help and support Legal notice Cancel contracts here

54.242.198.72

Not affiliated

© 2025 Springer Nature
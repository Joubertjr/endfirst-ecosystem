---
id: SRC-023
type: artigo-academico
title: "Meaningful Human Control over Autonomous Systems: A Philosophical Account"
autores: "Santoni de Sio, F. & van den Hoven, J."
ano: 2018
tags: [meaningful-human-control, mhc, autonomous-weapons, laws]
conceitos_chave: [meaningful-human-control, accountability-gap, moral-agency]
relacionado: [SRC-018, IA-C-003, FK-C-003, FK-C-004]
citado_em: [SRC-018]
---

# Meaningful Human Control over Autonomous Systems: A Philosophical Account

**Autores:** Santoni de Sio, F. & van den Hoven, J.  
**Ano:** 2018  
**Origem:** Debate sobre armas autônomas letais (LAWS)  
**Aplicação expandida:** Direção autônoma, saúde, triagem automatizada

---

## Resumo

Artigo seminal sobre **Meaningful Human Control (MHC)** - conceito central em governança de IA que se refere à necessidade de preservar controle humano "significativo" sobre sistemas automatizados.

---

## Origem do Conceito

### Debate sobre LAWS

**LAWS:** Lethal Autonomous Weapons Systems (Armas Autônomas Letais)

**Preocupações:**
1. **Accountability gap:** Ninguém pode ser responsabilizado por crimes de guerra cometidos por sistemas autônomos
2. **Objeção moral:** Máquina nunca deveria tomar decisões moralmente carregadas como tirar vida humana

**Solução proposta:** Meaningful Human Control

---

## Problema: Falta de Definição

### Citação Crítica

> "Although a commonly accepted definition of MHC is missing, many authors have provided useful analyses"

**Situação:**
- Conceito amplamente usado em governança de IA
- UNESCO, EU AI Act, IEEE, IBM, AWS referenciam MHC
- **MAS:** Nenhuma definição aceita
- **MAS:** Muitas análises, mas sem consenso

---

## Aplicação Expandida

### Além de LAWS

**MHC agora aplicado a:**
1. **Direção autônoma** - Quem controla decisões de vida ou morte?
2. **Saúde** - Decisões médicas críticas
3. **Triagem automatizada** - Priorização de pacientes em pandemia
4. **Tomada de decisão geral** - Qualquer sistema que afete agência humana

---

## Análises Existentes (Sem Consenso)

### Abordagens Propostas

**1. Tracking account:**
- Controle como rastreamento de razões
- Decisão deve rastrear razões do humano

**2. Guidance account:**
- Controle como orientação
- Humano deve guiar o sistema

**3. Tracing account:**
- Controle como rastreabilidade
- Decisão deve ser rastreável ao humano

**Problema:** Nenhuma abordagem é universalmente aceita

---

## Conexão com Frankl

### O Que Falta

**Santoni de Sio & van den Hoven identificam o problema mas NÃO oferecem solução definitiva:**

1. ❌ O QUE é "meaningful"? (múltiplas interpretações)
2. ❌ O QUE é "control"? (tracking, guidance, tracing?)
3. ❌ QUANDO MHC é necessário? (sem critérios claros)
4. ❌ COMO implementar MHC? (sem framework operacional)

---

### Fundamentação Frankliana Proposta

**Definição frankliana de MHC:**  
Controle é "meaningful" (significativo) quando **preserva o espaço de escolha consciente** entre estímulo e resposta.

**Baseado em:** [[INT-002]] (Espaço Estímulo-Resposta)

---

## Framework Frankliano para MHC

### Critérios de "Meaningful"

| Critério | Descrição | Conexão Frankliana |
|----------|-----------|-------------------|
| **Tempo de deliberação** | Espaço temporal para reflexão consciente | [[INT-002]] |
| **Informação adequada** | Compreensão suficiente para escolha informada | [[FK-C-006]] |
| **Liberdade real** | Capacidade efetiva de escolher alternativas | [[FK-C-003]] |
| **Responsabilidade correspondente** | Responsabilidade proporcional à liberdade | [[FK-C-004]] |
| **Autoria existencial** | Reconhecimento de "eu escolhi isso" | [[FK-C-006]] |

---

### Quando MHC é Necessário?

**Framework frankliano:**  
MHC é necessário quando decisão afeta **capacidade de resposta autêntica** do ser humano.

**Classificação por risco existencial:**

1. **Alto risco existencial** (MHC obrigatório):
   - Decisões que afetam identidade pessoal
   - Escolhas moralmente carregadas (vida, morte, liberdade)
   - Decisões que impactam valores fundamentais

2. **Médio risco existencial** (MHC recomendado):
   - Decisões que podem ser delegadas mas têm impacto significativo
   - Escolhas que afetam bem-estar mas não identidade

3. **Baixo risco existencial** (MHC opcional):
   - Tarefas repetitivas sem impacto em escolhas significativas
   - Decisões puramente técnicas ou operacionais

---

### Como Implementar MHC?

**Mecanismos de preservação (baseados em Frankl):**

1. **Preservar tempo de deliberação**
   - Não forçar decisões imediatas
   - Permitir reflexão consciente

2. **Fornecer informação adequada**
   - Explicar opções e consequências (XAI)
   - Tornar trade-offs explícitos

3. **Garantir liberdade real**
   - Oferecer alternativas genuínas
   - Permitir rejeição de recomendações

4. **Alinhar responsabilidade e liberdade**
   - Responsabilidade proporcional ao controle real
   - Preservar tríade: liberdade-responsabilidade-noos

5. **Preservar autoria existencial**
   - Decisão deve refletir escolha consciente
   - Garantir que "eu escolhi isso" seja verdadeiro

---

## Conexão com Accountability Gap

### Problema Identificado

**Accountability gap:**  
Ninguém pode ser responsabilizado por decisões de sistemas autônomos.

**Análise frankliana:**  
Gap existe porque:
1. Responsabilidade ([[FK-C-004]]) pressupõe liberdade ([[FK-C-003]])
2. Se liberdade é eliminada (automação completa), responsabilidade não pode ser atribuída
3. **Solução:** Preservar MHC = preservar liberdade = permitir responsabilidade

---

## Conexão com Critical Decision Points

### Onde Implementar MHC?

**Santoni de Sio & van den Hoven:** MHC necessário em decisões moralmente carregadas

**Framework frankliano:** MHC necessário em **critical decision points** ([[IA-C-004]])

**Critérios para identificar:**
1. Afeta identidade/valores/dignidade?
2. Colapsa espaço frankliano?
3. Elimina liberdade real?
4. Envolve julgamento moral?
5. Irreversível ou longo prazo?

---

## Relevância para Governança

### MHC em Regulações

**UNESCO (2021):** Human oversight ([[SRC-021]])  
**EU AI Act (2024):** Appropriate oversight ([[SRC-022]])  
**Santoni de Sio (2018):** Meaningful Human Control

**Todos usam conceitos similares SEM definição aceita.**

**Oportunidade:**  
Usar Frankl para fundamentar MHC em regulações e standards.

---

## Citações Representativas

### Sobre Falta de Definição

> "Although a commonly accepted definition of MHC is missing, many authors have provided useful analyses"

**Análise:**  
Reconhecimento explícito da lacuna conceitual

### Sobre Accountability Gap

> "Ninguém pode ser responsabilizado por crimes de guerra cometidos por sistemas autônomos"

**Análise:**  
Problema de responsabilidade sem liberdade (violação da tríade existencial)

---

## Contribuição para o Repositório

Este artigo é **crítico** porque:

1. ✅ Introduz MHC como conceito central em governança de IA
2. ✅ Reconhece explicitamente que definição aceita está faltando
3. ✅ Identifica accountability gap como problema fundamental
4. ❌ **MAS:** Não oferece solução definitiva

**Frankl oferece exatamente a fundamentação que falta.**

---

## Próximos Passos

1. [ ] Buscar texto completo do artigo
2. [ ] Comparar as 3 abordagens (tracking, guidance, tracing) com Frankl
3. [ ] Propor "Frankl account" de MHC
4. [ ] Usar como evidência de que MHC requer fundamentação frankliana

---

**Fonte original:** [[SRC-018]] (seção 5.1)  
**Conceitos relacionados:** [[IA-C-003]], [[IA-C-004]], [[FK-C-003]], [[FK-C-004]], [[FK-C-006]], [[INT-002]]  
**Regulações relacionadas:** [[SRC-021]], [[SRC-022]]

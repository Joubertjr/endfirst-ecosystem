---
id: SRC-002
type: livro
title: "A Vontade de Sentido"
authors: Viktor E. Frankl
year: 1969
tags: [frankl, logoterapia, vontade-sentido, teoria]
created: 2025-11-24
---

# A Vontade de Sentido (The Will to Meaning)

**Título Original:** The Will to Meaning: Foundations and Applications of Logotherapy  
**Autor:** Viktor E. Frankl  
**Ano:** 1969  
**ISBN:** Várias edições disponíveis

---

## Sobre a Obra

"A Vontade de Sentido" é uma obra teórica mais aprofundada onde Frankl desenvolve sistematicamente os fundamentos filosóficos e clínicos da Logoterapia. É considerada a exposição mais completa de sua teoria psicológica.

### Temas Principais

#### 1. Fundamentos Filosóficos

- **Dimensão Noética:** [[FK-C-009]] A dimensão especificamente humana
- **Liberdade e Responsabilidade:** [[FK-C-003]] [[FK-C-004]]
- **Autotranscendência:** [[FK-C-005]] O caráter auto-transcendente da existência humana

#### 2. Conceitos Clínicos

- **Vazio Existencial:** [[FK-C-007]] A neurose de massa do século XX
- **Neurose Noogênica:** [[FK-C-008]] Distúrbios originados na dimensão noética
- **Tríade Trágica:** [[FK-C-009]] Sofrimento, culpa e morte

#### 3. Técnicas Terapêuticas

- **Derreflexão:** Técnica para superar hiper-reflexão
- **Intenção Paradoxal:** Abordagem para fobias e ansiedades
- **Diálogo Socrático:** Método para descoberta de sentido

---

## Relevância para IA

Esta obra fornece a base teórica para aplicar Logoterapia ao design de IA:

### Design de Agentes Autônomos

- **Dimensão Noética em IA:** Como incorporar capacidades de reflexão e escolha consciente
- **Transparência e Responsabilidade:** Sistemas devem tornar visível o "espaço de escolha"
- **Combate ao Vazio Existencial Digital:** Tecnologia não deve preencher tempo, mas apoiar busca de sentido

### Frameworks Práticos

- [[IA-F-001]] Meaningful HCI Framework (baseado nesta obra)
- [[IA-F-002]] AI Thinking Framework (paralelos conceituais)
- [[IA-F-003]] Framework de Liberdade Reflexiva

---

## Citações Importantes

> "A vontade de sentido é a motivação primária do ser humano, não uma racionalização secundária de impulsos instintivos."

> "O homem não é apenas determinado por seus instintos e ambiente, mas também por sua capacidade de tomar uma posição em relação a eles."

> "A autotranscendência é a essência da existência humana: o ser humano sempre aponta para algo ou alguém além de si mesmo."

---

## Conexões

- **Conceitos:** [[FK-C-001]] [[FK-C-002]] [[FK-C-003]] [[FK-C-004]] [[FK-C-005]]
- **Autores:** [[AR-P-001]] Elisabeth Lukas, [[AR-P-002]] Alfried Längle
- **Interseções:** [[INT-001]] Sentido em Agentes
- **Sínteses:** [[SYN-011]] Análise Integradora

---

## Estrutura do Livro

1. **Parte I:** Fundamentos da Logoterapia
2. **Parte II:** Aplicações Clínicas
3. **Parte III:** Logoterapia e Existencialismo
4. **Parte IV:** Dimensão Espiritual do Homem

---

**Referência completa:**  
FRANKL, Viktor E. A vontade de sentido: fundamentos e aplicações da logoterapia. São Paulo: Paulus, 2011.

---
id: SRC-009
type: perfil
title: "Perfil: Jose F. Quesada"
authors: Universidad de Sevilla
year: 2024
tags: ['pesquisador', 'ia', 'linguagem', 'perfil']
created: 2025-11-24
---

# Sorry...

**URL:** https://scholar.google.com/citations?user=8uyoiBoAAAAJ&hl=es

---

Google	
Sorry...
We're sorry...

... but your computer or network may be sending automated queries. To protect our users, we can't process your request right now.

See Google Help for more information.


Google Home
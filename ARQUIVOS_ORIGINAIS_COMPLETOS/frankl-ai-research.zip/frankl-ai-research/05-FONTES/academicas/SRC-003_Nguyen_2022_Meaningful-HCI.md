---
id: SRC-003
type: artigo
title: "What is meaningful human-computer interaction?"
authors: Nguyen et al.
year: 2022
tags: ['hci', 'meaningful-design', 'logoterapia']
created: 2025-11-24
---

# Just a moment...

**URL:** https://dl.acm.org/doi/10.1145/3532106.3533484

---

dl.acm.org

Verifying you are human. This may take a few seconds.

dl.acm.org needs to review the security of your connection before proceeding.
Ray ID: 9a37c6b6eeae3b71
Performance & security by Cloudflare
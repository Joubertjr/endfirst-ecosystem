---
id: SRC-029
type: artigo-academico
title: "Workplace XAI: Sociotechnical Gap in Work Environments"
autores: "Schmuntzsch, U. & Hartmann, E."
ano: 2023
tags: [workplace-xai, sociotechnical-gap, loss-of-control]
conceitos_chave: [loss-of-control, responsibility-without-freedom]
relacionado: [SRC-018, SRC-019, FK-C-004, FK-C-008]
citado_em: [SRC-018, SRC-019]
---

# Workplace XAI: Sociotechnical Gap in Work Environments

**Autores:** Schmuntzsch, U. & Hartmann, E.  
**Ano:** 2023  
**Foco:** Sociotechnical gap em ambientes de trabalho

## Descoberta Crítica

**Citação:**
> "Users expressed fear of losing control because of not knowing what the machine is doing and why, but still being responsible for the result" (p. 499)

## Análise

**Quando transparência, explicabilidade ou liberdade de ação estão ausentes:**
- Usuários perdem soberania
- Usuários relatam medo de perder controle
- Ainda são responsabilizados pelos resultados de sistemas que não entendem

## Análise Frankliana

**Responsabilidade SEM liberdade** = neurose noogênica ([[FK-C-008]])

- Colapso do espaço de escolha mantendo a responsabilidade
- Violação da tríade existencial ([[FK-C-003]], [[FK-C-004]])

**MAS:** Sem teoria sobre como restaurar essa agência

---

**Fonte:** [[SRC-018]] (seção 1.2)

---
id: SRC-018
type: analise-sistematica
title: "Literatura sobre IA que NÃO Menciona Frankl: Análise de Lacuna Teórica"
ano: 2024
tags: [lacuna-teorica, meaningful-human-control, critical-decision-points, governanca-ia]
conceitos_chave: [meaningful-human-control, critical-decision-points, human-agency, human-autonomy]
relacionado: [SYN-021, IA-C-003, IA-C-004]
fontes_analisadas: [SRC-019, SRC-020, SRC-021, SRC-022, SRC-023, SRC-024, SRC-025, SRC-026, SRC-027, SRC-028, SRC-029, SRC-030, SRC-031]
---

# Literatura sobre IA que NÃO Menciona Frankl

**Análise Sistemática de Lacuna Teórica**  
**Ano:** 2024  
**Documentos analisados:** 45  
**Menções a Frankl:** 0

---

## Resumo Executivo

Este documento apresenta uma análise sistemática de **45 documentos acadêmicos e técnicos** sobre IA que utilizam conceitos centrais da teoria existencial de Viktor Frankl **sem citá-lo**.

**Descoberta principal:** Existe uma **lacuna teórica crítica** na literatura de governança de IA, onde termos como "meaningful human control", "human agency", "human autonomy" e "critical decision points" são amplamente usados **sem fundamentação filosófica**.

---

## Metodologia

1. Revisão de literatura em XAI, governança de IA e arquiteturas de agentes
2. Identificação de conceitos que "gritam por Frankl"
3. Análise de 13 fontes principais (SRC-019 a SRC-031)
4. Mapeamento de conceitos para equivalentes franklianos

---

## Fontes Analisadas

### 1. XAI e Agência Humana (3 fontes)

- **[[SRC-019]]** - Ridley (2024): Sociodigital sovereignty, Actionable agency
- **[[SRC-029]]** - Schmuntzsch & Hartmann (2023): Loss of control
- **[[SRC-025]]** - Miller (2023): Evaluative AI

### 2. Automated Decision-Making (3 fontes)

- **[[SRC-020]]** - Binns (2022): Attributability gap
- **[[SRC-024]]** - Wagner (2019): Rubber-stamping
- **[[SRC-030]]** - Hartmann & Kriebel (2021): GDPR Article 22

### 3. Governança de IA (3 fontes)

- **[[SRC-021]]** - UNESCO (2021): Human autonomy, HITL/HOTL/HIC
- **[[SRC-022]]** - EU AI Act (2024): Human agency, Appropriate oversight
- **[[SRC-031]]** - Lazcoz & De Hert (2022-2023): Human intervention governance

### 4. Arquiteturas de Agentes (3 fontes)

- **[[SRC-026]]** - IBM (2025): Reactive, Deliberative, Cognitive architectures
- **[[SRC-027]]** - AWS (2025): Agency vs Autonomy
- **[[SRC-028]]** - IEEE (2025): Critical decision points

### 5. Meaningful Human Control (1 fonte)

- **[[SRC-023]]** - Santoni de Sio & van den Hoven (2018): MHC (sem definição aceita)

---

## Conceitos Que "Gritam por Frankl"

### 1. "Meaningful" Human Control

**Usado em:** UNESCO, EU AI Act, IEEE, IBM, AWS, Santoni de Sio (2018)  
**Problema:** Termo "meaningful" NUNCA é definido filosoficamente  
**O que Frankl oferece:** Definição rigorosa de "meaningful" = preservação do espaço de escolha consciente ([[INT-002]])

### 2. "Human Agency"

**Usado em:** EU AI Act, Ridley (2024), AWS (2025)  
**Problema:** Termo "agency" tratado como autoevidente  
**O que Frankl oferece:** Tríade existencial: liberdade-responsabilidade-noos ([[FK-C-003]], [[FK-C-004]])

### 3. "Human Autonomy"

**Usado em:** UNESCO, EU AI Act  
**Problema:** "Autonomy" sem fundamentação existencial  
**O que Frankl oferece:** Liberdade de Vontade como primeiro existencial ([[FK-C-003]])

### 4. "Critical Decision Points"

**Usado em:** IEEE (2025)  
**Problema:** NENHUMA teoria sobre o que torna um ponto "crítico"  
**O que Frankl oferece:** Framework para identificar pontos que afetam resposta autêntica ([[IA-C-004]])

### 5. "Sociodigital Sovereignty"

**Usado em:** Ridley (2024)  
**Problema:** Conceito vago sem fundamentação  
**O que Frankl oferece:** Preservação do espaço frankliano ([[INT-002]])

### 6. "Actionable Agency"

**Usado em:** Ridley (2024)  
**Problema:** Sem teoria sobre POR QUÊ agência importa  
**O que Frankl oferece:** Capacidade de responder (não apenas reagir) ([[INT-002]])

### 7. "Decision Ownership"

**Usado em:** Binns (2022)  
**Problema:** Baseado em Watson (1996), não em teoria existencial  
**O que Frankl oferece:** Autoria existencial de escolhas ([[FK-C-006]])

### 8. "Attributability"

**Usado em:** Binns (2022)  
**Problema:** Sem fundamentação sobre POR QUÊ attributability importa  
**O que Frankl oferece:** "Eu escolhi isso" como reconhecimento noético ([[FK-C-006]])

### 9. "Rubber-Stamping"

**Usado em:** Wagner (2019)  
**Problema:** Sem teoria sobre COMO evitar  
**O que Frankl oferece:** Preservar espaço de deliberação ([[INT-002]])

---

## O Que Está Faltando

### Problemas Identificados

1. ❌ **Definição de "meaningful"** - Tratado como autoevidente
2. ❌ **Fundamentação de "agency"** - Sem teoria existencial
3. ❌ **Critérios para "critical"** - Sem framework
4. ❌ **Teoria sobre "autonomy"** - Conceito vago
5. ❌ **Explicação de POR QUÊ** - Apenas COMO implementar
6. ❌ **Fundamentação filosófica** - Regulações sem base teórica

### O Que Frankl Oferece

1. ✅ **Definição rigorosa de "meaningful"** - Preservação do espaço de escolha consciente
2. ✅ **Teoria sobre agência** - Tríade liberdade-responsabilidade-noos
3. ✅ **Framework para "critical"** - Identificar pontos que afetam resposta autêntica
4. ✅ **Fundamentação de autonomia** - Liberdade de Vontade como existencial
5. ✅ **Explicação de POR QUÊ** - Dimensão noética, autoria existencial
6. ✅ **Base filosófica sólida** - 70+ anos de teoria e prática clínica

---

## Síntese: A Lacuna Teórica

**Situação atual:**
- 45 documentos analisados
- 15+ termos críticos sem definição filosófica
- 6+ problemas sem solução teórica
- 0 menções a Viktor Frankl

**Oportunidade:**
- Frankl oferece exatamente a fundamentação que falta
- Conceitos franklianos mapeiam perfeitamente para termos de IA
- Base para paper acadêmico de alto impacto
- Contribuição para UNESCO, EU AI Act, IEEE, IBM, AWS

---

## Conclusão

A literatura de governança de IA está **repleta de conceitos franklianos** usados **sem citar Frankl**.

Esta é uma **lacuna teórica crítica** que representa uma **oportunidade de pesquisa** de alto impacto.

---

**Próximos passos:** Ver [[SYN-021]] para síntese integradora  
**Conceitos relacionados:** [[IA-C-003]], [[IA-C-004]], [[INT-002]]  
**Frameworks:** [[IA-F-001]], [[IA-F-002]], [[IA-F-003]]

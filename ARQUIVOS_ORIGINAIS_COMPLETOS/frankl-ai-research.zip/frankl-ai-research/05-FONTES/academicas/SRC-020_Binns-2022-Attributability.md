---
id: SRC-020
type: artigo-academico
title: "Attributability Gap in AI Decision Support Systems"
autor: "Binns, R."
ano: 2022
publicacao: "PMC (PubMed Central)"
tags: [attributability, accountability, decision-ownership, ai-dss]
conceitos_chave: [attributability, accountability, decision-ownership, practical-identity]
relacionado: [SRC-018, IA-C-003, FK-C-006]
citado_em: [SRC-018]
---

# Attributability Gap in AI Decision Support Systems

**Autor:** Binns, R.  
**Ano:** 2022  
**Publicação:** PMC (PubMed Central)  
**Foco:** "Decision ownership" em AI-DSS (Decision Support Systems)

---

## Resumo

Artigo sobre o **attributability gap** em sistemas de suporte à decisão baseados em IA. Distingue entre **attributability** (autoria da decisão) e **accountability** (responsabilidade por resultados).

---

## Conceitos-Chave

### 1. Attributability vs Accountability

**Attributability (Atribuibilidade):**
- Autoria da decisão
- Identidade moral
- Caráter do tomador de decisão
- Questão: "Foi a decisão um exercício claro da agência do tomador de decisão, refletindo sua identidade prática?"

**Accountability (Responsabilização):**
- Responsabilidade por resultados
- Culpa, elogio, punição
- Consequências da decisão

**Distinção crítica:**  
Você pode ser **accountable** (responsável) por uma decisão sem que ela seja **attributable** (sua autoria).

---

### 2. Decision Ownership

**Definição:**  
Propriedade existencial de uma decisão - reconhecimento de que "eu escolhi isso".

**Problema identificado:**  
Difícil identificar agentes humanos aos quais podemos atribuir julgamentos de valor refletidos em decisões de AI-DSS.

**Análise frankliana:**  
"Decision ownership" = autoria existencial de escolhas ([[FK-C-006]] - Dimensão Noética)

---

### 3. Practical Identity

**Definição:**  
Identidade prática do tomador de decisão - valores, caráter, julgamentos morais.

**Questão central:**  
A decisão reflete a identidade prática do humano ou do sistema de IA?

**Análise frankliana:**  
"Practical identity" = dimensão noética da pessoa ([[FK-C-006]])

---

## Problema: Attributability Gap

### O Que É

**Gap de atribuibilidade:**  
Situação onde é difícil ou impossível identificar o agente humano responsável por julgamentos de valor em decisões assistidas por IA.

**Exemplo:**
- Sistema de IA recomenda decisão
- Humano aprova (rubber-stamping)
- Decisão não reflete identidade prática do humano
- Mas humano é responsabilizado (accountable)

**Resultado:** Accountability sem attributability

---

### Por Que Importa

**Baseado em Watson (1996):**  
Attributability importa porque:
1. Decisões refletem **caráter** do tomador de decisão
2. Identidade moral está em jogo
3. "Eu escolhi isso" tem significado existencial

**Análise frankliana:**  
Attributability = reconhecimento noético de autoria ("eu escolhi isso") ([[FK-C-006]])

---

## Conexão com Frankl

### Conceitos Franklianos Implícitos

| Conceito de Binns | Equivalente Frankliano | Fundamentação |
|-------------------|------------------------|---------------|
| **Decision ownership** | Autoria existencial de escolhas | [[FK-C-006]] |
| **Practical identity** | Dimensão noética da pessoa | [[FK-C-006]] |
| **Attributability** | "Eu escolhi isso" (reconhecimento noético) | [[FK-C-006]] |
| **Accountability** | Responsabilidade pressupõe liberdade | [[FK-C-004]] |

### O Que Falta

**Binns identifica o problema mas usa Watson (1996), NÃO Frankl:**

1. ❌ O QUE é "practical identity"? (baseado em Watson, não em teoria existencial)
2. ❌ POR QUÊ attributability importa? (sem fundamentação existencial)
3. ❌ COMO preservar decision ownership? (sem framework)
4. ❌ QUANDO attributability é crítica? (sem critérios)

**Frankl ofereceria:**
- Definição rigorosa de "practical identity": dimensão noética (espiritual) da pessoa
- Teoria sobre POR QUÊ attributability importa: autoria existencial, não apenas moral
- Framework para preservar ownership: não colapsar espaço de deliberação
- Critérios para quando é crítica: decisões que afetam identidade existencial

---

## Relevância para Meaningful Human Control

### Conexão com MHC

**Meaningful Human Control** ([[IA-C-003]]) requer:
1. Liberdade real de escolha
2. Responsabilidade correspondente
3. **Attributability** - reconhecimento de autoria

**Sem attributability:**
- Controle não é "meaningful"
- Torna-se rubber-stamping
- Ilusão de escolha

**Framework frankliano:**  
MHC preserva attributability quando preserva espaço frankliano ([[INT-002]])

---

## Citações Representativas

### Sobre Attributability Gap

> "Difícil identificar agentes humanos aos quais podemos atribuir julgamentos de valor refletidos em decisões"

**Análise:**  
Gap existe porque espaço de deliberação foi colapsado

### Sobre Practical Identity

> "Foi a decisão um exercício claro da agência do tomador de decisão, refletindo sua identidade prática?"

**Análise:**  
Questão existencial sobre autoria, não apenas responsabilidade

---

## Contribuição para o Repositório

Este artigo é **crítico** porque:

1. ✅ Distingue attributability de accountability (conceito único)
2. ✅ Introduz "decision ownership" como conceito central
3. ✅ Identifica "practical identity" como critério
4. ❌ **MAS:** Baseado em Watson (1996), não em Frankl

**Frankl oferece fundamentação existencial mais profunda que Watson.**

---

## Próximos Passos

1. [ ] Buscar texto completo do artigo (PMC)
2. [ ] Comparar Watson (1996) com Frankl
3. [ ] Mapear "practical identity" para dimensão noética
4. [ ] Usar como evidência de que attributability requer fundamentação frankliana

---

**Fonte original:** [[SRC-018]] (seção 2.1)  
**Conceitos relacionados:** [[IA-C-003]], [[FK-C-004]], [[FK-C-006]], [[INT-002]]  
**Frameworks:** [[IA-F-001]]

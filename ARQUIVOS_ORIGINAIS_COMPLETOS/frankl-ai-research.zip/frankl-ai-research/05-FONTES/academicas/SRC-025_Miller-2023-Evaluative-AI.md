---
id: SRC-025
type: artigo-academico
title: "Evaluative AI: Moving Beyond Recommend-and-Defend"
autor: "Miller, T."
ano: 2023
tags: [evaluative-ai, xai, recommend-and-defend]
conceitos_chave: [evaluative-ai, evidence-based-xai]
relacionado: [SRC-018, SRC-019, IA-C-003]
citado_em: [SRC-018]
---

# Evaluative AI: Moving Beyond Recommend-and-Defend

**Autor:** Miller, T.  
**Ano:** 2023  
**Crítica:** Abordagens "recommend and defend" de XAI limitam agência do usuário

## Proposta

**XAI não deve:**
- Fornecer recomendações
- Defender decisões pré-tomadas

**XAI deve:**
- Fornecer evidências para apoiar ou refutar julgamentos humanos
- Explicar trade-offs entre opções
- Permitir que o tomador de decisão determine quais opções são melhores

## Análise Frankliana

**Critica exatamente o colapso do espaço de deliberação:**
- "Recommend and defend" = decisão já tomada, humano apenas aprova
- "Evaluative AI" = preserva capacidade humana de escolha informada

**Propõe restaurar capacidade humana de escolha informada** ([[INT-002]])

**MAS:** Sem fundamentação filosófica sobre POR QUÊ isso importa além de eficiência

---

**Fonte:** [[SRC-018]] (seção 1.3)

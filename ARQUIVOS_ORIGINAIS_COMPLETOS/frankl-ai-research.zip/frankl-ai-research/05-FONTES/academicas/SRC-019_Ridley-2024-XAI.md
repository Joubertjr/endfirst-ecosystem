---
id: SRC-019
type: artigo-academico
title: "Human-Centered Explainable AI: Toward a Reflective Sociotechnical Approach"
autor: "Ridley, M."
ano: 2024
publicacao: "Annual Review of Information Science and Technology (ARIST)"
doi: "10.1002/asi.24889"
tags: [xai, sociodigital-sovereignty, actionable-agency, human-centered-ai]
conceitos_chave: [sociodigital-sovereignty, actionable-agency, transparency, explainability]
relacionado: [SRC-018, IA-C-003, INT-002]
citado_em: [SRC-018]
---

# Human-Centered Explainable AI: Toward a Reflective Sociotechnical Approach

**Autor:** Ridley, M.  
**Ano:** 2024  
**Publicação:** Journal of the Association for Information Science and Technology (ARIST)  
**DOI:** 10.1002/asi.24889

---

## Resumo

Artigo de revisão sobre **Explainable AI (XAI)** com foco em abordagem sociotécnica centrada no humano. Introduz conceitos de **"sociodigital sovereignty"** e **"actionable agency"** como critérios para avaliar sistemas de IA.

---

## Conceitos-Chave

### 1. Sociodigital Sovereignty

**Definição:**  
Confluência de **transparência**, **explicabilidade**, **confiança na ação** (eficiência) e **liberdade de ação** (divergência).

**Características:**
- Transparência: Visibilidade do processo de decisão
- Explicabilidade: Compreensão do raciocínio do sistema
- Confiança na ação: Eficiência e confiabilidade
- Liberdade de ação: Capacidade de divergir ou rejeitar

**Análise frankliana:**  
"Sociodigital sovereignty" = preservação do espaço frankliano ([[INT-002]])

---

### 2. Actionable Agency

**Definição:**  
Quando qualquer uma das características da sociodigital sovereignty está ausente ou diminuída, a **agência acionável** dos usuários fica comprometida.

**Características:**
- Capacidade de **agir** baseado em informação
- Não apenas **reagir** a recomendações
- **Escolher** entre alternativas informadas

**Análise frankliana:**  
"Actionable agency" = capacidade de responder (não apenas reagir) ([[INT-002]])

---

## Descobertas Críticas

### Medo de Perda de Controle

**Citação:**
> "Users expressed fear of losing control because of not knowing what the machine is doing and why, but still being responsible for the result" (Schmuntzsch & Hartmann, 2023, p. 499, citado por Ridley)

**Análise:**
- Usuários perdem controle quando não compreendem o sistema
- Mas ainda são responsabilizados pelos resultados
- **Responsabilidade SEM liberdade** = neurose noogênica ([[FK-C-008]])

---

### Human-in-the-Loop (HITL)

**Proposta:**  
Necessidade de **conhecimento** e **engajamento humano** no design inicial e operação contínua.

**Análise frankliana:**
- HITL preserva espaço de deliberação
- Garante que decisões não sejam puramente reativas
- Mantém tríade: liberdade-responsabilidade-noos ([[FK-C-003]], [[FK-C-004]])

---

## Conexão com Frankl

### Conceitos Franklianos Implícitos

| Conceito de Ridley | Equivalente Frankliano | Fundamentação |
|---------------------|------------------------|---------------|
| **Sociodigital sovereignty** | Preservação do espaço frankliano | [[INT-002]] |
| **Actionable agency** | Capacidade de responder (não reagir) | [[INT-002]] |
| **Liberdade de ação** | Liberdade de Vontade | [[FK-C-003]] |
| **Responsabilidade pelos resultados** | Responsabilidade | [[FK-C-004]] |
| **Medo de perda de controle** | Colapso do espaço existencial | [[FK-C-008]] |

### O Que Falta

**Ridley identifica o problema mas não oferece fundamentação filosófica:**

1. ❌ O QUE é "sociodigital sovereignty"? (tratado como autoevidente)
2. ❌ POR QUÊ "actionable agency" importa? (sem teoria existencial)
3. ❌ COMO evitar perda de controle? (sem framework)
4. ❌ QUANDO preservar liberdade de ação? (sem critérios)

**Frankl ofereceria:**
- Definição rigorosa de "sovereignty": preservação do espaço de escolha consciente
- Teoria sobre POR QUÊ agência importa: dimensão noética, autoria existencial
- Framework para evitar perda: não colapsar espaço estímulo-resposta
- Critérios para preservar liberdade: identificar critical decision points ([[IA-C-004]])

---

## Relevância para Governança de IA

### Aplicação a Regulações

**UNESCO (2021):** Human autonomy  
**EU AI Act (2024):** Human agency  
**Ridley (2024):** Sociodigital sovereignty

**Todos usam conceitos similares SEM fundamentação filosófica.**

**Oportunidade:**  
Usar Frankl para fundamentar "sociodigital sovereignty" em regulações e standards.

---

## Citações Representativas

### Sobre Perda de Controle

> "Users expressed fear of losing control because of not knowing what the machine is doing and why, but still being responsible for the result"

**Análise:**  
Responsabilidade sem liberdade = violação da tríade existencial

### Sobre Actionable Agency

> "When any of these characteristics [transparency, explainability, trust, freedom] is absent or diminished, users' actionable agency is compromised"

**Análise:**  
Compromisso da agência = colapso do espaço frankliano

---

## Contribuição para o Repositório

Este artigo é **crítico** porque:

1. ✅ Introduz conceitos centrais: sociodigital sovereignty, actionable agency
2. ✅ Identifica problema: responsabilidade sem controle
3. ✅ Propõe HITL como solução
4. ❌ **MAS:** Sem fundamentação filosófica

**Frankl preenche exatamente essa lacuna.**

---

## Próximos Passos

1. [ ] Buscar texto completo do artigo (DOI: 10.1002/asi.24889)
2. [ ] Extrair definições formais de "sociodigital sovereignty"
3. [ ] Mapear todos os conceitos para equivalentes franklianos
4. [ ] Usar como evidência em paper sobre lacuna teórica

---

**Fonte original:** [[SRC-018]] (seção 1.1)  
**Conceitos relacionados:** [[IA-C-003]], [[INT-002]], [[FK-C-003]], [[FK-C-004]], [[FK-C-008]]  
**Frameworks:** [[IA-F-001]] (Meaningful HCI)

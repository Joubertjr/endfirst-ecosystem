---
id: SRC-022
type: regulacao-governanca
title: "European Union Artificial Intelligence Act"
organizacao: "European Union"
ano: 2024
tipo_documento: "Regulação legal"
tags: [governanca-ia, human-agency, human-oversight, eu-ai-act, regulacao]
conceitos_chave: [human-agency, appropriate-oversight, risk-based-approach]
relacionado: [SRC-018, SRC-021, IA-C-003, IA-C-004]
citado_em: [SRC-018]
---

# European Union Artificial Intelligence Act (EU AI Act)

**Organização:** European Union  
**Ano:** 2024  
**Tipo:** Regulação legal vinculante  
**Status:** Primeira regulação abrangente de IA do mundo

---

## Resumo

Regulação europeia que estabelece regras para desenvolvimento, comercialização e uso de sistemas de IA na União Europeia. Baseada em **abordagem de risco** (risk-based approach).

---

## Princípios Orientadores

### 1. Human Agency

**Definição EU AI Act:**  
Sistemas de IA devem "servir as pessoas" (AI systematically prioritises humans).

**Recital 6:**
> "AI systematically prioritises humans"

**Problema:** Termo **nunca é DEFINIDO filosoficamente**

**Análise frankliana:**  
"Human agency" = tríade existencial: liberdade-responsabilidade-noos ([[FK-C-003]], [[FK-C-004]])

---

### 2. Human Oversight

**Definição EU AI Act:**  
Supervisão "apropriada" por humanos, aplicável a todos os níveis de risco.

**Para sistemas de alto risco:**
- Supervisores devem ter **competência**
- Supervisores devem ter **treinamento**
- Supervisores devem ter **autoridade** necessárias
- Nível de **literacia em IA** deve ser garantido

**Problema:** Nenhuma orientação sobre ONDE colocar pontos de intervenção

**Análise frankliana:**  
"Appropriate oversight" = preservação do espaço frankliano em critical decision points ([[IA-C-004]])

---

## Abordagem de Risco

### Classificação de Sistemas

**4 níveis de risco:**

1. **Risco inaceitável** (proibido)
   - Manipulação subliminar
   - Exploração de vulnerabilidades
   - Social scoring governamental
   - Vigilância biométrica em tempo real

2. **Alto risco**
   - Infraestrutura crítica
   - Educação e treinamento vocacional
   - Emprego e gestão de trabalhadores
   - Serviços públicos e privados essenciais
   - Aplicação da lei
   - Gestão de migração, asilo e controle de fronteiras
   - Administração da justiça e processos democráticos

3. **Risco limitado** (obrigações de transparência)
   - Chatbots
   - Sistemas de geração de conteúdo (deepfakes)

4. **Risco mínimo** (sem restrições)
   - Filtros de spam
   - Jogos de vídeo

---

## Problema: Sem Fundamentação Filosófica

### O Que Falta

**EU AI Act estabelece classificação mas NÃO explica:**

1. ❌ O QUE é "human agency"? (nunca definido)
2. ❌ POR QUÊ alguns sistemas são "alto risco"? (sem fundamentação)
3. ❌ COMO determinar quando supervisão é "apropriada"? (sem critérios)
4. ❌ ONDE colocar pontos de intervenção humana? (sem orientação)
5. ❌ O QUE significa "priorizar humanos"? (vago)

**Resultado:** Regulação sem base teórica para implementação

---

## Framework Frankliano para EU AI Act

### Fundamentação de "Human Agency"

**Definição frankliana:**  
"Human agency" = capacidade de tomar posição entre estímulo e resposta

**Componentes:**
1. **Liberdade de Vontade** ([[FK-C-003]]) - capacidade de escolher
2. **Responsabilidade** ([[FK-C-004]]) - assumir autoria das escolhas
3. **Dimensão Noética** ([[FK-C-006]]) - "eu escolhi isso"

**Tríade existencial:** Liberdade-Responsabilidade-Noos

---

### Fundamentação de Classificação de Risco

**Framework frankliano proposto:**

| Classificação AI Act | Risco Existencial | Fundamentação Frankliana |
|----------------------|-------------------|--------------------------|
| **Risco inaceitável** | Colapso total do espaço frankliano | Manipulação elimina liberdade de escolha |
| **Alto risco** | 🔴 Crítico Existencial | Afeta identidade, valores, dignidade, direitos |
| **Risco limitado** | 🟡 Crítico Operacional | Afeta bem-estar, requer transparência |
| **Risco mínimo** | 🟢 Não-Crítico | Tarefas operacionais sem impacto em agência |

**Critério:** Quanto maior o potencial de colapso do espaço frankliano, maior o risco

---

### Critérios para "Appropriate Oversight"

**Framework frankliano:**

**Oversight é "apropriado" quando:**
1. ✅ Preserva tempo de deliberação (não força decisões imediatas)
2. ✅ Fornece informação adequada (compreensão real)
3. ✅ Garante liberdade real (alternativas genuínas)
4. ✅ Alinha responsabilidade e liberdade (tríade existencial)
5. ✅ Preserva autoria existencial ("eu escolhi isso")

**Oversight NÃO é apropriado quando:**
1. ❌ Rubber-stamping (aprovação sem deliberação)
2. ❌ Responsabilidade sem liberdade
3. ❌ Informação insuficiente
4. ❌ Pressão temporal
5. ❌ Ilusão de escolha

---

### Identificação de Pontos de Intervenção

**Framework frankliano para Critical Decision Points ([[IA-C-004]]):**

**Matriz de decisão:**
1. Afeta identidade/valores/dignidade? → 🔴 HITL obrigatório
2. Colapsa espaço frankliano? → 🔴 HITL obrigatório
3. Elimina liberdade real? → 🟡 HOTL recomendado
4. Envolve julgamento moral? → 🔴 HITL obrigatório
5. Irreversível ou longo prazo? → 🟡 HOTL recomendado

---

## Conexão com UNESCO

### UNESCO (2021) + EU AI Act (2024)

**UNESCO:** Princípios globais (HITL/HOTL/HIC)  
**EU AI Act:** Regulação vinculante (classificação de risco)

**Ambos carecem de fundamentação filosófica.**

**Solução frankliana:**  
Usar conceitos de Frankl para fundamentar AMBOS:
- UNESCO: definir O QUE é human autonomy
- EU AI Act: explicar POR QUÊ alguns sistemas são alto risco

---

## Relevância para Meaningful Human Control

### EU AI Act + MHC

**EU AI Act:** "Appropriate oversight"  
**MHC:** Meaningful Human Control ([[IA-C-003]])

**Problema:** AI Act não define O QUE torna oversight "meaningful"

**Solução frankliana:**  
Oversight é "meaningful" quando preserva espaço de escolha consciente ([[INT-002]])

---

## Exemplos de Aplicação

### Caso 1: Contratação Automatizada (Alto Risco)

**AI Act:** Sistema de alto risco (emprego)  
**Requisito:** Human oversight apropriado

**Análise frankliana:**
- ✅ Afeta identidade profissional? **Sim**
- ✅ Colapsa espaço frankliano? **Sim** (decisão binária)
- ✅ Julgamento moral? **Parcial** (impacto social)

**Classificação:** 🔴 Crítico Existencial  
**Requisito:** HITL - humano deve decidir, não apenas aprovar

---

### Caso 2: Chatbot (Risco Limitado)

**AI Act:** Risco limitado (obrigação de transparência)  
**Requisito:** Informar que é IA

**Análise frankliana:**
- ❌ Afeta identidade? **Não**
- ❌ Colapsa espaço frankliano? **Não** (usuário pode parar)
- ❌ Julgamento moral? **Não**

**Classificação:** 🟢 Não-Crítico  
**Requisito:** Transparência suficiente

---

## Citações Representativas

### Sobre Human Agency

> "AI systematically prioritises humans" (Recital 6)

**Análise:**  
Princípio claro, mas O QUE significa "priorizar humanos"? Sem definição.

### Sobre Supervisão

> "Supervisores devem ter competência, treinamento, autoridade necessárias"

**Análise:**  
Requisitos claros, mas QUANDO e ONDE supervisionar? Sem orientação.

---

## Contribuição para o Repositório

Este documento é **crítico** porque:

1. ✅ Primeira regulação abrangente de IA do mundo
2. ✅ Vinculante para 27 países da UE
3. ✅ Estabelece classificação de risco e requisitos de oversight
4. ❌ **MAS:** Sem fundamentação filosófica para implementação

**Frankl oferece exatamente a fundamentação que falta.**

---

## Próximos Passos

1. [ ] Buscar texto completo do EU AI Act
2. [ ] Mapear todos os artigos para conceitos franklianos
3. [ ] Propor framework de implementação baseado em Frankl
4. [ ] Usar como evidência de lacuna em regulações vinculantes

---

**Fonte original:** [[SRC-018]] (seção 3.2)  
**Conceitos relacionados:** [[IA-C-003]], [[IA-C-004]], [[FK-C-003]], [[FK-C-004]], [[FK-C-005]], [[FK-C-006]], [[INT-002]]  
**Regulações relacionadas:** [[SRC-021]] (UNESCO)

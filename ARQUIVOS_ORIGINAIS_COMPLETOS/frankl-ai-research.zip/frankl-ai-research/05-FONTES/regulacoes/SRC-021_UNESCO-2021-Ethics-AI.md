---
id: SRC-021
type: regulacao-governanca
title: "UNESCO Recommendation on the Ethics of Artificial Intelligence"
organizacao: "UNESCO"
ano: 2021
tipo_documento: "Recomendação oficial"
tags: [governanca-ia, human-autonomy, human-oversight, unesco, etica-ia]
conceitos_chave: [human-autonomy, human-oversight, hitl, hotl, hic]
relacionado: [SRC-018, SRC-022, IA-C-003, IA-C-004]
citado_em: [SRC-018]
---

# UNESCO Recommendation on the Ethics of Artificial Intelligence

**Organização:** UNESCO  
**Ano:** 2021  
**Tipo:** Recomendação oficial sobre ética de IA  
**Status:** Documento de governança internacional

---

## Resumo

Primeiro instrumento normativo global sobre ética de IA, adotado por 193 países. Estabelece princípios fundamentais para desenvolvimento e uso responsável de IA.

---

## Princípios Centrais

### 1. Human Autonomy

**Definição UNESCO:**  
Humanos devem ser livres para expressar opiniões e tomar decisões **sem interferência, coerção ou manipulação**.

**Características:**
- Liberdade de expressão
- Liberdade de decisão
- Proteção contra interferência
- Proteção contra coerção
- Proteção contra manipulação

**Análise frankliana:**  
"Human autonomy" = liberdade como primeiro existencial ([[FK-C-003]])

**Conexão com Frankl:**
- "Sem interferência" = preservação do espaço de escolha
- "Sem coerção" = liberdade de vontade
- "Sem manipulação" = autenticidade da resposta

---

### 2. Human Oversight

**Definição UNESCO:**  
Garantir que sistemas de IA não façam decisões sem supervisão humana.

**Três tipos propostos:**

#### 2.1. Human-in-the-Loop (HITL)

**Descrição:** Humano **media todas as decisões**  
**Quando usar:** Decisões críticas que requerem julgamento humano  
**Análise frankliana:** Preserva completamente o espaço frankliano

#### 2.2. Human-on-the-Loop (HOTL)

**Descrição:** Humano **monitora** e **pode intervir**  
**Quando usar:** Decisões que podem ser delegadas mas requerem supervisão  
**Análise frankliana:** Preserva parcialmente o espaço frankliano

#### 2.3. Human-in-Command (HIC)

**Descrição:** Supervisão estendida a impactos **econômicos, sociais, legais, éticos**  
**Quando usar:** Supervisão estratégica de sistemas complexos  
**Análise frankliana:** Supervisão de impactos existenciais

---

### 3. Protection of Fundamental Rights

**Princípio:** Sistemas de IA não devem violar direitos humanos fundamentais.

**Direitos protegidos:**
- Dignidade humana
- Privacidade
- Liberdade
- Igualdade
- Não-discriminação

**Análise frankliana:**  
Dignidade humana = capacidade de tomar posição ([[FK-C-005]])

---

### 4. Transparency and Fairness

**Transparência:** Visibilidade do processo de decisão  
**Fairness:** Justiça e não-discriminação

**Análise frankliana:**  
Transparência é **meio** para preservar agência, não fim em si

---

## Problema: Falta de Fundamentação Filosófica

### O Que Falta

**UNESCO estabelece princípios mas NÃO define:**

1. ❌ O QUE é "human autonomy"? (tratado como autoevidente)
2. ❌ QUANDO usar HITL vs HOTL vs HIC? (sem critérios)
3. ❌ O QUE torna oversight "significativo" vs "rubber-stamping"?
4. ❌ COMO determinar quando supervisão é "apropriada"?

**Resultado:** Princípios vagos sem orientação de implementação

---

## Framework Frankliano para UNESCO

### Definições Fundamentadas

| Princípio UNESCO | Definição Frankliana | Conceito |
|------------------|----------------------|----------|
| **Human autonomy** | Liberdade de Vontade | [[FK-C-003]] |
| **Human oversight** | Preservação do espaço frankliano | [[INT-002]] |
| **Fundamental rights** | Capacidade de tomar posição | [[FK-C-005]] |
| **Dignity** | Dignidade existencial | [[FK-C-005]] |

### Critérios para HITL/HOTL/HIC

**Framework frankliano proposto:**

| Nível de Criticidade | Tipo de Oversight | Fundamentação |
|----------------------|-------------------|---------------|
| 🔴 **Crítico Existencial** | **HITL** | Decisões que afetam identidade, valores, dignidade |
| 🟡 **Crítico Operacional** | **HOTL** | Decisões que afetam bem-estar mas não identidade |
| 🟢 **Não-Crítico** | **HIC** | Supervisão estratégica de impactos |

**Critério:** Quanto maior o potencial de colapso do espaço frankliano, mais crítico ([[IA-C-004]])

---

## Conexão com Meaningful Human Control

### UNESCO + MHC

**UNESCO (2021):** Human oversight (HITL/HOTL/HIC)  
**MHC:** Meaningful Human Control ([[IA-C-003]])

**Problema:** UNESCO não define O QUE torna oversight "meaningful"

**Solução frankliana:**  
Oversight é "meaningful" quando preserva espaço de escolha consciente ([[INT-002]])

**Critérios de significância:**
1. ✅ Tempo de deliberação
2. ✅ Informação adequada
3. ✅ Liberdade real
4. ✅ Responsabilidade correspondente
5. ✅ Autoria existencial

---

## Relevância para Governança de IA

### Aplicação a Regulações

**UNESCO (2021):** Princípios globais  
**EU AI Act (2024):** Regulação europeia ([[SRC-022]])  
**LGPD Art. 20:** Regulação brasileira

**Todos usam conceitos similares SEM fundamentação filosófica.**

**Oportunidade:**  
Usar Frankl para fundamentar princípios da UNESCO em implementações nacionais.

---

## Citações Representativas

### Sobre Human Autonomy

> "Humanos livres para expressar opiniões e tomar decisões sem interferência, coerção ou manipulação"

**Análise:**  
Definição de liberdade, mas sem teoria sobre O QUE é essa liberdade

### Sobre Human Oversight

> "Garantir que sistemas IA não façam decisões sem supervisão"

**Análise:**  
Princípio claro, mas sem orientação sobre QUANDO e COMO supervisionar

---

## Contribuição para o Repositório

Este documento é **crítico** porque:

1. ✅ Primeiro instrumento normativo global sobre ética de IA
2. ✅ Adotado por 193 países (alta relevância)
3. ✅ Introduz HITL/HOTL/HIC como tipos de oversight
4. ❌ **MAS:** Sem fundamentação filosófica para implementação

**Frankl oferece exatamente a fundamentação que falta.**

---

## Próximos Passos

1. [ ] Buscar texto completo da Recomendação UNESCO
2. [ ] Mapear todos os princípios para conceitos franklianos
3. [ ] Propor framework de implementação baseado em Frankl
4. [ ] Usar como evidência de lacuna em regulações internacionais

---

**Fonte original:** [[SRC-018]] (seção 3.1)  
**Conceitos relacionados:** [[IA-C-003]], [[IA-C-004]], [[FK-C-003]], [[FK-C-005]], [[INT-002]]  
**Regulações relacionadas:** [[SRC-022]] (EU AI Act)

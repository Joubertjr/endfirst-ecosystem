# Mapas Conceituais
[← Voltar](../README.md)

## Estrutura da Logoterapia

```
Vontade de Sentido (central)
    ↓
Três Pilares:
1. Liberdade de Vontade
2. Vontade de Sentido  
3. Sentido da Vida
    ↓
Três Caminhos:
1. Via Criativa
2. Via Vivencial
3. Via Atitudinal
```

## Automação e Espaço Frankliano

```
Sistema Tradicional:
Estímulo → Resposta (automático)

Sistema Humano:
Estímulo → [ESPAÇO: consciência, escolha, liberdade] → Resposta

Sistema Automatizado:
Estímulo → [ESPAÇO COLAPSADO: algoritmo] → Resposta

Questão: Onde preservar o espaço?
```

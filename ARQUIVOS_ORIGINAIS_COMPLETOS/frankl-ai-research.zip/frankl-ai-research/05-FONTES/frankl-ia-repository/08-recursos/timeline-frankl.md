# Linha do Tempo de Viktor Frankl
[← Voltar](../README.md)

- **1905:** Nascimento em Viena
- **1924:** Primeiro artigo publicado
- **1925:** Expulso círculo de Adler
- **1930:** Graduação em Medicina
- **1938:** Primeira menção "logoterapia"
- **1942-1945:** Campos de concentração
- **1946:** "Man's Search for Meaning" ditado em 9 dias
- **1948:** PhD em Filosofia
- **1955-1990:** Professor Universidade de Viena
- **1992:** Fundação Viktor Frankl Institute
- **1997:** Morte em Viena (92 anos)

# Glossário de Termos
[← Voltar](../README.md)

**Logoterapia:** Psicoterapia centrada no sentido (logos = sentido)

**Vontade de Sentido:** Motivação primária humana

**Vazio Existencial:** Falta de sentido na vida moderna

**Neurose Noogênica:** Sofrimento por falta de sentido

**Autotranscendência:** Ir além de si mesmo

**Tríade Trágica:** Sofrimento, culpa, morte

**Otimismo Trágico:** Esperança apesar de adversidade

**Dimensão Noética:** Dimensão humana do sentido/espiritual

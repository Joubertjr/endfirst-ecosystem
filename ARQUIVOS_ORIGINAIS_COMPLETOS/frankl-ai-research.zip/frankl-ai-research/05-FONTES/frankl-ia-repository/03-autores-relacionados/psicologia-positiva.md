# Psicologia Positiva e Frankl
[← Voltar](../README.md)

## Martin Seligman (PP 1.0)
- Fundador Psicologia Positiva (1998)
- PERMA model
- Foco em felicidade/otimismo
- **Diferença:** Hedônico vs. Eudaimônico (Frankl)

## Paul T. P. Wong (PP 2.0)
- Criador Positive Psychology 2.0 (2011)
- Baseada em Frankl
- **Tragic Optimism**
- **Self-Transcendence**
- Modelo Frankl-Wong

**PP 2.0 = Existential Positive Psychology + Indigenous Psychology**

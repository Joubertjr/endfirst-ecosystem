# Continuadores da Logoterapia
[← Voltar](../README.md)

## Principais

### Elisabeth Lukas (1942-)
- Austríaca, uma das principais discípulas
- 30 livros, Logo-Test
- Defende logoterapia pura de Frankl

### Alfried Längle (1951-)
- Austríaco, fundador GLE Vienna
- Desenvolveu Análise Existencial Pessoal
- 4 Motivações Fundamentais
- Controvérsia: modificou conceitos originais

### Alexander Batthyány (1969-)
- Diretor Viktor Frankl Institute Vienna
- Editor obra completa (12 volumes)
- Pesquisa empírica em logoterapia

### Joseph Fabry (1909-1994)
- Sobrevivente Holocausto
- Fundador Institute of Logotherapy (California)

# Existencialistas Europeus
[← Voltar](../README.md)

## Precursores (Século XIX)
- **Søren Kierkegaard** (1813-1855): Angústia, fé, subjetividade
- **Friedrich Nietzsche** (1844-1900): "Quem tem porquê vive qualquer como"

## Século XX
- **Martin Heidegger** (1889-1976): Dasein, ser-para-a-morte
- **Jean-Paul Sartre** (1905-1980): Existência precede essência
- **Karl Jaspers** (1883-1969): Situações-limite
- **Martin Buber** (1878-1965): Relação Eu-Tu
- **Albert Camus** (1913-1960): Absurdismo
- **Gabriel Marcel** (1889-1973): Existencialismo cristão

# Meta-análises
[← Voltar](../README.md)

Ver: Batthyany & Associates (2005, 2009)
Proceedings of Viktor Frankl Institute

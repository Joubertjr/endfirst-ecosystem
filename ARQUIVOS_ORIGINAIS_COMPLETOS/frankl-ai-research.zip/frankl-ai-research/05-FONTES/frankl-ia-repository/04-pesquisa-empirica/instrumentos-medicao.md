# Instrumentos de Medição
[← Voltar](../README.md)

## Principais

1. **Purpose in Life Test (PIL)** - Crumbaugh & Maholick (1964)
2. **Logo-Test** - Elisabeth Lukas
3. **Life Attitude Scale (LAS)** - Wong
4. **Meaning in Life Questionnaire (MLQ)** - Michael Steger
5. **Existence Scale (ES)** - Alfried Längle

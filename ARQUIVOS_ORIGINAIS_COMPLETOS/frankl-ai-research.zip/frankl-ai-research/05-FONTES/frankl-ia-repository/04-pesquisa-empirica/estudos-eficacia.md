# Estudos de Eficácia da Logoterapia
[← Voltar](../README.md)

## Resultados Principais

**Depressão:**
- Effect size: **d = 1.885-1.961** (muito grande)
- 42+ estudos empíricos

**Aplicações:**
- Câncer: Melhora qualidade de vida
- PTSD: Transformação de trauma
- Doenças crônicas: Maior resiliência
- Burnout: Prevenção via sentido

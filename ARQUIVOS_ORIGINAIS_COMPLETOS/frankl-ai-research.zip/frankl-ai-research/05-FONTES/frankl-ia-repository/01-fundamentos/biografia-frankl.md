# Biografia de Viktor Emil Frankl

[← Voltar ao índice](../README.md)

---

## Dados Biográficos Essenciais

**Nome Completo:** Viktor Emil Frankl  
**Nascimento:** 26 de março de 1905, Viena, Áustria-Hungria  
**Morte:** 2 de setembro de 1997, Viena, Áustria (92 anos)  
**Nacionalidade:** Austríaco  
**Profissão:** Neurologista, Psiquiatra, Filósofo  

---

## Formação Acadêmica

### Educação Formal

- **Medicina:** Universidade de Viena (graduação 1930)
- **Especialização:** Neurologia e Psiquiatria
- **Doutorado em Filosofia:** 1948, Universidade de Viena

### Desenvolvimento Intelectual Precoce

- **1924:** Primeiro artigo publicado no *International Journal of Psychoanalysis*
- **1924:** Presidente do movimento juvenil socialista para estudantes secundários
- **Anos 1920:** Correspondência com Sigmund Freud (ainda adolescente)
- **1925:** Expulso do círculo de Alfred Adler por insistir que **sentido** (não poder) era motivação primária

---

## Trajetória Profissional

### Pré-Guerra (1930-1942)

**1930-1933:** Hospital Psiquiátrico Am Steinhof, Viena
- Chefe do programa de prevenção de suicídio feminino

**1933-1937:** Direção do programa de prevenção de suicídio juvenil
- **Resultado:** Redução dramática de suicídios entre adolescentes em Viena
- Estabeleceu centros de aconselhamento juvenil

**1937-1940:** Prática médica privada (neurologia e psiquiatria)

**1940-1942:** Chefe de Neurologia no Hospital Rothschild
- Único hospital para população judaica em Viena
- Tratamento de pacientes judeus sob regime nazista

### Anos de Concentração (1942-1945)

**25 de setembro de 1942:** Deportação com toda a família
- Pais: Gabriel e Elsa Frankl
- Irmão: Walter
- Primeira esposa: Tilly Grosser (casada em 1941)
- Única sobrevivente: Irmã Stella

**Campos onde esteve:**
1. **Theresienstadt Ghetto** (1942-1944)
   - Pai morreu em 6 meses
2. **Auschwitz** (outubro 1944)
   - Mãe e irmão mortos
   - Frankl ficou poucos dias (área de depósito)
3. **Kaufering III** (subcampo de Dachau, 1944-1945)
   - Trabalho forçado
   - Desenvolvimento de ideias sobre logoterapia
4. **Türkheim** (até libertação em abril 1945)
   - Esposa Tilly morreu em Bergen-Belsen

**Experiência-limite:**
- Reduzido ao "ser e não-ser"
- Perda de manuscrito sobre logoterapia
- Observação sistemática do comportamento humano em condições extremas
- Descoberta empírica: quem tinha "porquê" (sentido) sobrevivia melhor

### Pós-Guerra (1945-1997)

**1945:** Retorno a Viena
- Reconstrução profissional e emocional

**1946:** Produção intensa
- Dita *Ein Psycholog erlebt das Konzentrationslager* em **9 dias**
  - Publicado como "Man's Search for Meaning"
- Publica *Ärztliche Seelsorge* ("The Doctor and the Soul")

**1947:** Novo casamento
- Eleonore "Elly" Katharina Schwindt
- Filha: Gabriele Frankl (psicóloga infantil)
- Casamento durou 50 anos até morte de Frankl

**1946-1971:** Chefe da Pró-clínica Neurológica de Viena

**1955-1990:** Professor de Neurologia e Psiquiatria
- Universidade de Viena

**1961-1990:** Docente em Universidades Americanas
- Harvard
- Stanford
- Duquesne
- Southern Methodist University
- Pittsburgh
- U.S. International University (San Diego)

**1992:** Fundação do Viktor Frankl Institute (Viena)

**1997:** Morte por falência cardíaca
- Deixou legado de 39 livros
- Milhões de vidas impactadas pela logoterapia

---

## Família

### Família de Origem

- **Pai:** Gabriel Frankl (funcionário público no Ministério de Serviço Social)
- **Mãe:** Elsa Lion Frankl
- **Irmão:** Walter Frankl (morto em Auschwitz)
- **Irmã:** Stella Frankl (única sobrevivente)

**Origem:** Família judia vienense de classe média

### Casamentos

**Primeiro Casamento (1941-1945):**
- Tilly Grosser
- Enfermeira no Hospital Rothschild
- Deportada junto com Frankl
- Morreu em Bergen-Belsen (1945)
- Sem filhos

**Segundo Casamento (1947-1997):**
- Eleonore "Elly" Katharina Schwindt
- Filha: Gabriele Frankl (nascida 1947)
- Casamento durou 50 anos
- Elly tornou-se presidente honorária do Viktor Frankl Institute

---

## Reconhecimentos e Honrarias

### Prêmios

**1985:** Oskar Pfister Award
- American Psychiatric Association
- Contribuições à religião e psiquiatria

### Doutorados Honorários

- Loyola University (Chicago)
- Edgecliff College
- Rockford College
- Mount Mary College
- Universidades no Brasil
- Diversas instituições europeias e americanas

### Legado Literário

- **39 livros** publicados
- Traduções em **50+ idiomas**
- **Man's Search for Meaning:**
  - 16+ milhões de cópias vendidas
  - Top 10 livros mais influentes (Library of Congress, EUA)
  - Considerado um dos livros mais importantes do século XX

---

## Desenvolvimento da Logoterapia

### Linha do Tempo Conceitual

**Anos 1920-1930:**
- Divergência com Freud (motivação não é apenas prazer sexual)
- Expulsão do círculo de Adler (motivação não é apenas poder)
- Formulação inicial: **"vontade de sentido"** como motivação primária

**1938:** Primeira publicação usando termo "logoterapia"
- Artigo: "Zur geistigen Problematik der Psychotherapie"

**1942:** Manuscrito sobre logoterapia confiscado ao entrar em Theresienstadt
- Frankl tentou recriar de memória durante aprisionamento

**1942-1945:** "Laboratório" dos campos de concentração
- Observação sistemática: quem tinha sentido resistia melhor
- Validação empírica das ideias pré-guerra

**1946:** Sistematização pós-libertação
- Redação de "Man's Search for Meaning" em 9 dias
- Fundação da "Terceira Escola Vienense de Psicoterapia"
  - 1ª: Sigmund Freud (Psicanálise)
  - 2ª: Alfred Adler (Psicologia Individual)
  - 3ª: Viktor Frankl (Logoterapia)

**1946-1997:** Expansão e consolidação
- Ensino em universidades mundiais
- Publicação de 39 livros
- Formação de milhares de logoterapeutas
- Reconhecimento científico internacional

---

## Características Pessoais

### Paixões

- **Montanhismo:** Escalou Alpes austríacos até idade avançada
- **Aviação:** Obteve licença de piloto aos 67 anos
- **Música:** Apreciador de música clássica

### Filosofia de Vida

**Otimismo Trágico:**
> "Diga sim à vida apesar de tudo."

**Humor como Resiliência:**
- Usava humor até em palestras sobre Holocausto
- Via humor como ferramenta de distanciamento psicológico

**Responsabilidade:**
- Acreditava que cada pessoa é única e responsável
- Crítico do determinismo radical
- Defensor da liberdade existencial

---

## Controvérsias e Críticas

### Debate sobre relato de Auschwitz

**Timothy Pytell (2000s):**
- Alegou discrepâncias no relato autobiográfico
- Frankl teria ficado apenas dias (não meses) em Auschwitz

**Resposta de Alexander Batthyány:**
- Pytell nunca consultou arquivos primários
- Não entrevistou Frankl enquanto vivo
- Interpretação contextualmente inadequada

### Uso por negacionistas

**Theodore O'Keefe (negacionista do Holocausto):**
- Usou críticas a Frankl para questionar Holocausto

**Consenso acadêmico:**
- Críticas não invalidam experiência ou contribuição de Frankl
- Logoterapia validada independentemente por pesquisa empírica

---

## Legado

### Impacto Científico

- Fundação de escola psicoterapêutica reconhecida mundialmente
- 42+ estudos empíricos validando eficácia
- Effect size d=1.885-1.961 para depressão
- Integração com CBT, ACT, mindfulness

### Impacto Cultural

- Inspiração para milhões através de "Man's Search for Meaning"
- Influência em psicologia positiva (Martin Seligman, Paul Wong)
- Aplicações em coaching, liderança, educação

### Impacto Filosófico

- Renovação do existencialismo após Segunda Guerra
- Ponte entre psicoterapia e filosofia existencial
- Resposta ao niilismo moderno

### Instituições

- **Viktor Frankl Institute Vienna** (1992)
- **Viktor Frankl Institute of America**
- **Elisabeth Lukas Archive** (Alemanha)
- Dezenas de centros de logoterapia em todos os continentes

---

## Citações Memoráveis

> "Quando não podemos mudar a situação, somos desafiados a mudar a nós mesmos."

> "Entre o estímulo e a resposta existe um espaço. Nesse espaço está nosso poder de escolher nossa resposta."

> "O que o homem realmente precisa não é um estado sem tensão, mas sim a luta por um objetivo que valha a pena."

> "Tudo pode ser tirado de um homem, menos uma coisa: a última das liberdades humanas — escolher sua atitude em qualquer conjunto de circunstâncias."

> "Aqueles que têm um 'porquê' viver podem suportar quase qualquer 'como'." (citando Nietzsche)

---

## Referências

- Frankl, V. E. (2000). *Viktor Frankl Recollections: An Autobiography*. Perseus.
- Batthyány, A. (Ed.). (2024). *Viktor Frankl and the Shoah*. Viktor Frankl Institute.
- Pytell, T. (2006). *Transcending the Angel Beast: Viktor Frankl and Humanistic Psychology*. Psychoanalytic Psychology.

---

[← Voltar ao índice](../README.md) | [Próximo: Conceitos Centrais →](conceitos-centrais-logoterapia.md)

# Tríade Trágica e Otimismo Trágico

[← Voltar ao índice](../README.md)

## Tríade Trágica

**Três dimensões irredutíveis da existência humana:**

1. **Sofrimento** (inevitável)
2. **Culpa** (irreparável)
3. **Morte** (inescapável)

**Resposta de Frankl:** Mesmo diante dessa tríade, permanece a **"última das liberdades humanas"** - escolher nossa atitude.

## Otimismo Trágico

> "Diga sim à vida apesar de tudo."

**Definição:** Manter esperança e encontrar sentido **apesar** de experiências trágicas.

**Não é:**
- ❌ Otimismo ingênuo (negar realidade)
- ❌ Pensamento positivo superficial
- ❌ Autoajuda piegas

**É:**
- ✅ Realismo + Esperança
- ✅ Aceitação + Transformação
- ✅ Ver potencial de sentido no sofrimento

## 5 Ingredientes (Paul Wong)

1. **Aceitação** do que não pode ser mudado
2. **Afirmação** do valor da vida
3. **Autotranscendência**
4. **Fé** em Deus/outros/vida
5. **Coragem** para enfrentar adversidade

[← Voltar ao índice](../README.md)

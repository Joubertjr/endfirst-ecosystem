# Conceitos Centrais da Logoterapia

[← Voltar ao índice](../README.md)

---

## Vontade de Sentido (Will to Meaning)

**Definição:** A motivação primária do ser humano é a busca por sentido na vida.

**Diferenciação:**
- **Freud:** Vontade de prazer (princípio do prazer)
- **Adler:** Vontade de poder (superioridade)
- **Frankl:** Vontade de sentido (busca de significado)

**Características:**
- Força motivacional **primária** (não secundária/defensiva)
- Transcende necessidades básicas (Maslow)
- Validada empiricamente nos campos de concentração
- Sentido é **descoberto**, não criado ou dado

---

## Três Pilares Filosóficos

### 1. Liberdade de Vontade
- Humanos não são completamente determinados
- Capacidade de tomar posição frente às condições
- **"Última das liberdades humanas":** escolher atitude

### 2. Vontade de Sentido
- Motivação primária para significado
- Frustração gera vazio existencial
- Diferente de busca por felicidade

### 3. Sentido da Vida
- Vida tem sentido em todas as circunstâncias
- Sentido é único e pessoal
- Pode ser encontrado mesmo no sofrimento

---

## Autotranscendência

**Conceito:** Sentido é sempre encontrado **fora** de si mesmo.

**Contraste com auto-realização (Maslow):**
- Auto-realização = efeito colateral
- Autotranscendência = objetivo primário
- Quanto mais se busca felicidade, mais ela escapa
- Sentido vem de servir algo/alguém maior

---

## Três Caminhos para o Sentido

### 1. Via Criativa
- Criar obra ou realizar ato significativo
- Contribuição ao mundo através do trabalho
- Legado tangível

### 2. Via Vivencial
- Experienciar algo (beleza, natureza, arte)
- Amar alguém (encontro genuíno)
- Relações autênticas Eu-Tu (Martin Buber)

### 3. Via Atitudinal
- Transformar sofrimento inevitável em conquista
- Escolher atitude diante de tragédia
- **Mais importante:** quando outras vias estão bloqueadas

---

## Tríade Trágica

**Três dimensões irredutíveis da existência:**
1. Sofrimento (inevitável)
2. Culpa (irreparável)
3. Morte (inescapável)

**Resposta logoterapêutica:**
- Mesmo diante disso, permanece liberdade de atitude
- Otimismo trágico: dizer sim à vida apesar de tudo

---

## Vazio Existencial

**Definição:** Sensação de falta de sentido na vida moderna.

**Causas:**
- Perda de tradições (não há mais regras automáticas)
- Perda de instintos (não há mais direções inatas)
- **Resultado:** Conformismo ou totalitarismo

**Manifestações:**
- Tédio ("mal-estar dominical")
- Depressão existencial
- Vícios e compulsões
- Violência e agressão

**Frankl antecipou:** Crise de sentido da modernidade tardia

---

## Neurose Noogênica

**Definição:** Sofrimento que surge da **falta de sentido** (não de conflitos psíquicos).

**Distinção:**
- **Neuroses psicogênicas:** Conflitos inconscientes (Freud)
- **Neuroses somatogênicas:** Causas físicas/neurológicas
- **Neuroses noogênicas:** Frustração existencial

**Tratamento:** Logoterapia (não psicanálise tradicional)

---

## Dimensão Noogênica/Espiritual

**Modelo tridimensional do ser humano:**

1. **Dimensão Somática** (corpo, biologia)
2. **Dimensão Psíquica** (emoções, inconsciente)
3. **Dimensão Noética/Espiritual** (sentido, valores, liberdade)

**Importante:** "Espiritual" ≠ religioso necessariamente
- Refere-se à capacidade humana de buscar sentido
- Independe de crenças religiosas
- **"Inconsciente espiritual"** (além do inconsciente freudiano)

---

## Conceitos Complementares

### Hiper-intenção
- Esforço excessivo frustra objetivo
- Exemplo: tentar dormir demais impede sono
- Solução: intenção paradoxal

### Hiper-reflexão
- Foco excessivo em si mesmo
- Auto-observação obsessiva
- Solução: desreflexão

### Responsabilidade Existencial
- Cada pessoa é responsável por encontrar sentido
- Ninguém pode fazer isso por outro
- Liberdade implica responsabilidade

---

[← Voltar ao índice](../README.md)

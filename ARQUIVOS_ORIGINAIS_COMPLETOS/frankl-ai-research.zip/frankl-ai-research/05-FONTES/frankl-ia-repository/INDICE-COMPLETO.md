# 📑 Índice Completo do Repositório

## 📊 Estatísticas
- **29 arquivos** Markdown
- **8 pastas** temáticas
- **79KB** de conteúdo
- **Pesquisa em 477 fontes** acadêmicas

---

## 📁 Estrutura Completa

### [README.md](README.md) ⭐
**Página inicial - comece aqui!**

---

### 📘 01-fundamentos/
- [biografia-frankl.md](01-fundamentos/biografia-frankl.md) - Vida completa de Viktor Frankl
- [conceitos-centrais-logoterapia.md](01-fundamentos/conceitos-centrais-logoterapia.md) - Vontade de Sentido, 3 Pilares
- [espaco-estimulo-resposta.md](01-fundamentos/espaco-estimulo-resposta.md) - **Conceito-chave para IA**
- [triade-tragica.md](01-fundamentos/triade-tragica.md) - Otimismo Trágico

### 📚 02-obras/
- [livros-essenciais.md](02-obras/livros-essenciais.md) - Top 10 livros
- [livros-portugues-brasil.md](02-obras/livros-portugues-brasil.md) - Disponíveis no Brasil
- [obras-completas-catalogo.md](02-obras/obras-completas-catalogo.md) - 39 livros

### 👥 03-autores-relacionados/
- [existencialistas.md](03-autores-relacionados/existencialistas.md) - Kierkegaard, Heidegger, Sartre...
- [continuadores-logoterapia.md](03-autores-relacionados/continuadores-logoterapia.md) - Lukas, Längle, Batthyány
- [psicologia-positiva.md](03-autores-relacionados/psicologia-positiva.md) - Seligman, Paul Wong

### 🔬 04-pesquisa-empirica/
- [estudos-eficacia.md](04-pesquisa-empirica/estudos-eficacia.md) - Effect size d=1.885-1.961
- [instrumentos-medicao.md](04-pesquisa-empirica/instrumentos-medicao.md) - PIL, Logo-Test
- [meta-analises.md](04-pesquisa-empirica/meta-analises.md)

### 🤖 05-lacuna-ia/ **← DESCOBERTA CENTRAL**
- [analise-lacuna.md](05-lacuna-ia/analise-lacuna.md) - Zero artigos conectando Frankl e IA
- [relevancia-conceitual.md](05-lacuna-ia/relevancia-conceitual.md) - Por que importa
- [oportunidades-pesquisa.md](05-lacuna-ia/oportunidades-pesquisa.md) - Títulos de pesquisa
- [framework-proposto.md](05-lacuna-ia/framework-proposto.md) - Classificação de sistemas

### 💻 06-aplicacoes/
- [ia-agentes.md](06-aplicacoes/ia-agentes.md) - Arquiteturas, agentes "franklianos"
- [governanca-ia.md](06-aplicacoes/governanca-ia.md) - LGPD, AI Act
- [design-ux.md](06-aplicacoes/design-ux.md) - Friction by design
- [setor-publico-brasileiro.md](06-aplicacoes/setor-publico-brasileiro.md) - RNDS, compliance

### 📖 07-referencias/
- [bibliografia-frankl.md](07-referencias/bibliografia-frankl.md) - Obras de Frankl
- [bibliografia-ia.md](07-referencias/bibliografia-ia.md) - IA e agência (sem Frankl)
- [bibliografia-filosofia.md](07-referencias/bibliografia-filosofia.md) - Existencialismo
- [institutos-organizacoes.md](07-referencias/institutos-organizacoes.md) - Institutos mundiais

### 🛠️ 08-recursos/
- [glossario.md](08-recursos/glossario.md) - Termos-chave
- [timeline-frankl.md](08-recursos/timeline-frankl.md) - 1905-1997
- [mapas-conceituais.md](08-recursos/mapas-conceituais.md) - Diagramas

---

## 🎯 Caminhos Recomendados

### Para entender Frankl:
1. README.md
2. 01-fundamentos/biografia-frankl.md
3. 01-fundamentos/conceitos-centrais-logoterapia.md
4. 01-fundamentos/espaco-estimulo-resposta.md

### Para pesquisa sobre IA:
1. README.md
2. 05-lacuna-ia/analise-lacuna.md
3. 05-lacuna-ia/relevancia-conceitual.md
4. 05-lacuna-ia/framework-proposto.md
5. 06-aplicacoes/

### Para aplicação prática:
1. 06-aplicacoes/ (todas)
2. 05-lacuna-ia/framework-proposto.md

---

## 🔑 Conceito Central

> "Entre o estímulo e a resposta existe um espaço. Nesse espaço está nosso poder de escolher nossa resposta."

**Automação = Colapso desse espaço**

**Questão:** Como preservar agência humana em sistemas de IA?

**Resposta:** Nenhuma pesquisa acadêmica explorou isso ainda.

---

**Repositório completo em: frankl-ia-repository.zip**

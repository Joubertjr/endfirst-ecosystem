# Framework Proposto
[← Voltar](../README.md)

## Classificação de Sistemas por Risco Existencial

### Classe 1: Automação Plena (espaço = 0)
- Decisões puramente operacionais
- Ex: balanceamento de carga, cache
- Supervisão: logs auditáveis, rollback

### Classe 2: Automação com Revisão (espaço preservado)
- IA sugere, humano decide
- Ex: triagem de processos, priorização
- Supervisão: explicabilidade, contestação

### Classe 3: Proibição de Automação (espaço obrigatório)
- Decisões sobre dignidade, liberdade, direitos
- Ex: benefícios sociais, diagnósticos finais
- Supervisão: decisão humana obrigatória

## Princípios de Design

1. **Transparência:** Tornar "espaço" visível
2. **Reversibilidade:** Permitir rollback
3. **Explicabilidade:** Habilitar compreensão
4. **Contestação:** Facilitar revisão humana
5. **Pause Points:** Momentos de deliberação obrigatória

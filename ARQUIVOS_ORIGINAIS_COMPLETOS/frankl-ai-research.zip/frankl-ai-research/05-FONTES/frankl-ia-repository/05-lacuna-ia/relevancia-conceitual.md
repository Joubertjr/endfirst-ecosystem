# Relevância Conceitual
[← Voltar](../README.md)

## Automação = Colapso do Espaço

### Sistema Automatizado
```
Estímulo (input) → [Espaço COLAPSADO] → Resposta (output)
```

### Sistema Humano-Centrado
```
Estímulo → [ESPAÇO: deliberação, consciência, escolha] → Resposta
```

## Questões Críticas

1. Como preservar espaços de deliberação humana em sistemas críticos?
2. Quando automação viola dignidade e autonomia?
3. Como projetar agentes de IA que respeitam agência humana?
4. Onde o "espaço frankliano" é obrigatório por questões éticas/legais?

## Aplicações

- **XAI:** Explicabilidade = preservar autonomia
- **Governança:** LGPD Art. 20 = espaço de revisão
- **Design UX:** Friction by design = manter consciência
- **Agentes:** Arquiteturas com pause points

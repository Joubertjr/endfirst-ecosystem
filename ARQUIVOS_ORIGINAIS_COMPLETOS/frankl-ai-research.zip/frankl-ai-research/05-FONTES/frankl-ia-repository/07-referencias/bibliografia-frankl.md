# Bibliografia de Viktor Frankl
[← Voltar](../README.md)

## Obras Principais

1. Frankl, V. E. (1946/1985). *Man's Search for Meaning*. Simon & Schuster.
2. Frankl, V. E. (1955/1973). *The Doctor and the Soul*. Random House.
3. Frankl, V. E. (1988). *The Will to Meaning*. Penguin.
4. Frankl, V. E. (1997). *Man's Search for Ultimate Meaning*. Perseus.
5. Frankl, V. E. (2000). *Viktor Frankl Recollections*. Perseus.
6. Frankl, V. E. (2020). *Yes to Life*. Beacon Press.

# Bibliografia sobre IA e Agência
[← Voltar](../README.md)

## Principais (sem mencionar Frankl)

1. Dung, L. (2024). *Understanding Artificial Agency*. PhilArchive.
2. Rubel, A., et al. (2020). *Algorithms, agency, and respect for persons*. Social Theory and Practice.
3. Coeckelbergh, M. (2020). *AI Ethics*. MIT Press.
4. Gunkel, D. J. (2018). *Robot Rights*. MIT Press.

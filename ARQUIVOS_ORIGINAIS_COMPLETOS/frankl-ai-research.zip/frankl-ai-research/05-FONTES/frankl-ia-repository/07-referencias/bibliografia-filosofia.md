# Bibliografia de Filosofia Existencial
[← Voltar](../README.md)

## Principais

1. Heidegger, M. (1927/1996). *Being and Time*. SUNY Press.
2. Sartre, J.-P. (1943/1993). *Being and Nothingness*. Washington Square Press.
3. Jaspers, K. (1932/1970). *Philosophy* (Vol. 2). University of Chicago Press.
4. Buber, M. (1923/1970). *I and Thou*. Scribner.
5. Kierkegaard, S. (1843/1989). *Fear and Trembling*. Penguin.

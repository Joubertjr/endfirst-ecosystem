# Institutos e Organizações
[← Voltar](../README.md)

## Principais Centros Mundiais

**Viktor Frankl Institute Vienna** (Áustria)
- www.viktorfrankl.org
- Diretor: Prof. Dr. Alexander Batthyány

**Viktor Frankl Institute of America**
- viktorfranklamerica.com

**Elisabeth Lukas Archive** (Alemanha)
- elisabeth-lukas-archiv.de

**GLE Vienna** (Alfried Längle)
- www.existenzanalyse.org

## Regionais

- Argentina: Centro Viktor Frankl (Buenos Aires)
- Brasil: Diversos institutos
- Israel, Líbano/Chipre, Austrália

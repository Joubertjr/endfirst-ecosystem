# Livros Essenciais de Viktor Frankl
[← Voltar](../README.md)

## Top 10

1. **Man's Search for Meaning** (1946) - Em Busca de Sentido ⭐
2. **The Doctor and the Soul** (1946) - O Médico e a Alma
3. **The Will to Meaning** (1969) - A Vontade de Sentido
4. **Man's Search for Ultimate Meaning** (1997)
5. **The Unconscious God** (1948) - Deus Inconsciente
6. **Yes to Life: In Spite of Everything** (2020) - Sim à Vida
7. **Psychotherapy and Existentialism** (1967)
8. **The Unheard Cry for Meaning** (1978)
9. **Viktor Frankl Recollections** (2000)
10. **On the Theory and Therapy of Mental Disorders** (2004)

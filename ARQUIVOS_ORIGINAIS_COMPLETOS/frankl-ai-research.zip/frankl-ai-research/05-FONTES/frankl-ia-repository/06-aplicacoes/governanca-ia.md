# Governança de IA
[← Voltar](../README.md)

## Frameworks Aplicáveis

**Brasil:**
- LGPD Art. 20: Direito de revisão = espaço frankliano
- Decreto 11.930/2024: Governança de IA

**União Europeia:**
- AI Act: Sistemas de alto risco = espaço obrigatório

**Princípios:**
- Preservação de agência humana
- Dignidade e autonomia
- Accountability

# Design UX e Tecnologia
[← Voltar](../README.md)

## Princípios Franklianos de Design

1. **Friction by Design:** Pausa intencional
2. **Nudges vs Shoves:** Quando influenciar vs. coagir
3. **Digital Well-being:** Sentido na tecnologia
4. **Intentionality:** Usuário como agente ativo

## Exemplos

- Confirmações antes de ações críticas
- Tempos de espera intencionais
- Transparência sobre influência algorítmica

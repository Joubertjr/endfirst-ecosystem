# Aplicações em IA e Agentes
[← Voltar](../README.md)

## Arquiteturas de Agentes

**Agentes "Franklianos":**
- Preservam espaços de deliberação humana
- Pause points antes de ações críticas
- Explicabilidade como princípio arquitetural

## Tipos de Aplicação

1. **Agentes Autônomos:** Onde preservar supervisão?
2. **Sistemas de Recomendação:** Como manter intencionalidade?
3. **Decisão Automatizada:** Quando exigir humano no loop?
4. **Chatbots Terapêuticos:** Logoterapia como base?

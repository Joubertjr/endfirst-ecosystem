# Setor Público Brasileiro
[← Voltar](../README.md)

## Aplicações

### Sistemas Críticos
- RNDS: Espaços de deliberação em saúde
- Sistemas judiciais: Preservação de julgamento humano
- Benefícios sociais: Revisão humana obrigatória

### Compliance
- LGPD Art. 20
- TCU: Accountability
- Frameworks de IA responsável

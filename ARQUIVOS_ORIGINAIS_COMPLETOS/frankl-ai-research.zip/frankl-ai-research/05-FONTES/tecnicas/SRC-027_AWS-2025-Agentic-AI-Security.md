---
id: SRC-027
type: documento-tecnico
title: "AWS Agentic AI Security Matrix"
organizacao: "AWS"
ano: 2025
tags: [agentic-ai, agency-vs-autonomy, security]
conceitos_chave: [agency, autonomy, security-matrix]
relacionado: [SRC-018, FK-C-003, IA-C-004]
citado_em: [SRC-018]
---

# AWS Agentic AI Security Matrix

**Organização:** AWS  
**Ano:** 2025  
**Tipo:** Documento técnico sobre segurança de agentes

## Distinção Conceitual Crucial

### Agency (Agência)

**Definição AWS:**
- Capacidades e permissões
- Com quais sistemas pode interagir
- Quais operações pode realizar
- Quais recursos pode modificar
- **"O que o sistema está PERMITIDO a fazer"**

### Autonomy (Autonomia)

**Definição AWS:**
- Grau de tomada de decisão e ação independente
- Quando opera
- Como escolhe entre ações disponíveis
- Se requer aprovação humana para execução
- **"Quão LIVREMENTE o sistema pode agir"**

## Exemplo Ilustrativo

- **Alta agency + Baixa autonomy** = pode fazer muitas ações, mas requer aprovação humana para cada uma
- **Baixa agency + Alta autonomy** = poucas ações possíveis, mas opera independentemente

## Análise Frankliana

**Agency** = escopo de liberdade (possibilidades) ([[FK-C-003]])  
**Autonomy** = quando espaço frankliano é colapsado ou preservado ([[INT-002]])

**Framework:** Autonomy deve ser inversamente proporcional ao risco existencial ([[IA-C-004]])

## O Que Falta

**AWS distingue agency de autonomy mas NÃO oferece:**
- Teoria sobre COMO determinar nível apropriado de autonomy
- Framework para classificar sistemas por "risco existencial"

---

**Fonte:** [[SRC-018]] (seção 4.2)

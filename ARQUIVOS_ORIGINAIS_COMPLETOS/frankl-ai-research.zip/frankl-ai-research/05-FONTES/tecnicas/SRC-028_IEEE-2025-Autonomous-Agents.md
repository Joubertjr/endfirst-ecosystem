---
id: SRC-028
type: standard-tecnico
title: "IEEE Standard for Autonomous AI Agents"
organizacao: "IEEE"
ano: 2025
tags: [autonomous-agents, critical-decision-points, human-oversight]
conceitos_chave: [critical-decision-points, human-oversight, modular-architecture]
relacionado: [SRC-018, IA-C-004, IA-C-003]
citado_em: [SRC-018]
---

# IEEE Standard for Autonomous AI Agents

**Organização:** IEEE  
**Ano:** 2025  
**Tipo:** Standard técnico

## Componentes Arquiteturais

- LLM (raciocínio)
- Módulo de tomada de decisão
- Interface com ambiente
- Camada de execução

## Princípio Destacado

> "Maintaining human oversight at critical decision points"

## Problema

**IEEE menciona "critical decision points" mas:**
- NENHUMA teoria sobre o que torna um decision point "crítico"
- Como determinar quais decisões requerem oversight humano?
- Por que alguns pontos são mais críticos que outros?

## Framework Frankliano

**Critical decision points** = momentos que afetam capacidade de resposta autêntica ([[IA-C-004]])

**Critério:** Quanto maior o potencial de colapso do espaço frankliano, mais crítico o ponto

---

**Fonte:** [[SRC-018]] (seção 4.3)

---
id: SRC-026
type: documento-tecnico
title: "IBM Agentic Architecture: Three Types of AI Agents"
organizacao: "IBM"
ano: 2025
tags: [agentic-architecture, reactive, deliberative, cognitive]
conceitos_chave: [reactive-architecture, deliberative-architecture, cognitive-architecture]
relacionado: [SRC-018, IA-C-004, INT-002]
citado_em: [SRC-018]
---

# IBM Agentic Architecture

**Organização:** IBM  
**Ano:** 2025  
**Tipo:** Documento técnico sobre arquiteturas de agentes

## Três Tipos de Arquitetura

### 1. Reactive Architecture

**Descrição:** Mapeia situações diretamente para ações  
**Características:**
- Reflexiva, baseada em estímulos imediatos
- Não pode aprender do passado ou planejar futuro

**Análise frankliana:**  
Colapso total do espaço frankliano (estímulo → ação imediata) ([[INT-002]])

### 2. Deliberative Architecture

**Descrição:** Decisões baseadas em raciocínio, planejamento, modelos internos do mundo  
**Características:**
- Agentes analisam ambiente
- Preveem resultados
- Fazem escolhas informadas antes de agir

**Análise frankliana:**  
Preserva espaço de deliberação ([[INT-002]])

### 3. Cognitive Architecture

**Descrição:** Sistema avançado que mimetiza pensamento humano  
**Características:**
- Raciocínio
- Aprendizagem
- Tomada de decisão

**Análise frankliana:**  
Tenta replicar dimensão noética, mas simulação ≠ agência real

## O Que Falta

**IBM descreve arquiteturas mas NÃO discute:**
- QUANDO deliberação deve ser preservada
- Custos existenciais da reactive architecture
- POR QUÊ deliberative é melhor que reactive

---

**Fonte:** [[SRC-018]] (seção 4.1)

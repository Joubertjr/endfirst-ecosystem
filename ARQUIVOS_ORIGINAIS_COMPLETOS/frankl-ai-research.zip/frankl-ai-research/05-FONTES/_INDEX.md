# Índice: Fontes Primárias

Este diretório contém os arquivos brutos de fontes primárias (artigos, livros, perfis de autores).

---

## Fontes Acadêmicas (10 arquivos)

- [[SRC-001]] — Documento Base do Usuário
- [[SRC-003]] — Nguyen et al. (2022) - Meaningful HCI
- [[SRC-004]] — Kıralp (2025) - Logotherapy and the Future
- [[SRC-005]] — Quesada (2025) - AI Thinking Framework
- [[SRC-006]] — National Planning Cycles (2025) - AI and Existentialism
- [[SRC-007]] — Positive AI and Frankl
- [[SRC-008]] — Perfil de Quynh Nguyen (Google Scholar)
- [[SRC-009]] — Perfil de Jose Quesada (Google Scholar)
- [[SRC-010]] — Perfil de Jose Quesada (ResearchGate)
- [[SRC-011]] — Lista de Livros de Viktor Frankl

---

**Última atualização:** 24 de novembro de 2025

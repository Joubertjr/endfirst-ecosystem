---
id: IA-C-004
type: conceito-ia
title: "Critical Decision Points (CDP)"
tags: [critical-decision-points, cdp, human-oversight, governanca-ia]
conceitos_relacionados: [FK-C-003, FK-C-004, FK-C-006, INT-002, IA-C-003]
fontes: [SRC-018, SRC-028]
---

# Critical Decision Points (CDP)

**Usado por:** IEEE (2025)  
**Problema:** Nenhuma teoria sobre o que torna um ponto "crítico"  
**Solução frankliana:** Pontos que afetam capacidade de resposta autêntica

---

## Definição Frankliana

**Critical Decision Point** = momento que afeta a **capacidade de resposta autêntica** do ser humano.

**Baseado em:** Espaço Estímulo-Resposta ([[INT-002]])

---

## Critérios para Identificar CDP

**Matriz de decisão (5 perguntas):**

1. **Afeta identidade/valores/dignidade?**
   - Se SIM → 🔴 Crítico Existencial

2. **Colapsa espaço frankliano?**
   - Se SIM → 🔴 Crítico Existencial

3. **Elimina liberdade real?**
   - Se SIM → 🟡 Crítico Operacional

4. **Envolve julgamento moral?**
   - Se SIM → 🔴 Crítico Existencial

5. **Irreversível ou longo prazo?**
   - Se SIM → 🟡 Crítico Operacional

---

## Classificação de Criticidade

### 🔴 Crítico Existencial (HITL obrigatório)

**Características:**
- Afeta identidade pessoal, valores, dignidade
- Envolve julgamento moral
- Colapsa espaço de escolha consciente
- Irreversível ou longo prazo

**Exemplos:**
- Contratação/demissão
- Decisões médicas críticas
- Concessão/negação de crédito
- Decisões judiciais
- Triagem em emergências

**Requisito:** Human-in-the-Loop (HITL) - humano decide, não apenas aprova

---

### 🟡 Crítico Operacional (HOTL recomendado)

**Características:**
- Afeta bem-estar mas não identidade
- Pode ser delegado mas requer supervisão
- Impacto significativo mas reversível

**Exemplos:**
- Recomendações de produtos
- Priorização de tarefas
- Otimização de rotas
- Moderação de conteúdo

**Requisito:** Human-on-the-Loop (HOTL) - humano monitora e pode intervir

---

### 🟢 Não-Crítico (HIC suficiente)

**Características:**
- Tarefas operacionais sem impacto em agência
- Decisões puramente técnicas
- Reversível e sem consequências existenciais

**Exemplos:**
- Filtros de spam
- Correção ortográfica
- Compressão de imagens
- Cache de dados

**Requisito:** Human-in-Command (HIC) - supervisão estratégica

---

## Framework para Implementação

### Passo 1: Identificar CDP

Use a matriz de 5 perguntas para cada decisão no sistema.

### Passo 2: Classificar Criticidade

Determine se é 🔴 Existencial, 🟡 Operacional ou 🟢 Não-Crítico.

### Passo 3: Implementar Oversight Apropriado

- 🔴 → HITL (humano decide)
- 🟡 → HOTL (humano monitora)
- 🟢 → HIC (supervisão estratégica)

### Passo 4: Preservar MHC

Garantir que oversight preserva [[IA-C-003]] (Meaningful Human Control).

---

## Conexão com Regulações

- **IEEE (2025):** "Critical decision points" sem teoria ([[SRC-028]])
- **UNESCO (2021):** HITL/HOTL/HIC sem critérios ([[SRC-021]])
- **EU AI Act (2024):** "Appropriate oversight" sem orientação ([[SRC-022]])

**Frankl oferece framework para implementação.**

---

**Fonte:** [[SRC-018]], [[SYN-021]]  
**Conceitos relacionados:** [[IA-C-003]], [[INT-002]], [[FK-C-003]], [[FK-C-004]], [[FK-C-006]]

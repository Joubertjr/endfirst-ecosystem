---
id: IA-C-003
type: conceito-ia
title: "Meaningful Human Control (MHC)"
tags: [meaningful-human-control, mhc, governanca-ia, human-oversight]
conceitos_relacionados: [FK-C-003, FK-C-004, FK-C-006, INT-002, IA-C-004]
fontes: [SRC-018, SRC-021, SRC-022, SRC-023]
---

# Meaningful Human Control (MHC)

**Conceito central em governança de IA**  
**Problema:** Nenhuma definição aceita (Santoni de Sio, 2018)  
**Solução frankliana:** Preservação do espaço de escolha consciente

---

## Definição Frankliana

**Meaningful Human Control** existe quando o sistema preserva o **espaço de escolha consciente** entre estímulo e resposta ([[INT-002]]).

**Baseado em:** Espaço Estímulo-Resposta de Frankl

---

## Critérios de "Meaningful"

| Critério | Descrição | Conexão Frankliana |
|----------|-----------|-------------------|
| **Tempo de deliberação** | Espaço temporal para reflexão consciente | [[INT-002]] |
| **Informação adequada** | Compreensão suficiente para escolha informada | [[FK-C-006]] |
| **Liberdade real** | Capacidade efetiva de escolher alternativas | [[FK-C-003]] |
| **Responsabilidade correspondente** | Responsabilidade proporcional à liberdade | [[FK-C-004]] |
| **Autoria existencial** | Reconhecimento de "eu escolhi isso" | [[FK-C-006]] |

---

## Quando MHC é Necessário?

**Framework frankliano:**  
MHC é necessário quando decisão afeta **capacidade de resposta autêntica**.

**Classificação por risco existencial:**

1. **Alto risco existencial** (MHC obrigatório):
   - Decisões que afetam identidade pessoal
   - Escolhas moralmente carregadas
   - Decisões que impactam valores fundamentais

2. **Médio risco existencial** (MHC recomendado):
   - Decisões delegáveis com impacto significativo
   - Escolhas que afetam bem-estar mas não identidade

3. **Baixo risco existencial** (MHC opcional):
   - Tarefas repetitivas sem impacto em escolhas significativas
   - Decisões puramente técnicas

---

## Como Implementar MHC?

**Mecanismos de preservação:**

1. **Preservar tempo de deliberação**
   - Não forçar decisões imediatas
   - Permitir reflexão consciente

2. **Fornecer informação adequada**
   - Explicar opções e consequências (XAI)
   - Tornar trade-offs explícitos

3. **Garantir liberdade real**
   - Oferecer alternativas genuínas
   - Permitir rejeição de recomendações

4. **Alinhar responsabilidade e liberdade**
   - Responsabilidade proporcional ao controle real
   - Preservar tríade: liberdade-responsabilidade-noos

5. **Preservar autoria existencial**
   - Decisão deve refletir escolha consciente
   - Garantir que "eu escolhi isso" seja verdadeiro

---

## Conexão com Regulações

- **UNESCO (2021):** Human oversight ([[SRC-021]])
- **EU AI Act (2024):** Appropriate oversight ([[SRC-022]])
- **Santoni de Sio (2018):** MHC sem definição aceita ([[SRC-023]])

**Frankl oferece a fundamentação que falta.**

---

**Fonte:** [[SRC-018]], [[SYN-021]]  
**Conceitos relacionados:** [[IA-C-004]], [[INT-002]], [[FK-C-003]], [[FK-C-004]], [[FK-C-006]]

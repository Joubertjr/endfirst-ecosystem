---
id: IA-F-002
tipo: framework
titulo: "AI Thinking Framework"
---

# AI Thinking Framework (Quesada, 2025)

Desenvolvimento de IA COM as pessoas (não PARA).

## Três Pilares

1. **Compreensão Cultural** - Contexto local importa
2. **Agência Comunitária** - Comunidade controla dados
3. **Inovação Tecnológica** - Tecnologia serve comunidade

## Cinco Camadas

1. Quem - Comunidade
2. O quê - O que é valioso
3. Como - Metodologia participativa
4. Com o quê - Ferramentas adaptadas
5. Para quê - Objetivo maior

## Relação com Frankl

- Liberdade: Comunidade escolhe
- Responsabilidade: Comunidade assume
- Sentido: Reforça identidade

---
id: IA-F-001
tipo: framework
titulo: "Meaningful HCI Framework"
---

# Meaningful HCI Framework (Nguyen et al., 2022)

Framework para design de IA centrado em significado, baseado em Frankl.

## Quatro Dimensões

1. **Resultado** - Aumenta liberdade/responsabilidade/sentido?
2. **Embutido** - Incorpora existenciais na estrutura?
3. **Interação** - Oferece escolhas reais durante uso?
4. **Não-uso** - Respeita desconexão?

## Operacionalização

- Liberdade → Múltiplas opções
- Responsabilidade → Explicabilidade
- Noos → Reflexão sobre valores
- Espaço → Pausa deliberativa

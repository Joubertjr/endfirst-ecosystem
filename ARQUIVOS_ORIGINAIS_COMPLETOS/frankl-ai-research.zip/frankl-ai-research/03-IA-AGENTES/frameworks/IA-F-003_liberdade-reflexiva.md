---
id: IA-F-003
tipo: framework
titulo: "Framework de Liberdade Reflexiva"
---

# Framework de Liberdade Reflexiva (NPC, 2025)

Manter existencialismo na era da IA.

## Quatro Pilares

1. **Liberdade Reflexiva** - Consciência + escolha deliberada
2. **Autenticidade** - Apropriação ativa da tecnologia
3. **Sentido** - Independente de performance
4. **Responsabilidade** - Compartilhada (dev + gov + usuário)

## Princípios de Design

1. Transparência radical
2. Controle do usuário
3. Alinhamento com valores
4. Pausa deliberativa
5. Accountability

## Operacionalização

- Múltiplas opções + explicação
- Perguntas sobre valores
- Sugestões baseadas em significado
- Registro de decisões

---
id: IA-T-001
tipo: ferramenta
titulo: "Checklist de Auditoria de IA Baseado em Frankl"
tags: [auditoria, design, implementacao, pratico]
relacionado: [[FK-C-003]], [[FK-C-004]], [[FK-C-005]], [[FK-C-006]]
fonte: [[SRC-013]]
---

# Checklist de Auditoria de IA Baseado em Frankl

Ferramenta prática para auditar sistemas de IA contra os princípios de Viktor Frankl antes do lançamento.

## Pilar 1: Liberdade de Escolha

- [ ] Usuário entende como a recomendação foi feita?
- [ ] Sistema mostra múltiplas opções e trade-offs?
- [ ] Usuário pode contrariar recomendação sem punição?
- [ ] Interface evita "dark patterns"?
- [ ] Há "botão de escape" fácil?
- [ ] Sistema reduz dependência ou a aumenta?
- [ ] Usuário se sente em controle?

## Pilar 2: Facilitação de Significado

- [ ] Sistema ajuda usuário a explorar valores?
- [ ] Há perguntas abertas sobre o que importa?
- [ ] Sistema prescreve "bom" ou facilita descoberta?
- [ ] Recomendações baseiam-se em valores pessoais?
- [ ] Usuário consegue refletir sobre propósito?
- [ ] Sistema conecta ações a impacto maior?
- [ ] Há oportunidade de crescimento pessoal?

## Pilar 3: Espaço Reflexivo

- [ ] Sistema cria "pausas" intencionais?
- [ ] Há ritmo humano ou apenas velocidade máxima?
- [ ] Antes de decisão importante, há reflexão?
- [ ] Sistema permite respiração ou força ação?
- [ ] Notificações são necessárias ou manipulativas?
- [ ] Usuário tem tempo para processar informação?
- [ ] Interface permite contemplação ou apenas reação?

## Pilar 4: Autotranscendência

- [ ] Sistema mostra como ações impactam outros?
- [ ] Há componente comunitário/compartilhado?
- [ ] Usuário vê contribuição para bem maior?
- [ ] Há oportunidade de servir/ajudar?
- [ ] Métricas incluem impacto social?
- [ ] Sistema encoraja isolamento ou conexão?
- [ ] Propósito é benefício pessoal apenas?

## Aplicação

Use este checklist antes de lançar qualquer novo recurso de IA. Documente as respostas e as ações tomadas.

#!/usr/bin/env python3
"""
Script de Auditoria de Frontmatter YAML
Verifica presença e qualidade do frontmatter em arquivos Markdown
"""

import os
import re
from pathlib import Path

def check_frontmatter(filepath):
    """Verifica se arquivo tem frontmatter YAML válido"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # Verificar se tem frontmatter (--- no início e fim)
        if not content.startswith('---'):
            return {
                'has_frontmatter': False,
                'has_id': False,
                'has_type': False,
                'has_title': False,
                'has_tags': False,
                'id_value': None
            }
        
        # Extrair frontmatter
        parts = content.split('---', 2)
        if len(parts) < 3:
            return {
                'has_frontmatter': False,
                'has_id': False,
                'has_type': False,
                'has_title': False,
                'has_tags': False,
                'id_value': None
            }
        
        frontmatter = parts[1]
        
        # Verificar campos obrigatórios
        has_id = bool(re.search(r'^id:\s*\S+', frontmatter, re.MULTILINE))
        has_type = bool(re.search(r'^type:\s*\S+', frontmatter, re.MULTILINE))
        has_title = bool(re.search(r'^title:\s*.+', frontmatter, re.MULTILINE))
        has_tags = bool(re.search(r'^tags:\s*\[.+\]', frontmatter, re.MULTILINE))
        
        # Extrair valor do ID
        id_match = re.search(r'^id:\s*(\S+)', frontmatter, re.MULTILINE)
        id_value = id_match.group(1) if id_match else None
        
        return {
            'has_frontmatter': True,
            'has_id': has_id,
            'has_type': has_type,
            'has_title': has_title,
            'has_tags': has_tags,
            'id_value': id_value
        }
        
    except Exception as e:
        print(f"  ⚠️  Erro ao ler {filepath}: {e}")
        return None

def extract_id_from_filename(filename):
    """Extrai ID do nome do arquivo (padrão TIPO-NNN)"""
    match = re.search(r'([A-Z]{2,3}-[A-Z0-9]+-[0-9]{3})', filename)
    return match.group(1) if match else None

def main():
    print("=" * 60)
    print("AUDITORIA DE FRONTMATTER YAML")
    print("=" * 60)
    print()
    
    # Diretórios que devem ter frontmatter
    dirs_to_check = [
        '01-FRANKL-CORE',
        '02-AUTORES-RELACIONADOS',
        '03-IA-AGENTES',
        '04-INTERSECOES',
        '06-SINTESES'
    ]
    
    total_files = 0
    files_with_frontmatter = 0
    files_without_frontmatter = []
    files_with_incomplete_frontmatter = []
    files_with_id_mismatch = []
    
    for dir_name in dirs_to_check:
        if not os.path.exists(dir_name):
            print(f"⚠️  Diretório não encontrado: {dir_name}")
            continue
        
        for root, _, files in os.walk(dir_name):
            for filename in files:
                if not filename.endswith('.md'):
                    continue
                if filename.startswith('_') or filename == 'README.md':
                    continue
                
                filepath = os.path.join(root, filename)
                total_files += 1
                
                result = check_frontmatter(filepath)
                if result is None:
                    continue
                
                if not result['has_frontmatter']:
                    files_without_frontmatter.append(filepath)
                else:
                    files_with_frontmatter += 1
                    
                    # Verificar campos obrigatórios
                    missing_fields = []
                    if not result['has_id']:
                        missing_fields.append('id')
                    if not result['has_type']:
                        missing_fields.append('type')
                    if not result['has_title']:
                        missing_fields.append('title')
                    if not result['has_tags']:
                        missing_fields.append('tags')
                    
                    if missing_fields:
                        files_with_incomplete_frontmatter.append({
                            'file': filepath,
                            'missing': missing_fields
                        })
                    
                    # Verificar consistência do ID
                    filename_id = extract_id_from_filename(filename)
                    if filename_id and result['id_value']:
                        if filename_id != result['id_value']:
                            files_with_id_mismatch.append({
                                'file': filepath,
                                'filename_id': filename_id,
                                'frontmatter_id': result['id_value']
                            })
    
    # Relatório
    print(f"## 1. ESTATÍSTICAS GERAIS")
    print()
    print(f"  Total de arquivos analisados: {total_files}")
    print(f"  Arquivos COM frontmatter: {files_with_frontmatter}")
    print(f"  Arquivos SEM frontmatter: {len(files_without_frontmatter)}")
    print()
    
    if files_without_frontmatter:
        print(f"## 2. ARQUIVOS SEM FRONTMATTER ({len(files_without_frontmatter)})")
        print()
        for filepath in files_without_frontmatter:
            print(f"  ✗ {filepath}")
        print()
    
    if files_with_incomplete_frontmatter:
        print(f"## 3. ARQUIVOS COM FRONTMATTER INCOMPLETO ({len(files_with_incomplete_frontmatter)})")
        print()
        for item in files_with_incomplete_frontmatter:
            print(f"  ⚠️  {item['file']}")
            print(f"      Campos faltando: {', '.join(item['missing'])}")
        print()
    
    if files_with_id_mismatch:
        print(f"## 4. INCONSISTÊNCIA DE IDs ({len(files_with_id_mismatch)})")
        print()
        for item in files_with_id_mismatch:
            print(f"  ⚠️  {item['file']}")
            print(f"      Nome do arquivo: {item['filename_id']}")
            print(f"      Frontmatter: {item['frontmatter_id']}")
        print()
    
    # Resumo final
    print("=" * 60)
    print("RESUMO DA AUDITORIA DE FRONTMATTER")
    print("=" * 60)
    print()
    
    issues = len(files_without_frontmatter) + len(files_with_incomplete_frontmatter) + len(files_with_id_mismatch)
    
    if issues == 0:
        print("✓ FRONTMATTER 100% CONFORME")
        return 0
    else:
        print(f"✗ {issues} PROBLEMAS ENCONTRADOS")
        if files_without_frontmatter:
            print(f"  - {len(files_without_frontmatter)} arquivos sem frontmatter")
        if files_with_incomplete_frontmatter:
            print(f"  - {len(files_with_incomplete_frontmatter)} arquivos com frontmatter incompleto")
        if files_with_id_mismatch:
            print(f"  - {len(files_with_id_mismatch)} arquivos com IDs inconsistentes")
        return 1

if __name__ == '__main__':
    exit(main())

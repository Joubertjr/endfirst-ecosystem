# Template do Script verify_complete.py

Este documento define a **estrutura e componentes** do script de verificação completa. Use-o como referência para modificar ou regenerar o script.

---

## 📋 Estrutura Geral

```
verify_complete.py
├── Imports
├── Classe RepositoryVerifier
│   ├── __init__()
│   ├── verify_file_content()
│   ├── find_file_by_pattern()
│   ├── collect_all_ids()
│   ├── verify_links()
│   ├── verify_sources()
│   ├── verify_frankl_concepts()
│   ├── verify_frameworks()
│   ├── verify_intersections()
│   ├── verify_syntheses()
│   ├── verify_assets()
│   ├── verify_scripts()
│   ├── generate_report()
│   └── run()
└── Main execution
```

---

## 🔧 Componentes Principais

### 1. Imports Necessários

```python
import os
import re
import glob
from datetime import datetime
from pathlib import Path
```

**Justificativa:**
- `os`, `pathlib`: Manipulação de arquivos e diretórios
- `re`: Expressões regulares para extrair IDs e links
- `glob`: Busca de arquivos por padrão
- `datetime`: Timestamp no relatório

---

### 2. Classe RepositoryVerifier

#### 2.1. Inicialização

```python
def __init__(self, base_dir='.'):
    self.base_dir = Path(base_dir).resolve()
    self.results = {
        'fontes': {},
        'conceitos_frankl': {},
        'frameworks': {},
        'intersecoes': {},
        'sinteses': {},
        'autores': {},
        'conceitos_ia': {},
        'ferramentas': {},
        'assets': {},
        'scripts': {},
        'links': {'total': 0, 'broken': 0, 'details': []},
        'ids_map': {}
    }
    self.errors = []
    self.warnings = []
```

**Estrutura de dados:**
- `results`: Dicionário com resultados de cada categoria
- `errors`: Lista de erros críticos
- `warnings`: Lista de avisos
- `ids_map`: Mapeamento ID → arquivo

---

#### 2.2. Verificação de Conteúdo

```python
def verify_file_content(self, filepath, expected_id, min_lines=10):
    """
    Verifica:
    - Existência do arquivo
    - Conteúdo mínimo (número de linhas)
    - Frontmatter YAML
    - ID correto no frontmatter
    
    Retorna:
    {
        'exists': bool,
        'has_content': bool,
        'has_frontmatter': bool,
        'has_correct_id': bool,
        'lines': int,
        'path': str
    }
    """
```

**Parâmetros ajustáveis:**
- `min_lines`: Número mínimo de linhas (padrão: 10)

---

#### 2.3. Busca de Arquivos

```python
def find_file_by_pattern(self, pattern):
    """
    Busca arquivo por padrão glob
    
    Exemplo:
    pattern = "05-FONTES/**/*SRC-001*.md"
    """
```

---

#### 2.4. Coleta de IDs

```python
def collect_all_ids(self):
    """
    Percorre todos os .md do repositório
    Extrai IDs do frontmatter
    Popula self.results['ids_map']
    
    Ignora: frankl-ia-repository/
    """
```

---

#### 2.5. Verificação de Links

```python
def verify_links(self):
    """
    Encontra wikilinks [[ID]]
    Verifica se ID existe em ids_map
    Agrupa links quebrados por ID
    """
```

**Padrão de wikilink:** `\[\[([a-zA-Z0-9_-]+)\]\]`

---

#### 2.6. Métodos de Verificação por Categoria

Cada categoria tem seu método:

```python
def verify_sources(self):
    """Verifica SRC-001 a SRC-017 (exceto SRC-012)"""
    
def verify_frankl_concepts(self):
    """Verifica FK-C-001 a FK-C-010"""
    
def verify_frameworks(self):
    """Verifica IA-F-001 a IA-F-003"""
    
def verify_intersections(self):
    """Verifica INT-001 a INT-004"""
    
def verify_syntheses(self):
    """Verifica SYN-001 a SYN-012 + SYN-020"""
    
def verify_assets(self):
    """Verifica imagens em 08-ASSETS/imagens/"""
    
def verify_scripts(self):
    """Verifica scripts em 00-META/scripts-auditoria/"""
```

**Padrão comum:**
```python
for i in range(1, N):
    file_id = f"PREFIX-{i:03d}"
    pattern = f"DIRETORIO/**/*{file_id}*.md"
    filepath = self.find_file_by_pattern(pattern)
    
    if filepath:
        result = self.verify_file_content(filepath, file_id, min_lines=X)
    else:
        result = {'exists': False, ...}
    
    self.results['categoria'][file_id] = result
```

---

#### 2.7. Geração de Relatório

```python
def generate_report(self):
    """
    Gera relatório em Markdown
    
    Seções:
    1. Resumo executivo (métricas)
    2. Verificação por categoria
    3. Links quebrados (top 10)
    4. Erros críticos
    5. Avisos
    
    Retorna: string (Markdown)
    """
```

**Formato do relatório:**
- Título com data/hora
- Tabela de métricas
- Listas por categoria (✓/✗)
- Detalhamento de problemas

---

#### 2.8. Execução Principal

```python
def run(self):
    """
    Orquestra toda a verificação
    
    Fluxo:
    1. Coletar IDs
    2. Verificar categorias
    3. Verificar links
    4. Gerar relatório
    5. Salvar relatório
    6. Exibir resumo
    
    Retorna: bool (sucesso)
    """
```

---

## 🎯 Critérios de Validação por Categoria

### Fontes (SRC)

| Critério | Valor |
|:---------|:------|
| Range | SRC-001 a SRC-017 (exceto SRC-012) |
| Diretório | `05-FONTES/**/*` |
| Linhas mínimas | 15 |
| Frontmatter | Obrigatório |
| ID correto | Obrigatório |

### Conceitos Frankl (FK-C)

| Critério | Valor |
|:---------|:------|
| Range | FK-C-001 a FK-C-010 |
| Diretório | `01-FRANKL-CORE/**/*` |
| Linhas mínimas | 20 |
| Frontmatter | Obrigatório |
| ID correto | Obrigatório |

### Frameworks (IA-F)

| Critério | Valor |
|:---------|:------|
| Range | IA-F-001 a IA-F-003 |
| Diretório | `03-IA-AGENTES/**/*` |
| Linhas mínimas | 15 |
| Frontmatter | Obrigatório |
| ID correto | Obrigatório |

### Interseções (INT)

| Critério | Valor |
|:---------|:------|
| Range | INT-001 a INT-004 |
| Diretório | `04-INTERSECOES/**/*` |
| Linhas mínimas | 15 |
| Frontmatter | Obrigatório |
| ID correto | Obrigatório |

### Sínteses (SYN)

| Critério | Valor |
|:---------|:------|
| Range | SYN-001 a SYN-012 + SYN-020 |
| Diretório | `06-SINTESES/**/*` |
| Linhas mínimas | 10 |
| Frontmatter | Obrigatório |
| ID correto | Obrigatório |

### Assets

| Critério | Valor |
|:---------|:------|
| Arquivos | roadmap-leitura-frankl.png<br>framework-design-frankl-ia.png<br>mapa-logoterapia.png |
| Diretório | `08-ASSETS/imagens/` |
| Validação | Existência + tamanho > 0 |

### Scripts

| Critério | Valor |
|:---------|:------|
| Arquivos | README.md<br>audit_structure.sh<br>audit_frontmatter.py<br>audit_links.py<br>audit_complete.sh<br>generate_metrics.py<br>verify_complete.py |
| Diretório | `00-META/scripts-auditoria/` |
| Validação | Existência + tamanho > 0 |

---

## 📊 Métricas Calculadas

### Taxa de Completude

```python
completion_rate = (complete_files / total_files * 100)
```

**Onde:**
- `total_files`: Soma de arquivos em todas as categorias
- `complete_files`: Arquivos com `exists=True`, `has_correct_id=True`, `has_content=True`

### Taxa de Links OK

```python
links_ok_rate = ((total_links - broken_links) / total_links * 100)
```

---

## 🔄 Fluxo de Execução

```
1. Inicializar RepositoryVerifier
   ↓
2. Coletar todos os IDs existentes
   ↓
3. Verificar cada categoria:
   - Fontes (SRC)
   - Conceitos Frankl (FK-C)
   - Frameworks (IA-F)
   - Interseções (INT)
   - Sínteses (SYN)
   - Assets
   - Scripts
   ↓
4. Verificar links internos
   ↓
5. Gerar relatório Markdown
   ↓
6. Salvar em 00-META/_VERIFICACAO_AUTO.md
   ↓
7. Exibir resumo no terminal
   ↓
8. Retornar status (sucesso/falha)
```

---

## 🎨 Formato de Saída

### Terminal

```
============================================================
VERIFICAÇÃO COMPLETA DO REPOSITÓRIO
============================================================

Coletando IDs existentes...
✓ Encontrados N IDs únicos

Verificando fontes (SRC)...
Verificando conceitos de Frankl (FK-C)...
...

✓ M links verificados
✗ X links quebrados

Gerando relatório...
✓ Relatório salvo em: 00-META/_VERIFICACAO_AUTO.md

============================================================
RESUMO
============================================================
Erros críticos: X
Avisos: Y
Links quebrados: Z

✅/⚠️/❌ STATUS
```

### Arquivo Markdown

```markdown
# Relatório de Verificação Automática

**Data:** YYYY-MM-DD HH:MM:SS
**Versão:** 1.0

## 📊 Resumo Executivo

| Métrica | Valor |
|:--------|------:|
| ... | ... |

## 📁 Verificação por Categoria

### Fontes (SRC)
- ✓/✗ **ID** (N linhas)

...

## 🔗 Links Quebrados (X)

### `[[ID]]` - N referência(s)
- arquivo1.md
- arquivo2.md

...
```

---

## 🔧 Pontos de Extensão

### Adicionar Nova Categoria

1. Adicionar chave em `self.results`
2. Criar método `verify_nova_categoria()`
3. Chamar método em `run()`
4. Adicionar seção em `generate_report()`

### Ajustar Critérios

Modificar parâmetros em cada método:
- `min_lines`: Número mínimo de linhas
- `range`: Range de IDs a verificar
- `pattern`: Padrão glob de busca

### Modificar Relatório

Editar método `generate_report()`:
- Adicionar/remover seções
- Mudar formato de tabelas
- Ajustar ordenação

---

**Este template serve como especificação completa do script.**  
**Use-o para entender, modificar ou regenerar o script.**

---

**Última atualização:** 24 de novembro de 2025

# Checklist de Verificação - verify_complete.py

Este documento define o **checklist completo** de tudo que o script deve verificar. Use-o para garantir que nada está faltando.

---

## 📋 Checklist Geral

### Preparação
- [ ] Script está no diretório correto: `00-META/scripts-auditoria/`
- [ ] Script tem permissão de execução: `chmod +x verify_complete.py`
- [ ] Python 3.7+ está instalado
- [ ] Executando do diretório raiz do repositório

---

## 🔍 Checklist de Verificações

### 1. Coleta de IDs

- [ ] Percorre todos os arquivos `.md` do repositório
- [ ] Ignora diretório `05-FONTES/frankl-ia-repository/`
- [ ] Extrai IDs do frontmatter (regex: `^id:\s*(\S+)`)
- [ ] Armazena em `ids_map` (ID → caminho do arquivo)
- [ ] Exibe quantidade de IDs encontrados no terminal
- [ ] IDs esperados: mínimo 54

---

### 2. Fontes (SRC) - 16 arquivos

#### Arquivos a Verificar:
- [ ] SRC-001: Em Busca de Sentido
- [ ] SRC-002: A Vontade de Sentido
- [ ] SRC-003: Nguyen 2022 - Meaningful HCI
- [ ] SRC-004: Kiralp 2025 - Logotherapy Future
- [ ] SRC-005: Quesada 2025 - AI Thinking
- [ ] SRC-006: National Planning 2025 - AI Existentialism
- [ ] SRC-007: Positive AI Frankl
- [ ] SRC-008: Profile Quynh Nguyen
- [ ] SRC-009: Profile Jose Quesada
- [ ] SRC-010: Profile Quesada ResearchGate
- [ ] SRC-011: Frankl Books List
- [ ] SRC-013: Guia Prático de Implementação
- [ ] SRC-014: Sumário Executivo
- [ ] SRC-015: Repositório Completo
- [ ] SRC-016: Síntese Final da Missão
- [ ] SRC-017: Pesquisa Avançada 2025

#### Validações por Arquivo:
- [ ] Arquivo existe
- [ ] Tem mínimo 15 linhas
- [ ] Tem frontmatter YAML (começa com `---`)
- [ ] Tem ID correto no frontmatter
- [ ] Caminho correto: `05-FONTES/**/*SRC-NNN*.md`

#### Tratamento de Erros:
- [ ] Se arquivo não existe → adicionar a `errors`
- [ ] Se frontmatter incorreto → adicionar a `warnings`

---

### 3. Conceitos de Frankl (FK-C) - 10 arquivos

#### Arquivos a Verificar:
- [ ] FK-C-001: Vontade de Sentido
- [ ] FK-C-002: Logoterapia
- [ ] FK-C-003: Liberdade de Vontade
- [ ] FK-C-004: Responsabilidade
- [ ] FK-C-005: Autotranscendência
- [ ] FK-C-006: Dimensão Noética
- [ ] FK-C-007: Vazio Existencial
- [ ] FK-C-008: Neurose Noogênica
- [ ] FK-C-009: Tríade Trágica
- [ ] FK-C-010: Três Caminhos do Sentido

#### Validações por Arquivo:
- [ ] Arquivo existe
- [ ] Tem mínimo 20 linhas
- [ ] Tem frontmatter YAML
- [ ] Tem ID correto no frontmatter
- [ ] Caminho correto: `01-FRANKL-CORE/**/*FK-C-NNN*.md`

#### Tratamento de Erros:
- [ ] Se arquivo não existe → adicionar a `errors`

---

### 4. Frameworks (IA-F) - 3 arquivos

#### Arquivos a Verificar:
- [ ] IA-F-001: Meaningful HCI Framework (Nguyen et al., 2022)
- [ ] IA-F-002: AI Thinking Framework (Quesada, 2025)
- [ ] IA-F-003: Framework de Liberdade Reflexiva (National Planning, 2025)

#### Validações por Arquivo:
- [ ] Arquivo existe
- [ ] Tem mínimo 15 linhas
- [ ] Tem frontmatter YAML
- [ ] Tem ID correto no frontmatter
- [ ] Caminho correto: `03-IA-AGENTES/**/*IA-F-NNN*.md`

#### Tratamento de Erros:
- [ ] Se arquivo não existe → adicionar a `errors`

---

### 5. Interseções (INT) - 4 arquivos

#### Arquivos a Verificar:
- [ ] INT-001: Sentido em Agentes
- [ ] INT-002: Espaço Estímulo-Resposta
- [ ] INT-003: Responsabilidade em Sistemas Autônomos
- [ ] INT-004: Meaningful HCI Framework

#### Validações por Arquivo:
- [ ] Arquivo existe
- [ ] Tem mínimo 15 linhas
- [ ] Tem frontmatter YAML
- [ ] Tem ID correto no frontmatter
- [ ] Caminho correto: `04-INTERSECOES/**/*INT-NNN*.md`

#### Tratamento de Erros:
- [ ] Se arquivo não existe → adicionar a `errors`

---

### 6. Sínteses (SYN) - 13 arquivos

#### Análises Detalhadas (4):
- [ ] SYN-001: Análise Nguyen 2022
- [ ] SYN-002: Análise Kiralp 2025
- [ ] SYN-003: Análise Quesada 2025
- [ ] SYN-004: Análise National Planning 2025

#### Planos de Aula (4):
- [ ] SYN-005: Plano de Aula Nguyen 2022
- [ ] SYN-006: Plano de Aula Kiralp 2025
- [ ] SYN-007: Plano de Aula Quesada 2025
- [ ] SYN-008: Plano de Aula National Planning 2025

#### Outputs (2):
- [ ] SYN-009: Resumo Executivo
- [ ] SYN-010: Texto Estímulo-Resposta

#### Análises Integradoras (2):
- [ ] SYN-011: Análise Integradora SRC-002
- [ ] SYN-012: Frameworks Práticos

#### Estratégia (1):
- [ ] SYN-020: Roadmap de Publicação Acadêmica

#### Validações por Arquivo:
- [ ] Arquivo existe
- [ ] Tem mínimo 10 linhas
- [ ] Tem frontmatter YAML
- [ ] Tem ID correto no frontmatter
- [ ] Caminho correto: `06-SINTESES/**/*SYN-NNN*.md`

#### Tratamento de Erros:
- [ ] Se arquivo não existe → adicionar a `warnings` (não crítico)

---

### 7. Assets Visuais - 3 imagens

#### Imagens a Verificar:
- [ ] roadmap-leitura-frankl.png
- [ ] framework-design-frankl-ia.png
- [ ] mapa-logoterapia.png

#### Validações por Imagem:
- [ ] Arquivo existe
- [ ] Tamanho > 0 KB
- [ ] Caminho correto: `08-ASSETS/imagens/`

#### Tratamento de Erros:
- [ ] Se imagem não existe → adicionar a `errors`

---

### 8. Scripts de Auditoria - 7 arquivos

#### Scripts a Verificar:
- [ ] README.md
- [ ] audit_structure.sh
- [ ] audit_frontmatter.py
- [ ] audit_links.py
- [ ] audit_complete.sh
- [ ] generate_metrics.py
- [ ] verify_complete.py

#### Validações por Script:
- [ ] Arquivo existe
- [ ] Tamanho > 0 bytes
- [ ] Caminho correto: `00-META/scripts-auditoria/`

#### Tratamento de Erros:
- [ ] Se script não existe → não reportar erro (pode estar sendo criado)

---

### 9. Links Internos

#### Coleta de Links:
- [ ] Percorre todos os arquivos `.md` (exceto `frankl-ia-repository/`)
- [ ] Encontra wikilinks usando regex: `\[\[([a-zA-Z0-9_-]+)\]\]`
- [ ] Conta total de links encontrados

#### Validação de Links:
- [ ] Para cada link, verifica se ID existe em `ids_map`
- [ ] Conta links quebrados
- [ ] Agrupa links quebrados por ID
- [ ] Lista arquivos que referenciam cada link quebrado

#### Ordenação:
- [ ] Ordena links quebrados por número de referências (decrescente)
- [ ] Exibe top 10 no relatório

#### Tratamento:
- [ ] Links quebrados não geram erro crítico
- [ ] Apenas reportados no relatório

---

## 📊 Checklist de Métricas

### Métricas a Calcular:

#### Taxa de Completude:
- [ ] Conta total de arquivos verificados
- [ ] Conta arquivos completos (exists + has_content + has_correct_id)
- [ ] Calcula: `(completos / total) * 100`

#### Taxa de Links OK:
- [ ] Conta total de links
- [ ] Conta links quebrados
- [ ] Calcula: `((total - quebrados) / total) * 100`

#### Contadores:
- [ ] Erros críticos: `len(self.errors)`
- [ ] Avisos: `len(self.warnings)`
- [ ] IDs únicos: `len(self.results['ids_map'])`
- [ ] Links totais: `self.results['links']['total']`
- [ ] Links quebrados: `self.results['links']['broken']`

---

## 📝 Checklist de Relatório

### Estrutura do Relatório:

#### Cabeçalho:
- [ ] Título: "Relatório de Verificação Automática"
- [ ] Data/hora de geração
- [ ] Versão do relatório

#### Resumo Executivo:
- [ ] Tabela de métricas
- [ ] Taxa de completude
- [ ] Arquivos verificados
- [ ] Arquivos completos
- [ ] Erros críticos
- [ ] Avisos
- [ ] IDs únicos
- [ ] Links totais
- [ ] Links quebrados
- [ ] Taxa de links OK

#### Verificação por Categoria:
- [ ] Seção "Fontes (SRC)" com lista de arquivos
- [ ] Seção "Conceitos de Frankl (FK-C)" com lista
- [ ] Seção "Frameworks (IA-F)" com lista
- [ ] Seção "Interseções (INT)" com lista
- [ ] Seção "Sínteses (SYN)" com lista
- [ ] Seção "Assets Visuais" com lista

#### Links Quebrados (se houver):
- [ ] Seção "Links Quebrados (N)"
- [ ] Top 10 links mais referenciados
- [ ] Para cada link: ID e arquivos que o referenciam

#### Erros (se houver):
- [ ] Seção "Erros Críticos"
- [ ] Lista de todos os erros

#### Avisos (se houver):
- [ ] Seção "Avisos"
- [ ] Lista de todos os avisos

#### Rodapé:
- [ ] Timestamp de geração

### Formato:
- [ ] Markdown válido
- [ ] Tabelas formatadas corretamente
- [ ] Listas com marcadores (✓/✗)
- [ ] Emojis para seções (📊, 📁, 🔗, ❌, ⚠️)

---

## 💻 Checklist de Saída no Terminal

### Cabeçalho:
- [ ] Linha de separação (60 caracteres)
- [ ] Título: "VERIFICAÇÃO COMPLETA DO REPOSITÓRIO"
- [ ] Linha de separação

### Progresso:
- [ ] "Coletando IDs existentes..."
- [ ] "✓ Encontrados N IDs únicos"
- [ ] Linha em branco
- [ ] "Verificando fontes (SRC)..."
- [ ] "Verificando conceitos de Frankl (FK-C)..."
- [ ] "Verificando frameworks (IA-F)..."
- [ ] "Verificando interseções (INT)..."
- [ ] "Verificando sínteses (SYN)..."
- [ ] "Verificando assets visuais..."
- [ ] "Verificando scripts de auditoria..."
- [ ] "Verificando links internos..."
- [ ] "✓ N links verificados"
- [ ] "✗ M links quebrados"
- [ ] Linha em branco
- [ ] "Gerando relatório..."
- [ ] "✓ Relatório salvo em: 00-META/_VERIFICACAO_AUTO.md"
- [ ] Linha em branco

### Resumo:
- [ ] Linha de separação
- [ ] Título: "RESUMO"
- [ ] Linha de separação
- [ ] "Erros críticos: N"
- [ ] "Avisos: M"
- [ ] "Links quebrados: X"
- [ ] Linha em branco

### Status Final:
- [ ] Se erros == 0 e avisos == 0: "✅ REPOSITÓRIO COMPLETO E VERIFICADO!"
- [ ] Se erros == 0 e avisos > 0: "⚠️ REPOSITÓRIO OK COM AVISOS"
- [ ] Se erros > 0: "❌ REPOSITÓRIO COM ERROS CRÍTICOS"

---

## 🔧 Checklist de Robustez

### Tratamento de Erros:

#### Arquivo não encontrado:
- [ ] Não quebra o script
- [ ] Registra em `results` com `exists=False`
- [ ] Adiciona a `errors` ou `warnings` conforme criticidade

#### Arquivo vazio:
- [ ] Não quebra o script
- [ ] Registra `lines=0`
- [ ] Marca `has_content=False`

#### Frontmatter malformado:
- [ ] Não quebra o script
- [ ] Marca `has_frontmatter=False` ou `has_correct_id=False`
- [ ] Adiciona a `warnings`

#### Diretório não existe:
- [ ] Não quebra o script
- [ ] `glob.glob()` retorna lista vazia
- [ ] Registra arquivo como não encontrado

#### Encoding inválido:
- [ ] Tenta ler com `encoding='utf-8'`
- [ ] Se falhar, captura exceção
- [ ] Registra erro no resultado

---

## ✅ Checklist Final de Validação

Antes de considerar o script completo:

### Funcionalidade:
- [ ] Todas as 7 categorias verificadas
- [ ] Todos os 46 arquivos principais verificados
- [ ] Todos os assets verificados
- [ ] Todos os scripts verificados
- [ ] Todos os links verificados

### Qualidade:
- [ ] Executa sem erros
- [ ] Executa em < 30 segundos
- [ ] Não quebra com arquivos faltantes
- [ ] Não quebra com frontmatter malformado
- [ ] Resultados precisos

### Saída:
- [ ] Relatório gerado corretamente
- [ ] Terminal exibe progresso
- [ ] Terminal exibe resumo
- [ ] Status final correto

### Documentação:
- [ ] Docstrings em todas as funções
- [ ] Comentários em código complexo
- [ ] README atualizado
- [ ] Guia de uso disponível

---

## 📊 Checklist de Valores Esperados

### Repositório Completo:

| Métrica | Valor Esperado |
|:--------|---------------:|
| IDs únicos | ≥ 54 |
| Arquivos verificados | 46 |
| Arquivos completos | 46 |
| Taxa de completude | 100% |
| Erros críticos | 0 |
| Avisos | 0 |
| Links totais | ≥ 150 |
| Links quebrados | ≤ 20 |
| Taxa de links OK | ≥ 85% |

### Por Categoria:

| Categoria | Arquivos | Status |
|:----------|:--------:|:------:|
| Fontes (SRC) | 16 | ✓ Todos |
| Conceitos Frankl (FK-C) | 10 | ✓ Todos |
| Frameworks (IA-F) | 3 | ✓ Todos |
| Interseções (INT) | 4 | ✓ Todos |
| Sínteses (SYN) | 13 | ✓ Todos |
| Assets | 3 | ✓ Todos |
| Scripts | 7 | ✓ Todos |

---

**Use este checklist para garantir que o script verifica TUDO corretamente.**  
**Marque cada item conforme implementado e testado.**

---

**Última atualização:** 24 de novembro de 2025

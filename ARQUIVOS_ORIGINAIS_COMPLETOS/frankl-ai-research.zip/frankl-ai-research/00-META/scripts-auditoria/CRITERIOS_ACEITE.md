# Critérios de Aceite - verify_complete.py

Este documento define os **critérios de aceite** que o script deve satisfazer. Use-o para validar se o script está funcionando corretamente.

---

## 🎯 Critérios Funcionais

### 1. Coleta de IDs

**Critério:** O script deve coletar todos os IDs existentes no repositório.

**Validação:**
- ✅ Percorre todos os arquivos `.md` do repositório
- ✅ Ignora diretório `frankl-ia-repository/`
- ✅ Extrai IDs do frontmatter usando regex `^id:\s*(\S+)`
- ✅ Armazena em `self.results['ids_map']` (ID → caminho)
- ✅ Exibe no terminal: `✓ Encontrados N IDs únicos`

**Teste:**
```bash
python3 verify_complete.py
# Deve exibir: "✓ Encontrados 54 IDs únicos" (ou mais)
```

---

### 2. Verificação de Fontes (SRC)

**Critério:** O script deve verificar 16 arquivos de fontes.

**Validação:**
- ✅ Verifica SRC-001 a SRC-017 (exceto SRC-012)
- ✅ Busca em `05-FONTES/**/*SRC-NNN*.md`
- ✅ Valida existência do arquivo
- ✅ Valida mínimo de 15 linhas
- ✅ Valida presença de frontmatter YAML
- ✅ Valida ID correto no frontmatter
- ✅ Armazena resultado em `self.results['fontes']`

**Teste:**
```bash
python3 verify_complete.py
grep "SRC-001" 00-META/_VERIFICACAO_AUTO.md
# Deve exibir: "- ✓ **SRC-001** (N linhas)"
```

**Critério de Falha:**
- ❌ Se arquivo não existe: adicionar a `self.errors`
- ⚠️ Se frontmatter incorreto: adicionar a `self.warnings`

---

### 3. Verificação de Conceitos Frankl (FK-C)

**Critério:** O script deve verificar 10 conceitos de Frankl.

**Validação:**
- ✅ Verifica FK-C-001 a FK-C-010
- ✅ Busca em `01-FRANKL-CORE/**/*FK-C-NNN*.md`
- ✅ Valida mínimo de 20 linhas
- ✅ Valida frontmatter e ID correto

**Teste:**
```bash
grep "FK-C-001" 00-META/_VERIFICACAO_AUTO.md
# Deve exibir: "- ✓ **FK-C-001** (N linhas)"
```

---

### 4. Verificação de Frameworks (IA-F)

**Critério:** O script deve verificar 3 frameworks.

**Validação:**
- ✅ Verifica IA-F-001 a IA-F-003
- ✅ Busca em `03-IA-AGENTES/**/*IA-F-NNN*.md`
- ✅ Valida mínimo de 15 linhas
- ✅ Valida frontmatter e ID correto

**Teste:**
```bash
grep "IA-F-001" 00-META/_VERIFICACAO_AUTO.md
# Deve exibir: "- ✓ **IA-F-001** (N linhas)"
```

---

### 5. Verificação de Interseções (INT)

**Critério:** O script deve verificar 4 interseções.

**Validação:**
- ✅ Verifica INT-001 a INT-004
- ✅ Busca em `04-INTERSECOES/**/*INT-NNN*.md`
- ✅ Valida mínimo de 15 linhas
- ✅ Valida frontmatter e ID correto

**Teste:**
```bash
grep "INT-001" 00-META/_VERIFICACAO_AUTO.md
# Deve exibir: "- ✓ **INT-001** (N linhas)"
```

---

### 6. Verificação de Sínteses (SYN)

**Critério:** O script deve verificar 13 sínteses.

**Validação:**
- ✅ Verifica SYN-001 a SYN-012 + SYN-020
- ✅ Busca em `06-SINTESES/**/*SYN-NNN*.md`
- ✅ Valida mínimo de 10 linhas
- ✅ Valida frontmatter e ID correto

**Teste:**
```bash
grep "SYN-001" 00-META/_VERIFICACAO_AUTO.md
# Deve exibir: "- ✓ **SYN-001** (N linhas)"
```

---

### 7. Verificação de Assets

**Critério:** O script deve verificar 3 imagens.

**Validação:**
- ✅ Verifica existência de:
  - `08-ASSETS/imagens/roadmap-leitura-frankl.png`
  - `08-ASSETS/imagens/framework-design-frankl-ia.png`
  - `08-ASSETS/imagens/mapa-logoterapia.png`
- ✅ Valida tamanho > 0 KB

**Teste:**
```bash
grep "roadmap-leitura-frankl.png" 00-META/_VERIFICACAO_AUTO.md
# Deve exibir: "- ✓ roadmap-leitura-frankl.png (N KB)"
```

---

### 8. Verificação de Scripts

**Critério:** O script deve verificar 7 scripts de auditoria.

**Validação:**
- ✅ Verifica existência de:
  - README.md
  - audit_structure.sh
  - audit_frontmatter.py
  - audit_links.py
  - audit_complete.sh
  - generate_metrics.py
  - verify_complete.py
- ✅ Valida tamanho > 0 bytes

**Teste:**
```bash
grep "verify_complete.py" 00-META/_VERIFICACAO_AUTO.md
# Deve exibir script na lista
```

---

### 9. Verificação de Links

**Critério:** O script deve verificar todos os wikilinks `[[ID]]`.

**Validação:**
- ✅ Encontra todos os wikilinks usando regex `\[\[([a-zA-Z0-9_-]+)\]\]`
- ✅ Verifica se cada ID existe em `ids_map`
- ✅ Conta total de links
- ✅ Conta links quebrados
- ✅ Agrupa links quebrados por ID
- ✅ Ordena por número de referências (decrescente)

**Teste:**
```bash
python3 verify_complete.py
# Deve exibir: "✓ N links verificados"
# Deve exibir: "✗ M links quebrados"
```

---

### 10. Geração de Relatório

**Critério:** O script deve gerar relatório completo em Markdown.

**Validação:**
- ✅ Cria arquivo `00-META/_VERIFICACAO_AUTO.md`
- ✅ Inclui data/hora de geração
- ✅ Inclui tabela de métricas
- ✅ Inclui verificação por categoria
- ✅ Inclui top 10 links quebrados (se houver)
- ✅ Inclui erros críticos (se houver)
- ✅ Inclui avisos (se houver)

**Teste:**
```bash
test -f 00-META/_VERIFICACAO_AUTO.md && echo "✓ Relatório criado"
head -10 00-META/_VERIFICACAO_AUTO.md
# Deve exibir título e data
```

---

### 11. Exibição no Terminal

**Critério:** O script deve exibir resumo no terminal.

**Validação:**
- ✅ Exibe cabeçalho com separadores
- ✅ Exibe progresso de cada categoria
- ✅ Exibe estatísticas de links
- ✅ Exibe resumo final
- ✅ Exibe status (✅/⚠️/❌)

**Formato esperado:**
```
============================================================
VERIFICAÇÃO COMPLETA DO REPOSITÓRIO
============================================================

Coletando IDs existentes...
✓ Encontrados N IDs únicos

Verificando fontes (SRC)...
Verificando conceitos de Frankl (FK-C)...
...

============================================================
RESUMO
============================================================
Erros críticos: X
Avisos: Y
Links quebrados: Z

✅ REPOSITÓRIO COMPLETO E VERIFICADO!
```

---

## 📊 Critérios de Qualidade

### 1. Performance

**Critério:** O script deve executar em tempo razoável.

**Validação:**
- ✅ Execução completa < 30 segundos
- ✅ Sem loops infinitos
- ✅ Uso eficiente de memória

**Teste:**
```bash
time python3 verify_complete.py
# Deve completar em < 30s
```

---

### 2. Robustez

**Critério:** O script deve lidar com erros gracefully.

**Validação:**
- ✅ Não quebra se arquivo não existe
- ✅ Não quebra se arquivo está vazio
- ✅ Não quebra se frontmatter está malformado
- ✅ Não quebra se diretório não existe
- ✅ Captura exceções e continua execução

**Teste:**
```bash
# Remover temporariamente um arquivo
mv 05-FONTES/academicas/SRC-001*.md /tmp/
python3 verify_complete.py
# Deve executar sem erro, apenas reportar arquivo faltando
mv /tmp/SRC-001*.md 05-FONTES/academicas/
```

---

### 3. Precisão

**Critério:** O script deve reportar resultados corretos.

**Validação:**
- ✅ Taxa de completude = (completos / total) * 100
- ✅ Taxa de links OK = ((total - quebrados) / total) * 100
- ✅ Contagem de arquivos correta
- ✅ Contagem de linhas correta

**Teste:**
```bash
# Verificar manualmente um arquivo
wc -l 05-FONTES/academicas/SRC-001*.md
# Comparar com relatório
grep "SRC-001" 00-META/_VERIFICACAO_AUTO.md
```

---

### 4. Completude

**Critério:** O script deve verificar TODAS as categorias.

**Validação:**
- ✅ Fontes (SRC): 16 arquivos
- ✅ Conceitos Frankl (FK-C): 10 arquivos
- ✅ Frameworks (IA-F): 3 arquivos
- ✅ Interseções (INT): 4 arquivos
- ✅ Sínteses (SYN): 13 arquivos
- ✅ Assets: 3 imagens
- ✅ Scripts: 7 arquivos
- ✅ Links: Todos os wikilinks

**Total esperado:** 46 arquivos principais + 3 assets + 7 scripts

---

## 🎯 Critérios de Aceitação por Status

### ✅ Status: REPOSITÓRIO COMPLETO E VERIFICADO!

**Condições:**
- `len(self.errors) == 0`
- `len(self.warnings) == 0`
- Taxa de completude = 100%

**Significa:**
- Todos os 46 arquivos existem
- Todos têm conteúdo adequado
- Todos têm frontmatter correto
- Todos têm ID correto

---

### ⚠️ Status: REPOSITÓRIO OK COM AVISOS

**Condições:**
- `len(self.errors) == 0`
- `len(self.warnings) > 0`

**Significa:**
- Arquivos principais OK
- Alguns avisos menores (ex: links quebrados para placeholders)

---

### ❌ Status: REPOSITÓRIO COM ERROS CRÍTICOS

**Condições:**
- `len(self.errors) > 0`

**Significa:**
- Arquivos essenciais faltando
- Frontmatter incorreto
- Conteúdo insuficiente

---

## 🔍 Critérios de Validação de Conteúdo

### Arquivo Válido

Um arquivo é considerado **válido** se:

1. ✅ **Existe** no sistema de arquivos
2. ✅ **Tem conteúdo** (mínimo de linhas conforme categoria)
3. ✅ **Tem frontmatter** (começa com `---`)
4. ✅ **Tem ID correto** (linha `id: EXPECTED_ID` no frontmatter)

### Frontmatter Válido

Um frontmatter é considerado **válido** se:

1. ✅ Começa com `---` na primeira linha
2. ✅ Contém linha `id: ID_CORRETO`
3. ✅ Formato YAML válido

**Exemplo:**
```yaml
---
id: SRC-001
type: livro
title: "Em Busca de Sentido"
tags: [frankl, logoterapia]
---
```

### Link Válido

Um link é considerado **válido** se:

1. ✅ Formato: `[[ID]]`
2. ✅ ID existe em `ids_map`
3. ✅ Aponta para arquivo existente

---

## 📝 Checklist de Aceitação

Antes de aceitar o script como completo, verificar:

### Funcionalidade Básica
- [ ] Script executa sem erros
- [ ] Gera relatório em `00-META/_VERIFICACAO_AUTO.md`
- [ ] Exibe resumo no terminal
- [ ] Retorna exit code correto (0 = sucesso, 1 = erro)

### Verificações
- [ ] Coleta IDs corretamente
- [ ] Verifica todas as 7 categorias
- [ ] Verifica links internos
- [ ] Detecta arquivos faltantes
- [ ] Detecta frontmatter incorreto
- [ ] Detecta conteúdo insuficiente

### Relatório
- [ ] Inclui data/hora
- [ ] Inclui métricas completas
- [ ] Inclui verificação por categoria
- [ ] Inclui links quebrados (se houver)
- [ ] Inclui erros e avisos (se houver)
- [ ] Formato Markdown válido

### Qualidade
- [ ] Executa em < 30 segundos
- [ ] Não quebra com arquivos faltantes
- [ ] Não quebra com frontmatter malformado
- [ ] Resultados precisos e corretos

### Documentação
- [ ] Docstrings em todas as funções
- [ ] Comentários em código complexo
- [ ] README atualizado
- [ ] Guia de uso disponível

---

## 🧪 Testes de Aceitação

### Teste 1: Repositório Completo

```bash
# Executar em repositório completo
python3 verify_complete.py
# Esperado: ✅ REPOSITÓRIO COMPLETO E VERIFICADO!
```

### Teste 2: Arquivo Faltante

```bash
# Remover um arquivo
mv 05-FONTES/academicas/SRC-001*.md /tmp/
python3 verify_complete.py
# Esperado: ❌ REPOSITÓRIO COM ERROS CRÍTICOS
# Esperado: "SRC-001: Arquivo não encontrado" em erros
mv /tmp/SRC-001*.md 05-FONTES/academicas/
```

### Teste 3: Frontmatter Incorreto

```bash
# Remover ID de um arquivo
sed -i '/^id:/d' 05-FONTES/academicas/SRC-001*.md
python3 verify_complete.py
# Esperado: ⚠️ REPOSITÓRIO OK COM AVISOS
# Esperado: "SRC-001: Frontmatter sem ID correto" em avisos
# Restaurar arquivo original
```

### Teste 4: Links Quebrados

```bash
# Verificar detecção de links quebrados
python3 verify_complete.py
grep "Links Quebrados" 00-META/_VERIFICACAO_AUTO.md
# Esperado: Lista de links quebrados (se houver)
```

---

## ✅ Critério Final de Aceitação

O script é considerado **ACEITO** se:

1. ✅ Passa em todos os testes de aceitação
2. ✅ Satisfaz todos os critérios funcionais
3. ✅ Satisfaz todos os critérios de qualidade
4. ✅ Gera relatório completo e correto
5. ✅ Executa em tempo razoável (< 30s)
6. ✅ Não quebra com erros comuns
7. ✅ Documentação completa e clara

---

**Use este documento para validar se o script está funcionando corretamente.**  
**Todos os critérios devem ser satisfeitos para aceitação.**

---

**Última atualização:** 24 de novembro de 2025

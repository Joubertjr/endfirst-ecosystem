# Scripts de Auditoria Automatizada

**Versão:** 1.0  
**Data:** 24 de novembro de 2025

---

## Objetivo

Esta pasta contém scripts automatizados para verificar a conformidade do repositório `frankl-ai-research` com a metodologia documentada em `_METODOLOGIA.md`. Os scripts podem ser executados localmente ou integrados em ferramentas de IA como Cursor AI ou Claude Code.

---

## Scripts Disponíveis

### 1. `audit_structure.sh`
**Função:** Verifica a estrutura de diretórios e nomenclatura de arquivos

**Execução:**
```bash
cd /caminho/para/frankl-ai-research
bash 00-META/scripts-auditoria/audit_structure.sh
```

**Verifica:**
- Estrutura de diretórios esperada
- Nomenclatura de arquivos (padrão TIPO-NNN)
- Contagem de arquivos por diretório

---

### 2. `audit_frontmatter.py`
**Função:** Verifica a presença e qualidade do frontmatter YAML

**Execução:**
```bash
cd /caminho/para/frankl-ai-research
python3 00-META/scripts-auditoria/audit_frontmatter.py
```

**Verifica:**
- Presença de frontmatter YAML
- Campos obrigatórios (id, type, title, tags)
- Consistência entre ID do arquivo e ID do frontmatter

---

### 3. `audit_links.py`
**Função:** Verifica a integridade dos links internos (wikilinks)

**Execução:**
```bash
cd /caminho/para/frankl-ai-research
python3 00-META/scripts-auditoria/audit_links.py
```

**Verifica:**
- Links quebrados no formato `[[ID]]`
- IDs referenciados que não existem
- Arquivos com links problemáticos

---

### 4. `audit_complete.sh`
**Função:** Executa todos os scripts de auditoria em sequência

**Execução:**
```bash
cd /caminho/para/frankl-ai-research
bash 00-META/scripts-auditoria/audit_complete.sh
```

**Gera:** Relatório completo de auditoria em `00-META/_AUDITORIA_AUTO.md`

---

### 5. `generate_metrics.py`
**Função:** Gera métricas e indicadores de valor do repositório

**Execução:**
```bash
cd /caminho/para/frankl-ai-research
python3 00-META/scripts-auditoria/generate_metrics.py
```

**Gera:** Arquivo `00-META/_VALOR_GERADO.md` com estatísticas completas

---

## Integração com Cursor AI / Claude Code

### Uso Recomendado

1. **Antes de cada commit:**
   ```bash
   bash 00-META/scripts-auditoria/audit_complete.sh
   ```

2. **Após adicionar novos conteúdos:**
   ```bash
   python3 00-META/scripts-auditoria/audit_links.py
   ```

3. **Para gerar relatório de progresso:**
   ```bash
   python3 00-META/scripts-auditoria/generate_metrics.py
   ```

### Prompt para Cursor AI / Claude Code

```
Execute a auditoria completa do repositório frankl-ai-research usando os scripts em 00-META/scripts-auditoria/. 

1. Execute: bash 00-META/scripts-auditoria/audit_complete.sh
2. Analise o relatório gerado em 00-META/_AUDITORIA_AUTO.md
3. Corrija quaisquer problemas identificados
4. Re-execute a auditoria para confirmar correções
```

---

## Requisitos

- **Bash:** Para scripts `.sh`
- **Python 3.11+:** Para scripts `.py`
- **Permissões de execução:** `chmod +x *.sh`

---

## Manutenção

Estes scripts devem ser atualizados sempre que a metodologia (`_METODOLOGIA.md`) for modificada para garantir que as verificações permaneçam alinhadas com os padrões do repositório.

---

**Fim do README**

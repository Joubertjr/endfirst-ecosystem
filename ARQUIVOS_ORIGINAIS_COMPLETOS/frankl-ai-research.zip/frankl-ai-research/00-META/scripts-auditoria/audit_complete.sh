#!/bin/bash

# Script de Auditoria Completa
# Executa todos os scripts de auditoria em sequência

echo "=========================================="
echo "AUDITORIA COMPLETA DO REPOSITÓRIO"
echo "frankl-ai-research"
echo "=========================================="
echo ""
echo "Data: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# Verificar se estamos no diretório correto
if [ ! -d "00-META" ]; then
    echo "❌ ERRO: Execute este script a partir do diretório raiz do repositório"
    exit 1
fi

OUTPUT_FILE="00-META/_AUDITORIA_AUTO.md"

# Iniciar arquivo de saída
cat > "$OUTPUT_FILE" << 'EOF'
# Relatório de Auditoria Automatizada

**Data:** $(date '+%Y-%m-%d %H:%M:%S')  
**Gerado por:** Scripts de auditoria automatizada

---

EOF

echo "Executando auditoria completa..."
echo ""

# 1. Auditoria de Estrutura
echo "1/3 Auditando estrutura de diretórios..."
bash 00-META/scripts-auditoria/audit_structure.sh >> "$OUTPUT_FILE" 2>&1
structure_status=$?

echo "" >> "$OUTPUT_FILE"
echo "---" >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# 2. Auditoria de Frontmatter
echo "2/3 Auditando frontmatter YAML..."
python3 00-META/scripts-auditoria/audit_frontmatter.py >> "$OUTPUT_FILE" 2>&1
frontmatter_status=$?

echo "" >> "$OUTPUT_FILE"
echo "---" >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# 3. Auditoria de Links
echo "3/3 Auditando links internos..."
python3 00-META/scripts-auditoria/audit_links.py >> "$OUTPUT_FILE" 2>&1
links_status=$?

echo "" >> "$OUTPUT_FILE"
echo "---" >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# Resumo final
cat >> "$OUTPUT_FILE" << EOF

## RESUMO GERAL DA AUDITORIA

| Categoria | Status |
|:----------|:-------|
| Estrutura de Diretórios | $([ $structure_status -eq 0 ] && echo "✓ OK" || echo "✗ FALHA") |
| Frontmatter YAML | $([ $frontmatter_status -eq 0 ] && echo "✓ OK" || echo "✗ FALHA") |
| Links Internos | $([ $links_status -eq 0 ] && echo "✓ OK" || echo "✗ FALHA") |

---

**Fim do Relatório**
EOF

echo ""
echo "=========================================="
echo "AUDITORIA COMPLETA FINALIZADA"
echo "=========================================="
echo ""
echo "Relatório salvo em: $OUTPUT_FILE"
echo ""

# Exibir resumo no terminal
if [ $structure_status -eq 0 ] && [ $frontmatter_status -eq 0 ] && [ $links_status -eq 0 ]; then
    echo "✓ REPOSITÓRIO 100% CONFORME"
    exit 0
else
    echo "✗ PROBLEMAS ENCONTRADOS - Consulte o relatório para detalhes"
    exit 1
fi

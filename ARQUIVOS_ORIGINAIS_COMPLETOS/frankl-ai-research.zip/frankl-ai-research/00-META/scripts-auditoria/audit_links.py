import os
import re

def audit_repository(root_dir):
    report = []
    md_files = []
    all_ids = set()

    # Pass 1: Collect all defined IDs from filenames and frontmatter
    for dirpath, _, filenames in os.walk(root_dir):
        for filename in filenames:
            if filename.endswith(".md"):
                filepath = os.path.join(dirpath, filename)
                md_files.append(filepath)

                # Extract ID from filename (e.g., FK-C-001)
                match = re.search(r"([A-Z]{2,3}-[A-Z]-[0-9]{3})", filename)
                if match:
                    all_ids.add(match.group(1))

                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                        # Extract ID from YAML frontmatter
                        id_match = re.search(r"^id:\s*(\S+)", content, re.MULTILINE)
                        if id_match:
                            all_ids.add(id_match.group(1).strip())
                except (UnicodeDecodeError, IOError):
                    continue # Ignore files that can't be read

    report.append("=== AUDITORIA DE LINKS INTERNOS ===")
    broken_links_count = 0
    file_with_broken_links = set()

    # Pass 2: Check for broken wikilinks
    for filepath in md_files:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                # Find all wikilinks like [[ID]]
                wikilinks = re.findall(r"\[\[([a-zA-Z0-9_-]+)\]\]", content)
                for link in wikilinks:
                    if link not in all_ids:
                        report.append(f"  - Link quebrado: [[{link}]] no arquivo: {filepath.replace(root_dir, '')}")
                        broken_links_count += 1
                        file_with_broken_links.add(filepath)
        except (UnicodeDecodeError, IOError):
            report.append(f"  - Não foi possível ler o arquivo: {filepath}")
            continue

    report.append("\n--- RESUMO DA AUDITORIA DE LINKS ---")
    if broken_links_count == 0:
        report.insert(1, "\n  **Status:** ✓ SUCESSO\n")
        report.append("  - Nenhum link interno quebrado foi encontrado.")
    else:
        report.insert(1, "\n  **Status:** ✗ FALHA\n")
        report.append(f"  - Total de links quebrados: {broken_links_count}")
        report.append(f"  - Total de arquivos com problemas: {len(file_with_broken_links)}")

    return "\n".join(report)

if __name__ == "__main__":
    repo_path = "/home/ubuntu/frankl-ai-research"
    final_report = audit_repository(repo_path)
    print(final_report)

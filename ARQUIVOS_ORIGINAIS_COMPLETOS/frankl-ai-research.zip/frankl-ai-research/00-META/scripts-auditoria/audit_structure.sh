#!/bin/bash

# Script de Auditoria de Estrutura
# Verifica estrutura de diretórios e nomenclatura de arquivos

echo "=========================================="
echo "AUDITORIA DE ESTRUTURA DO REPOSITÓRIO"
echo "=========================================="
echo ""
echo "Data: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# Verificar se estamos no diretório correto
if [ ! -d "00-META" ]; then
    echo "❌ ERRO: Execute este script a partir do diretório raiz do repositório"
    exit 1
fi

echo "✓ Diretório raiz encontrado"
echo ""

# 1. Verificar estrutura de diretórios esperada
echo "## 1. ESTRUTURA DE DIRETÓRIOS"
echo ""

EXPECTED_DIRS=(
    "00-META"
    "01-FRANKL-CORE"
    "02-AUTORES-RELACIONADOS"
    "03-IA-AGENTES"
    "04-INTERSECOES"
    "05-FONTES"
    "06-SINTESES"
    "08-ASSETS"
)

missing_dirs=0
for dir in "${EXPECTED_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        echo "  ✓ $dir"
    else
        echo "  ✗ FALTANDO: $dir"
        missing_dirs=$((missing_dirs + 1))
    fi
done

echo ""
if [ $missing_dirs -eq 0 ]; then
    echo "Status: ✓ TODOS OS DIRETÓRIOS PRINCIPAIS PRESENTES"
else
    echo "Status: ✗ FALTAM $missing_dirs DIRETÓRIOS"
fi
echo ""

# 2. Contagem de arquivos por diretório
echo "## 2. CONTAGEM DE ARQUIVOS .md POR DIRETÓRIO"
echo ""

total_md=0
for dir in "${EXPECTED_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        count=$(find "$dir" -name "*.md" 2>/dev/null | wc -l)
        printf "  %-30s %3d arquivos\n" "$dir:" "$count"
        total_md=$((total_md + count))
    fi
done

echo ""
echo "  TOTAL: $total_md arquivos .md"
echo ""

# 3. Verificar nomenclatura de arquivos
echo "## 3. NOMENCLATURA DE ARQUIVOS"
echo ""

# Arquivos que devem ter padrão TIPO-NNN
non_compliant=0
for file in $(find 01-FRANKL-CORE 02-AUTORES-RELACIONADOS 03-IA-AGENTES 04-INTERSECOES 06-SINTESES -name "*.md" ! -name "_*" ! -name "README.md" 2>/dev/null); do
    filename=$(basename "$file")
    if ! echo "$filename" | grep -qE "^[A-Z]{2,3}-[A-Z0-9]+-[0-9]{3}"; then
        echo "  ✗ Nomenclatura não conforme: $file"
        non_compliant=$((non_compliant + 1))
    fi
done

if [ $non_compliant -eq 0 ]; then
    echo "  ✓ Todos os arquivos seguem o padrão TIPO-NNN"
else
    echo "  ✗ $non_compliant arquivos não seguem o padrão"
fi
echo ""

# 4. Verificar arquivos essenciais
echo "## 4. ARQUIVOS ESSENCIAIS"
echo ""

ESSENTIAL_FILES=(
    "00-META/_METODOLOGIA.md"
    "00-META/_RASTREABILIDADE.md"
    "00-META/_GAPS.md"
    "README.md"
)

missing_files=0
for file in "${ESSENTIAL_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✓ $file"
    else
        echo "  ✗ FALTANDO: $file"
        missing_files=$((missing_files + 1))
    fi
done

echo ""
if [ $missing_files -eq 0 ]; then
    echo "Status: ✓ TODOS OS ARQUIVOS ESSENCIAIS PRESENTES"
else
    echo "Status: ✗ FALTAM $missing_files ARQUIVOS ESSENCIAIS"
fi
echo ""

# 5. Resumo final
echo "=========================================="
echo "RESUMO DA AUDITORIA DE ESTRUTURA"
echo "=========================================="
echo ""

if [ $missing_dirs -eq 0 ] && [ $non_compliant -eq 0 ] && [ $missing_files -eq 0 ]; then
    echo "✓ ESTRUTURA 100% CONFORME"
    exit 0
else
    echo "✗ PROBLEMAS ENCONTRADOS:"
    [ $missing_dirs -gt 0 ] && echo "  - $missing_dirs diretórios faltando"
    [ $non_compliant -gt 0 ] && echo "  - $non_compliant arquivos com nomenclatura incorreta"
    [ $missing_files -gt 0 ] && echo "  - $missing_files arquivos essenciais faltando"
    exit 1
fi

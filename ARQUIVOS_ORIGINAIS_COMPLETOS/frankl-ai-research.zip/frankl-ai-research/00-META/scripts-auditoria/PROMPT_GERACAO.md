# Prompt de Geração - verify_complete.py

Este documento contém o **prompt exato** para regenerar o script `verify_complete.py`. Use-o no Cursor AI ou Claude Code quando precisar modificar o script.

---

## 🎯 Como Usar Este Prompt

### 1. Editar Especificações

Antes de regenerar, edite os arquivos de especificação conforme necessário:

- **`TEMPLATE_SCRIPT.md`** - Para mudar estrutura ou componentes
- **`CRITERIOS_ACEITE.md`** - Para mudar critérios de validação
- **`CHECKLIST_VERIFICACAO.md`** - Para adicionar/remover verificações

### 2. Copiar Prompt Abaixo

Copie o prompt completo da seção "Prompt Completo" abaixo.

### 3. Executar no Cursor AI / Claude Code

Cole o prompt no Cursor AI ou Claude Code e execute.

---

## 📋 Prompt Completo para Geração

Copie tudo abaixo e cole no Cursor AI / Claude Code:

\`\`\`
Crie o script Python verify_complete.py para verificação completa do repositório frankl-ai-research seguindo as especificações em TEMPLATE_SCRIPT.md, CRITERIOS_ACEITE.md e CHECKLIST_VERIFICACAO.md.

O script deve verificar 46 arquivos principais em 7 categorias (SRC, FK-C, IA-F, INT, SYN, assets, scripts) e gerar relatório automático em 00-META/_VERIFICACAO_AUTO.md.

Leia os arquivos de especificação e implemente exatamente conforme documentado.
\`\`\`

---

**Última atualização:** 24 de novembro de 2025

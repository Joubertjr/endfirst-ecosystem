#!/usr/bin/env python3
"""
Script de Verificação Completa do Repositório frankl-ai-research
Verifica existência, conteúdo, frontmatter, IDs e links de todos os arquivos.

Uso:
    python3 verify_complete.py
    
Saída:
    - Relatório no terminal
    - Arquivo 00-META/_VERIFICACAO_AUTO.md
"""

import os
import re
import glob
from datetime import datetime
from pathlib import Path

class RepositoryVerifier:
    def __init__(self, base_dir='.'):
        self.base_dir = Path(base_dir).resolve()
        self.results = {
            'fontes': {},
            'conceitos_frankl': {},
            'frameworks': {},
            'intersecoes': {},
            'sinteses': {},
            'autores': {},
            'conceitos_ia': {},
            'ferramentas': {},
            'assets': {},
            'scripts': {},
            'links': {'total': 0, 'broken': 0, 'details': []},
            'ids_map': {}
        }
        self.errors = []
        self.warnings = []
    
    def verify_file_content(self, filepath, expected_id, min_lines=10):
        """Verifica conteúdo de um arquivo"""
        if not filepath.exists():
            return {
                'exists': False,
                'has_content': False,
                'has_frontmatter': False,
                'has_correct_id': False,
                'lines': 0,
                'error': 'Arquivo não encontrado'
            }
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.count('\n') + 1
            
            has_frontmatter = content.startswith('---')
            has_correct_id = f"id: {expected_id}" in content
            has_content = lines >= min_lines
            
            return {
                'exists': True,
                'has_content': has_content,
                'has_frontmatter': has_frontmatter,
                'has_correct_id': has_correct_id,
                'lines': lines,
                'path': str(filepath.relative_to(self.base_dir))
            }
        except Exception as e:
            return {
                'exists': True,
                'has_content': False,
                'has_frontmatter': False,
                'has_correct_id': False,
                'lines': 0,
                'error': str(e)
            }
    
    def find_file_by_pattern(self, pattern):
        """Encontra arquivo por padrão glob"""
        files = list(self.base_dir.glob(pattern))
        return files[0] if files else None
    
    def collect_all_ids(self):
        """Coleta todos os IDs existentes no repositório"""
        for filepath in self.base_dir.rglob('*.md'):
            # Ignorar frankl-ia-repository
            if 'frankl-ia-repository' in str(filepath):
                continue
            
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Extrair ID do frontmatter
                    match = re.search(r'^id:\s*(\S+)', content, re.MULTILINE)
                    if match:
                        file_id = match.group(1).strip()
                        self.results['ids_map'][file_id] = str(filepath.relative_to(self.base_dir))
            except:
                pass
    
    def verify_links(self):
        """Verifica links internos quebrados"""
        broken_links = []
        
        for filepath in self.base_dir.rglob('*.md'):
            if 'frankl-ia-repository' in str(filepath):
                continue
            
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Encontrar wikilinks
                    wikilinks = re.findall(r'\[\[([a-zA-Z0-9_-]+)\]\]', content)
                    for link in wikilinks:
                        self.results['links']['total'] += 1
                        if link not in self.results['ids_map']:
                            self.results['links']['broken'] += 1
                            broken_links.append({
                                'file': str(filepath.relative_to(self.base_dir)),
                                'link': link
                            })
            except:
                pass
        
        # Agrupar por link faltante
        missing_ids = {}
        for item in broken_links:
            link_id = item['link']
            if link_id not in missing_ids:
                missing_ids[link_id] = []
            missing_ids[link_id].append(item['file'])
        
        self.results['links']['details'] = sorted(
            missing_ids.items(), 
            key=lambda x: len(x[1]), 
            reverse=True
        )
    
    def verify_sources(self):
        """Verifica arquivos SRC"""
        print("Verificando fontes (SRC)...")
        for i in range(1, 18):
            if i == 12:  # SRC-012 não existe
                continue
            src_id = f"SRC-{i:03d}"
            pattern = f"05-FONTES/**/*{src_id}*.md"
            filepath = self.find_file_by_pattern(pattern)
            
            if filepath:
                result = self.verify_file_content(filepath, src_id, min_lines=15)
            else:
                result = {'exists': False, 'has_content': False, 
                         'has_frontmatter': False, 'has_correct_id': False, 'lines': 0}
            
            self.results['fontes'][src_id] = result
            
            if not result['exists']:
                self.errors.append(f"{src_id}: Arquivo não encontrado")
            elif not result['has_correct_id']:
                self.warnings.append(f"{src_id}: Frontmatter sem ID correto")
    
    def verify_frankl_concepts(self):
        """Verifica conceitos FK-C"""
        print("Verificando conceitos de Frankl (FK-C)...")
        for i in range(1, 11):
            fk_id = f"FK-C-{i:03d}"
            pattern = f"01-FRANKL-CORE/**/*{fk_id}*.md"
            filepath = self.find_file_by_pattern(pattern)
            
            if filepath:
                result = self.verify_file_content(filepath, fk_id, min_lines=20)
            else:
                result = {'exists': False, 'has_content': False, 
                         'has_frontmatter': False, 'has_correct_id': False, 'lines': 0}
            
            self.results['conceitos_frankl'][fk_id] = result
            
            if not result['exists']:
                self.errors.append(f"{fk_id}: Conceito não encontrado")
    
    def verify_frameworks(self):
        """Verifica frameworks IA-F"""
        print("Verificando frameworks (IA-F)...")
        for i in range(1, 4):
            fw_id = f"IA-F-{i:03d}"
            pattern = f"03-IA-AGENTES/**/*{fw_id}*.md"
            filepath = self.find_file_by_pattern(pattern)
            
            if filepath:
                result = self.verify_file_content(filepath, fw_id, min_lines=15)
            else:
                result = {'exists': False, 'has_content': False, 
                         'has_frontmatter': False, 'has_correct_id': False, 'lines': 0}
            
            self.results['frameworks'][fw_id] = result
            
            if not result['exists']:
                self.errors.append(f"{fw_id}: Framework não encontrado")
    
    def verify_intersections(self):
        """Verifica interseções INT"""
        print("Verificando interseções (INT)...")
        for i in range(1, 5):
            int_id = f"INT-{i:03d}"
            pattern = f"04-INTERSECOES/**/*{int_id}*.md"
            filepath = self.find_file_by_pattern(pattern)
            
            if filepath:
                result = self.verify_file_content(filepath, int_id, min_lines=15)
            else:
                result = {'exists': False, 'has_content': False, 
                         'has_frontmatter': False, 'has_correct_id': False, 'lines': 0}
            
            self.results['intersecoes'][int_id] = result
            
            if not result['exists']:
                self.errors.append(f"{int_id}: Interseção não encontrada")
    
    def verify_syntheses(self):
        """Verifica sínteses SYN"""
        print("Verificando sínteses (SYN)...")
        for i in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 20]:
            syn_id = f"SYN-{i:03d}"
            pattern = f"06-SINTESES/**/*{syn_id}*.md"
            filepath = self.find_file_by_pattern(pattern)
            
            if filepath:
                result = self.verify_file_content(filepath, syn_id, min_lines=10)
            else:
                result = {'exists': False, 'has_content': False, 
                         'has_frontmatter': False, 'has_correct_id': False, 'lines': 0}
            
            self.results['sinteses'][syn_id] = result
            
            if not result['exists']:
                self.warnings.append(f"{syn_id}: Síntese não encontrada")
    
    def verify_assets(self):
        """Verifica assets visuais"""
        print("Verificando assets visuais...")
        assets = [
            "08-ASSETS/imagens/roadmap-leitura-frankl.png",
            "08-ASSETS/imagens/framework-design-frankl-ia.png",
            "08-ASSETS/imagens/mapa-logoterapia.png"
        ]
        
        for asset in assets:
            filepath = self.base_dir / asset
            self.results['assets'][asset] = {
                'exists': filepath.exists(),
                'size': filepath.stat().st_size if filepath.exists() else 0
            }
            
            if not filepath.exists():
                self.errors.append(f"Asset não encontrado: {asset}")
    
    def verify_scripts(self):
        """Verifica scripts de auditoria"""
        print("Verificando scripts de auditoria...")
        scripts = [
            "00-META/scripts-auditoria/README.md",
            "00-META/scripts-auditoria/audit_structure.sh",
            "00-META/scripts-auditoria/audit_frontmatter.py",
            "00-META/scripts-auditoria/audit_links.py",
            "00-META/scripts-auditoria/audit_complete.sh",
            "00-META/scripts-auditoria/generate_metrics.py",
            "00-META/scripts-auditoria/verify_complete.py"
        ]
        
        for script in scripts:
            filepath = self.base_dir / script
            self.results['scripts'][script] = {
                'exists': filepath.exists(),
                'size': filepath.stat().st_size if filepath.exists() else 0
            }
    
    def generate_report(self):
        """Gera relatório em Markdown"""
        report = f"""# Relatório de Verificação Automática

**Data:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Versão:** 1.0

---

## 📊 Resumo Executivo

"""
        
        # Contar sucessos e falhas
        total_files = 0
        complete_files = 0
        
        for category in ['fontes', 'conceitos_frankl', 'frameworks', 'intersecoes', 'sinteses']:
            for file_id, result in self.results[category].items():
                total_files += 1
                if result.get('exists') and result.get('has_correct_id') and result.get('has_content'):
                    complete_files += 1
        
        completion_rate = (complete_files / total_files * 100) if total_files > 0 else 0
        
        report += f"""| Métrica | Valor |
|:--------|------:|
| **Taxa de Completude** | {completion_rate:.1f}% |
| **Arquivos Verificados** | {total_files} |
| **Arquivos Completos** | {complete_files} |
| **Erros Críticos** | {len(self.errors)} |
| **Avisos** | {len(self.warnings)} |
| **IDs Únicos** | {len(self.results['ids_map'])} |
| **Links Totais** | {self.results['links']['total']} |
| **Links Quebrados** | {self.results['links']['broken']} |
| **Taxa de Links OK** | {((self.results['links']['total'] - self.results['links']['broken']) / self.results['links']['total'] * 100) if self.results['links']['total'] > 0 else 0:.1f}% |

---

## 📁 Verificação por Categoria

"""
        
        # Fontes
        report += "### Fontes (SRC)\n\n"
        for src_id, result in sorted(self.results['fontes'].items()):
            status = "✓" if result.get('exists') and result.get('has_correct_id') else "✗"
            lines = result.get('lines', 0)
            report += f"- {status} **{src_id}** ({lines} linhas)\n"
        
        # Conceitos Frankl
        report += "\n### Conceitos de Frankl (FK-C)\n\n"
        for fk_id, result in sorted(self.results['conceitos_frankl'].items()):
            status = "✓" if result.get('exists') and result.get('has_correct_id') else "✗"
            lines = result.get('lines', 0)
            report += f"- {status} **{fk_id}** ({lines} linhas)\n"
        
        # Frameworks
        report += "\n### Frameworks (IA-F)\n\n"
        for fw_id, result in sorted(self.results['frameworks'].items()):
            status = "✓" if result.get('exists') and result.get('has_correct_id') else "✗"
            lines = result.get('lines', 0)
            report += f"- {status} **{fw_id}** ({lines} linhas)\n"
        
        # Interseções
        report += "\n### Interseções (INT)\n\n"
        for int_id, result in sorted(self.results['intersecoes'].items()):
            status = "✓" if result.get('exists') and result.get('has_correct_id') else "✗"
            lines = result.get('lines', 0)
            report += f"- {status} **{int_id}** ({lines} linhas)\n"
        
        # Sínteses
        report += "\n### Sínteses (SYN)\n\n"
        for syn_id, result in sorted(self.results['sinteses'].items()):
            status = "✓" if result.get('exists') and result.get('has_correct_id') else "✗"
            lines = result.get('lines', 0)
            report += f"- {status} **{syn_id}** ({lines} linhas)\n"
        
        # Assets
        report += "\n### Assets Visuais\n\n"
        for asset, result in self.results['assets'].items():
            status = "✓" if result['exists'] else "✗"
            size_kb = result['size'] / 1024 if result['size'] > 0 else 0
            report += f"- {status} {os.path.basename(asset)} ({size_kb:.1f} KB)\n"
        
        # Links quebrados
        if self.results['links']['broken'] > 0:
            report += f"\n---\n\n## 🔗 Links Quebrados ({self.results['links']['broken']})\n\n"
            for link_id, files in self.results['links']['details'][:10]:
                report += f"### `[[{link_id}]]` - {len(files)} referência(s)\n\n"
                for f in files[:3]:
                    report += f"- {f}\n"
                if len(files) > 3:
                    report += f"- ... e mais {len(files) - 3} arquivo(s)\n"
                report += "\n"
        
        # Erros
        if self.errors:
            report += "\n---\n\n## ❌ Erros Críticos\n\n"
            for error in self.errors:
                report += f"- {error}\n"
        
        # Avisos
        if self.warnings:
            report += "\n---\n\n## ⚠️ Avisos\n\n"
            for warning in self.warnings:
                report += f"- {warning}\n"
        
        report += f"\n---\n\n**Gerado em:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        
        return report
    
    def run(self):
        """Executa verificação completa"""
        print("="*60)
        print("VERIFICAÇÃO COMPLETA DO REPOSITÓRIO")
        print("="*60)
        print()
        
        # Coletar IDs
        print("Coletando IDs existentes...")
        self.collect_all_ids()
        print(f"✓ Encontrados {len(self.results['ids_map'])} IDs únicos")
        print()
        
        # Verificar categorias
        self.verify_sources()
        self.verify_frankl_concepts()
        self.verify_frameworks()
        self.verify_intersections()
        self.verify_syntheses()
        self.verify_assets()
        self.verify_scripts()
        
        # Verificar links
        print("Verificando links internos...")
        self.verify_links()
        print(f"✓ {self.results['links']['total']} links verificados")
        print(f"✗ {self.results['links']['broken']} links quebrados")
        print()
        
        # Gerar relatório
        print("Gerando relatório...")
        report = self.generate_report()
        
        # Salvar relatório
        output_file = self.base_dir / "00-META" / "_VERIFICACAO_AUTO.md"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"✓ Relatório salvo em: {output_file.relative_to(self.base_dir)}")
        print()
        
        # Resumo final
        print("="*60)
        print("RESUMO")
        print("="*60)
        print(f"Erros críticos: {len(self.errors)}")
        print(f"Avisos: {len(self.warnings)}")
        print(f"Links quebrados: {self.results['links']['broken']}")
        print()
        
        if len(self.errors) == 0 and len(self.warnings) == 0:
            print("✅ REPOSITÓRIO COMPLETO E VERIFICADO!")
        elif len(self.errors) == 0:
            print("⚠️  REPOSITÓRIO OK COM AVISOS")
        else:
            print("❌ REPOSITÓRIO COM ERROS CRÍTICOS")
        
        return len(self.errors) == 0

if __name__ == '__main__':
    verifier = RepositoryVerifier()
    success = verifier.run()
    exit(0 if success else 1)

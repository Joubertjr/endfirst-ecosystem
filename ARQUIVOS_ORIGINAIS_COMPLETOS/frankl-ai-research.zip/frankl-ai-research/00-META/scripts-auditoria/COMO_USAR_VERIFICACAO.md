# Como Usar o Script de Verificação Completa

## 📋 Visão Geral

O script `verify_complete.py` é uma ferramenta automatizada que verifica **TUDO** no repositório frankl-ai-research:

✅ Existência de arquivos  
✅ Conteúdo real (não apenas placeholders)  
✅ Frontmatter YAML completo  
✅ IDs corretos  
✅ Links internos  
✅ Tamanho mínimo de conteúdo  
✅ Assets visuais  
✅ Scripts de auditoria  

---

## 🚀 Uso Rápido

### No Terminal

```bash
cd frankl-ai-research
python3 00-META/scripts-auditoria/verify_complete.py
```

### No Cursor AI

1. Abra o repositório no Cursor AI
2. Abra o terminal integrado (Ctrl+`)
3. Execute:
   ```bash
   python3 00-META/scripts-auditoria/verify_complete.py
   ```

### No Claude Code

1. Abra o repositório no Claude Code
2. Use o comando:
   ```
   Execute o script de verificação:
   python3 00-META/scripts-auditoria/verify_complete.py
   ```

---

## 📊 O Que o Script Verifica

### 1. Fontes (SRC)

Verifica **16 arquivos** de fontes primárias:
- SRC-001 a SRC-011 (obras de Frankl e artigos)
- SRC-013 a SRC-017 (guias e documentação)

**Critérios:**
- ✅ Arquivo existe
- ✅ Tem pelo menos 15 linhas
- ✅ Tem frontmatter YAML
- ✅ ID correto no frontmatter

### 2. Conceitos de Frankl (FK-C)

Verifica **10 conceitos** principais:
- FK-C-001 a FK-C-010

**Critérios:**
- ✅ Arquivo existe
- ✅ Tem pelo menos 20 linhas
- ✅ Tem frontmatter YAML
- ✅ ID correto no frontmatter

### 3. Frameworks (IA-F)

Verifica **3 frameworks** práticos:
- IA-F-001: Meaningful HCI Framework
- IA-F-002: AI Thinking Framework
- IA-F-003: Framework de Liberdade Reflexiva

**Critérios:**
- ✅ Arquivo existe
- ✅ Tem pelo menos 15 linhas
- ✅ Tem frontmatter YAML
- ✅ ID correto no frontmatter

### 4. Interseções (INT)

Verifica **4 interseções** Frankl-IA:
- INT-001 a INT-004

**Critérios:**
- ✅ Arquivo existe
- ✅ Tem pelo menos 15 linhas
- ✅ Tem frontmatter YAML
- ✅ ID correto no frontmatter

### 5. Sínteses (SYN)

Verifica **13 sínteses**:
- SYN-001 a SYN-012 (análises e planos de aula)
- SYN-020 (roadmap de publicação)

**Critérios:**
- ✅ Arquivo existe
- ✅ Tem pelo menos 10 linhas
- ✅ Tem frontmatter YAML
- ✅ ID correto no frontmatter

### 6. Assets Visuais

Verifica **3 imagens**:
- roadmap-leitura-frankl.png
- framework-design-frankl-ia.png
- mapa-logoterapia.png

**Critérios:**
- ✅ Arquivo existe
- ✅ Tamanho > 0 KB

### 7. Links Internos

Verifica **todos os wikilinks** `[[ID]]`:
- Coleta todos os IDs existentes
- Verifica se cada link aponta para um ID válido
- Lista links quebrados com arquivos que os referenciam

### 8. Scripts de Auditoria

Verifica **7 scripts**:
- README.md
- audit_structure.sh
- audit_frontmatter.py
- audit_links.py
- audit_complete.sh
- generate_metrics.py
- verify_complete.py

---

## 📄 Saída do Script

### No Terminal

O script exibe:

```
============================================================
VERIFICAÇÃO COMPLETA DO REPOSITÓRIO
============================================================

Coletando IDs existentes...
✓ Encontrados 54 IDs únicos

Verificando fontes (SRC)...
Verificando conceitos de Frankl (FK-C)...
Verificando frameworks (IA-F)...
Verificando interseções (INT)...
Verificando sínteses (SYN)...
Verificando assets visuais...
Verificando scripts de auditoria...
Verificando links internos...
✓ 150 links verificados
✗ 13 links quebrados

Gerando relatório...
✓ Relatório salvo em: 00-META/_VERIFICACAO_AUTO.md

============================================================
RESUMO
============================================================
Erros críticos: 0
Avisos: 0
Links quebrados: 13

✅ REPOSITÓRIO COMPLETO E VERIFICADO!
```

### Arquivo Gerado

O script gera automaticamente:

**`00-META/_VERIFICACAO_AUTO.md`**

Contém:
- 📊 Resumo executivo com métricas
- 📁 Verificação detalhada por categoria
- 🔗 Lista de links quebrados
- ❌ Erros críticos (se houver)
- ⚠️ Avisos (se houver)

---

## 🎯 Interpretando os Resultados

### ✅ Status OK

```
✅ REPOSITÓRIO COMPLETO E VERIFICADO!
```

**Significa:**
- Todos os arquivos existem
- Todos têm conteúdo adequado
- Todos têm frontmatter correto
- Nenhum erro crítico

### ⚠️ Status com Avisos

```
⚠️ REPOSITÓRIO OK COM AVISOS
```

**Significa:**
- Arquivos principais OK
- Alguns avisos menores (ex: links quebrados para placeholders)
- Repositório utilizável

### ❌ Status com Erros

```
❌ REPOSITÓRIO COM ERROS CRÍTICOS
```

**Significa:**
- Arquivos essenciais faltando
- Frontmatter incorreto
- Conteúdo insuficiente
- **Ação necessária!**

---

## 🔧 Exemplos de Uso

### Exemplo 1: Verificação Rápida

```bash
# Verificar se tudo está OK
cd frankl-ai-research
python3 00-META/scripts-auditoria/verify_complete.py

# Ver relatório gerado
cat 00-META/_VERIFICACAO_AUTO.md
```

### Exemplo 2: Verificação Antes de Commit

```bash
# Antes de fazer commit
python3 00-META/scripts-auditoria/verify_complete.py

# Se OK, fazer commit
git add .
git commit -m "Atualização verificada"
```

### Exemplo 3: Verificação Após Adicionar Conteúdo

```bash
# Após adicionar novo arquivo SRC-018
python3 00-META/scripts-auditoria/verify_complete.py

# Verificar se foi detectado
grep "SRC-018" 00-META/_VERIFICACAO_AUTO.md
```

### Exemplo 4: Uso no Cursor AI

**Prompt para o Cursor AI:**

```
Execute a verificação completa do repositório:

python3 00-META/scripts-auditoria/verify_complete.py

Depois, mostre-me o relatório gerado em 00-META/_VERIFICACAO_AUTO.md
e corrija quaisquer erros encontrados.
```

### Exemplo 5: Uso no Claude Code

**Prompt para o Claude Code:**

```
Verifique a integridade completa do repositório frankl-ai-research 
executando o script verify_complete.py e analise o relatório gerado.
```

---

## 📝 Personalizando o Script

### Adicionar Nova Categoria

Para verificar uma nova categoria de arquivos, edite `verify_complete.py`:

```python
def verify_nova_categoria(self):
    """Verifica nova categoria"""
    print("Verificando nova categoria...")
    for i in range(1, 10):
        novo_id = f"NOVO-{i:03d}"
        pattern = f"DIRETORIO/**/*{novo_id}*.md"
        filepath = self.find_file_by_pattern(pattern)
        
        if filepath:
            result = self.verify_file_content(filepath, novo_id, min_lines=10)
        else:
            result = {'exists': False, ...}
        
        self.results['nova_categoria'][novo_id] = result
```

Depois, adicione a chamada em `run()`:

```python
def run(self):
    ...
    self.verify_nova_categoria()  # Adicionar aqui
    ...
```

### Ajustar Critérios de Validação

Para mudar o número mínimo de linhas:

```python
# Linha original
result = self.verify_file_content(filepath, src_id, min_lines=15)

# Ajustado para 30 linhas
result = self.verify_file_content(filepath, src_id, min_lines=30)
```

---

## 🐛 Solução de Problemas

### Erro: "ModuleNotFoundError"

**Problema:** Python não encontra módulos.

**Solução:**
```bash
# Verificar versão do Python
python3 --version  # Deve ser 3.7+

# Usar Python correto
python3.11 00-META/scripts-auditoria/verify_complete.py
```

### Erro: "FileNotFoundError"

**Problema:** Script não encontra o repositório.

**Solução:**
```bash
# Executar do diretório raiz do repositório
cd frankl-ai-research
python3 00-META/scripts-auditoria/verify_complete.py
```

### Erro: "Permission Denied"

**Problema:** Script não tem permissão de execução.

**Solução:**
```bash
chmod +x 00-META/scripts-auditoria/verify_complete.py
python3 00-META/scripts-auditoria/verify_complete.py
```

### Muitos Links Quebrados

**Problema:** Relatório mostra muitos links quebrados.

**Solução:**
1. Verifique se são placeholders (`[[ID]]`, `[[ID_CONCEITO_IA]]`)
2. Se sim, é normal (placeholders para expansão futura)
3. Se não, crie os arquivos faltantes ou corrija os links

---

## 📚 Integração com Outros Scripts

### Workflow Completo

```bash
# 1. Verificar estrutura
bash 00-META/scripts-auditoria/audit_structure.sh

# 2. Verificar frontmatter
python3 00-META/scripts-auditoria/audit_frontmatter.py

# 3. Verificar links
python3 00-META/scripts-auditoria/audit_links.py

# 4. Verificação completa (tudo junto)
python3 00-META/scripts-auditoria/verify_complete.py

# 5. Gerar métricas
python3 00-META/scripts-auditoria/generate_metrics.py
```

### Ou Usar o Script Completo

```bash
# Executa todos os scripts acima automaticamente
bash 00-META/scripts-auditoria/audit_complete.sh
```

---

## ✅ Checklist de Uso

Antes de usar o script, certifique-se de:

- [ ] Estar no diretório raiz do repositório
- [ ] Ter Python 3.7+ instalado
- [ ] Ter permissões de leitura nos arquivos
- [ ] Ter permissões de escrita em `00-META/`

Após executar o script:

- [ ] Ler o resumo no terminal
- [ ] Abrir `00-META/_VERIFICACAO_AUTO.md`
- [ ] Corrigir erros críticos (se houver)
- [ ] Revisar avisos (se houver)
- [ ] Decidir sobre links quebrados

---

## 📞 Suporte

Se encontrar problemas:

1. Verifique a seção "Solução de Problemas" acima
2. Leia `00-META/scripts-auditoria/README.md`
3. Consulte `00-META/_METODOLOGIA.md`

---

**Última atualização:** 24 de novembro de 2025

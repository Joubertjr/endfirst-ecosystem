# Relatório de Verificação Automática

**Data:** 2025-12-08 17:39:21  
**Versão:** 1.0

---

## 📊 Resumo Executivo

| Métrica | Valor |
|:--------|------:|
| **Taxa de Completude** | 100.0% |
| **Arquivos Verificados** | 46 |
| **Arquivos Completos** | 46 |
| **Erros Críticos** | 0 |
| **Avisos** | 0 |
| **IDs Únicos** | 71 |
| **Links Totais** | 410 |
| **Links Quebrados** | 33 |
| **Taxa de Links OK** | 92.0% |

---

## 📁 Verificação por Categoria

### Fontes (SRC)

- ✓ **SRC-001** (72 linhas)
- ✓ **SRC-002** (94 linhas)
- ✓ **SRC-003** (23 linhas)
- ✓ **SRC-004** (429 linhas)
- ✓ **SRC-005** (580 linhas)
- ✓ **SRC-006** (224 linhas)
- ✓ **SRC-007** (504 linhas)
- ✓ **SRC-008** (128 linhas)
- ✓ **SRC-009** (26 linhas)
- ✓ **SRC-010** (39 linhas)
- ✓ **SRC-011** (91 linhas)
- ✓ **SRC-013** (388 linhas)
- ✓ **SRC-014** (335 linhas)
- ✓ **SRC-015** (1169 linhas)
- ✓ **SRC-016** (449 linhas)
- ✓ **SRC-017** (695 linhas)

### Conceitos de Frankl (FK-C)

- ✓ **FK-C-001** (70 linhas)
- ✓ **FK-C-002** (68 linhas)
- ✓ **FK-C-003** (44 linhas)
- ✓ **FK-C-004** (34 linhas)
- ✓ **FK-C-005** (34 linhas)
- ✓ **FK-C-006** (32 linhas)
- ✓ **FK-C-007** (54 linhas)
- ✓ **FK-C-008** (61 linhas)
- ✓ **FK-C-009** (55 linhas)
- ✓ **FK-C-010** (81 linhas)

### Frameworks (IA-F)

- ✓ **IA-F-001** (24 linhas)
- ✓ **IA-F-002** (30 linhas)
- ✓ **IA-F-003** (32 linhas)

### Interseções (INT)

- ✓ **INT-001** (69 linhas)
- ✓ **INT-002** (58 linhas)
- ✓ **INT-003** (52 linhas)
- ✓ **INT-004** (49 linhas)

### Sínteses (SYN)

- ✓ **SYN-001** (83 linhas)
- ✓ **SYN-002** (79 linhas)
- ✓ **SYN-003** (86 linhas)
- ✓ **SYN-004** (82 linhas)
- ✓ **SYN-005** (103 linhas)
- ✓ **SYN-006** (104 linhas)
- ✓ **SYN-007** (106 linhas)
- ✓ **SYN-008** (131 linhas)
- ✓ **SYN-009** (35 linhas)
- ✓ **SYN-010** (30 linhas)
- ✓ **SYN-011** (109 linhas)
- ✓ **SYN-012** (29 linhas)
- ✓ **SYN-020** (16 linhas)

### Assets Visuais

- ✓ roadmap-leitura-frankl.png (39.8 KB)
- ✓ framework-design-frankl-ia.png (34.9 KB)
- ✓ mapa-logoterapia.png (32.6 KB)

---

## 🔗 Links Quebrados (33)

### `[[ID]]` - 13 referência(s)

- 00-META/_METODOLOGIA.md
- 00-META/_AUDITORIA_FINAL_v2.md
- 00-META/_VERIFICACAO_AUTO.md
- ... e mais 10 arquivo(s)

### `[[ID_CONCEITO_IA]]` - 4 referência(s)

- 00-META/_TEMPLATE.md
- 00-META/_VERIFICACAO_AUTO.md
- 00-META/RELATORIO_FINAL_ENTREGA.md
- ... e mais 1 arquivo(s)

### `[[IA-C-005]]` - 4 referência(s)

- 00-META/_RASTREABILIDADE.md
- 00-META/_RASTREABILIDADE.md
- 00-META/_VERIFICACAO_AUTO.md
- ... e mais 1 arquivo(s)

### `[[IA-C-010]]` - 3 referência(s)

- 00-META/_VERIFICACAO_AUTO.md
- 00-META/RELATORIO_FINAL_ENTREGA.md
- 01-FRANKL-CORE/conceitos/FK-C-002_logoterapia.md

### `[[INT-005]]` - 3 referência(s)

- 00-META/_VERIFICACAO_AUTO.md
- 00-META/RELATORIO_FINAL_ENTREGA.md
- 01-FRANKL-CORE/conceitos/FK-C-004_responsabilidade.md

### `[[INT-006]]` - 3 referência(s)

- 00-META/_VERIFICACAO_AUTO.md
- 00-META/RELATORIO_FINAL_ENTREGA.md
- 01-FRANKL-CORE/conceitos/FK-C-005_autotranscendencia.md

### `[[SRC-012]]` - 2 referência(s)

- 00-META/_VERIFICACAO_AUTO.md
- 06-SINTESES/analises/SYN-012_Frameworks-Praticos.md

### `[[_ACOES_FUTURAS]]` - 1 referência(s)

- 06-SINTESES/analises/SYN-021_Lacuna-Teorica-Literatura-IA.md


---

**Gerado em:** 2025-12-08 17:39:21

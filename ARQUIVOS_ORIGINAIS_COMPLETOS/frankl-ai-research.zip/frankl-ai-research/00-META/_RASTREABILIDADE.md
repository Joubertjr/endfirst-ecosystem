# Matriz de Rastreabilidade

**Versão:** 2.0  
**Data:** 24 de novembro de 2025  
**Última atualização:** Integração de SRC-002

---

## Cadeias Conceituais

### Frankl → IA (Direto)

- **Cadeia 1: Sentido em Agentes**
  - [[FK-C-001]] (Vontade de Sentido)
  - → [[INT-001]] (Sentido em Agentes)
  - → [[IA-C-002]] (Goal-Oriented Behavior)
  - → [[SRC-003]] (Nguyen et al., 2022)

- **Cadeia 2: Espaço de Escolha**
  - [[FK-C-003]] (Liberdade de Vontade)
  - → [[INT-002]] (Espaço Entre Estímulo e Resposta)
  - → [[IA-C-005]] (Human-in-the-Loop)
  - → [[SRC-003]] (Nguyen et al., 2022)

- **Cadeia 3: Responsabilidade**
  - [[FK-C-004]] (Responsabilidade)
  - → [[INT-003]] (Responsabilidade em Sistemas Autônomos)
  - → [[IA-C-003]] (Value Alignment)
  - → [[SRC-006]] (National Planning Cycles, 2025)

- **Cadeia 4: Três Vias para o Sentido**
  - [[FK-C-010]] (Três Caminhos para o Sentido)
  - → [[INT-004]] (Meaningful HCI Framework)
  - → [[AR-IA-001]] (Quynh Nguyen)
  - → [[SRC-003]] (Nguyen et al., 2022)

### Frankl → Continuadores → IA (Indireto)

- **Cadeia 5: Psicologia Positiva 2.0**
  - [[FK-C-001]] (Vontade de Sentido)
  - → [[AR-P-004]] (Paul Wong)
  - → Psicologia Positiva 2.0
  - → *Potencial para aplicação em IA de bem-estar*

---

## Status de Cobertura

| Conceito Frankl | Interseção | Conceito IA | Fontes | Status |
| :--- | :--- | :--- | :--- | :--- |
| [[FK-C-001]] | [[INT-001]] | [[IA-C-002]] | 2 | ✅ |
| [[FK-C-002]] | - | - | 1 | ⚠️ Aplicável |
| [[FK-C-003]] | [[INT-002]] | [[IA-C-005]] | 2 | ✅ |
| [[FK-C-004]] | [[INT-003]] | [[IA-C-003]] | 2 | ✅ |
| [[FK-C-005]] | - | - | 1 | ⚠️ Aplicável |
| [[FK-C-006]] | - | - | 1 | ❌ GAP |
| [[FK-C-007]] | - | - | 1 | ⚠️ **NOVO** - Vazio Existencial e IA |
| [[FK-C-008]] | - | - | 1 | ⚠️ **NOVO** - Neurose Noogênica e IA |
| [[FK-C-009]] | - | - | 1 | ❌ **NOVO** - Tríade Trágica (baixa aplicabilidade) |
| [[FK-C-010]] | [[INT-004]] | - | 2 | ✅ **NOVO** |

---

## Autores Continuadores

| Autor | ID | Área | Conexão com IA | Status |
| :--- | :--- | :--- | :--- | :--- |
| Elisabeth Lukas | [[AR-P-001]] | Logoterapia clínica | Baixa | ✅ |
| Alfried Längle | [[AR-P-002]] | Análise Existencial | Baixa | ✅ |
| Alexander Batthyány | [[AR-P-003]] | Pesquisa empírica | Média | ✅ |
| Paul T. P. Wong | [[AR-P-004]] | Psicologia Positiva 2.0 | Média | ✅ |

---

## Novas Oportunidades de Interseção

### Alta Prioridade

1.  **[[FK-C-007]] (Vazio Existencial) ↔ IA**
    - **Hipótese:** Automação excessiva e algoritmos de recomendação podem amplificar o vazio existencial.
    - **Aplicação:** Framework para avaliar "risco de vazio existencial" em sistemas de IA.

2.  **[[FK-C-008]] (Neurose Noogênica) ↔ IA**
    - **Hipótese:** Substituição de trabalho significativo por automação pode induzir neuroses noogênicas em larga escala.
    - **Aplicação:** Políticas de requalificação centradas em sentido, não apenas em habilidades técnicas.

### Média Prioridade

3.  **[[AR-P-004]] (Paul Wong) ↔ IA de Bem-Estar**
    - **Hipótese:** Psicologia Positiva 2.0 pode informar o design de sistemas de IA para promoção de bem-estar autêntico.
    - **Aplicação:** Chatbots terapêuticos baseados em sentido, não apenas em redução de sintomas.

---

## Estatísticas

- **Conceitos de Frankl:** 10 (4 novos)
- **Interseções confirmadas:** 4
- **Autores continuadores:** 4 (novos)
- **Fontes primárias:** 11 + 1 (SRC-002)
- **Cobertura:** 40% dos conceitos têm interseções confirmadas

## Atualização: Frameworks Práticos (24/11/2025)

### Novos Frameworks Adicionados

| ID | Framework | Fonte | Conceitos Relacionados |
| :--- | :--- | :--- | :--- |
| **IA-F-001** | Meaningful HCI | SRC-003, SRC-012 | FK-C-001, FK-C-003, FK-C-004, FK-C-006 |
| **IA-F-002** | AI Thinking | SRC-005, SRC-012 | FK-C-001, FK-C-003, FK-C-004 |
| **IA-F-003** | Liberdade Reflexiva | SRC-006, SRC-012 | FK-C-001, FK-C-003, FK-C-004 |

### Cadeias de Implementação

1.  **Frankl → Frameworks → Componentes Técnicos**
    - FK-C-001 (Vontade de Sentido) → IA-F-001 (Meaningful HCI) → Módulo de Reflexão
    - FK-C-003 (Liberdade) → IA-F-003 (Liberdade Reflexiva) → Módulo de Escolha Consciente
    - FK-C-004 (Responsabilidade) → IA-F-001 (Meaningful HCI) → Sistema de Explicabilidade

2.  **Frameworks → Interseções**
    - IA-F-001 → INT-001 (Sentido em Agentes)
    - IA-F-002 → INT-001 (Sentido em Agentes)
    - IA-F-003 → INT-002 (Espaço de Escolha)

# Resumo da Pesquisa: Conceitos, Frameworks e Metodologias sobre Mudança de Comportamento Baseada na Identidade e Teoria do Autoconceito

## Introdução

A mudança de comportamento sustentável representa um desafio persistente em diversas áreas, desde a saúde pública até o desenvolvimento pessoal. A pesquisa psicológica e comportamental tem convergido para a compreensão de que a **identidade** e o **autoconceito** não são meros correlatos, mas sim mecanismos causais e preditores centrais da manutenção do comportamento [2] [10] [11]. Este resumo sintetiza os principais conceitos teóricos, frameworks conceituais e metodologias práticas, não-tecnológicas, que fundamentam a abordagem da mudança de comportamento baseada na identidade.

## Teorias Psicológicas Fundacionais do Autoconceito

O arcabouço teórico da mudança de comportamento baseada na identidade está profundamente enraizado em teorias clássicas do autoconceito, que definem a estrutura e a função da autoimagem na regulação da ação humana.

### Teoria do Self (Carl Rogers, 1959)

Carl Rogers estabeleceu a **Teoria do Self** no contexto da abordagem Centrada na Pessoa, definindo o **Self-Concept** como o conjunto organizado e consistente de percepções e crenças que um indivíduo tem sobre si mesmo [8]. A mudança de comportamento, neste contexto, é vista como uma consequência da redução da **incongruência** entre o *self real* (como o indivíduo se percebe) e o *self ideal* (como o indivíduo gostaria de ser). A intervenção, tipicamente o aconselhamento, facilita essa mudança ao prover um ambiente de aceitação incondicional e congruência, permitindo que o indivíduo reorganize sua percepção de si mesmo e, consequentemente, seu comportamento [8] [18].

### Teoria dos Esquemas do Self (Hazel Markus, 1977)

Hazel Markus introduziu o conceito de **Self-Schema** (Esquema do Self), que são estruturas cognitivas derivadas de experiências passadas que organizam e guiam o processamento de informações relacionadas ao self [5]. Indivíduos com um esquema do self bem definido em um domínio (ex: "eu sou um atleta") processam informações mais rapidamente, fazem previsões de comportamento mais confiantes e são mais resistentes a informações que contradizem seu esquema. A mudança de comportamento sustentável, portanto, exige a **criação ou modificação** desses esquemas do self para que o novo comportamento se torne automático e consistente com a autoimagem [5] [12].

### Teoria da Discrepância do Self (E. Tory Higgins, 1987)

E. Tory Higgins refinou a compreensão do autoconceito ao postular a **Teoria da Discrepância do Self**, que distingue três domínios do self: o *Self Real* (Actual Self), o *Self Ideal* (Ideal Self) e o *Self Obrigatório* (Ought Self) [4]. A motivação para a mudança de comportamento é frequentemente impulsionada pela necessidade de reduzir as discrepâncias entre essas representações. A discrepância entre o *Self Real* e o *Self Ideal* gera emoções de desânimo (como decepção), enquanto a discrepância entre o *Self Real* e o *Self Obrigatório* gera emoções de agitação (como ansiedade). A mudança de comportamento é, em essência, um esforço para alinhar o *self real* com os *selves* desejados ou obrigatórios [4].

### Teoria dos Selves Possíveis (Markus & Nurius, 1986)

Complementando a teoria dos esquemas, Markus e Nurius introduziram o conceito de **Possible Selves** (Selves Possíveis), que são as representações cognitivas do que um indivíduo pode se tornar, gostaria de se tornar ou teme se tornar [9]. Os Selves Possíveis funcionam como **incentivos** para o comportamento futuro, fornecendo o contexto motivacional para a mudança. A intervenção eficaz envolve a ativação e o desenvolvimento de *selves possíveis* desejados e a criação de estratégias para evitar *selves possíveis* temidos [9].

## Frameworks Conceituais e Metodologias

A aplicação prática dessas teorias resultou em frameworks conceituais robustos que orientam intervenções focadas na identidade como motor da mudança.

### 1. Motivação Baseada na Identidade (Identity-Based Motivation - IBM)

Desenvolvido por Daphna Oyserman e colaboradores, o modelo IBM é um framework sociocognitivo que postula que as identidades são dinamicamente construídas e que as pessoas preferem ações que são **congruentes com a identidade** ativa no momento [1] [3] [20].

| Componente | Descrição | Implicação para a Mudança |
| :--- | :--- | :--- |
| **Identidade Ativa** | A autoimagem que está acessível e relevante no momento. | O comportamento é mais provável se for percebido como "coisa de gente como eu" [1]. |
| **Congruência** | O alinhamento entre a identidade e o comportamento. | Quando o comportamento é congruente, a dificuldade é interpretada como **importância**; quando incongruente, a dificuldade é interpretada como **impossibilidade** [1]. |
| **Selves Possíveis** | Identidades futuras desejadas ou temidas. | A mudança é sustentada ao ligar o comportamento atual à identidade futura desejada [3] [20]. |

O IBM é um framework que se traduz em metodologias de intervenção que visam tornar a identidade desejada mais acessível e o comportamento congruente com ela [13].

### 2. Modelo de Mudança de Comportamento Baseado na Identidade Social (SIMBC)

O **Social Identity Model of Behavior Change (SIMBC)** aplica a **Teoria da Identidade Social** e a **Teoria da Autocategorização** para explicar a mudança de comportamento em contextos de grupo [6] [7] [15].

O SIMBC foca em **estruturas humanas** e **intervenções de grupo** como o principal mecanismo de mudança. A identificação com um grupo social (Identidade Social Compartilhada - SSI) que endossa o comportamento desejado é um preditor chave de mudança e manutenção [6]. A metodologia prática envolve:

1.  **Formação de Identidade:** Criar um senso de "nós" entre os participantes.
2.  **Definição de Normas:** Estabelecer as normas do grupo que apoiam o novo comportamento.
3.  **Apoio Social:** Utilizar a influência social e o apoio mútuo do grupo para sustentar a mudança [7] [15].

### 3. Hábitos Baseados na Identidade (James Clear, 2018)

Embora popularizado em um livro de desenvolvimento pessoal, o conceito de **Hábitos Baseados na Identidade** é um framework conceitual que sintetiza as teorias psicológicas em uma metodologia prática [16]. Ele propõe que a mudança mais profunda e duradoura ocorre quando o foco se desloca do *resultado* (ex: perder 10kg) para a *identidade* (ex: tornar-se uma pessoa saudável). A mudança de comportamento é um processo de três camadas:

$$\text{Resultado} \rightarrow \text{Processo} \rightarrow \text{Identidade}$$

O foco metodológico é na **evidência** do novo self: cada ação é um "voto" para o tipo de pessoa que se deseja ser. A sustentabilidade é alcançada quando o comportamento se torna uma **expressão** da identidade, e não um sacrifício para alcançar um resultado [16] [17].

## Evidências Científicas e Metodologias Não-Tecnológicas

Revisões sistemáticas confirmam o papel central da identidade na pesquisa de comportamento [10] [19]. A manutenção da mudança de comportamento, em particular, é fortemente ligada ao alinhamento do comportamento com o autoconceito [2] [12].

As metodologias práticas (não-tecnológicas) e as estruturas humanas mais eficazes para promover a mudança baseada na identidade incluem:

*   **Aconselhamento e Consultoria:** Intervenções focadas no autoconceito, como as baseadas na abordagem Centrada na Pessoa, demonstraram eficácia na promoção da mudança comportamental [14].
*   **Intervenções de Grupo:** O SIMBC utiliza a dinâmica de grupo para criar uma identidade social compartilhada que reforça o comportamento desejado, sendo uma metodologia prática e socialmente estruturada [7] [15].
*   **Coaching e Mentoria:** O uso de *selves possíveis* e a ativação da identidade desejada são aplicados em contextos de coaching para alinhar as ações com os objetivos de longo prazo [13] [20].

## Referências

1.  **Identity-Based Motivation: Implications for Intervention** | Oyserman, D., & Destin, M. (2010). *The Counseling Psychologist*, 38(7), 1001–1043. [https://journals.sagepub.com/doi/abs/10.1177/0011000010374775]
2.  **Theoretical explanations for maintenance of behaviour change: a systematic review of behaviour theories** | Kwasnicka, D., Dombrowski, S. U., White, M., & Sniehotta, F. (2016). *Health Psychology Review*, 10(3), 277–296. [https://www.tandfonline.com/doi/full/10.1080/17437199.2016.1151372]
3.  **An Identity-Based Motivation Framework for Self-Regulation** | Oyserman, D., Lewis Jr, N. A., Yan, V. X., Fisher, O., O'Donnell, S. C., & Horowitz, E. (2017). *Psychological Inquiry*, 28(2-3), 139–147. [http://dx.doi.org/10.1080/1047840X.2017.1337406]
4.  **Self-discrepancy: A theory relating self and affect** | Higgins, E. T. (1987). *Psychological Review*, 94(3), 319–340. [https://psycnet.apa.org/record/1987-34444-001]
5.  **Self-schemata and processing information about the self** | Markus, H. (1977). *Journal of Personality and Social Psychology*, 35(2), 63–78. [https://psycnet.apa.org/record/1977-27587-001]
6.  **The Social Identity Model of Behavior Change (SIMBC)** | Tarrant, M., Haslam, S. A., et al. (2020). *Handbook of Behavior Change*. [Referências em https://www.cambridge.org/core/books/handbook-of-behavior-change/social-identity-interventions/B967A5A5E4F61C3929EAEE0CF8B388B0]
7.  **Social Identity Interventions** | Tarrant, M. (2020). In *The Handbook of Behavior Change*. Cambridge University Press. [https://www.cambridge.org/core/books/handbook-of-behavior-change/social-identity-interventions/B967A5A5E4F61C3929EAEE0CF8B388B0]
8.  **A Theory of Therapy, Personality, and Interpersonal Relationships** | Rogers, C. R. (1959). In S. Koch (Ed.), *Psychology: A Study of a Science* (Vol. 3, pp. 184–256). McGraw-Hill. [https://www.beeleaf.com/wp-content/uploads/2017/09/rogers_chapter_in_koch-1.pdf]
9.  **Possible Selves** | Markus, H., & Nurius, P. (1986). *American Psychologist*, 41(9), 954–969. [https://psycnet.apa.org/record/1987-01154-001]
10. **The Role of Identity in Human Behavior Research: A Systematic Scoping Review** | Alfrey, K. L., et al. (2023). *Journal of Behavioral Medicine*. [https://www.tandfonline.com/doi/abs/10.1080/15283488.2023.2209586]
11. **The Role of the Self in Behavioral Change** | Stein, K. F., & Markus, H. R. (1996). *Journal of Psychotherapy Integration*, 6(1), 3–28. [https://psycnet.apa.org/fulltext/1997-38336-003.html]
12. **Theoretical explanations for maintenance of behaviour change: a systematic review of behaviour theories (Detail)** | Kwasnicka, D., et al. (2016). *BMC Medicine*, 14(1), 1–10. [https://pmc.ncbi.nlm.nih.gov/articles/PMC4975085/]
13. **Pathways to success through identity-based motivation** | Oyserman, D. (2015). Oxford University Press. [https://books.google.com/books?hl=en&lr=&id=oC5mBgAAQBAJ&oi=fnd&pg=PP1]
14. **Self-concept and behavioral changes through counseling/consulting interventions** | Martinez Martin, F. M. (1978). Texas Tech University. [https://ttu-ir.tdl.org/bitstreams/1e88c8cb-e88a-4dec-9ffd-473b1f9a12ff/download]
15. **Social Identity Interventions (Detail)** | Tarrant, M., et al. (2020). *ResearchGate*. [https://www.researchgate.net/publication/374446349_Social_Identity_Interventions]
16. **Atomic Habits: An Easy & Proven Way to Build Good Habits & Break Bad Ones** | Clear, J. (2018). Avery. [https://books.google.com/books?hl=en&lr=&id=lFhbDwAAQBAJ&oi=fnd&pg=PA1]
17. **The Power of Habit: Why We Do What We Do in Life and Business** | Duhigg, C. (2012). Random House. [https://nacada.ksu.edu/Resources/Book-Reviews/Current-Past-Book-Reviews/articleType/ArticleView/articleId/5329/The-Power-of-Habit-Why-we-do-what-we-do-in-life-and-business.aspx]
18. **The Self-Concept in Relation to Behavior: Theoretical and Empirical Research** | Shlien, J. M. (1962). *The Review of Educational Research*, 32(4), 408–419. [https://www.tandfonline.com/doi/pdf/10.1080/003440862057S408]
19. **The Role of Identity in Human Behavior Research (Detail)** | Alfrey, K. L., et al. (2023). *ResearchGate*. [https://www.researchgate.net/publication/370909605_The_Role_of_Identity_in_Human_Behavior_Research_A_Systematic_Scoping_Review]
20. **Identity-Based Motivation: Core Processes and Intervention Examples** | Oyserman, D. (2015). *ResearchGate*. [https://www.researchgate.net/publication/281692029_Identity-Based_Motivation_Core_Processes_and_Intervention_Examples]

***

*   **Total de Fontes Identificadas:** 20
*   **Área Temática:** Psicologia Social, Psicologia da Personalidade, Economia Comportamental e Psicologia da Saúde.
*   **Cobertura Geográfica:** Principalmente Estados Unidos (E.U.A.) e Reino Unido (R.U.), com ampla disseminação global em publicações acadêmicas.
*   **Principais Conceitos-Chave:** Motivação Baseada na Identidade (IBM), Teoria do Self, Esquemas do Self, Selves Possíveis, Teoria da Discrepância do Self, Modelo de Mudança de Comportamento Baseado na Identidade Social (SIMBC), Hábitos Baseados na Identidade.
*   **Metodologias Não-Tecnológicas:** Intervenções de Grupo (SIMBC), Aconselhamento Centrado na Pessoa, Coaching focado em Selves Possíveis.

[/home/ubuntu/research_summary.md]

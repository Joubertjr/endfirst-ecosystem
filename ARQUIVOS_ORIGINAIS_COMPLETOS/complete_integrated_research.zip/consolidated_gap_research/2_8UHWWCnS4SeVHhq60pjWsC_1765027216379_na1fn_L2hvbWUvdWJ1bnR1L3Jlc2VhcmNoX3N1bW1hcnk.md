# Resumo da Pesquisa: Aderência a Tratamentos Médicos sob a Perspectiva Psicossocial, Sociológica e Cultural

## Introdução

A aderência a tratamentos médicos, definida como a extensão em que o comportamento de uma pessoa (tomar medicamentos, seguir dietas, modificar o estilo de vida) coincide com as recomendações acordadas com um profissional de saúde, é um desafio global que afeta a eficácia dos cuidados e os resultados de saúde [1] [2]. A não-aderência é um fenômeno complexo e multifatorial, e a pesquisa acadêmica, particularmente nas áreas de psicologia, sociologia e antropologia, tem desenvolvido diversos modelos e *frameworks* conceituais para explicar as falhas de implementação. Esta pesquisa focou exclusivamente em conceitos teóricos, metodologias e evidências empíricas que abordam as dimensões **psicológicas, sociológicas, culturais e institucionais** da aderência, excluindo intencionalmente qualquer menção a tecnologias, aplicativos ou produtos comerciais.

## 1. Teorias Psicológicas e Comportamentais

As teorias psicológicas buscam explicar a aderência como um comportamento individual, influenciado por crenças, motivações e habilidades. Elas fornecem a base para a compreensão da **falha de implementação** a nível do paciente, focando em por que os indivíduos decidem (ou não) seguir as recomendações médicas.

### 1.1. Modelos de Crenças e Cognição

O **Modelo de Crenças em Saúde (Health Belief Model - HBM)** postula que a probabilidade de um indivíduo adotar um comportamento de saúde é determinada por suas percepções de suscetibilidade e gravidade da doença, e pelos benefícios e barreiras percebidas da ação [3]. A **Autoeficácia**, a crença na capacidade de realizar o comportamento com sucesso, foi posteriormente incorporada ao HBM e é um construto central na **Teoria da Autoeficácia** de Albert Bandura, parte da Teoria Cognitiva Social [3] [7]. A autoeficácia está consistentemente associada a menores níveis de não-aderência, e o suporte social percebido pode mediar essa relação [7].

O **Necessity-Concerns Framework (NCF)**, por sua vez, foca na aderência intencional, propondo que a decisão de aderir é um equilíbrio entre as **Crenças de Necessidade** (julgamento da necessidade pessoal do tratamento) e as **Preocupações** (medos sobre efeitos adversos, dependência, etc.) [11]. A não-aderência intencional ocorre quando as preocupações superam a percepção de necessidade.

### 1.2. Modelos de Ação e Estágios de Mudança

A **Teoria do Comportamento Planejado (TCP)** explica a aderência através da **Intenção Comportamental**, que é influenciada pela atitude do indivíduo, pela norma subjetiva (pressão social percebida) e pelo controle comportamental percebido [4].

O **Modelo Transteórico (Transtheoretical Model - TTM)**, de Prochaska e DiClemente, descreve a aderência como um processo dinâmico que se desenrola em **Estágios de Mudança** (Pré-contemplação, Contemplação, Preparação, Ação, Manutenção) [9]. A falha de implementação, neste contexto, é vista como uma intervenção inadequada ao estágio motivacional do paciente.

O **Modelo de Habilidades de Informação-Motivação-Comportamento (IMB)** integra fatores psicossociais, sugerindo que a aderência é um produto da **Informação** (conhecimento), **Motivação** (pessoal e social) e **Habilidades Comportamentais** (capacidade objetiva e autoeficácia) [10].

O **Modelo COM-B (Capability, Opportunity, Motivation, Behavior)** é um *framework* mais recente e abrangente, que postula que o comportamento é o resultado da interação entre **Capacidade** (física e psicológica), **Oportunidade** (física e social) e **Motivação** (reflexiva e automática) [12]. Este modelo é frequentemente usado para diagnosticar barreiras e desenhar intervenções não-tecnológicas.

## 2. Frameworks Sociológicos e Sistêmicos

Estes *frameworks* movem o foco do indivíduo para o contexto social e as **estruturas institucionais** que moldam a aderência, explicando as falhas de implementação como problemas sistêmicos.

### 2.1. O Framework das Cinco Dimensões da OMS

A **Organização Mundial da Saúde (OMS)** categoriza os fatores de não-aderência em cinco dimensões inter-relacionadas, reforçando a natureza multifatorial do problema [2]:

| Dimensão | Fatores Chave |
| :--- | :--- |
| **Socioeconômicos** | Custo do tratamento, pobreza, baixa escolaridade, suporte social inadequado. |
| **Relacionados à Condição** | Gravidade da doença, cronicidade, comorbidades. |
| **Relacionados à Terapia** | Complexidade do regime, duração do tratamento, efeitos colaterais. |
| **Relacionados ao Paciente** | Crenças, conhecimento, autoeficácia, habilidades cognitivas. |
| **Relacionados ao Sistema de Saúde** | Acesso, relação profissional-paciente, tempo de consulta, organização do serviço. |

### 2.2. Determinantes Sociais da Saúde (DSS) e Barreiras Institucionais

A pesquisa sociológica e de saúde pública estabelece uma forte ligação entre os **Determinantes Sociais da Saúde (DSS)** e a aderência [6]. Fatores como **Insegurança Alimentar** e **Instabilidade Habitacional** são consistentemente identificados como barreiras socioeconômicas que impactam negativamente a aderência, reforçando que a falha de implementação é, em grande parte, um problema **sociológico** [6].

Em um nível mais amplo, as **barreiras institucionais e sistêmicas** (não-tecnológicas) são cruciais para a falha de implementação de diretrizes clínicas e, por extensão, para a aderência do paciente [14]. Estas incluem barreiras políticas (regulamentações excessivas), organizacionais (carga de trabalho pesada, falta de suporte administrativo) e de recursos (limitação de pessoal, falta de infraestrutura), que impedem a entrega de cuidados de saúde de forma eficaz [14].

## 3. Perspectivas Culturais e Antropológicas

A **Antropologia Médica** oferece uma crítica fundamental ao conceito de *compliance* (conformidade), que implica uma obediência passiva do paciente, e introduz a importância das **diferenças culturais** e dos **sistemas humanos e sociais** na aderência [8].

O conceito de **"Schismogenics Médicos"** critica a biomedicina por **medicalizar a "cultura"** ao categorizá-la como um uso irracional de medicamentos por parte do paciente, desviando o foco das falhas sistêmicas [8]. A aderência é vista como um fenômeno culturalmente mediado, onde as **crenças culturais** (como o uso de medicina tradicional ou o fatalismo) e a **discriminação percebida** atuam como barreiras psicossociais significativas [1] [13].

O **Estigma** e a **Discriminação** são identificados como barreiras psicossociais e sociais poderosas, levando os pacientes a evitar clínicas, esconder medicamentos e pular doses por medo de serem reconhecidos, o que contribui diretamente para a falha de implementação do tratamento [13].

## Conclusão

A pesquisa acadêmica demonstra que a aderência a tratamentos é um comportamento complexo que transcende a simples vontade individual. As falhas de implementação são o resultado de uma intrincada rede de fatores:

*   **Psicológicos:** Crenças, autoeficácia, motivação e estágio de mudança (HBM, NCF, TTM, IMB, SDT).
*   **Sociológicos/Sistêmicos:** Pobreza, instabilidade social, barreiras de acesso e organização do sistema de saúde (DSS, OMS 5 Dimensões, Barreiras Institucionais).
*   **Culturais:** Estigma, discriminação e representações culturais da doença e do tratamento (Antropologia Médica, Schismogenics Médicos).

A abordagem eficaz da não-aderência requer intervenções que sejam culturalmente competentes, adaptadas ao estágio motivacional do paciente e que abordem as barreiras estruturais e institucionais subjacentes.

## Referências

| ID | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| [1] | Cultural Issues in Medication Adherence: Disparities and Directions | McQuaid, E. L., & Landier, W. | 2017 | https://pmc.ncbi.nlm.nih.gov/articles/PMC5789102/ |
| [2] | A systematic review of factors that influence treatment adherence in paediatric oncology patients | Goh, X. T. W., Tan, Y. B., Thirumoorthy, T., & Kwan, Y. H. | 2017 | https://onlinelibrary.wiley.com/doi/10.1111/jcpt.12441 |
| [3] | Predicting Adherence to Medications Using Health Psychology Theories: A Systematic Review of 20 Years of Empirical Research | Holmes, E. A. F., Hughes, D. A., & Morrison, V. L. | 2014 | https://www.valueinhealthjournal.com/article/S1098-3015(14)04621-X/fulltext |
| [4] | The relationship between the theory of planned behavior and medication adherence in patients with epilepsy | Lin, C. Y., Updegraff, J. A., & Pakpour, A. H. | 2016 | https://www.sciencedirect.com/science/article/abs/pii/S1525505016301159 |
| [5] | Can the common-sense model predict adherence in chronically ill patients? A meta-analysis | Brandes, K., & Mullan, B. | 2014 | https://www.tandfonline.com/doi/abs/10.1080/17437199.2013.820986 |
| [6] | The Impact of Social Determinants of Health on Medication Adherence: a Systematic Review and Meta-analysis | Wilder, M. E., et al. | 2021 | https://pubmed.ncbi.nlm.nih.gov/33515188/ |
| [7] | Self-efficacy and adherence to treatment: the mediating effects of social support | Martos-Méndez, M. J. | 2015 | https://www.sciencedirect.com/science/article/pii/S2007078017300020 |
| [8] | Medical Schismogenics: Compliance and "Culture" in Caribbean Biomedicine | Whitmarsh, I. | 2009 | https://www.jstor.org/stable/25488279 |
| [9] | Use of the transtheoretical model in medication adherence: A systematic review | Imeri, H., Toth, J., Arnold, A., & Barnard, M. | 2022 | https://pubmed.ncbi.nlm.nih.gov/34275751/ |
| [10] | Applying the Information-Motivation-Behavioral Skills Model in Medication Adherence Among Thai Youth Living with HIV: A Qualitative Study | Rongkavilit, C., et al. | 2010 | https://pmc.ncbi.nlm.nih.gov/articles/PMC3011990/ |
| [11] | Understanding Patients’ Adherence-Related Beliefs about Medicines Prescribed for Long-Term Conditions: A Meta-Analytic Review of the Necessity-Concerns Framework | Horne, R., et al. | 2013 | https://pmc.ncbi.nlm.nih.gov/articles/PMC3846635/ |
| [12] | The use of the Capability-Opportunity- Motivation Behavior (COM-B) model to identify barriers to medication adherence and the application of mobile health technology in adults with coronary heart disease: A qualitative study | Park, L. G., Ng, F., & Handley, M. A. | 2023 | https://pmc.ncbi.nlm.nih.gov/articles/PMC10518702/ |
| [13] | Effects of Stigmatization/Discrimination on Antiretroviral Therapy Adherence among HIV-Infected Patients in a Rural Tertiary Medical Center in Nigeria | Omosanya, O. E., et al. | 2014 | https://www.researchgate.net/publication/236070285_Effects_of_StigmatizationDiscrimination_on_Antiretroviral_Therapy_Adherence_among_HIV-Infected_Patients_in_a_Rural_Tertiary_Medical_Center_in_Nigeria |
| [14] | Barriers and enablers to implementing clinical practice guidelines in primary care: an overview of systematic reviews | Wang, T., Tan, J. Y. B., Liu, X. L., & Zhao, I. | 2023 | https://pmc.ncbi.nlm.nih.gov/articles/PMC9827241/ |
| [15] | Self-Determination Theory and Preventive Medication Adherence: Motivational Considerations to Support Historically Marginalized Adolescents with Asthma | Blaakman, S. W., et al. | 2022 | https://pmc.ncbi.nlm.nih.gov/articles/PMC9805470/ |

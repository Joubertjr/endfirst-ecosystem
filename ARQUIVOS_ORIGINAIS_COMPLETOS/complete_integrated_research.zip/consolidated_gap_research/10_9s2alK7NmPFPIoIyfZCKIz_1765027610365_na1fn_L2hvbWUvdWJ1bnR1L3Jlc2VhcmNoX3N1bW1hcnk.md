# Relatório de Pesquisa: Grupos de Apoio e Peer Support - Conceitos Teóricos, Evidências de Eficácia e Falhas de Implementação

## 1. Área Temática e Escopo da Pesquisa

O presente relatório sintetiza a pesquisa sobre os **conceitos teóricos, frameworks e evidências de eficácia de grupos de apoio e peer support**, com um foco específico nas **falhas de implementação** e nas **perspectivas culturais e institucionais** que modulam seu sucesso. A pesquisa buscou exclusivamente literatura acadêmica e teórica, excluindo qualquer menção a tecnologia, softwares ou produtos comerciais, conforme as diretrizes estabelecidas. Foram identificadas 15 fontes acadêmicas relevantes, incluindo artigos de psicologia, sociologia, antropologia, meta-análises e estudos cross-culturais [1-15].

## 2. Conceitos Teóricos e Frameworks Fundamentais

A eficácia dos grupos de apoio e do suporte de pares (peer support) é explicada por um conjunto robusto de teorias psicológicas e sociológicas que se concentram nos processos interpessoais e grupais.

### 2.1. Teorias Psicológicas e Sociológicas da Eficácia

| Teoria/Princípio | Conceito Central | Mecanismo de Eficácia no Peer Support | Fonte |
| :--- | :--- | :--- | :--- |
| **Princípio da Terapia do Ajudante (HTP)** | O ato de ajudar um colega sofredor é terapêutico para o próprio ajudante [11]. | Aumenta a **autoestima**, o senso de **competência interpessoal** e o **valor pessoal** do ajudante, contribuindo para sua própria recuperação [7] [11]. | [7] [11] |
| **Teoria da Identidade Social (SIT)** | O impacto do suporte é maximizado pela **identificação grupal** e pelo senso de pertencimento [10]. | A criação de uma **identidade social baseada em grupo** aumenta o suporte de pares (emocional e informacional) e a **autoeficácia** [10]. | [10] |
| **Teoria da Troca Social (SET)** | As relações são mantidas por um cálculo de custos e benefícios, mas em grupos de apoio, foca-se na **troca mútua** de recursos [13]. | A troca de **apoio emocional** e **informação experiencial** é o processo terapêutico central. A eficácia depende da maximização das trocas benéficas e da minimização de "comportamentos indesejados" (trocas negativas) [13]. | [13] |
| **Dinâmica de Grupo (Kurt Lewin)** | O comportamento é moldado por um **campo de forças** em equilíbrio, e a mudança social ocorre em processos de grupo [8]. | A **identidade grupal** e a **identificação de problemas comuns** são cruciais para a construção do **vínculo** e para a mudança social [1]. O risco é a instrumentalização do processo que pode **obnubilar relações de poder e determinações estruturais** [8]. | [1] [8] |
| **Apoio Social e Comparação Social** | O apoio social atua como um **buffer contra o estresse** [7]. A comparação com pares (especialmente a **comparação social ascendente**) serve como **modelo de papel** e aumenta a **esperança** e a **motivação** [7]. | O suporte de pares fornece informações que levam a pessoa a se sentir cuidada, amada, estimada e valorizada [7]. | [1] [7] |

### 2.2. Evidências de Eficácia

Meta-análises indicam que o suporte de pares (Peer Support Interventions - PSI) pode ser eficaz, embora com efeitos modestos, para a **recuperação clínica** (redução de sintomas) e, de forma mais consistente, para a **recuperação pessoal** [14]. A recuperação pessoal é um conceito central, focado em uma vida satisfatória, esperançosa e contributiva, com ênfase no **empoderamento** e na **autodeterminação** [2] [14]. No entanto, a evidência é frequentemente insuficiente para recomendar a implementação rotineira em serviços de saúde mental, e os resultados para a **recuperação funcional** (ex: qualidade de vida) são inconsistentes [2] [14].

## 3. Falhas de Implementação e Perspectivas Institucionais

As falhas na implementação de programas de suporte de pares e políticas sociais mais amplas são frequentemente atribuídas a fatores estruturais e institucionais, e não apenas a deficiências no desenho do programa.

### 3.1. A Lacuna de Implementação (Policy-Implementation Gap)

A **Teoria Institucional** e a análise da **Lacuna de Implementação** explicam que as políticas falham ou têm sucesso não apenas por seus méritos intrínsecos, mas pela forma como interagem com as estruturas existentes [6] [12]. Quatro fatores principais contribuem para a falha de implementação [12]:

1.  **Expectativas Excessivamente Otimistas:** Falha no desenho da política.
2.  **Implementação em Governança Dispersa:** Falha estrutural devido à complexidade do sistema (ex: sistemas de saúde mental [3] [12]).
3.  **Recursos Inadequados:** Falha de recursos.
4.  **Resistência e Oposição:** Falha política/institucional (ex: hostilidade de funcionários não-pares [3]).

### 3.2. Barreiras Institucionais e Culturais

A **institucionalização** do papel do Trabalhador de Suporte de Pares (PSW) em ambientes clínicos pode levar à **diluição** das tarefas essenciais de suporte de pares e à **falta de clareza de papel** (unclear role), o que é uma barreira comum em todos os contextos culturais [3] [9]. A **resistência** em sistemas de saúde mental que mantêm uma abordagem biomédica e a **hostilidade** de funcionários não-pares são barreiras institucionais significativas [3].

A **perspectiva antropológica** argumenta que a falha na implementação ocorre quando o programa não leva em conta os **valores, atitudes e crenças** da população, constituindo uma **miopia frente ao social** e uma **falha no recorte da realidade** [15]. A doença e o problema social são **fenômenos sociológicos** e **realidades construídas** [15].

### 3.3. A Perspectiva dos Sistemas Sociais

A **Teoria dos Sistemas Sociais de Luhmann** oferece uma visão alternativa sobre a falha, tratando-a não como um erro moral, mas como uma **perturbação** (irritação) que leva o sistema a **auto-observação** e **auto-reprodução** (autopoiese) [5]. Nessa perspectiva, as falhas são **funcionais** para a evolução do sistema, que se diferencia funcionalmente e observa a si mesmo.

## 4. Perspectivas Culturais e Estudos Cross-Culturais

Estudos cross-culturais demonstram que a implementação e os resultados do suporte de pares variam significativamente entre contextos de baixa, média e alta renda (LMIC & HIC) [9].

| Contexto Cultural | Foco do Peer Support | Barreiras e Influências Culturais | Fonte |
| :--- | :--- | :--- | :--- |
| **LMIC (Baixa/Média Renda)** | **Gestão da doença**, **acesso a cuidados**, **empregabilidade** e **situação financeira** [9]. | Os PSWs interagem ativamente com *stakeholders* comunitários (polícia, parentes), promovendo **influências socioeducativas e anti-estigma** [9]. | [9] |
| **HIC (Alta Renda)** | **Auto-revelação (self-disclosure)** e **desenvolvimento vocacional** do par [9]. | A implementação é mais focada na integração em serviços de saúde mental já estabelecidos [9]. | [9] |
| **Contextos Asiáticos** | A literatura ocidental pode ser insuficiente. O **estigma social** e a necessidade de **lentes culturalmente fundamentadas** para examinar a **recuperação pessoal** são barreiras significativas [3]. | A **cultura escolar dominante** (e, por extensão, a cultura institucional) tende a priorizar o **uniforme** e o **homogêneo**, o que pode levar à **desigualdade** e **discriminação** ao lidar com a diferença cultural [4]. | [3] [4] |

## 5. Referências

1.  Onocko Campos, R. T., & do Val, M. D. (2024). Efeito de grupos de apoio entre pares na saúde mental de estudantes da saúde. *Revista Brasileira de Educação Médica*. https://www.scielo.br/j/rbem/a/jymXJwcbS6NFrtgD9Qk7VvN/
2.  Lyons, N., Cooper, C., & Lloyd-Evans, B. (2021). A systematic review and meta-analysis of group peer support interventions for people experiencing mental health conditions. *BMC Psychiatry*. https://pmc.ncbi.nlm.nih.gov/articles/PMC8220835/
3.  Kuek, J. H. L., Chua, H. C., & Poremski, D. (2021). Barriers and facilitators of peer support work in a large psychiatric hospital: a thematic analysis. *BMC Psychiatry*. https://pmc.ncbi.nlm.nih.gov/articles/PMC8212403/
4.  Candau, V. M. F. (2011). Diferenças Culturais, Cotidiano Escolar e Práticas Pedagógicas. *Currículo sem Fronteiras*. https://www.curriculosemfronteiras.org/vol11iss2articles/candau.htm
5.  Rocha, L. S., & Costa, B. L. C. (2021). O sentido da crítica para a teoria dos sistemas sociais: uma observação sobre a sociologia sistêmica da crítica. *Revista Brasileira de Sociologia do Direito*. https://revista.abrasd.com.br/index.php/rbsd/article/download/460/283
6.  Peters, B. G. (2024). Institutionalism(s) and implementation: sources of implementation failure. *The Elgar Companion to Implementation Studies*. https://www.elgaronline.com/edcollchap/book/9781800885905/book-part-9781800885905-21.xml
7.  Proudfoot, J. G., et al. (2012). Mechanisms underpinning effective peer support: a qualitative analysis of interactions between expert peers and patients newly-diagnosed with bipolar disorder. *BMC Psychiatry*. https://pmc.ncbi.nlm.nih.gov/articles/PMC3549948/
8.  Pasqualini, J. C., Martins, F. R., & Filho, A. E. (2021). A "Dinâmica de Grupo" de Kurt Lewin: proposições, contexto e crítica. *Psicologia: Ciência e Profissão*. http://pepsic.bvsalud.org/scielo.php?script=sci_arttext&pid=S1413-294X2021000200005
9.  Moran, G. S., et al. (2025). Multicultural Implementation-Experiences of Peer Support Workers in MH Services: Qualitative Findings of UPSIDES Innovative Intervention—An International Multi-Site Project. *Community Mental Health Journal*. https://link.springer.com/article/10.1007/s10926-025-10320-4
10. Su, J., Dugas, M., Guo, X., & Gao, G. (2022). Building social identity-based groups to enhance online peer support for patients with chronic disease: a pilot study using mixed-methods evaluation. *Translational Behavioral Medicine*. https://academic.oup.com/tbm/article-abstract/12/5/702/6551571
11. Pagano, M. E. (2011). Alcoholics Anonymous-Related Helping and the Helper Therapy Principle. *Alcohol Research & Health*. https://pmc.ncbi.nlm.nih.gov/articles/PMC3603139/
12. Hudson, B., Hunter, D., & Peckham, S. (2019). Policy failure and the policy-implementation gap: can policy support programs help? *Policy Design and Practice*. https://researchonline.lshtm.ac.uk/id/eprint/4653365/1/hudson_etal_2018_Policy_failure_policy_implementation_gap.pdf
13. Brown, L. D., Tang, X., & Hollman, R. L. (2014). The Structure of Social Exchange in Self-Help Support Groups: Development of a Measure. *American Journal of Community Psychology*. https://pmc.ncbi.nlm.nih.gov/articles/PMC4012643/
14. Smit, D., et al. (2022). The effectiveness of peer support for individuals with mental illness: systematic review and meta-analysis. *Psychological Medicine*. https://pmc.ncbi.nlm.nih.gov/articles/PMC10476060/
15. Minayo, M. C. S. (1991). Abordagem antropológica para avaliação de políticas sociais. *Revista de Saúde Pública*. https://www.scielo.br/j/rsp/a/KdjFt86bzjcxQdbBBnfcVMp/?format=html&lang=pt

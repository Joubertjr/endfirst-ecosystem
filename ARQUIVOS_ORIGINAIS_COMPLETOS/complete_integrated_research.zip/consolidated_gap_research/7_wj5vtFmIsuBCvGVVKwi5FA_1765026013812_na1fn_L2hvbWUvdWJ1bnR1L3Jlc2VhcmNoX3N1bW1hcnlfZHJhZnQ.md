# Fundamentos Teóricos e Evidências Científicas em Frameworks de Coaching Profissional (ICF e Modelo GROW)

## Introdução

Esta pesquisa concentra-se na análise de conceitos teóricos, frameworks e metodologias que sustentam o coaching profissional, com foco nos modelos da International Coaching Federation (ICF) e no Modelo GROW. O objetivo é mapear as bases psicológicas e as evidências científicas que conferem rigor e eficácia a essas práticas, excluindo qualquer menção a tecnologia, software ou produtos comerciais, conforme as diretrizes estabelecidas. A investigação se baseia em 16 fontes acadêmicas, incluindo artigos de psicologia, meta-análises e revisões sistemáticas.

## 1. O Modelo GROW e Seus Fundamentos Psicológicos

O **Modelo GROW** (Goal, Reality, Options, Will/Way Forward) é reconhecido como o framework de coaching mais influente e amplamente utilizado no mundo [12]. Sua estrutura simples e sequencial visa facilitar a definição de metas e a solução de problemas, guiando o coachee através de quatro etapas cruciais: a definição do **Objetivo** (Goal), a exploração da **Realidade** atual (Reality), a geração de **Opções** (Options) e o estabelecimento do **Caminho a Seguir** (Will/Way Forward) [3].

A filosofia central do GROW, popularizada por Sir John Whitmore, baseia-se na crença de que "o melhor está dentro" das pessoas e que o papel do coach é "desbloquear o potencial" [12]. Essa perspectiva tem raízes profundas na **Psicologia Humanista**, particularmente no conceito de **"Inner Game" (Jogo Interior)** de Timothy Gallwey, que influenciou Whitmore. Gallwey postulou que o maior obstáculo ao desempenho não é a falta de habilidade, mas sim o conflito interno (dúvida, medo) [12].

O GROW também se conecta a teorias de mudança comportamental. Extensões do modelo, como o **GROWS** (adicionando "Strategies" para superar obstáculos) e o **RE-GROW** (focando na revisão), demonstram a integração com a **Teoria da Autorregulação (Self-Regulation Theory)** e o **Health Action Process Approach (HAPA)**, que segmentam a mudança em fases de planejamento e ação, enfatizando a autoeficácia e a superação de contratempos [1, 7].

## 2. O Framework de Competências da ICF e Suas Bases Teóricas

A **International Coaching Federation (ICF)** estabelece o padrão de prática ética e as **Competências Essenciais** que definem a profissão [2]. O framework de competências da ICF não é um modelo de sessão como o GROW, mas sim um conjunto de habilidades e comportamentos que um coach deve demonstrar.

O fundamento teórico mais proeminente para as competências da ICF é a **Psicologia Humanista**, especialmente a **Abordagem Centrada na Pessoa** de **Carl Rogers** [16]. Competências como a criação de confiança, a escuta ativa e a manutenção da presença refletem diretamente os princípios rogerianos de **consideração positiva incondicional**, **empatia** e **congruência** (autenticidade) [16]. O foco no cliente como especialista em sua própria vida e a crença em seu potencial de autorrealização são centrais tanto para a Psicologia Humanista quanto para a mentalidade de coaching da ICF.

Outras teorias psicológicas que sustentam o framework da ICF incluem:
*   **Teoria da Autodeterminação (Self-Determination Theory - SDT):** Postula que a satisfação das necessidades psicológicas básicas de **autonomia**, **competência** e **relacionamento** é crucial para a motivação intrínseca e o bem-estar. O coaching eficaz, ao apoiar essas necessidades, facilita uma forte aliança de trabalho e a consecução de metas [6].
*   **Teoria do Desenvolvimento Adulto (Adult Development Theory):** Fornece um framework para entender como os indivíduos constroem significado e se desenvolvem em estágios de complexidade crescente. Essa teoria é fundamental para o coaching de desenvolvimento, que visa a transformação da perspectiva do coachee, e não apenas a mudança comportamental [15].
*   **Teoria da Aprendizagem Social (Social Learning Theory):** Sugere que a aprendizagem ocorre por meio da observação, imitação e modelagem. O coaching, ao fornecer um ambiente de observação e feedback, alinha-se a essa teoria, especialmente em contextos de coaching organizacional [14].

## 3. Metodologias Práticas e Evidências Científicas

O coaching profissional se beneficia da integração de diversos frameworks conceituais e metodologias práticas, muitas delas derivadas da psicologia clínica e organizacional:

*   **Coaching Cognitivo-Comportamental (CBC):** Utiliza a conceituação de problemas e ferramentas baseadas na **Terapia Cognitivo-Comportamental (TCC)**. O CBC é uma abordagem estruturada e focada que tem demonstrado resultados positivos em meta-análises, embora o campo ainda exija estudos mais rigorosos [13].
*   **Coaching Focado na Solução (SFBC):** Baseado na Terapia Breve Focada na Solução (SFBT), esta metodologia se concentra nos recursos, nas exceções ao problema e na construção de um futuro desejado, em vez de analisar as causas do problema. É um modelo holístico que se alinha com a **Psicologia Positiva** ao promover o bem-estar psicológico [9].
*   **Teoria do Controle (Control Theory - CT):** Serve como um framework organizador para o coaching executivo, enfatizando que o coach deve ajudar o coachee a se tornar um **autorregulador** mais eficaz, focado na definição de **metas** e na busca de **feedback** [5].

A eficácia do coaching é corroborada por **evidências científicas** robustas. Meta-análises de **Ensaios Controlados Randomizados (RCTs)** demonstram que o coaching no local de trabalho tem um efeito positivo e estatisticamente significativo em resultados de liderança e pessoais, com um tamanho de efeito moderado (g = 0,59) [11]. Outras revisões sistemáticas confirmam os efeitos positivos do coaching em resultados organizacionais e afetivos [10]. No entanto, a literatura também aponta para a necessidade de maior rigor metodológico e um foco mais aprofundado nos **mecanismos psicológicos** subjacentes (o "como" o coaching funciona) para legitimar ainda mais a profissão [4].

## 4. Fontes de Pesquisa e Contribuições Teóricas

A tabela a seguir resume as 16 fontes acadêmicas e teóricas utilizadas, destacando suas principais contribuições para o campo do coaching profissional.

| ID | Título | Autor(es) | Ano | Contribuição Teórica Principal |
| :---: | :--- | :--- | :---: | :--- |
| 1 | The GROWS model: extending the GROW coaching model to support behavioural change | Panchal, S. e Riddell, P. | 2020 | Extensão do GROW; Integração com o **Health Action Process Approach (HAPA)** e **Teoria da Autorregulação**. |
| 2 | Introduction to the ICF Core Competency Model | Passmore, J. e Sinclair, T. | 2020 | Apresentação do **Modelo de Competências Essenciais da ICF** e seu papel como padrão ético e profissional. |
| 3 | Coaching models, theories, and structures: An overview for teaching faculty... | Deiorio, N. M. et al. | 2022 | Revisão de modelos (incluindo GROW) e sua aplicação em contextos profissionais; Conexão com **Capital Psicológico**. |
| 4 | A systematic review of executive coaching outcomes: Is it the journey or the destination that matters the most? | Athanasopoulou, A. e Dopson, S. | 2018 | Revisão sistemática; Crítica à falta de rigor metodológico e necessidade de focar no **processo** de coaching. |
| 5 | Goals, feedback, and self-regulation: Control theory as a natural framework for executive coaching. | Gregory, J. B. et al. | 2011 | Aplicação da **Teoria do Controle (Control Theory)** como framework para o coaching executivo (metas e feedback). |
| 6 | Prospective associations between working alliance, basic psychological need satisfaction, and coaching outcome indicators... | Vermeiden, M. et al. | 2022 | Estudo empírico; Aplicação da **Teoria da Autodeterminação (SDT)** (autonomia, competência, relacionamento) e sua ligação com a aliança de trabalho. |
| 7 | Is it Time to REGROW the GROW Model? Issues related to teaching coaching session structures | Grant, A. M. | 2022 | Apresentação do modelo **RE-GROW**; Ligação explícita entre a estrutura da sessão e a **Teoria da Autorregulação**. |
| 8 | Positive psychology coaching | Knowles, S. | 2021 | Livro sobre **Coaching baseado na Psicologia Positiva**; Foco no funcionamento humano ideal, bem-estar e forças. |
| 9 | Using Solution-Focused Coaching in Social Work Practice... | Zatloukal, L. et al. | 2023 | Aplicação do **Coaching Focado na Solução** (SFBC) e do modelo **Reteaming**; Conexão com o **bem-estar psicológico**. |
| 10 | The effectiveness of workplace coaching: A meta-analysis of learning and performance outcomes from coaching | Jones, R. J. et al. | 2016 | **Meta-análise** que comprova os **efeitos positivos** do coaching no local de trabalho (δ = 0,36); Evidência científica robusta. |
| 11 | What Can We Know about the Effectiveness of Coaching? A Meta-Analysis Based Only on Randomized Controlled Trials | De Haan, E. e Nilsson, V. O. | 2023 | **Meta-análise de RCTs**; Evidência de alta qualidade com tamanho de efeito moderado (g = 0,59); Modelo baseado na **corregulação**. |
| 12 | The GROW model | Whitmore, J. | 1992 | Origem e filosofia do **Modelo GROW**; Influência do **"Inner Game"** de Gallwey; Fundamentação na **Psicologia Humanista**. |
| 13 | Is cognitive-behavioral coaching an empirically supported approach to coaching? a meta-analysis... | Tomoiagă, C. e David, O. | 2023 | **Meta-análise** sobre o **Coaching Cognitivo-Comportamental (CBC)**; Uso da **Terapia Cognitivo-Comportamental (TCC)**. |
| 14 | Is the coaching fit for purpose? A typology of coaching and learning approaches | Brockbank, A. | 2008 | Tipologia de coaching baseada na **Teoria da Aprendizagem Social** (Bandura); Relação com a definição de coaching da ICF. |
| 15 | Adult Development Theories | Diversos | 2016 | Identifica a **Teoria do Desenvolvimento Adulto** como um dos principais fundamentos teóricos do coaching (Kegan, Cook-Greuter). |
| 16 | Foundations of Professional Coaching: Models, Methods, and Core Competencies | Gavin, J. | 2021 | Confirma a **Psicologia Humanista** de **Carl Rogers** como fundamento teórico dominante das **Competências Essenciais da ICF**. |

## Referências

[1] Panchal, S. e Riddell, P. (2020). *The GROWS model: extending the GROW coaching model to support behavioural change*. Disponível em: https://centaur.reading.ac.uk/id/eprint/104381
[2] Passmore, J. e Sinclair, T. (2020). *Introduction to the ICF Core Competency Model*. In: Becoming a Coach: The Essential ICF Guide. Springer. Disponível em: https://link.springer.com/chapter/10.1007/978-3-030-53161-4_5
[3] Deiorio, N. M. et al. (2022). *Coaching models, theories, and structures: An overview for teaching faculty in the emergency department and educators in the offices*. Disponível em: https://pmc.ncbi.nlm.nih.gov/articles/PMC9482416/
[4] Athanasopoulou, A. e Dopson, S. (2018). *A systematic review of executive coaching outcomes: Is it the journey or the destination that matters the most?*. Disponível em: https://www.sciencedirect.com/science/article/abs/pii/S1048984317301431
[5] Gregory, J. B., Beck, J. W., & Carr, A. E. (2011). *Goals, feedback, and self-regulation: Control theory as a natural framework for executive coaching*. Disponível em: https://psycnet.apa.org/record/2011-06707-003
[6] Vermeiden, M. et al. (2022). *Prospective associations between working alliance, basic psychological need satisfaction, and coaching outcome indicators...*. Disponível em: https://pmc.ncbi.nlm.nih.gov/articles/PMC9664732/
[7] Grant, A. M. (2022). *Is it Time to REGROW the GROW Model? Issues related to teaching coaching session structures*. In: Coaching Practiced. Wiley. Disponível em: https://onlinelibrary.wiley.com/doi/abs/10.1002/9781119835714.ch3
[8] Knowles, S. (2021). *Positive psychology coaching*. Springer. Disponível em: https://link.springer.com/content/pdf/10.1007/978-3-030-88995-1.pdf
[9] Zatloukal, L. et al. (2023). *Using Solution-Focused Coaching in Social Work Practice with the Long-Term Unemployed to Promote Their Well-Being*. Disponível em: https://pmc.ncbi.nlm.nih.gov/articles/PMC10049261/
[10] Jones, R. J., Woods, S. A., & Guillaume, Y. R. F. (2016). *The effectiveness of workplace coaching: A meta-analysis of learning and performance outcomes from coaching*. Disponível em: https://bpspsychub.onlinelibrary.wiley.com/doi/abs/10.1111/joop.12119
[11] De Haan, E. e Nilsson, V. O. (2023). *What Can We Know about the Effectiveness of Coaching? A Meta-Analysis Based Only on Randomized Controlled Trials*. Disponível em: https://journals.aom.org/doi/10.5465/amle.2022.0107
[12] Whitmore, J. (1992). *The GROW model*. Performance Consultants. Disponível em: https://www.performanceconsultants.com/resources/the-grow-model/
[13] Tomoiagă, C. e David, O. (2023). *Is cognitive-behavioral coaching an empirically supported approach to coaching? a meta-analysis to investigate its outcomes and moderators*. Disponível em: https://link.springer.com/article/10.1007/s10942-023-00498-y
[14] Brockbank, A. (2008). *Is the coaching fit for purpose? A typology of coaching and learning approaches*. Disponível em: https://www.tandfonline.com/doi/abs/10.1080/17521880802328046
[15] Diversos. (2016). *Adult Development Theories*. In: The Complete Handbook of Coaching. SAGE Publications. Disponível em: https://books.google.com/books?hl=en&lr=&id=pt3WDwAAQBAJ&oi=fnd&pg=PA403&dq=%22Adult+Development+Theory%22+coaching+ICF+academic&ots=YWiF8ncAZb&sig=oB3C-PhuPjpFfdMHe6aRD14KDW4
[16] Gavin, J. (2021). *Foundations of Professional Coaching: Models, Methods, and Core Competencies*. In: The Complete Handbook of Coaching. SAGE Publications. Disponível em: https://books.google.com/books?hl=en&lr=&id=SyQnEAAAQBAJ&oi=fnd&pg=PR1&dq=%22ICF+core+competencies%22+%22Carl+Rogers%22+%22Humanistic+Psychology%22+academic&ots=ZmYECsY0u8&sig=_7WOHqabbMrV8ZM1nPU0d4FAAlM

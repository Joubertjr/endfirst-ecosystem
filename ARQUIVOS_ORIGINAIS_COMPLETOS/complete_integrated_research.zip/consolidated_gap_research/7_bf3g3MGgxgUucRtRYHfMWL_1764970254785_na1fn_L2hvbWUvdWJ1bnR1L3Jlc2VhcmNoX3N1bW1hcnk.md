# Pesquisa sobre Desconto Temporal e Viés do Presente em Tomada de Decisão

## Área Temática
A área temática desta pesquisa é a **Economia Comportamental** e a **Psicologia da Decisão**, com foco nos conceitos de **Desconto Temporal (Temporal Discounting)** e **Viés do Presente (Present Bias)**, e suas implicações para a **Escolha Intertemporal (Intertemporal Choice)** e o **Autocontrole (Self-Control)**.

## Introdução
A escolha intertemporal, que envolve decisões cujas consequências se manifestam em diferentes momentos no tempo, é um pilar da teoria econômica e da psicologia. O modelo tradicional de **Utilidade Descontada (DU)**, que assume uma taxa de desconto constante (exponencial), falhou em explicar diversas **anomalias** comportamentais observadas [3]. A pesquisa moderna, impulsionada pela economia comportamental e pela psicologia, identificou o **Desconto Temporal Hiperbólico** e o **Viés do Presente** como os principais mecanismos psicológicos que levam à **inconsistência dinâmica** e à **procrastinação** [1] [3] [6].

## Conceitos, Teorias e Frameworks Fundamentais

### 1. Modelos de Desconto e Inconsistência Temporal

| Conceito/Modelo | Autores Chave | Contribuição Teórica |
| :--- | :--- | :--- |
| **Desconto Exponencial** | Samuelson (1937) | Modelo normativo que assume uma taxa de desconto constante, resultando em preferências dinamicamente consistentes. É o modelo padrão, mas não descritivamente preciso [3]. |
| **Desconto Hiperbólico** | Ainslie (1975, 1992) | Função de desconto que decai mais rapidamente no curto prazo do que no longo prazo, levando à **reversão de preferência** e à **inconsistência dinâmica** [6]. |
| **Desconto Quase-Hiperbólico ($\beta-\delta$)** | Laibson (1997) | Modelo formal que aproxima o desconto hiperbólico, introduzindo o parâmetro $\beta$ (que representa o **Viés do Presente**) e $\delta$ (o desconto exponencial padrão). É o framework dominante em economia comportamental [1] [3]. |
| **Viés do Presente** | Frederick, Loewenstein, O'Donoghue (2002) | Tendência a dar peso desproporcional a recompensas ou custos imediatos em comparação com os futuros. É a manifestação comportamental da taxa de desconto decrescente [1] [3]. |

### 2. Modelos de Autocontrole e Múltiplos Eus

O conflito entre a gratificação imediata e os objetivos de longo prazo é frequentemente modelado como uma luta entre diferentes "eus" ou sistemas:

*   **Modelo Dual-Self (Thaler & Shefrin, 1981)**: Postula um **"Planner"** (Planejador) de longo prazo e um **"Doer"** (Executor) de curto prazo. O conflito entre eles explica a falta de autocontrole e a procrastinação [4].
*   **Picoeconomia (Ainslie, 1992)**: Vê o autocontrole como um processo de **barganha intertemporal** entre "eus" sucessivos, onde o indivíduo estabelece **regras pessoais** para se proteger da impulsividade futura [6].
*   **Modelo Dual-Self (Fudenberg & Levine, 2006)**: Formalização mais avançada que descreve o conflito entre um Eu de Longo Prazo e um Eu de Curto Prazo, onde o Eu de Longo Prazo pode exercer **autocontrole custoso** [14].

### 3. Teorias Psicológicas e Fatores Moduladores

| Teoria/Framework | Autores Chave | Relação com Desconto Temporal |
| :--- | :--- | :--- |
| **Teoria do Nível de Construção (CLT)** | Trope & Liberman (2010) | A **distância temporal** leva a um **nível de construção alto** (abstrato), enquanto a proximidade leva a um **nível de construção baixo** (concreto). O desconto ocorre porque recompensas distantes são vistas de forma mais abstrata [9]. |
| **Teoria da Perspectiva Temporal** | Zimbardo & Boyd (2008) | O **Viés do Presente Hedonista** (foco no prazer imediato) está diretamente correlacionado com o **alto desconto temporal** [16]. |
| **Continuidade do Eu Futuro** | Hershfield et al. (2011) | A **baixa conexão psicológica** com o Eu Futuro faz com que o indivíduo trate o Eu Futuro como um estranho, levando a um **maior desconto temporal** [15] [18]. |
| **Depleção do Ego** | Kuhn et al. (2014) | O **autocontrole** é um **recurso limitado** que, quando esgotado, leva a um **aumento no desconto temporal** (maior impulsividade) [8]. |
| **Previsão Afetiva** | Urminsky & Zauberman (2015) | Erros na previsão de como nos sentiremos no futuro (e.g., superestimar a intensidade da emoção imediata) contribuem para o **Viés do Presente** [10]. |
| **Teoria da Autorregulação Temporal (TST)** | Hall & Fong (2007) | Integra a preferência temporal e a capacidade de autorregulação para prever o comportamento. O desconto temporal é um preditor da capacidade de autorregulação [12]. |

## Metodologias Práticas e Estruturas Humanas (Não-Tecnológicas)

As metodologias práticas e estruturas humanas visam mitigar os efeitos do viés do presente e da inconsistência temporal:

*   **Mecanismos de Comprometimento (Commitment Devices)**: Restrições impostas no presente para limitar escolhas futuras impulsivas. Exemplos incluem contratos sociais e apostas (não-tecnológicas) [5].
*   **Intenções de Implementação (Implementation Intentions)**: Estratégia cognitiva que automatiza a resposta a um gatilho específico, preenchendo a lacuna entre a intenção e a ação ("Se [situação], então [comportamento]") [11].
*   **Pensamento Episódico Futuro (Episodic Future Thinking - EFT)**: Técnica cognitiva que envolve a **imaginação vívida** de eventos futuros, o que aumenta a saliência e a proximidade psicológica das consequências futuras, **reduzindo o desconto temporal** [7].
*   **Entrevista Motivacional (Motivational Interviewing - MI)**: Estrutura de **coaching** focada em explorar e resolver a ambivalência do indivíduo em relação à mudança, fortalecendo a motivação intrínseca para objetivos de longo prazo [13].
*   **Nudge (Empurrão)**: Metodologia prática baseada em economia comportamental que usa o conhecimento dos vieses (como o viés do presente) para influenciar sutilmente as escolhas das pessoas em direções mais vantajosas, sem restringir suas opções [2] [5].

## Documentação Detalhada das Fontes

A tabela a seguir resume as 18 fontes acadêmicas e teóricas utilizadas na pesquisa:

| # | Título | Autor(es) | Ano | URL | Contribuições Principais |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Intertemporal choice | Ericson, K. M., & Laibson, D. | 2019 | [1] | Revisão abrangente; introdução de "present-focused preferences"; contraste entre desconto exponencial e quase-hiperbólico. |
| 2 | The malleability of intertemporal choice | Lempert, K. M., & Phelps, E. A. | 2015 | [2] | Revisão sobre a maleabilidade da escolha intertemporal; influência do contexto; modelos heurísticos (ITCH, DRIFT); conceito de "nudge". |
| 3 | Time Discounting and Time Preference: A Critical Review | Frederick, S., Loewenstein, G., & O'Donoghue, T. | 2002 | [3] | Revisão seminal e crítica do modelo DU; sumarização das "anomalias" (incluindo viés do presente). |
| 4 | An Economic Theory of Self-Control | Thaler, R. H., & Shefrin, H. M. | 1981 | [4] | Introdução do **Modelo Dual-Self** (Planner vs. Doer) para explicar a inconsistência temporal. |
| 5 | Commitment devices under self-control problems: An overview | Benartzi, S. H., & Thaler, R. H. | 2004 | [5] | Foco nos **Mecanismos de Comprometimento** como metodologia prática para superar o viés do presente. |
| 6 | Picoeconomics: The Strategic Interaction of Successive Motivational States within the Person | Ainslie, G. | 1992 | [6] | Desenvolvimento da **Picoeconomia**; formulação original do **desconto hiperbólico**; autocontrole como barganha intertemporal. |
| 7 | The effects of positive affect and episodic future thinking on temporal discounting... | Levens, S. M., et al. | 2019 | [7] | Foca no **Episodic Future Thinking (EFT)** como metodologia prática para **reduzir o desconto temporal**. |
| 8 | Self control and intertemporal choice: Evidence from glucose and depletion interventions | Kuhn, M., Kuhn, P., & Villeval, M. C. | 2014 | [8] | Estudo empírico sobre a **Teoria da Depleção do Ego** e seu impacto no aumento do desconto temporal. |
| 9 | Construal-Level Theory of Psychological Distance | Trope, Y., & Liberman, N. | 2010 | [9] | Explica o desconto temporal pela **distância psicológica** e o **nível de construção** (abstrato vs. concreto). |
| 10 | The Psychology of Intertemporal Preferences | Urminsky, O., & Zauberman, G. | 2015 | [10] | Revisão psicológica; discute o papel da **Previsão Afetiva** e seus erros no viés do presente. |
| 11 | Implementation Intentions: Strong Effects of Simple Plans on the Pursuit of Goals | Gollwitzer, P. M. | 1999 | [11] | Introdução das **Intenções de Implementação** como metodologia prática para automatizar a ação e superar o "gap de implementação". |
| 12 | Temporal Self-Regulation Theory: A Model for Individual Health Behavior | Hall, P. A., & Fong, G. T. | 2007 | [12] | Framework da **Teoria da Autorregulação Temporal (TST)**, integrando preferência temporal e capacidade de autorregulação. |
| 13 | Motivational Interviewing: Preparing People for Change | Miller, W. R., & Rollnick, S. | 2002 | [13] | **Metodologia prática** de **coaching** (Entrevista Motivacional) para resolver a ambivalência e fortalecer a motivação intrínseca. |
| 14 | A Dual-Self Model of Impulse Control | Fudenberg, D., & Levine, D. K. | 2006 | [14] | Formalização do **Modelo Dual-Self** com autocontrole custoso e alternância entre "eus". |
| 15 | Psychological Connectedness and Intertemporal Choice | Bartels, D. M., & Rips, L. J. | 2010 | [15] | Introdução da **Conexão Psicológica** como fator que modera o desconto temporal (conexão com o "Eu Futuro"). |
| 16 | The Time Paradox: The New Psychology of Time That Will Change Your Life | Zimbardo, P., & Boyd, J. | 2008 | [16] | **Teoria da Perspectiva Temporal**; correlação entre **Presente Hedonista** e alto desconto temporal. |
| 17 | Social cognitive theory of self-regulation | Bandura, A. | 1991 | [17] | **Teoria Sociocognitiva da Autorregulação**; ênfase na **Autoeficácia** como mecanismo central de autocontrole. |
| 18 | Future self-continuity: How conceptions of the future self transform intertemporal choice | Hershfield, H. E., et al. | 2011 | [18] | Foca na **Continuidade do Eu Futuro** e como intervenções para aumentar a vividez do Eu Futuro podem reduzir o desconto temporal. |

## Referências

[1] Ericson, K. M., & Laibson, D. (2019). Intertemporal choice. *Handbook of Behavioral Economics: Applications and Foundations 1*, 2, 1–67. [https://doi.org/10.1016/bs.hesbe.2018.12.001](https://doi.org/10.1016/bs.hesbe.2018.12.001)

[2] Lempert, K. M., & Phelps, E. A. (2015). The malleability of intertemporal choice. *Trends in Cognitive Sciences*, 20(1), 64–74. [https://pmc.ncbi.nlm.nih.gov/articles/PMC4698025/](https://pmc.ncbi.nlm.nih.gov/articles/PMC4698025/)

[3] Frederick, S., Loewenstein, G., & O'Donoghue, T. (2002). Time Discounting and Time Preference: A Critical Review. *Journal of Economic Literature*, 40(2), 351–401. [https://www.aeaweb.org/articles?id=10.1257/002205102320161311](https://www.aeaweb.org/articles?id=10.1257/002205102320161311)

[4] Thaler, R. H., & Shefrin, H. M. (1981). An Economic Theory of Self-Control. *Journal of Political Economy*, 89(2), 392–406. (Fonte conceitual)

[5] Benartzi, S. H., & Thaler, R. H. (2004). Commitment devices under self-control problems: An overview. (Conceito amplamente discutido)

[6] Ainslie, G. (1992). *Picoeconomics: The Strategic Interaction of Successive Motivational States within the Person*. Cambridge University Press. (Livro, conceito central em picoeconomics.org)

[7] Levens, S. M., Sagui-Henson, S. J., Padro, M., et al. (2019). The effects of positive affect and episodic future thinking on temporal discounting and healthy food demand and choice among overweight and obese adults: a randomized controlled trial protocol. *JMIR Research Protocols*, 8(3), e12265. [https://www.researchprotocols.org/2019/3/e12265](https://www.researchprotocols.org/2019/3/e12265)

[8] Kuhn, M., Kuhn, P., & Villeval, M. C. (2014). Self control and intertemporal choice: Evidence from glucose and depletion interventions. *SSRN Electronic Journal*. [https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2398279](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2398279)

[9] Trope, Y., & Liberman, N. (2010). Construal-Level Theory of Psychological Distance. *Psychological Review*, 117(2), 440–463. (Conceito central em psicologia social)

[10] Urminsky, O., & Zauberman, G. (2015). The Psychology of Intertemporal Preferences. *The Wiley Blackwell Handbook of Judgment and Decision Making*, 107–134. [https://onlinelibrary.wiley.com/doi/abs/10.1002/9781118468333.ch5](https://onlinelibrary.wiley.com/doi/abs/10.1002/9781118468333.ch5)

[11] Gollwitzer, P. M. (1999). Implementation Intentions: Strong Effects of Simple Plans on the Pursuit of Goals. *Journal of Personality and Social Psychology*, 76(2), 249–268. (Artigo seminal em psicologia da motivação)

[12] Hall, P. A., & Fong, G. T. (2007). Temporal Self-Regulation Theory: A Model for Individual Health Behavior. *Health Psychology Review*, 1(1), 6–52. (Conceito central em psicologia da saúde)

[13] Miller, W. R., & Rollnick, S. (2002). *Motivational Interviewing: Preparing People for Change* (2nd ed.). Guilford Press. (Livro seminal)

[14] Fudenberg, D., & Levine, D. K. (2006). A Dual-Self Model of Impulse Control. *American Economic Review*, 96(5), 1449–1476. (Artigo seminal em economia comportamental)

[15] Bartels, D. M., & Rips, L. J. (2010). Psychological Connectedness and Intertemporal Choice. *Journal of Experimental Psychology: General*, 139(1), 49–69. [https://psycnet.apa.org/record/2010-01266-008](https://psycnet.apa.org/record/2010-01266-008)

[16] Zimbardo, P., & Boyd, J. (2008). *The Time Paradox: The New Psychology of Time That Will Change Your Life*. Free Press. (Livro, conceito central em psicologia social)

[17] Bandura, A. (1991). Social cognitive theory of self-regulation. *Organizational Behavior and Human Decision Processes*, 50(2), 248–287. [https://www.sciencedirect.com/science/article/pii/074959789190022L](https://www.sciencedirect.com/science/article/pii/074959789190022L)

[18] Hershfield, H. E., Bartels, D. M., Reiff, L. D., et al. (2011). Future self-continuity: How conceptions of the future self transform intertemporal choice. *Annals of the New York Academy of Sciences*, 1235(1), 30–43. [https://nyaspubs.onlinelibrary.wiley.com/doi/abs/10.1111/j.1749-6632.2011.06201.x](https://nyaspubs.onlinelibrary.wiley.com/doi/abs/10.1111/j.1749-6632.2011.06201.x)

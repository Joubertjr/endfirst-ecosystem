# A Teoria da Autodeterminação: Frameworks Conceituais e o Continuum Motivacional

A **Teoria da Autodeterminação (SDT - Self-Determination Theory)**, desenvolvida por Edward L. Deci e Richard M. Ryan, constitui um dos mais influentes *frameworks* macro-teóricos na psicologia da motivação e personalidade [1] [2]. Sua premissa central é que a motivação humana não é um construto monolítico, mas sim um *continuum* que reflete o grau em que o comportamento é autodeterminado e autônomo [3]. A SDT transcende a dicotomia simplista entre motivação intrínseca e extrínseca, propondo uma taxonomia detalhada que varia desde a **amotivação** (ausência de intenção de agir) até a **motivação intrínseca** (ação realizada pelo prazer e satisfação inerentes à própria atividade) [4].

## O Núcleo Conceitual: Necessidades Psicológicas Básicas

O cerne da SDT reside na postulação de três **Necessidades Psicológicas Básicas (NPBs)** inatas e universais, cuja satisfação é essencial para o crescimento psicológico, a integridade e o bem-estar em todas as culturas [5]:

1.  **Autonomia**: A necessidade de experimentar o comportamento como sendo de escolha própria, com um senso de volição e de ser a origem das próprias ações [1].
2.  **Competência**: A necessidade de sentir-se eficaz na interação com o ambiente, expressando e aprimorando as próprias capacidades [1].
3.  **Relacionamento (ou Vínculo)**: A necessidade de sentir-se conectado, cuidado e pertencente a um grupo social significativo [1].

A satisfação dessas NPBs é o mecanismo fundamental pelo qual o contexto social influencia a motivação e o desenvolvimento [6].

## Frameworks Teóricos: As Mini-Teorias da SDT

A SDT é um sistema teórico abrangente, composto por seis mini-teorias que detalham diferentes aspectos da motivação e do desenvolvimento [7]:

| Mini-Teoria | Foco Principal | Contribuição Teórica |
| :--- | :--- | :--- |
| **Teoria da Avaliação Cognitiva (CET)** | Motivação Intrínseca | Explica como eventos externos (recompensas, *feedback*, controles) afetam a motivação intrínseca, postulando que eventos percebidos como controladores minam a autonomia, enquanto eventos percebidos como informativos sobre a competência a fortalecem [4] [8]. |
| **Teoria da Integração Organísmica (OIT)** | Motivação Extrínseca e Internalização | Detalha o *continuum* da motivação extrínseca, que inclui a **Regulação Externa** (menos autônoma), **Regulação Introjetada**, **Regulação Identificada** e **Regulação Integrada** (mais autônoma), descrevendo o processo de internalização de valores e regulamentos [4]. |
| **Teoria das Orientações de Causalidade (COT)** | Diferenças Individuais na Motivação | Descreve as orientações motivacionais estáveis de um indivíduo em relação ao ambiente: **Autônoma** (orientada pela satisfação das NPBs), **Controlada** (orientada por recompensas e pressões) e **Impessoal** (Amotivação) [7]. |
| **Teoria das Necessidades Psicológicas Básicas (BPNT)** | Bem-Estar e Funcionamento Ótimo | Postula que a satisfação das NPBs é um preditor universal do bem-estar psicológico e da saúde mental, enquanto a frustração dessas necessidades leva à patologia e ao mal-estar [5]. |
| **Teoria dos Conteúdos de Metas (GCT)** | Conteúdo das Metas e Bem-Estar | Distingue entre metas **Intrínsecas** (ex: crescimento pessoal, afiliação) e **Extrínsecas** (ex: riqueza, fama), demonstrando que a busca e o alcance de metas intrínsecas estão associados a um maior bem-estar e funcionamento [9]. |
| **Teoria das Relações em Microssistemas (RMT)** | Relações Interpessoais e Suporte | Examina como as relações interpessoais em contextos específicos (ex: pais, professores, *coaches*) podem apoiar ou frustrar as NPBs, influenciando a motivação e o engajamento [7]. |

## Metodologias Práticas e Estruturas Humanas

Embora a SDT seja primariamente um *framework* teórico, ela informa diretamente metodologias práticas não-tecnológicas em diversas áreas, com foco na criação de ambientes que suportam a autonomia. O principal modelo prático derivado é o **Estilo de Suporte à Autonomia** (*Autonomy-Supportive Style*), aplicado em contextos como *coaching*, educação e gestão [10] [11].

As práticas de suporte à autonomia envolvem:

*   **Assumir a Perspectiva do Indivíduo:** Esforçar-se para entender os sentimentos e o ponto de vista do outro.
*   **Oferecer Escolhas e Racionalidades:** Fornecer opções e justificar o porquê de uma tarefa ou regra, em vez de impor o controle [12].
*   **Fornecer *Feedback* Informativo:** Oferecer *feedback* que promova a competência, evitando críticas controladoras ou recompensas que minem a autonomia [8].
*   **Reconhecer Sentimentos:** Validar as dificuldades e emoções do indivíduo, demonstrando empatia [10].

Em estruturas humanas como o *coaching*, a aplicação da SDT tem demonstrado promover mudanças comportamentais mais duradouras e autônomas, focando na satisfação das NPBs do cliente [10] [13].

## Fontes Acadêmicas e Contribuições Teóricas

| Título | Autor(es) | Ano | URL | Contribuições Teóricas Principais |
| :--- | :--- | :--- | :--- | :--- |
| Self-Determination Theory and the Facilitation of Intrinsic Motivation, Social Development, and Well-Being | Ryan, R. M. & Deci, E. L. | 2000 | https://selfdeterminationtheory.org/SDT/documents/2000_RyanDeci_SDT.pdf | Artigo seminal que apresenta a SDT como uma metateoria organísmica e dialética, introduzindo as três NPBs e o *continuum* motivacional [1]. |
| Intrinsic and Extrinsic Motivations: Classic Definitions and New Directions | Ryan, R. M. & Deci, E. L. | 2000 | https://www.selfdeterminationtheory.org/SDT/documents/2000_RyanDeci_IntExtDefs.pdf | Define formalmente a motivação intrínseca e extrínseca, e detalha a Teoria da Integração Organísmica (OIT) com seus quatro tipos de regulação extrínseca [4]. |
| Self-Determination Theory: Basic Psychological Needs in Motivation, Development, and Wellness | Ryan, R. M. & Deci, E. L. | 2017 | Livro (Guilford Press) | A obra mais completa, revisando e integrando todas as mini-teorias da SDT e suas aplicações em diversos domínios [5]. |
| Intrinsic and extrinsic motivation from a self-determination theory perspective: Definitions, theory, practices, and future directions | Ryan, R. M. & Deci, E. L. | 2020 | https://www.sciencedirect.com/science/article/pii/S0361476X20300254 | Revisão atualizada focada na distinção entre motivação intrínseca e formas autônomas de motivação extrínseca (internalizada) [3]. |
| A meta-analysis of self-determination theory-informed intervention studies in the health domain: effects on motivation, health behavior, physical, and psychological outcomes | Ntoumanis, N. et al. | 2021 | https://www.tandfonline.com/doi/full/10.1080/17437199.2020.1718529 | Meta-análise que fornece evidências empíricas da eficácia de intervenções baseadas na SDT, especialmente no domínio da saúde [14]. |
| The Emerging Neuroscience of Intrinsic Motivation: A New Frontier in Self-Determination Research | Di Domenico, S. I. & Ryan, R. M. | 2017 | https://pmc.ncbi.nlm.nih.gov/articles/PMC5364176/ | Conecta a SDT com a neurociência, identificando os correlatos neurais da motivação intrínseca e do suporte à autonomia [15]. |
| Intrinsic versus extrinsic goal contents in self-determination theory: Another look at the quality of academic motivation | Vansteenkiste, M. et al. | 2006 | Artigo (Educational Psychologist) | Aplica a Teoria dos Conteúdos de Metas (GCT) no contexto acadêmico, diferenciando metas intrínsecas e extrínsecas e seu impacto na aprendizagem [9]. |
| Deci and Ryan's self-determination theory: A view from the hierarchical model of intrinsic and extrinsic motivation | Vallerand, R. J. | 2000 | Artigo (Psychological Inquiry) | Propõe o Modelo Hierárquico de Motivação, integrando a SDT em três níveis (Global, Contextual e Situacional) e detalhando a influência do contexto social [16]. |
| Coaching with self-determination theory in mind: Using theory to advance evidence-based coaching practice | Spence, G. B. & Oades, L. G. | 2011 | Artigo (The Coaching Psychologist) | Demonstra a aplicação prática da SDT no *coaching*, focando em como o *coach* pode satisfazer as NPBs do cliente para promover mudanças autônomas e duradouras [10]. |
| Self-determination theory: A case study of evidence-based coaching | Mallett, C. J. | 2005 | Artigo (The Sport Psychologist) | Estudo de caso que utiliza a SDT como estrutura conceitual para criar um clima motivacional de suporte à autonomia no esporte de alto rendimento [13]. |
| Methodological Overview of A Self-Determination Theory Approach to Studying Motivation and Development | Patrick, H. & Williams, G. C. | 2011 | https://pmc.ncbi.nlm.nih.gov/articles/PMC2900852/ | Oferece uma visão metodológica para pesquisadores que desejam aplicar a SDT, focando na medição das NPBs e dos tipos de motivação [17]. |
| Cognitive evaluation theory: The seedling that keeps self-determination theory growing | Reeve, J. | 2023 | Capítulo de Livro (Oxford Handbook of SDT) | Revisa a CET, a primeira mini-teoria, e seu papel central no desenvolvimento da SDT, explicando o efeito *undermining* (minador) das recompensas [8]. |
| Organismic integration theory: A theory of regulatory styles, internalization, integration, and human functioning in society | Pelletier, L. G. et al. | 2023 | Capítulo de Livro (Oxford Handbook of SDT) | Detalha a OIT, o processo de internalização e a importância da regulação integrada para o funcionamento social e o bem-estar [18]. |
| The role of self-determination theory and cognitive evaluation theory in home education | Riley, G. | 2016 | https://www.tandfonline.com/doi/full/10.1080/2331186X.2016.1163651 | Aplicação da SDT e CET no contexto da educação domiciliar, enfatizando a importância da autonomia e competência para a aprendizagem [12]. |
| We know this much is (meta-analytically) true: A meta-review of meta-analytic findings evaluating self-determination theory | Ryan, R. M. et al. | 2022 | Artigo (APA PsycNet) | Uma meta-revisão que consolida as evidências de múltiplas meta-análises, confirmando a robustez da SDT em diversos domínios [19]. |
| Self-determination theory within coaching contexts: Supporting motives and goals that promote optimal functioning and well-being | Spence, G. B. & Deci, E. L. | 2016 | Capítulo de Livro (Beyond Goals) | Expande a aplicação da SDT no *coaching*, ligando o suporte à autonomia com a promoção de metas intrínsecas e o bem-estar [11]. |
| A Teoria da Autodeterminação: Relações e Motivações | Pedersini, D. R. | Ano Indefinido | https://congressousp.fipecafi.org/anais/19UspInternational/ArtigosDownload/1746.pdf | Artigo em português que aplica a SDT para entender as variações do comportamento humano a partir da motivação, útil para o contexto brasileiro [20]. |
| O estilo motivacional do professor e a motivação intrínseca dos estudantes: uma perspectiva da teoria da autodeterminação | Scielo (sem autor principal claro no snippet) | Ano Indefinido | https://www.scielo.br/j/prc/a/DwSBb6xK4RknMzkf5qqpZ6Q/ | Artigo em português que foca na aplicação da SDT no contexto educacional, analisando o papel do professor [21]. |

## Referências

[1] Ryan, R. M. & Deci, E. L. (2000). Self-Determination Theory and the Facilitation of Intrinsic Motivation, Social Development, and Well-Being. *American Psychologist*, 55(1), 68-78. URL: https://selfdeterminationtheory.org/SDT/documents/2000_RyanDeci_SDT.pdf

[2] Ryan, R. M. & Deci, E. L. (2000). Intrinsic and Extrinsic Motivations: Classic Definitions and New Directions. *Contemporary Educational Psychology*, 25(1), 54-67. URL: https://www.selfdeterminationtheory.org/SDT/documents/2000_RyanDeci_IntExtDefs.pdf

[3] Ryan, R. M. & Deci, E. L. (2020). Intrinsic and extrinsic motivation from a self-determination theory perspective: Definitions, theory, practices, and future directions. *Contemporary Educational Psychology*, 61, 101860. URL: https://www.sciencedirect.com/science/article/pii/S0361476X20300254

[4] Ryan, R. M. & Deci, E. L. (2000). Intrinsic and Extrinsic Motivations: Classic Definitions and New Directions. *Contemporary Educational Psychology*, 25(1), 54-67. URL: https://www.selfdeterminationtheory.org/SDT/documents/2000_RyanDeci_IntExtDefs.pdf

[5] Ryan, R. M. & Deci, E. L. (2017). *Self-Determination Theory: Basic Psychological Needs in Motivation, Development, and Wellness*. Guilford Press.

[6] Patrick, H. & Williams, G. C. (2011). Methodological Overview of A Self-Determination Theory Approach to Studying Motivation and Development. *Advances in Experimental Social Psychology*, 44, 209-271. URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC2900852/

[7] Self-Determination Theory. (n.d.). *Formal Theory: SDT's Five Mini-Theories*. Retrieved from https://selfdeterminationtheory.org/formal-theory-sdts-five-mini-theories/

[8] Reeve, J. (2023). Cognitive evaluation theory: The seedling that keeps self-determination theory growing. In E. L. Deci & R. M. Ryan (Eds.), *The Oxford Handbook of Self-Determination Theory*. Oxford University Press.

[9] Vansteenkiste, M., Lens, W., & Deci, E. L. (2006). Intrinsic versus extrinsic goal contents in self-determination theory: Another look at the quality of academic motivation. *Educational Psychologist*, 41(1), 19-31.

[10] Spence, G. B. & Oades, L. G. (2011). Coaching with self-determination theory in mind: Using theory to advance evidence-based coaching practice. *The Coaching Psychologist*, 7(1), 10-18.

[11] Spence, G. B. & Deci, E. L. (2016). Self-determination theory within coaching contexts: Supporting motives and goals that promote optimal functioning and well-being. In A. M. Grant & S. A. David (Eds.), *Beyond Goals: Effective Strategies for Coaching and Mentoring*. Oxford University Press.

[12] Riley, G. (2016). The role of self-determination theory and cognitive evaluation theory in home education. *Cogent Education*, 3(1). URL: https://www.tandfonline.com/doi/full/10.1080/2331186X.2016.1163651

[13] Mallett, C. J. (2005). Self-determination theory: A case study of evidence-based coaching. *The Sport Psychologist*, 19(4), 417-429.

[14] Ntoumanis, N., Ng, J. Y. Y., Prestwich, A., Quested, E., Hancox, J. E., Thøgersen-Ntoumani, C., ... & Williams, G. C. (2021). A meta-analysis of self-determination theory-informed intervention studies in the health domain: effects on motivation, health behavior, physical, and psychological outcomes. *Health Psychology Review*, 15(2), 215-244. URL: https://www.tandfonline.com/doi/full/10.1080/17437199.2020.1718529

[15] Di Domenico, S. I. & Ryan, R. M. (2017). The Emerging Neuroscience of Intrinsic Motivation: A New Frontier in Self-Determination Research. *Frontiers in Human Neuroscience*, 11, 145. URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC5364176/

[16] Vallerand, R. J. (2000). Deci and Ryan's self-determination theory: A view from the hierarchical model of intrinsic and extrinsic motivation. *Psychological Inquiry*, 11(4), 312-318.

[17] Patrick, H. & Williams, G. C. (2011). Methodological Overview of A Self-Determination Theory Approach to Studying Motivation and Development. *Advances in Experimental Social Psychology*, 44, 209-271. URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC2900852/

[18] Pelletier, L. G., Tuson, K. M., & Fortier, M. S. (2023). Organismic integration theory: A theory of regulatory styles, internalization, integration, and human functioning in society. In E. L. Deci & R. M. Ryan (Eds.), *The Oxford Handbook of Self-Determination Theory*. Oxford University Press.

[19] Ryan, R. M., Duineveld, J. J., Di Domenico, S. I., & Deci, E. L. (2022). We know this much is (meta-analytically) true: A meta-review of meta-analytic findings evaluating self-determination theory. *Psychological Bulletin*, 148(11-12), 859–882.

[20] Pedersini, D. R. (Ano Indefinido). A Teoria da Autodeterminação: Relações e Motivações. *Anais do Congresso USP de Iniciação Científica em Contabilidade*. URL: https://congressousp.fipecafi.org/anais/19UspInternational/ArtigosDownload/1746.pdf

[21] Scielo. (Ano Indefinido). O estilo motivacional do professor e a motivação intrínseca dos estudantes: uma perspectiva da teoria da autodeterminação. *Psicologia: Reflexão e Crítica*. URL: https://www.scielo.br/j/prc/a/DwSBb6xK4RknMzkf5qqpZ6Q/

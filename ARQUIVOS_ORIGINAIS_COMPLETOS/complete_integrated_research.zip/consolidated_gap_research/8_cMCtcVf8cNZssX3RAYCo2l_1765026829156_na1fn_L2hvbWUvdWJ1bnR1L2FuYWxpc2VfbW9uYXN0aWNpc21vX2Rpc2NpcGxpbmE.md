# Análise Detalhada: Monges e Sistemas Monásticos como Estruturas de Disciplina

## Área Temática
A área temática pesquisada é a **Análise Sociológica e Psicológica de Estruturas Institucionais de Disciplina Não-Tecnológica**, com foco em **Sistemas Monásticos** e suas implicações para a **Teoria da Falha de Implementação**. O estudo se concentra em conceitos teóricos, *frameworks* e metodologias das ciências sociais (Sociologia, Psicologia, Antropologia) para entender como a disciplina é construída, mantida e como as falhas surgem em sistemas sociais humanos.

## Fontes Acadêmicas Selecionadas (N=15)

A tabela a seguir documenta as 15 fontes acadêmicas selecionadas, com foco em suas contribuições teóricas para o tema.

| ID | Título, Autor(es), Ano | URL | Principais Contribuições Teóricas |
| :---: | :--- | :--- | :--- |
| 1 | **The monastic origins of discipline: From the rule to the norm?** (Agustín Colombo, 2021) | `https://journals.sagepub.com/doi/abs/10.1177/01914537211042607` | **Genealogia da Disciplina:** Releitura da obra de Michel Foucault, argumentando que as regras monásticas fornecem um "modelo ótimo" para a regulação da conduta humana, contribuindo para o desenvolvimento da **normalização disciplinar** na sociedade moderna. |
| 2 | **On ritual and discipline in medieval Christian monasticism** (Talal Asad, 1987) | `https://www.tandfonline.com/doi/pdf/10.1080/03085148700000002` | **Práticas Disciplinares e Formação do Sujeito:** Analisa os rituais monásticos como **práticas disciplinares** enraizadas em condições materiais específicas. Contrasta o monastério com as "instituições totais" de Goffman, focando na criação de uma **"vontade de obedecer"** (obediência como virtude/poder) através da disciplina, e não apenas pela força. |
| 3 | **Institutionalized Organizations: Formal Structure as Myth and Ceremony** (John W. Meyer & Brian Rowan, 1977) | `https://www.journals.uchicago.edu/doi/abs/10.1086/226550` | **Teoria Institucional e Falha de Implementação (Decoupling):** Introduz o conceito de **isomorfismo institucional** e **desacoplamento** (*decoupling*). As organizações (incluindo estruturas sociais como monastérios) adotam estruturas formais (regras) como **"mito e cerimônia"** para ganhar legitimidade, mesmo que essas estruturas sejam desconectadas das práticas reais, o que explica falhas de implementação. |
| 4 | **Work practices, normative control and ascetic...** (M Sundberg, 2019) | `https://www.tandfonline.com/doi/full/10.1080/14766086.2019.1641141` | **Controle Normativo e Ascetismo:** Estudo de caso qualitativo em monastérios cistercienses. Examina como o trabalho é organizado e vivenciado, destacando o papel do **controle normativo** e do **ascetismo** na manutenção da ordem e da disciplina, e as tensões inerentes a essas práticas. |
| 5 | **Asceticism of the Mind: Forms of Attention and Self-Transformation in Late Antique Monasticism** (Inbar Graiver, 2018/2020) | `https://brill.com/view/journals/scri/16/1/article-p405_1.xml` | **Psicologia Cognitiva da Disciplina:** Explora a intersecção entre a disciplina monástica (práticas espirituais) e a **psicologia cognitiva** (atenção, autocontrole). Analisa como o treinamento mental monástico visa a **autotransformação** e o domínio do "eu" através de técnicas de atenção e combate à distração. |
| 6 | **The politics of monastic life: opportunities for exit and voice...** (M Sundberg, 2020) | `https://www.cambridge.org/core/journals/european-journal-of-sociology-archives-europeennes-de-sociologie/article/politics-of-monastic-life-opportunities-for-exit-and-voice-in-a-voluntary-total-institution/47FC21ACBD6103954ACA7F49F48A5519` | **Instituição Total Voluntária:** Classifica o monastério como uma **instituição total voluntária**, aplicando os conceitos de **"saída e voz"** (Hirschman) para analisar as dinâmicas de poder, resistência e conformidade dentro da estrutura monástica. |
| 7 | **Monastic life in medieval Daoism: a cross-cultural perspective** (Livia Kohn) | `https://books.google.com/books?hl=en&lr=&id=hjFlH1XkH5cC&oi=fnd&pg=PR9&dq=cross-cultural+studies+monastic+discipline+asceticism&ots=VouWSFbNUJ&sig=S3rMkXKZfZqly85Ss9yUJlksJZ8` | **Estudo Cross-Cultural:** Comparação da disciplina e estrutura monástica no **Taoísmo Medieval** com o monasticismo ocidental. Destaca a **instabilidade inerente** dos fenômenos monásticos e a variação cultural nas práticas de disciplina e etiqueta. |
| 8 | **The Monastery Rules: Buddhist Monastic Organization in...** (B Jansen) | `https://library.oapen.org/bitstream/id/1b620f45-9e6e-42d1-a232-d0863e52cc82/the-monastery-rules.pdf` | **Organização Monástica Budista:** Análise da organização e das regras monásticas budistas (*Vinaya*), oferecendo um modelo institucional não-ocidental de disciplina e controle social, com foco na ausência de violência física como punição. |
| 9 | **An appraisal of psychological & religious perspectives of self-control** (ED Bland, 2008) | `https://link.springer.com/article/10.1007/s10943-007-9135-0` | **Perspectivas de Autocontrole:** Examina e compara os mecanismos de **autocontrole** sob as lentes da **psicologia** (autorregulação) e das **tradições religiosas** (disciplina monástica/espiritual), identificando pontos de convergência e divergência. |
| 10 | **Introduction: Failed! The Sociological Analysis of Failure** (F Barbera, 2023) | `https://sociologica.unibo.it/article/view/18960` | **Sociologia da Falha:** Propõe um **framework sociológico** para a análise da falha, que pode ser aplicado para entender por que as regras e estruturas disciplinares monásticas falham em sua implementação (e.g., desvios, cisões, escândalos). |
| 11 | **The collective body: Legacies of monastic discipline in the post-Soviet prison** (Sage) | `https://journals.sagepub.com/doi/abs/10.1177/1362480620930677` | **Legados da Disciplina:** Estudo sobre a aplicação e os legados da disciplina monástica em contextos institucionais modernos (prisão pós-soviética), demonstrando a persistência de modelos de controle social baseados em estruturas não-tecnológicas. |
| 12 | **A comparative study of asceticism across world religions** (Granthaalayah Publication) | `https://www.granthaalayahpublication.org/Arts-Journal/ShodhKosh/article/download/5679/5172/29993` | **Ascetismo Comparado:** Define e compara o **ascetismo** como uma escolha de estilo de vida deliberada, marcada pela **autodisciplina** e restrição, em diferentes religiões, estabelecendo o ascetismo como um conceito central na análise da disciplina monástica. |
| 13 | **The neglected organisation of failure: Activities, ...** (M Hájek) | `https://journals.sagepub.com/doi/10.1177/00016993251337231` | **Organização da Falha:** Analisa a **organização da falha** em projetos e estruturas, um conceito que se alinha com a falha de implementação em sistemas monásticos, onde a falha não é um evento, mas um processo socialmente organizado. |
| 14 | **The neurotic personality in the monastic life** (Thomas Merton) | `https://merton.org/itms/annual/4/Merton3-19.pdf` | **Psicologia da Vida Monástica:** Aborda a dimensão **psicológica** dos problemas na vida monástica, como a **ansiedade neurótica**, sugerindo que a falha na disciplina pode ter raízes em questões de saúde mental e personalidade, e não apenas em falhas estruturais. |
| 15 | **Monastic Discipline and Communal Rules for Buddhist Nuns...** (Falk & Kawanami) | `https://eprints.lancs.ac.uk/id/eprint/138058/1/Final_draft_Falk_and_Kawanami_revised_jrc_edit_pkp.pdf` | **Regras Comunitárias e Realidade Social:** Estudo sobre a realidade social das monjas budistas em Mianmar e Tailândia através das **regulações monásticas**, demonstrando a lacuna entre a regra formal e a prática social (falha de implementação em nível micro-institucional). |

## Conceitos-Chave e Frameworks

Os principais conceitos, teorias e *frameworks* identificados são:

*   **Disciplina e Normalização (Foucault):** A disciplina monástica como precursora das técnicas de poder e controle social que culminam na **sociedade disciplinar** moderna. O foco está na microfísica do poder e na produção de corpos dóceis e úteis.
*   **Práticas Disciplinares e Formação do Sujeito (Asad):** A disciplina como um conjunto de **práticas rituais** que visam a **formação do "eu"** e a criação de uma disposição moral (a "vontade de obedecer"), diferenciando-se da mera coerção ou controle de instituições totais.
*   **Teoria Institucional (Meyer & Rowan):** O conceito de **isomorfismo institucional** (a tendência das organizações a se assemelharem para ganhar legitimidade) e o **desacoplamento** (*decoupling*), onde a estrutura formal (a regra monástica) se torna um **"mito e cerimônia"** desconectado da prática real, sendo uma causa fundamental da **falha de implementação** em estruturas sociais.
*   **Ascetismo e Autocontrole:** O **ascetismo** como o princípio fundamental da disciplina monástica, envolvendo a restrição voluntária e a **autodisciplina**. A análise psicológica foca em como essas práticas se relacionam com a **autorregulação** e o treinamento da atenção.
*   **Instituição Total Voluntária (Sundberg):** A aplicação do conceito de **instituição total** (Goffman) ao monastério, mas com a nuance da **voluntariedade**, permitindo a análise das dinâmicas de **"saída e voz"** (Hirschman) como mecanismos de resistência e falha interna.
*   **Sociologia da Falha:** O desenvolvimento de *frameworks* para analisar a falha não como um evento isolado, mas como um processo socialmente organizado e estruturalmente induzido em instituições.

## Cobertura Geográfica
As regiões geográficas cobertas pelas fontes incluem:

*   **Europa Ocidental:** Monasticismo Cristão Medieval (Cistercienses, Regras Monásticas), Teoria Social Europeia (Foucault, Asad).
*   **América do Norte:** Teoria Organizacional e Institucional (Meyer & Rowan).
*   **Ásia:** Monasticismo Budista (Mianmar, Tailândia), Monasticismo Taoísta Medieval (China).
*   **Múltiplas Culturas/Global:** Estudos cross-culturais de ascetismo e autocontrole.

## Estrutura do Arquivo de Resumo
O arquivo de resumo (`/home/ubuntu/analise_monasticismo_disciplina.md`) contém esta análise detalhada, incluindo a área temática, as 15 fontes documentadas, os conceitos-chave e a cobertura geográfica.

## Referências

[1] Colombo, A. (2021). The monastic origins of discipline: From the rule to the norm?. *Philosophy & Social Criticism*, 47(8), 957-975.
[2] Asad, T. (1987). On ritual and discipline in medieval Christian monasticism. *Economy and Society*, 16(2), 159-203.
[3] Meyer, J. W., & Rowan, B. (1977). Institutionalized Organizations: Formal Structure as Myth and Ceremony. *American Journal of Sociology*, 83(2), 340-363.
[4] Sundberg, M. (2019). Work practices, normative control and ascetic... *Culture and Organization*, 25(5), 373-390.
[5] Graiver, I. (2018/2020). Asceticism of the Mind: Forms of Attention and Self-Transformation in Late Antique Monasticism. *Scrinium*, 16(1), 405-408.
[6] Sundberg, M. (2020). The politics of monastic life: opportunities for exit and voice in a voluntary total institution. *European Journal of Sociology/Archives Européennes de Sociologie*, 61(1), 1-32.
[7] Kohn, L. (n.d.). Monastic life in medieval Daoism: a cross-cultural perspective. *University of Hawai'i Press*.
[8] Jansen, B. (n.d.). The Monastery Rules: Buddhist Monastic Organization in... *OAPEN*.
[9] Bland, E. D. (2008). An appraisal of psychological & religious perspectives of self-control. *Journal of Religion and Health*, 47, 399-411.
[10] Barbera, F. (2023). Introduction: Failed! The Sociological Analysis of Failure. *Sociologica*, 17(1), 1-14.
[11] Sage. (n.d.). The collective body: Legacies of monastic discipline in the post-Soviet prison. *Sage Journals*.
[12] Granthaalayah Publication. (n.d.). A comparative study of asceticism across world religions. *Granthaalayah Publication*.
[13] Hájek, M. (n.d.). The neglected organisation of failure: Activities, ... *Sage Journals*.
[14] Merton, T. (n.d.). The neurotic personality in the monastic life. *The Merton Institute for Contemplative Living*.
[15] Falk, M., & Kawanami, H. (n.d.). Monastic Discipline and Communal Rules for Buddhist Nuns... *Eprints, Lancaster University*.

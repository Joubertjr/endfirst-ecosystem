# Resumo da Pesquisa: Habit Loops e Gânglios da Base

## 1. Introdução

A pesquisa sobre **habit loops** (circuitos de hábito) e o papel dos **gânglios da base** (basal ganglia) representa uma área de convergência crítica entre a **neurociência fundamental**, a **economia comportamental avançada** e o **pensamento sistêmico**. O hábito é definido como um comportamento aprendido que, com a repetição, se torna automático, inflexível e, crucialmente, **insensível à desvalorização do resultado** (outcome devaluation) [1, 4, 14]. Essa insensibilidade é o marco que distingue o hábito da ação orientada a objetivos (goal-directed action), que é flexível e depende da avaliação contínua do valor do resultado [4, 14].

O objetivo desta análise é sintetizar os conceitos teóricos, frameworks e metodologias que fundamentam essa área de estudo, com foco nos fundamentos neurocientíficos, nas teorias de sistemas duais e nos modelos computacionais avançados.

## 2. Fundamentos Neurocientíficos: A Dissociação Funcional dos Gânglios da Base

Os gânglios da base, um conjunto de núcleos subcorticais, são o substrato neural central para a formação e expressão do hábito [1, 6, 15]. A teoria dominante postula uma **dissociação funcional** dentro do **estriado** (a principal porta de entrada dos gânglios da base), que é crucial para a transição do controle de ação orientado a objetivos para o habitual [4, 8, 11].

*   **Estriado Dorsomedial (DMS):** Associado ao **controle orientado a objetivos** (goal-directed control). Esta região, que recebe projeções do córtex pré-frontal, é sensível à contingência entre a ação e o resultado, e à avaliação do valor desse resultado [4, 11].
*   **Estriado Dorsolateral (DLS) / Putâmen:** Associado ao **comportamento habitual** (habitual behavior). Com o treinamento estendido, o controle da ação migra para o DLS/Putâmen, que passa a mediar as associações diretas **Estímulo-Resposta (S-R)**, tornando o comportamento rígido e independente do valor do resultado [4, 8, 11, 13].

Essa transição é mediada pela **plasticidade dependente da experiência** nos circuitos córtico-estriatais [6, 15]. O processo de habituação não implica a eliminação do sistema orientado a objetivos, mas sim uma **competição** ou **arbitragem** entre os dois sistemas [3, 13].

## 3. Economia Comportamental e Modelos de Sistemas Duais

A economia comportamental e a neuroeconomia adotaram e expandiram o conceito de sistemas duais (dual-system theory) para explicar a tomada de decisão, incluindo a formação de hábito [7, 9].

*   **Teoria de Sistemas Duais (Dual-System Theory):** Distingue entre um **Sistema 1** (rápido, automático, intuitivo, habitual) e um **Sistema 2** (lento, deliberativo, racional, orientado a objetivos) [1, 3]. O hábito, como um comportamento do Sistema 1, é frequentemente a causa de comportamentos econômicos **irracionais** ou subótimos, pois persiste mesmo quando o resultado não é mais vantajoso [7].
*   **Framework de Aprendizado por Reforço (RL):** A neurociência computacional formaliza essa dicotomia através do RL [10, 14].
    *   **RL Baseado em Modelo (Model-Based RL):** Corresponde à ação orientada a objetivos. Envolve a construção de um **mapa cognitivo** (modelo) do ambiente para prever os resultados de diferentes ações, exigindo alto **esforço cognitivo** [10, 13].
    *   **RL Livre de Modelo (Model-Free RL):** Corresponde ao comportamento habitual. Baseia-se no **erro de previsão de recompensa** (Reward Prediction Error - RPE) para atualizar o valor de uma ação em um determinado estado, sem a necessidade de um modelo do ambiente. É rápido e eficiente, mas inflexível [10, 14].
*   **Modelo Neuroeconômico "Neural Autopilot":** Este modelo propõe que o hábito serve como um **"piloto automático"** que economiza esforço cognitivo ao repetir escolhas confiavelmente recompensadoras [9]. Ele introduz a ideia de que o hábito, embora insensível à desvalorização da recompensa, pode ser **sensível ao contexto** (context-sensitivity), o que é crucial para a aplicação em dados de campo e a análise de elasticidade econômica [9].

## 4. Pensamento Sistêmico e Modelos Conceituais Avançados

O estudo do hábito exige uma abordagem de **pensamento sistêmico**, reconhecendo a interação complexa e hierárquica entre múltiplos circuitos neurais e processos cognitivos [5, 15].

*   **Modelo de Arbitragem (Arbitration Model):** Propõe que o cérebro possui um mecanismo para **arbitrar** (decidir) qual sistema (orientado a objetivos ou habitual) deve controlar o comportamento em um dado momento [13]. Essa decisão é baseada em métricas como a **incerteza** e a **variância** da recompensa de cada sistema, garantindo que o sistema mais confiável e eficiente seja ativado [13].
*   **Chunking de Ações (Action Chunking):** Os gânglios da base, especialmente o estriado, são essenciais para o **agrupamento de sequências de ações** (chunking) em unidades de comportamento mais eficientes e automáticas [12]. O *chunking* é um mecanismo chave para a eficiência do hábito, pois permite que o cérebro execute sequências complexas com menos esforço cognitivo, liberando recursos para outras tarefas [12]. O **bracketing** (marcação do início e fim da sequência) é um sinal neural desse processo [12].
*   **Loops Hierárquicos Córtico-Gânglios da Base:** Modelos avançados sugerem que os loops córtico-gânglios da base não são apenas paralelos, mas também **hierárquicos**, com cada loop selecionando objetivos em diferentes níveis de abstração, do mais abstrato (estriado ventral) ao mais motor (putâmen) [5]. O hábito emerge como um **atalho** (shortcut) que se desenvolve ao longo desses loops hierárquicos [5].

## 5. Fontes Acadêmicas Compiladas (Total: 15)

| # | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| 1 | A critical review of habit learning and the basal ganglia | Seger, C. A., & Spiering, B. J. | 2011 | [Link](https://www.frontiersin.org/journals/systems-neuroscience/articles/10.3389/fnsys.2011.00066/full) |
| 2 | Cortical and basal ganglia contributions to habit learning and automaticity | Ashby, F. G., Turner, B. O., & Horvitz, J. C. | 2010 | [Link](https://www.sciencedirect.com/science/article/abs/pii/S1364661310000306) |
| 3 | Control of Behaviour by Competing Learning Systems | de Wit, S. | 2017 | [Link](https://onlinelibrary.wiley.com/doi/10.1002/9781118920497.ch11) |
| 4 | The role of the basal ganglia in habit formation | Yin, H. H., & Knowlton, B. J. | 2006 | [Link](https://www.nature.com/articles/nrn1919) |
| 5 | Habit learning in hierarchical cortex–basal ganglia loops | Baladron, J., & Hamker, F. H. | 2020 | [Link](https://onlinelibrary.wiley.com/doi/10.1111/ejn.14730) |
| 6 | Habits, Rituals, and the Evaluative Brain | Graybiel, A. M. | 2008 | [Link](https://www.annualreviews.org/content/journals/10.1146/annurev.neuro.29.051605.112851) |
| 7 | The striatum's role in executing rational and irrational economic behaviors | Bamford, I. J., & Bamford, N. S. | 2019 | [Link](https://journals.sagepub.com/doi/abs/10.1177/1073858418824256) |
| 8 | Subregional specificity in human striatal habit learning: a meta-analytic review of the fMRI literature | Patterson, T. K., et al. | 2018 | [Link](https://www.sciencedirect.com/science/article/pii/S2352154617301195) |
| 9 | Neural autopilot and context-sensitivity of habits | Camerer, C. F., & Li, X. | 2021 | [Link](https://www.sciencedirect.com/science/article/abs/pii/S2352154621001406) |
| 10 | Goal-oriented and habitual decisions: Neural signatures of model-based and model-free learning | Huang, Y., Yaple, Z. A., & Yu, R. | 2020 | [Link](https://www.sciencedirect.com/science/article/pii/S1053811920303219) |
| 11 | Integrating cortico-limbic-basal ganglia architectures for learning model-based and model-free navigation strategies | Khamassi, M., & Humphries, M. D. | 2012 | [Link](https://www.frontiersin.org/journals/behavioral-neuroscience/articles/10.3389/fnbeh.2012.00079/full) |
| 12 | The striatum: where skills and habits meet | Graybiel, A. M., & Grafton, S. T. | 2015 | [Link](https://cshperspectives.cshlp.org/content/7/8/a021691.short) |
| 13 | Neural computations underlying arbitration between model-based and model-free learning | Lee, S. W., Shimojo, S., & O'Doherty, J. P. | 2014 | [Link](https://www.cell.com/neuron/fulltext/S0896-6273(13)01125-2) |
| 14 | Do model-based and model-free reinforcement learning correspond to goal-directed and habitual actions, respectively? A systematic review. | Yee, X. | 2024 | [Link](https://files.osf.io/v1/resources/qm3gp/providers/osfstorage/65982b559513848a9d23866c?format=pdf&action=download&direct&version=1) |
| 15 | Neurobiology of habit formation | Amaya, K. A., & Smith, K. S. | 2018 | [Link](https://www.sciencedirect.com/science/article/abs/pii/S235215461730089X) |

## 6. Referências

[1] Seger, C. A., & Spiering, B. J. (2011). A critical review of habit learning and the basal ganglia. *Frontiers in Systems Neuroscience*.
[2] Ashby, F. G., Turner, B. O., & Horvitz, J. C. (2010). Cortical and basal ganglia contributions to habit learning and automaticity. *Trends in Cognitive Sciences*.
[3] de Wit, S. (2017). Control of Behaviour by Competing Learning Systems. In *The Wiley Handbook on the Cognitive Neuroscience of Addiction*.
[4] Yin, H. H., & Knowlton, B. J. (2006). The role of the basal ganglia in habit formation. *Nature Reviews Neuroscience*.
[5] Baladron, J., & Hamker, F. H. (2020). Habit learning in hierarchical cortex–basal ganglia loops. *The European Journal of Neuroscience*.
[6] Graybiel, A. M. (2008). Habits, Rituals, and the Evaluative Brain. *Annual Review of Neuroscience*.
[7] Bamford, I. J., & Bamford, N. S. (2019). The striatum's role in executing rational and irrational economic behaviors. *The Neuroscientist*.
[8] Patterson, T. K., et al. (2018). Subregional specificity in human striatal habit learning: a meta-analytic review of the fMRI literature. *Current Opinion in Behavioral Sciences*.
[9] Camerer, C. F., & Li, X. (2021). Neural autopilot and context-sensitivity of habits. *Current Opinion in Behavioral Sciences*.
[10] Huang, Y., Yaple, Z. A., & Yu, R. (2020). Goal-oriented and habitual decisions: Neural signatures of model-based and model-free learning. *NeuroImage*.
[11] Khamassi, M., & Humphries, M. D. (2012). Integrating cortico-limbic-basal ganglia architectures for learning model-based and model-free navigation strategies. *Frontiers in Behavioral Neuroscience*.
[12] Graybiel, A. M., & Grafton, S. T. (2015). The striatum: where skills and habits meet. *Cold Spring Harbor Perspectives in Biology*.
[13] Lee, S. W., Shimojo, S., & O'Doherty, J. P. (2014). Neural computations underlying arbitration between model-based and model-free learning. *Neuron*.
[14] Yee, X. (2024). Do model-based and model-free reinforcement learning correspond to goal-directed and habitual actions, respectively? A systematic review. *OSF Preprints*.
[15] Amaya, K. A., & Smith, K. S. (2018). Neurobiology of habit formation. *Current Opinion in Behavioral Sciences*.

# Sistemas de Revisão Periódica e Retrospectivas: Fundamentos Teóricos e Metodológicos

## Introdução

A prática de revisão periódica e retrospectiva, popularizada por metodologias ágeis como Scrum e Kanban, encontra sua sustentação em um conjunto robusto de teorias e *frameworks* conceituais oriundos da psicologia, da economia comportamental e da teoria organizacional. Longe de serem meras ferramentas de gestão, esses sistemas representam a aplicação prática de mecanismos de **autorregulação** e **aprendizagem contínua** essenciais ao desenvolvimento humano.

O presente resumo consolida as contribuições de 16 fontes acadêmicas e teóricas, focando em: **Teorias Psicológicas** que explicam a motivação e o comportamento, **Frameworks Conceituais** que descrevem o processo de aprendizado e **Metodologias Práticas** não-tecnológicas para a reflexão estruturada.

## I. Fundamentos Psicológicos: Autorregulação e Motivação

O cerne dos sistemas de revisão reside na capacidade humana de **autorregulação** (*self-regulation*), definida como o processo de monitorar e ajustar o comportamento para atingir metas [7].

### 1. Teoria da Definição de Metas (Goal-Setting Theory)

A revisão periódica é o mecanismo de *feedback* que sustenta a **Teoria da Definição de Metas** de Locke e Latham [1]. Esta teoria postula que objetivos conscientes afetam a ação, e que metas específicas e difíceis (mas alcançáveis) levam a um desempenho superior. O **feedback** é o componente crucial, pois permite ao indivíduo monitorar a discrepância entre o estado atual e o objetivo, motivando o ajuste de esforço e estratégias [1]. A retrospectiva, portanto, é o momento formal de coleta e análise desse feedback.

### 2. Teoria do Controle (Control Theory)

A **Teoria do Controle** de Carver e Scheier [7] fornece o modelo cibernético para a autorregulação, o **circuito de feedback negativo** (TOTE: *Test-Operate-Test-Exit*). A revisão periódica corresponde ao estágio de **Teste** (*Test*), onde o desempenho é comparado com o valor de referência (a meta). A identificação de uma discrepância (erro) aciona a fase de **Operate** (*Operate*), que é a adaptação e o planejamento de novas ações. Esta teoria valida o princípio de "inspeção e adaptação" como um mecanismo psicológico fundamental.

### 3. Teoria Cognitiva Social (Social Cognitive Theory)

A **Teoria Cognitiva Social** de Bandura [13] destaca o papel da **Autoeficácia** (*Self-Efficacy*) — a crença na própria capacidade de executar ações para alcançar resultados. A retrospectiva é um ato de **autorreflexão avaliativa** que, ao analisar o sucesso e o fracasso, influencia diretamente a autoeficácia. Retrospectivas bem-sucedidas fortalecem a autoeficácia, criando um ciclo virtuoso de metas mais desafiadoras e maior persistência [13].

### 4. Teoria da Autodeterminação (Self-Determination Theory - SDT)

A SDT de Deci e Ryan [12] foca na qualidade da motivação. Para que a revisão periódica seja sustentável a longo prazo, ela deve satisfazer as necessidades psicológicas básicas de **Autonomia**, **Competência** e **Relacionamento** [12]. O foco em metas intrínsecas (crescimento pessoal) durante a revisão, em vez de metas extrínsecas (status), é crucial para a persistência e o bem-estar.

### 5. Economia Comportamental: O Desafio da Manutenção

A **Teoria da Autorregulação Temporal (TST)** de Hall e Fong [2] e o conceito de **Viés do Presente** (*Present Bias*) da Economia Comportamental [16] explicam por que a revisão periódica é difícil de manter. O benefício da revisão (melhoria futura) é distante, enquanto o custo (tempo e esforço) é imediato. A TST sugere que o sucesso depende do fortalecimento da **capacidade de autorregulação** para superar a atração de recompensas imediatas [2].

## II. Frameworks Conceituais de Aprendizagem

Os sistemas de revisão são, essencialmente, *frameworks* de aprendizagem.

### 6. Aprendizagem de Ciclo Simples e Duplo (Single and Double-Loop Learning)

O modelo de Argyris [3] distingue dois níveis de aprendizado:
*   **Ciclo Simples:** Correção de erros dentro das regras e pressupostos existentes (ex: "Fiz X, deu errado, vou tentar Y").
*   **Ciclo Duplo:** Questionamento e modificação das regras e pressupostos subjacentes (ex: "Por que eu tinha a regra de fazer X? Esta regra ainda é válida?").
As retrospectivas eficazes visam o **Ciclo Duplo**, levando a mudanças transformacionais na **teoria-em-uso** do indivíduo [3].

### 7. Metacognição

A **Metacognição** (Flavell [15]) é o processo de "pensar sobre o próprio pensamento". A revisão periódica é o ato de monitorar o desempenho passado e controlar as estratégias futuras. A eficácia da retrospectiva depende da capacidade metacognitiva de avaliar com precisão o que funcionou e por quê [15].

### 8. Ciclo de Aprendizagem Experiencial (Experiential Learning Cycle)

O modelo de Kolb [5] fornece a estrutura para o processo de retrospectiva: **Experiência Concreta** → **Observação Reflexiva** (a retrospectiva) → **Conceitualização Abstrata** (o aprendizado) → **Experimentação Ativa** (o plano de ação) [5]. Este ciclo valida a necessidade de um processo estruturado para transformar a experiência em conhecimento.

## III. Metodologias Práticas (Não-Tecnológicas)

Estes *frameworks* oferecem métodos estruturados para a condução da revisão.

### 9. Ciclo Plan-Do-Check-Act (PDCA)

O **Ciclo PDCA** (Deming [14], baseado em Shewhart) é o modelo de melhoria contínua que fundamenta o Agile. O estágio **Check** (*Checar/Estudar*) é a revisão periódica, onde os resultados são medidos e comparados com os objetivos, antes de se tomar uma ação corretiva (*Act*) [14].

### 10. Ciclo Reflexivo de Gibbs (Gibbs' Reflective Cycle)

O modelo de Gibbs [4] é uma metodologia de seis estágios para a reflexão estruturada, amplamente utilizada em contextos de saúde e educação. Ele garante que a revisão vá além dos fatos, incluindo a dimensão emocional (**Sentimentos**) e a formulação de um **Plano de Ação** concreto [4].

### 11. Modelo GROW (Goal, Reality, Options, Will)

O **Modelo GROW** de Whitmore [6] é um *framework* de *coaching* que utiliza a revisão (estágio **Reality**) como ponto de partida para o planejamento futuro. Ele é uma metodologia prática para aplicar o *feedback loop* no desenvolvimento pessoal, focando na exploração da situação atual antes de gerar soluções [6].

### 12. Intenções de Implementação (Implementation Intentions)

A pesquisa de Gollwitzer [8] mostra que a eficácia do plano de ação (o resultado da retrospectiva) é drasticamente aumentada quando as melhorias são formuladas como **Intenções de Implementação** ("Se [situação crítica], então [comportamento de resposta]"). Isso transforma a intenção vaga em um plano de ação automático, superando a lacuna entre intenção e comportamento [8].

### 13. Entrevista Motivacional (Motivational Interviewing - MI)

A MI de Miller e Rollnick [11] é uma metodologia de diálogo que oferece um *framework* para a retrospectiva em grupo ou com um *coach*, focando na **evocação** de **"Change Talk"** (falas de mudança) e na resolução da ambivalência. É um método para garantir que o plano de ação seja autônomo e sustentável [11].

## IV. Evidências Científicas e Suporte Humano

Meta-análises confirmam a eficácia dos componentes centrais dos sistemas de revisão:

*   **Eficácia do Coaching:** Meta-análises [9] demonstram que o *coaching* (que incorpora revisão e feedback, como o GROW) é eficaz porque estimula a **autorregulação** direcionada a metas.
*   **Eficácia do Automonitoramento:** Meta-análises [10] confirmam que o ato de **monitorar o progresso da meta** (o cerne da revisão) é um componente causalmente eficaz para o sucesso da meta.

## Tabela de Fontes (16 Fontes)

| # | Título | Autor(es) | Ano | Área Temática | Contribuição Principal |
| :---: | :--- | :--- | :---: | :--- | :--- |
| 1 | Building a Practically Useful Theory of Goal Setting and Task Motivation | Locke & Latham | 2002 | Psicologia | Teoria da Definição de Metas e o papel do Feedback. |
| 2 | Temporal self-regulation theory: A model for individual health behavior | Hall & Fong | 2007 | Psicologia Comportamental | TST e a dimensão temporal de custos/benefícios na autorregulação. |
| 3 | Double Loop Learning in Organizations | Chris Argyris | 1977 | Teoria Organizacional | Distinção entre Aprendizagem de Ciclo Simples e Duplo (mudança de pressupostos). |
| 4 | Learning by Doing: A Guide to Teaching and Learning Methods | Graham Gibbs | 1988 | Educação/Reflexão | Ciclo Reflexivo de Gibbs (metodologia de 6 estágios para retrospectiva). |
| 5 | Experiential Learning: Experience As The Source Of Learning And Development | David A. Kolb | 1984 | Psicologia Educacional | Ciclo de Aprendizagem Experiencial (estrutura teórica da retrospectiva). |
| 6 | Coaching for Performance | Sir John Whitmore | 2009 | Coaching/Metodologia | Modelo GROW (Goal, Reality, Options, Will) como framework de revisão. |
| 7 | Control Theory: A Useful Conceptual Framework for Personality and Social Psychology | Carver & Scheier | 1982 | Psicologia | Teoria do Controle e o circuito de feedback negativo (TOTE). |
| 8 | Implementation Intentions and Effective Goal Pursuit | Gollwitzer & Brandstätter | 1997 | Psicologia Social | Intenções de Implementação (If-Then) para traduzir a revisão em ação. |
| 9 | Does coaching work? A meta-analysis on the effects of coaching... | Theeboom et al. | 2014 | Meta-análise/Coaching | Evidência empírica da eficácia do coaching via autorregulação. |
| 10 | Does monitoring goal progress promote goal attainment? A meta-analysis... | Harkin et al. | 2016 | Meta-análise/Psicologia | Evidência empírica da eficácia do automonitoramento (revisão). |
| 11 | Motivational Interviewing: Helping People Change | Miller & Rollnick | 2013 | Psicologia Clínica | Entrevista Motivacional (MI) como metodologia de diálogo para a autorreflexão. |
| 12 | Self-Determination Theory | Deci & Ryan | 1985 | Psicologia | SDT e a importância da Autonomia, Competência e Relacionamento na sustentabilidade da revisão. |
| 13 | Social Foundations of Thought and Action: A Social Cognitive Theory | Albert Bandura | 1986 | Psicologia | Teoria Cognitiva Social e o papel da Autoeficácia na revisão e ajuste de metas. |
| 14 | Out of the Crisis | W. Edwards Deming | 1986 | Gestão/Qualidade | Ciclo PDCA (Plan-Do-Check-Act) como modelo de melhoria contínua. |
| 15 | Metacognition and Cognitive Monitoring... | John H. Flavell | 1979 | Psicologia Cognitiva | Metacognição como o processo de monitoramento e controle subjacente à revisão. |
| 16 | Doing It Now or Later | David Laibson | 1997 | Economia Comportamental | Viés do Presente (Present Bias) e Desconto Hiperbólico, explicando a dificuldade em manter a revisão. |

## Referências

[1] Locke, E. A., & Latham, G. P. (2002). *Building a Practically Useful Theory of Goal Setting and Task Motivation: A 35-Year Odyssey*. American Psychologist. URL: https://med.stanford.edu/content/dam/sm/s-spire/documents/PD.locke-and-latham-retrospective_Paper.pdf
[2] Hall, P. A., & Fong, G. T. (2007). *Temporal self-regulation theory: A model for individual health behavior*. Health Psychology Review. URL: https://www.researchgate.net/publication/232919984_Temporal_self-regulation_theory_A_model_for_individual_health_behavior
[3] Argyris, C. (1977). *Double Loop Learning in Organizations*. Harvard Business Review. URL: https://www.avannistelrooij.nl/wp/wp-content/uploads/2017/11/Argyris-1977-Double-Loop-Learning-in-Organisations-HBR.pdf
[4] Gibbs, G. (1988). *Learning by Doing: A Guide to Teaching and Learning Methods*. Oxford Polytechnic.
[5] Kolb, D. A. (1984). *Experiential Learning: Experience As The Source Of Learning And Development*. Prentice Hall.
[6] Whitmore, J. (2009). *Coaching for Performance: Growing Human Potential and Purpose—The Principles and Practice of Coaching and Leadership*. Nicholas Brealey Publishing.
[7] Carver, C. S., & Scheier, M. F. (1982). *Control Theory: A Useful Conceptual Framework for Personality and Social Psychology*. Journal of Personality and Social Psychology.
[8] Gollwitzer, P. M., & Brandstätter, V. (1997). *Implementation Intentions and Effective Goal Pursuit*. Journal of Personality and Social Psychology. URL: https://sparq.stanford.edu/sites/g/files/sbiybj19021/files/media/file/gollwitzer_brandstatter_1997_-_implementation_intentions_effective_goal_pursuit.pdf
[9] Theeboom, T., Beersma, B., & van Vianen, A. E. M. (2014). *Does coaching work? A meta-analysis on the effects of coaching on individual level outcomes in an organizational context*. The Journal of Positive Psychology. URL: https://www.tandfonline.com/doi/abs/10.1080/17439760.2013.837499
[10] Harkin, B., Webb, T. L., Chang, B. P. I., Prestwich, A., Conner, M., Kellar, I., ... & Epton, T. (2016). *Does monitoring goal progress promote goal attainment? A meta-analysis of the experimental evidence*. Psychological Bulletin. URL: https://psycnet.apa.org/record/2015-47216-001
[11] Miller, W. R., & Rollnick, S. (2013). *Motivational Interviewing: Helping People Change* (3rd ed.). Guilford Press.
[12] Deci, E. L., & Ryan, R. M. (1985). *Self-Determination Theory: An Approach to Human Motivation and Personality*. Plenum. URL: https://selfdeterminationtheory.org/theory/
[13] Bandura, A. (1986). *Social Foundations of Thought and Action: A Social Cognitive Theory*. Prentice Hall.
[14] Deming, W. E. (1986). *Out of the Crisis*. MIT Center for Advanced Engineering Study.
[15] Flavell, J. H. (1979). *Metacognition and Cognitive Monitoring: A New Area of Cognitive-Developmental Inquiry*. American Psychologist.
[16] Laibson, D. (1997). *Doing It Now or Later*. American Economic Review.

# Relatório de Pesquisa: Dopamina, Recompensa e Motivação - Fundamentos Neurocientíficos e Frameworks da Economia Comportamental

A presente pesquisa teve como objetivo investigar e documentar os conceitos teóricos, *frameworks* e metodologias que interligam a neurociência da dopamina, os circuitos neurais de recompensa e motivação, e os modelos avançados da economia comportamental. O foco foi em fundamentos neurocientíficos, teorias econômicas comportamentais, e pensamento sistêmico, excluindo menções a tecnologia, IA ou produtos comerciais. Foram identificadas 15 fontes acadêmicas de alto nível, incluindo artigos seminais e revisões recentes, que estabelecem as bases conceituais para a compreensão da tomada de decisão e do comportamento motivado.

## 1. Fundamentos Neurocientíficos da Dopamina e Recompensa

O papel da **dopamina (DA)** no cérebro transcende a simplificação de ser apenas o "transmissor do prazer". A pesquisa moderna, impulsionada por estudos seminais, estabeleceu a DA como um sinal fundamental para a **aprendizagem** e a **motivação**, operando em múltiplos circuitos e escalas de tempo [12].

### 1.1. O Erro de Predição de Recompensa (RPE)

O conceito mais influente na neurociência da recompensa é o **Erro de Predição de Recompensa (RPE)**, formalizado em 1997 [12]. O RPE é a diferença entre a recompensa esperada e a recompensa realmente recebida.
*   Se a recompensa é maior que a esperada (RPE positivo), os neurônios dopaminérgicos disparam em rajadas, reforçando o comportamento que levou ao resultado.
*   Se a recompensa é menor que a esperada (RPE negativo), a atividade dopaminérgica diminui, levando à desvalorização do comportamento.
*   Se a recompensa é exatamente a esperada (RPE zero), não há mudança na atividade dopaminérgica, indicando que o aprendizado foi concluído [3] [12].

Este *framework* de RPE, derivado do **Aprendizado por Reforço (*Reinforcement Learning* - RL)**, fornece a base computacional para a neuroeconomia, explicando como os organismos atualizam o valor de estímulos e ações [12].

### 1.2. Motivação Ativacional e Esforço

Uma reestruturação conceitual importante desafiou a visão da DA como codificadora apenas do prazer (*liking*), enfatizando seu papel na **motivação ativacional** e no **esforço** (*wanting*) [2] [5]. A **Teoria da Sensibilização Incentiva (IST)** dissocia o "querer" (motivação de busca, DA-dependente) do "gostar" (prazer hedônico, DA-independente) [5].

A dopamina mesocorticolímbica, particularmente no *nucleus accumbens* (NAc), é crucial para a **tomada de decisão baseada em esforço** (*effort-based decision making*), onde os organismos avaliam o **custo de resposta** (esforço) em relação ao benefício da recompensa (análise custo/benefício) [2] [13]. Estudos recentes sugerem que a liberação de DA estriatal integra o custo e o benefício, e que a alta motivação pode, surpreendentemente, amortecer o sinal fásico de DA evocada pela recompensa, indicando uma codificação complexa e multifacetada [4].

## 2. Frameworks da Economia Comportamental e Pensamento Sistêmico

A neurociência se apropria de modelos da economia comportamental para mapear a complexidade da tomada de decisão em circuitos neurais.

### 2.1. Teoria da Perspectiva e Aversão à Perda

A **Teoria da Perspectiva (*Prospect Theory*)**, um dos modelos mais proeminentes da economia comportamental, descreve como as pessoas tomam decisões sob risco, caracterizada pela **aversão à perda** (a dor de uma perda é maior que o prazer de um ganho equivalente) e pela **ponderação de probabilidade** não linear [9].

Estudos neurocientíficos encontraram evidências de que a atividade de neurônios individuais no circuito de recompensa (Córtex Orbitofrontal, Estriado) representa a avaliação subjetiva de risco de acordo com a Teoria da Perspectiva, codificando a combinação multiplicativa da **função de utilidade** e da **função de ponderação de probabilidade** [9]. Além disso, a **aversão à perda** em decisões baseadas em esforço é **modulada pelo estado dopaminérgico**, estendendo o papel da DA para a valência negativa e a motivação para evitar perdas [11].

### 2.2. Escolha Intertemporal e Desconto Hiperbólico

A **Escolha Intertemporal (IC)** refere-se a decisões que envolvem *trade-offs* entre recompensas imediatas e futuras. O comportamento humano é frequentemente descrito pelo **Desconto Hiperbólico**, onde o valor percebido de uma recompensa futura cai drasticamente à medida que o atraso aumenta [7] [14].

A base neural da IC é frequentemente explicada por um **Modelo de Sistemas Duais**, onde:
1.  Um sistema impulsivo (associado ao **Estriado Ventral** e ao **Sistema Dopaminérgico**) valoriza recompensas imediatas.
2.  Um sistema prudente (associado ao **Córtex Pré-Frontal Lateral**) avalia recompensas futuras [14].

A dopamina modula a dinâmica do processo de decisão intertemporal, influenciando a taxa de acumulação de evidências (*drift rate*) em modelos computacionais como o **Modelo de Difusão (*Drift Diffusion Model*)** [7].

### 2.3. Sistemas de Controle e Motivos de Circuitos Neurais

O **framework neuroeconômico** propõe que a tomada de decisão envolve cinco processos computacionais básicos: Representação, Avaliação, Seleção, Medição e Aprendizagem [6]. A avaliação e a seleção de ações são arbitradas por múltiplos sistemas de controle:
*   **Model-Free (Habitual):** Baseado no RPE e no valor de estado.
*   **Model-Based (Orientado a Objetivos):** Envolve planejamento prospectivo e a exploração de um modelo cognitivo do ambiente [8].

Curiosamente, o aumento da dopamina (via L-DOPA) demonstrou **promover a contribuição do sistema Model-Based** em detrimento do Model-Free, sugerindo que a DA modula a arbitragem entre o comportamento orientado a objetivos e o habitual [8].

Em uma perspectiva sistêmica, o processamento de valência (recompensa e aversão) é implementado através de **Motivos de Circuitos Neurais** [15]. Estes incluem:
*   **Linhas Rotuladas (*Labeled Lines*):** Vias paralelas para estímulos positivos e negativos (abordagem e evitação).
*   **Ganho Neuromodulatório (*Neuromodulatory Gain*):** Onde a dopamina atua para estender a plasticidade e permitir a dependência de estado [15].

## 3. Fontes Acadêmicas Documentadas

A tabela a seguir resume as 15 fontes acadêmicas de alto nível utilizadas para esta pesquisa.

| # | Título | Autor(es) | Ano | Contribuições Teóricas Principais |
| :--- | :--- | :--- | :--- | :--- |
| 1 | Dopamine in motivational control: rewarding, aversive, and alerting | Bromberg-Martin et al. | 2010 | Framework de múltiplos tipos de neurônios dopaminérgicos (Valor, Saliência, Alerta) para controle motivacional. |
| 2 | Dopamine, Behavioral Economics, and Effort | Salamone et al. | 2009 | Reestruturação conceitual da DA no NAc, focando no papel ativacional e na tomada de decisão baseada em esforço (custo de resposta). |
| 3 | Dopamine Prediction Errors in Reward Learning and Addiction: From Theory to Neural Circuitry | Keiflin & Janak | 2015 | Integração do modelo RPE com a neurobiologia dos circuitos dopaminérgicos, com foco na adição. |
| 4 | Striatal dopamine integrates cost, benefit, and motivation | Eshel et al. | 2024 | Demonstra que a DA estriatal integra custo irrecuperável e benefício; alta motivação amortece o sinal fásico de DA. |
| 5 | Liking, Wanting and the Incentive-Sensitization Theory of Addiction | Berridge & Robinson | 2016 | Teoria da Sensibilização Incentiva (IST), dissociando *Wanting* (motivação, DA-dependente) de *Liking* (prazer, DA-independente). |
| 6 | Neuroeconomics: The neurobiology of value-based decision-making | Rangel et al. | 2008 | Framework neuroeconômico de 5 processos (Representação, Avaliação, Seleção, Medição, Aprendizagem) para a tomada de decisão baseada em valor. |
| 7 | Dopaminergic Modulation of Human Intertemporal Choice: A Diffusion Model Analysis... | Wagner et al. | 2020 | Aplicação do Modelo de Difusão para mostrar que a DA (receptores D2) modula a dinâmica da Escolha Intertemporal (impulsividade). |
| 8 | Dopamine Enhances Model-Based over Model-Free Choice Behavior | Wunderlich et al. | 2012 | DA modula a arbitragem entre sistemas de controle, promovendo o sistema Model-Based (orientado a objetivos) em detrimento do Model-Free (habitual). |
| 9 | A neuronal prospect theory model in the brain reward circuitry | Imaizumi et al. | 2022 | Evidência de que neurônios individuais codificam a avaliação subjetiva de risco de acordo com a Teoria da Perspectiva (função de utilidade e ponderação de probabilidade). |
| 10 | Neurocircuits for motivation | Stuber | 2023 | Framework de circuitos neurais que unifica o entendimento de comportamentos motivados, com o papel central da DA VTA no reforço de ações. |
| 11 | Dopamine-Dependent Loss Aversion during Effort-Based Decision-Making | Chen et al. | 2020 | Demonstra que a aversão à perda em decisões baseadas em esforço é modulada pelo estado dopaminérgico. |
| 12 | A neural substrate of prediction and reward | Schultz et al. | 1997 | Artigo seminal que estabeleceu o framework do Erro de Predição de Recompensa (RPE) e sua conexão com a DA. |
| 13 | The Neurobiology of Activational Aspects of Motivation: Exertion of Effort... | Salamone & Correa | 2024 | Revisão que reforça a dissociação entre aspectos direcionais e ativacionais da motivação, com a DA como chave para o esforço e decisão custo/benefício. |
| 14 | Neurobiological bases of intertemporal choices: A comprehensive review | Moreira et al. | 2016 | Revisão sobre Escolhas Intertemporais (IC), mapeando a preferência por valor imediato para um Modelo de Sistemas Duais (Estriado Ventral vs. PFC). |
| 15 | Neural Circuit Motifs in Valence Processing | Tye | 2018 | Framework sistêmico de Motivos de Circuitos Neurais (Linhas Rotuladas, Ganho Neuromodulatório) para o processamento de valência (recompensa e aversão). |

## Referências

[1] Bromberg-Martin, E. S., Matsumoto, M., & Hikosaka, O. (2010). Dopamine in motivational control: rewarding, aversive, and alerting. *Neuron*, *68*(5), 815–834. [https://pmc.ncbi.nlm.nih.gov/articles/PMC3032992/](https://pmc.ncbi.nlm.nih.gov/articles/PMC3032992/)

[2] Salamone, J. D., Correa, M., Farrar, A. M., & Nunes, E. J. (2009). Dopamine, Behavioral Economics, and Effort. *Frontiers in Behavioral Neuroscience*, *3*, 13. [https://pmc.ncbi.nlm.nih.gov/articles/PMC2759361/](https://pmc.ncbi.nlm.nih.gov/articles/PMC2759361/)

[3] Keiflin, R., & Janak, P. H. (2015). Dopamine Prediction Errors in Reward Learning and Addiction: From Theory to Neural Circuitry. *Neuron*, *88*(2), 247–261. [https://doi.org/10.1016/j.neuron.2015.08.037](https://doi.org/10.1016/j.neuron.2015.08.037)

[4] Eshel, N., Touponse, G. C., Wang, A. R., Osterman, A. K., Shank, A. N., Groome, A. M., Taniguchi, L., Cardozo Pinto, D. F., Tucciarone, J., Bentzley, B. S., & Malenka, R. C. (2024). Striatal dopamine integrates cost, benefit, and motivation. *Neuron*, *112*(1), 147-160.e7. [https://doi.org/10.1016/j.neuron.2023.10.038](https://doi.org/10.1016/j.neuron.2023.10.038)

[5] Berridge, K. C., & Robinson, T. E. (2016). Liking, Wanting and the Incentive-Sensitization Theory of Addiction. *American Psychologist*, *71*(8), 779–791. [https://pmc.ncbi.nlm.nih.gov/articles/PMC5171207/](https://pmc.ncbi.nlm.nih.gov/articles/PMC5171207/)

[6] Rangel, A., Camerer, C., & Montague, P. R. (2008). Neuroeconomics: The neurobiology of value-based decision-making. *Nature Reviews Neuroscience*, *9*(7), 545–556. [https://pmc.ncbi.nlm.nih.gov/articles/PMC4332708/](https://pmc.ncbi.nlm.nih.gov/articles/PMC4332708/)

[7] Wagner, B., Clos, M., Sommer, T., & Peters, J. (2020). Dopaminergic Modulation of Human Intertemporal Choice: A Diffusion Model Analysis Using the D2-Receptor Antagonist Haloperidol. *The Journal of Neuroscience*, *40*(41), 7936–7947. [https://doi.org/10.1523/JNEUROSCI.0592-20.2020](https://doi.org/10.1523/JNEUROSCI.0592-20.2020)

[8] Wunderlich, K., Smittenaar, P., & Dolan, R. J. (2012). Dopamine Enhances Model-Based over Model-Free Choice Behavior. *Neuron*, *75*(3), 418–424. [https://pmc.ncbi.nlm.nih.gov/articles/PMC3417237/](https://pmc.ncbi.nlm.nih.gov/articles/PMC3417237/)

[9] Imaizumi, Y., Tymula, A., Tsubo, Y., Matsumoto, M., & Yamada, H. (2022). A neuronal prospect theory model in the brain reward circuitry. *Nature Communications*, *13*(1), 5855. [https://www.nature.com/articles/s41467-022-33579-0](https://www.nature.com/articles/s41467-022-33579-0)

[10] Stuber, G. D. (2023). Neurocircuits for motivation. *Science*, *382*(6669), 394–398. [https://doi.org/10.1126/science.adh8287](https://doi.org/10.1126/science.adh8287)

[11] Chen, X., Voets, S., Jenkinson, N., & Galea, J. M. (2020). Dopamine-Dependent Loss Aversion during Effort-Based Decision-Making. *The Journal of Neuroscience*, *40*(3), 661–670. [https://pmc.ncbi.nlm.nih.gov/articles/PMC6961986/](https://pmc.ncbi.nlm.nih.gov/articles/PMC6961986/)

[12] Schultz, W., Dayan, P., & Montague, P. R. (1997). A neural substrate of prediction and reward. *Science*, *275*(5306), 1593–1599. [https://pubmed.ncbi.nlm.nih.gov/9054347/](https://pubmed.ncbi.nlm.nih.gov/9054347/)

[13] Salamone, J. D., & Correa, M. (2024). The Neurobiology of Activational Aspects of Motivation: Exertion of Effort, Effort-Based Decision Making, and the Role of Dopamine. *Annual Review of Psychology*, *75*, 1–32. [https://doi.org/10.1146/annurev-psych-020223-012208](https://doi.org/10.1146/annurev-psych-020223-012208)

[14] Moreira, D., Pinto, M., Almeida, F., Barros, S., & Barbosa, F. (2016). Neurobiological bases of intertemporal choices: A comprehensive review. *Aggression and Violent Behavior*, *26*, 1–8. [https://www.sciencedirect.com/science/article/pii/S1359178915001743](https://www.sciencedirect.com/science/article/pii/S1359178915001743)

[15] Tye, K. M. (2018). Neural Circuit Motifs in Valence Processing. *Neuron*, *100*(2), 436–452. [https://pmc.ncbi.nlm.nih.gov/articles/PMC6590698/](https://pmc.ncbi.nlm.nih.gov/articles/PMC6590698/)

[16] Rutledge, R. B., Skandali, N., Dayan, P., & Dolan, R. J. (2015). Dopaminergic Modulation of Decision Making and Subjective Well-Being. *The Journal of Neuroscience*, *35*(27), 9811–9822. [https://www.jneurosci.org/content/35/27/9811](https://www.jneurosci.org/content/35/27/9811)

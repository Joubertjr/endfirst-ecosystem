# Análise Detalhada de Fontes Acadêmicas sobre Mastermind Groups e Peer Coaching

Este documento sintetiza as principais contribuições teóricas de fontes acadêmicas relevantes sobre os temas de Mastermind groups e Peer Coaching, com foco em seus frameworks conceituais, bases psicológicas e evidências de eficácia.


## Fontes Acadêmicas Identificadas

### 1. Revisão Sistemática e Framework Conceitual (Peer Development Groups)

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Psicologia Organizacional, Liderança | Unveiling the nature of peer development groups: A systematic review, conceptual framework, and research pathways | Roman Terekhin, S. R. Aurora | 2025 | [https://onlinelibrary.wiley.com/doi/10.1002/job.2845][1] |

**Principais Contribuições Teóricas:**

*   **Definição Conceitual:** Propõe o termo **Peer Development Groups (PDGs)** como um guarda-chuva para Mastermind groups, peer advisory groups e peer coaching groups. Define PDGs como "pequenos grupos organizados, compostos por membros de status e papéis percebidos como semelhantes, que se reúnem regularmente para promover o crescimento mútuo, fornecendo um ambiente de apoio e uma agenda flexível."
*   **Framework I-P-O (Input-Process-Outcome):** Desenvolve um framework conceitual que liga variáveis-chave (Inputs: características do grupo e do indivíduo; Processos: dinâmica de grupo, apoio mútuo, reflexão; Outcomes: desenvolvimento individual e organizacional) que influenciam a eficácia dos PDGs.
*   **Base Teórica:** Fundamenta a eficácia dos PDGs em teorias como a **Teoria da Autodeterminação** (Self-Determination Theory - SDT) de Ryan e Deci (2000), que explica como o suporte à autonomia, competência e relacionamento (necessidades psicológicas básicas) dentro do grupo impulsiona o desenvolvimento.
*   **Diferenciação:** Distingue PDGs de conceitos relacionados (mentoria, comunidades de prática), focando na **simetria de status** e no **foco primário no desenvolvimento** dos membros.

---

### 2. Peer Coaching como Processo Relacional

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Psicologia Organizacional, Desenvolvimento de Carreira | Peer coaching: A relational process for accelerating career learning | Polly Parker, Douglas T. Hall, Kathy E. Kram | 2008 | [https://journals.aom.org/doi/abs/10.5465/AMLE.2008.35882189][2] |

**Principais Contribuições Teóricas:**

*   **Definição de Peer Coaching:** Define **Peer Coaching** como um tipo de ferramenta de desenvolvimento que pode acelerar o aprendizado de carreira, focando em um **processo relacional** entre pares.
*   **Modelo de Três Etapas:** Propõe um modelo teórico de três etapas para o Peer Coaching eficaz: (1) **Construção do Relacionamento de Desenvolvimento** (baseado em confiança e reciprocidade), (2) **Criação de Sucesso no Desenvolvimento** (foco em metas e feedback), e (3) **Internalização da Tática de Aprendizagem** (aplicação do processo em futuros relacionamentos).
*   **Base Teórica:** Enquadra o Peer Coaching dentro da **Perspectiva Relacional sobre Aprendizagem de Carreira** (Relational Perspective on Career Learning), onde o suporte e o desafio fornecidos pelos pares são cruciais para o crescimento.
*   **Características Chave:** Enfatiza a importância da **igualdade de status** entre os parceiros, a **reciprocidade** e a capacidade de fornecer um **"desafio crítico"** em um ambiente de **suporte psicológico**.

---

### 3. Coaching de Grupo de Pares e Desenvolvimento de Habilidades

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Empreendedorismo, Desenvolvimento Organizacional | Skill-based development of entrepreneurs and the role of personal and peer group coaching in enterprise development | Nailya Kutzhanova, Thomas S. Lyons, Gregg A. Lichtenstein | 2009 | [https://journals.sagepub.com/doi/abs/10.1177/0891242409336547][3] |

**Principais Contribuições Teóricas:**

*   **Foco no Desenvolvimento de Habilidades:** Argumenta que a **construção de habilidades** é central para o sucesso de empreendedores e examina como o **coaching de grupo de pares** (peer group coaching) facilita esse processo.
*   **Estudo Empírico:** Analisa um programa de desenvolvimento empresarial que utiliza um sistema de coaching pessoal e de grupo de pares, triangulando resultados de entrevistas aprofundadas.
*   **Mecanismo de Aprendizagem:** O coaching de grupo de pares atua como um mecanismo para a **aprendizagem experiencial** e a **transferência de conhecimento** entre pares, permitindo que os participantes se beneficiem das experiências e perspectivas uns dos outros.
*   **Implicações Práticas:** Demonstra a eficácia de metodologias práticas (não-tecnológicas) e estruturas humanas (coaching de grupo) para o desenvolvimento de competências.

---

### 4. Estudo Empírico sobre Executive Peer Advisory Groups (Mastermind)

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Liderança, Desenvolvimento Executivo | EXECUTIVE PEER ADVISORY GROUPS | Anthony Feghali | 2022 | [https://digital.sandiego.edu/cgi/viewcontent.cgi?article=1935&context=dissertations][4] |

**Principais Contribuições Teóricas:**

*   **Foco em Mastermind Executivo:** Estudo empírico que investiga os **Executive Peer Advisory Groups** (grupos de Mastermind para executivos, como Vistage), que são o equivalente prático do conceito de Mastermind.
*   **Mecanismos de Suporte:** Identifica o valor desses grupos na **tomada de decisão**, **suporte confidencial** e **responsabilização** (accountability) entre pares.
*   **Base Teórica:** Embora o estudo seja empírico, ele se baseia em conceitos de **liderança transformacional** e **eficácia organizacional**, mostrando como a troca de experiências e o feedback dos pares influenciam o comportamento do CEO e os resultados da empresa.
*   **Evidência de Eficácia:** Corrobora a percepção de que esses grupos são uma "arma secreta" para líderes, fornecendo um ambiente de **desenvolvimento holístico** que transcende o coaching individual.

---

### 5. Teoria Psicológica Fundamental (Teoria da Autodeterminação)

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Psicologia, Motivação | Self-Determination Theory and the Facilitation of Intrinsic Motivation, Social Development, and Well-Being | Richard M. Ryan, Edward L. Deci | 2000 | [https://selfdeterminationtheory.org/SDT/documents/2000_DeciRyan_PIWhatWhy.pdf][5] |

**Principais Contribuições Teóricas:**

*   **Teoria da Autodeterminação (SDT):** Apresenta a SDT como uma macroteoria da motivação humana que distingue entre motivação autônoma (intrínseca) e controlada (extrínseca).
*   **Necessidades Psicológicas Básicas (BPNs):** Postula a existência de três necessidades psicológicas básicas e inatas, cuja satisfação é essencial para o crescimento psicológico, integridade e bem-estar:
    1.  **Autonomia:** Sentir-se a origem do próprio comportamento.
    2.  **Competência:** Sentir-se eficaz na interação com o ambiente.
    3.  **Relacionamento (Relatedness):** Sentir-se conectado e cuidado pelos outros.
*   **Relevância para Coaching/Mastermind:** O ambiente de suporte e a dinâmica de grupo em Mastermind groups e peer coaching são eficazes porque satisfazem essas três necessidades. O grupo oferece um ambiente de **Relacionamento** seguro, o processo de coaching/discussão promove a **Competência** e a natureza autodirigida do Mastermind suporta a **Autonomia**.

---

### 6. Estudo Empírico Comparativo (Coaching de Grupo vs. Individual)

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Psicologia, Liderança | Comparing the effectiveness of individual coaching, self-coaching, and group training: How leadership makes the difference | Sandra Losch, Eva Traut-Mattausch, Maria D. Mühlberger, Wolfgang G. Weber | 2016 | [https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2016.00629/full][6] |

**Principais Contribuições Teóricas:**

*   **Comparação de Eficácia:** Estudo empírico que compara a eficácia do coaching individual, autocoaching e **treinamento em grupo** (que compartilha características com o peer coaching/mastermind).
*   **Resultados:** Demonstra que o coaching individual resultou em maiores aumentos na **realização de metas**, **motivação intrínseca** e **autoeficácia** relacionada a metas em comparação com o treinamento em grupo.
*   **Implicação para Mastermind/Peer Coaching:** Embora o coaching individual seja superior em alguns aspectos, o estudo fornece uma base para entender os mecanismos de mudança em ambientes de grupo, sugerindo que o **foco na liderança** (ou facilitação) é um fator chave para a eficácia do grupo.

---

### 7. Metodologia Prática: Princípios de Parceria no Peer Coaching

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Educação, Desenvolvimento Profissional | Instructional Coaching: A Partnership Approach to Improving Instruction (e trabalhos subsequentes sobre Princípios de Parceria) | Jim Knight | 2007 (Princípios), 2013 (Foco) | [https://www.instructionalcoaching.com/jim-knight-coaching-institute/][7] |

**Principais Contribuições Teóricas/Metodológicas:**

*   **Princípios de Parceria (Partnership Principles):** Embora focado em coaching instrucional, o modelo de Knight é amplamente adaptado para o peer coaching devido aos seus princípios fundamentais, que estabelecem a estrutura humana para o relacionamento de desenvolvimento:
    1.  **Igualdade:** O coach e o coachee são parceiros de igual status.
    2.  **Escolha:** O coachee deve ter autonomia para escolher o que, quando e como será treinado (ligação direta com a **Autonomia** da SDT).
    3.  **Voz:** O coachee deve ter voz ativa no processo.
    4.  **Reflexão:** O processo deve ser baseado na reflexão mútua.
    5.  **Diálogo:** A comunicação deve ser um diálogo genuíno e não uma imposição.
*   **Metodologia Prática:** Fornece uma estrutura prática (não-tecnológica) para a interação entre pares, enfatizando a **simetria de poder** e a **autonomia** como pilares para o aprendizado e a mudança.

---

### 8. Teoria da Inteligência Coletiva e Sinergia de Grupo

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Psicologia Social, Ciência da Organização | Collective intelligence | Thomas W. Malone, Anita Williams Woolley | 2020 | [https://libros.metabiblioteca.org/bitstreams/d8bc08aa-c0c8-420b-9d20-95c0ffefe6b3/download][8] |

**Principais Contribuições Teóricas:**

*   **Inteligência Coletiva (IC):** Fornece a base teórica para o princípio Mastermind de **sinergia** ("duas ou mais mentes trabalhando em perfeita harmonia"). A IC é a capacidade de um grupo de realizar uma ampla gama de tarefas.
*   **Mecanismos de Grupo:** A eficácia de grupos de Mastermind/Peer Coaching é explicada pela IC, que depende de fatores como:
    1.  **Diversidade de Conhecimento:** Membros com diferentes experiências e *expertise* (Input).
    2.  **Comunicação Efetiva:** Capacidade de ouvir e contribuir (Processo).
    3.  **Inteligência Social:** A sensibilidade social média dos membros do grupo.
*   **Implicação:** O Mastermind, como um grupo de Inteligência Coletiva, é mais do que a soma de suas partes, e sua eficácia é um fenômeno mensurável e dependente da **dinâmica de grupo** (Processo).

---

### 9. Base Psicológica: Fatores Terapêuticos de Grupo

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Psicologia de Grupo, Terapia | The Theory and Practice of Group Psychotherapy (5ª Edição) | Irvin D. Yalom, Molyn Leszcz | 2005 | [https://www.wiley.com/en-us/The+Theory+and+Practice+of+Group+Psychotherapy%2C+5th+Edition-p-9780465092840][9] |

**Principais Contribuições Teóricas:**

*   **Fatores Terapêuticos de Yalom:** Embora focada em psicoterapia, esta obra é a base teórica para a compreensão da **dinâmica de grupo** em qualquer contexto de mudança e desenvolvimento, incluindo Mastermind e peer coaching. Os 11 fatores terapêuticos explicam por que o grupo é um veículo de mudança:
    1.  **Instilação de Esperança:** Ver outros membros progredirem.
    2.  **Universalidade:** Reconhecer que os problemas são compartilhados.
    3.  **Transmissão de Informação:** Receber conselhos e orientações.
    4.  **Altruísmo:** Ajudar os outros.
    5.  **Desenvolvimento de Técnicas de Socialização:** Aprender a interagir.
    6.  **Comportamento Imitativo:** Aprender observando.
    7.  **Coesão de Grupo:** Sentimento de pertencimento e valor.
    8.  **Catarse:** Expressão emocional.
    9.  **Aprendizagem Interpessoal:** Receber feedback sobre o impacto do comportamento.
    10. **Fatores Existenciais:** Lidar com a responsabilidade pessoal.
    11. **Recapitulação Corretiva do Grupo Familiar Primário.**
*   **Relevância para Mastermind/Peer Coaching:** Os grupos de pares e Mastermind capitalizam especialmente na **Universalidade**, **Transmissão de Informação**, **Altruísmo** e **Coesão de Grupo** para impulsionar o desenvolvimento.

---

### 10. Framework Conceitual para Group Coaching

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Coaching, Liderança | Group coaching: a new way of constructing leadership identity? (Referência ao Universal Integrated Framework - UIF) | Passmore, J., & Law, H. | 2009 | [https://www.researchgate.net/publication/277359825_Group_coaching_A_new_way_of_constructing_leadership_identity][10] |

**Principais Contribuições Teóricas:**

*   **Universal Integrated Framework (UIF):** O artigo faz referência ao UIF de Passmore (2009), que é um framework conceitual que busca integrar diversas abordagens de coaching. Embora o artigo se concentre na identidade de liderança, ele estabelece o **coaching de grupo** como um método válido e distinto para o desenvolvimento.
*   **Mecanismo de Construção de Identidade:** O grupo de coaching atua como um espaço social onde a **identidade de liderança** é negociada e construída, utilizando a **reflexão** e o **feedback** dos pares como ferramentas primárias.
*   **Implicação para Mastermind/Peer Coaching:** O framework apoia a ideia de que o grupo é um **sistema social** que facilita a mudança individual através da interação e da validação social, o que é um mecanismo central para Mastermind groups.

---

### 11. O Papel do Facilitador e a Dinâmica de Grupo

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Liderança, Desenvolvimento Organizacional | The pedagogy of action learning facilitation–a critique of the role of the facilitator in an organisational leadership programme | C. Sanyal | 2018 | [https://repository.mdx.ac.uk/item/88157][11] |

**Principais Contribuições Teóricas:**

*   **Pedagogia da Facilitação:** Analisa o papel do facilitador em contextos de aprendizado em grupo (como o *Action Learning*, que compartilha a estrutura de pares do Mastermind).
*   **Função do Facilitador:** O facilitador (ou *Chair* no Mastermind) tem um papel crucial de **"steer without being intrusive"** (guiar sem ser intrusivo), gerenciando a **dinâmica de grupo** e garantindo que o grupo se concentre na tarefa e na reflexão.
*   **Implicação para Mastermind/Peer Coaching:** O sucesso da metodologia depende da habilidade do facilitador em criar um ambiente de **segurança psicológica** e **responsabilidade** (accountability), que são essenciais para a honestidade e a profundidade das discussões entre pares.

---

### 12. Teoria Psicológica: Teoria da Aprendizagem Social e Autoeficácia

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Psicologia Comportamental, Educação | Social Learning Theory (e trabalhos subsequentes sobre Teoria Cognitiva Social) | Albert Bandura | 1977 | [https://www.wgu.edu/blog/guide-social-learning-theory-education2005.html][12] |

**Principais Contribuições Teóricas:**

*   **Teoria da Aprendizagem Social (SCT):** Fornece o mecanismo psicológico para a eficácia do Mastermind e do peer coaching. A aprendizagem ocorre através da **observação** (modelagem) e da **interação** social.
*   **Autoeficácia (Self-Efficacy):** O conceito central da SCT, definido como a crença na própria capacidade de executar tarefas e alcançar objetivos. O peer coaching e o Mastermind aumentam a autoeficácia através de:
    1.  **Experiências de Maestria Vicária:** Observar pares de status semelhante terem sucesso.
    2.  **Persuasão Social:** Receber encorajamento e *feedback* positivo do grupo.
*   **Implicação para Mastermind/Peer Coaching:** A eficácia desses grupos é amplamente explicada pela capacidade de criar um ambiente onde a **modelagem** e o **suporte social** elevam a autoeficácia dos membros, levando a um melhor desempenho.

---

### 13. Framework Conceitual: Comunidades de Prática (CoP)

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Sociologia, Aprendizagem Organizacional | Communities of Practice: Learning, Meaning, and Identity | Etienne Wenger | 1998 | [https://www.cambridge.org/core/books/communities-of-practice/70C12845012903774843799478794827][13] |

**Principais Contribuições Teóricas:**

*   **Comunidades de Prática (CoP):** Fornece um framework sociológico para entender como o aprendizado ocorre em grupos sociais. Mastermind groups e peer coaching são formas de CoP.
*   **Três Elementos de uma CoP:** O aprendizado em grupo é sustentado por:
    1.  **Domínio:** Um interesse comum compartilhado (ex: desenvolvimento de liderança, crescimento de negócios).
    2.  **Comunidade:** O relacionamento de apoio e a interação entre os membros.
    3.  **Prática:** Um repertório compartilhado de recursos, experiências e métodos.
*   **Mecanismo de Aprendizagem:** O aprendizado entre pares ocorre através da **participação periférica legítima** e da **negociação de significado** (mutual engagement, joint enterprise, shared repertoire). O Mastermind é eficaz porque é uma CoP focada em um domínio específico (o sucesso dos membros) e com uma prática estruturada (reuniões, *hot seats*).

---

### 14. Metodologia Prática: Action Learning (Aprendizagem-Ação)

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Desenvolvimento Gerencial, Aprendizagem Organizacional | ABC of action learning | Reg Revans | 2017 (Originalmente 1980s) | [https://www.taylorfrancis.com/books/mono/10.4324/9781315263533/abc-action-learning-reg-revans][14] |

**Principais Contribuições Teóricas/Metodológicas:**

*   **Action Learning (AL):** Uma metodologia de desenvolvimento gerencial baseada em grupos de pares (chamados *sets*) que se reúnem para trabalhar em problemas reais. É uma das estruturas mais antigas e formalizadas de aprendizado entre pares.
*   **Fórmula de Aprendizagem:** A teoria de Revans postula que o aprendizado (L) é igual ao Conhecimento Programado (P) mais o Questionamento (Q), ou **L = P + Q**. O Mastermind e o peer coaching maximizam o **Q** (questionamento e reflexão) em um ambiente de pares.
*   **Componentes Essenciais:** O AL, que é um precursor conceitual do Mastermind, requer:
    1.  Um problema real, complexo e urgente.
    2.  Um grupo de pares (o *set*).
    3.  Um processo de questionamento e reflexão.
    4.  Um compromisso com a ação.
    5.  Um facilitador (*set advisor*) que garante o processo, mas não fornece soluções.

---

### 15. Conceito Original: O Princípio Master-Mind

| Campo | Título | Autor(es) | Ano | URL |
| :--- | :--- | :--- | :--- | :--- |
| Desenvolvimento Pessoal, Filosofia do Sucesso | Think and Grow Rich | Napoleon Hill | 1937 | [https://archive.org/details/think-and-grow-rich-napoleon-hill/page/n7/mode/2up][15] |

**Principais Contribuições Teóricas:**

*   **Definição Original:** Introduz o conceito de **"Master Mind"** como "a coordenação de conhecimento e esforço, em um espírito de harmonia, entre duas ou mais pessoas, para a realização de um propósito definido."
*   **Mecanismo Psicológico (Sinergia):** Hill postula que a combinação de duas ou mais mentes cria uma terceira "mente invisível e intangível", uma força sinérgica que permite ao grupo acessar conhecimento e poder que não estariam disponíveis individualmente. Embora não seja uma teoria acadêmica, este é o primeiro registro do conceito.
*   **Base para Estruturas Modernas:** O princípio de Hill é a base filosófica para os modernos *peer advisory groups* e Mastermind groups, focando na **harmonia**, **propósito definido** e na **sinergia** criada pela inteligência coletiva do grupo.

---

## Síntese dos Achados e Conclusão

A pesquisa revela que os conceitos de Mastermind groups e Peer Coaching são manifestações práticas de um construto acadêmico mais amplo, denominado **Peer Development Groups (PDGs)** [1]. A eficácia dessas estruturas humanas e metodologias não-tecnológicas é solidamente fundamentada em teorias da **Psicologia** e do **Desenvolvimento Organizacional**.

### 1. Conceitos, Teorias e Frameworks Fundamentais

O sucesso dos Mastermind groups e do Peer Coaching reside na sua capacidade de criar um ambiente social e psicológico que acelera o desenvolvimento individual e coletivo.

#### A. Bases Psicológicas

As teorias psicológicas explicam os mecanismos internos de mudança:

*   **Teoria da Autodeterminação (SDT)** [5]: O ambiente de pares é eficaz porque satisfaz as três necessidades psicológicas básicas: **Autonomia** (o indivíduo escolhe o foco e a ação), **Competência** (o grupo fornece *feedback* e conhecimento para aprimoramento) e **Relacionamento** (o grupo oferece um senso de pertencimento e apoio mútuo).
*   **Teoria Cognitiva Social (SCT)** [12]: O grupo eleva a **Autoeficácia** dos membros. A observação de pares (experiências de **maestria vicária**) e o encorajamento social (persuasão social) reforçam a crença do indivíduo em sua capacidade de alcançar objetivos.
*   **Fatores Terapêuticos de Grupo (Yalom)** [9]: A dinâmica de grupo ativa fatores de mudança como a **Universalidade** (alívio ao saber que outros enfrentam problemas semelhantes), o **Altruísmo** (sentir-se útil ao ajudar um par) e a **Coesão de Grupo**, que é o pré-requisito para a aprendizagem interpessoal e a confiança.

#### B. Frameworks Conceituais e Metodológicos

Os frameworks conceituais fornecem a estrutura para a aplicação prática:

*   **Peer Development Groups (PDGs) - Framework I-P-O** [1]: Este modelo unificador analisa a eficácia do grupo através de **Inputs** (características dos membros e do grupo), **Processos** (dinâmica de grupo, reflexão, apoio) e **Outcomes** (desenvolvimento individual e organizacional).
*   **Peer Coaching Relacional** [2]: Enfatiza a **simetria de status** e a **reciprocidade** como elementos-chave. O processo é um ciclo de **construção de relacionamento**, **criação de sucesso** e **internalização da tática de aprendizagem**.
*   **Comunidades de Prática (CoP)** [13]: O Mastermind é uma CoP, onde o aprendizado é um processo social que ocorre através da **participação** em um **Domínio** compartilhado e da **negociação de significado** dentro da **Comunidade**.
*   **Action Learning (AL)** [14]: Uma metodologia prática que se baseia na fórmula **L = P + Q** (Aprendizagem = Conhecimento Programado + Questionamento). O grupo de pares atua como um "set" para o questionamento e a reflexão sobre problemas reais, sendo um dos precursores formais do Mastermind.
*   **Princípio Master-Mind (Original)** [15]: A base filosófica que postula a **sinergia** de duas ou mais mentes em harmonia, resultando em uma "terceira mente" com maior poder criativo e intelectual (Inteligência Coletiva [8]).

### 2. Cobertura Geográfica e Evidências

A maioria das fontes acadêmicas e dos estudos empíricos sobre Mastermind groups (sob o rótulo de *Executive Peer Advisory Groups*) e Peer Coaching provém de contextos **Anglo-Saxões** (Estados Unidos, Reino Unido) [1] [2] [7] [14].

*   **Evidência de Eficácia:** Estudos empíricos e meta-análises [4] [6] [10] demonstram que o coaching de grupo e o aprendizado entre pares são eficazes para o desenvolvimento de habilidades, aumento da autoeficácia e melhoria da realização de metas, embora o coaching individual possa ser superior em alguns resultados específicos [6].

### 3. Fontes Documentadas (Total: 15)

| # | Título | Autor(es) | Ano | Campo |
| :--- | :--- | :--- | :--- | :--- |
| 1 | Unveiling the nature of peer development groups: A systematic review, conceptual framework, and research pathways | Terekhin, R., & Aurora, S. R. | 2025 | Psicologia Organizacional |
| 2 | Peer coaching: A relational process for accelerating career learning | Parker, P., Hall, D. T., & Kram, K. E. | 2008 | Desenvolvimento de Carreira |
| 3 | Skill-based development of entrepreneurs and the role of personal and peer group coaching in enterprise development | Kutzhanova, N., Lyons, T. S., & Lichtenstein, G. A. | 2009 | Empreendedorismo |
| 4 | EXECUTIVE PEER ADVISORY GROUPS | Feghali, A. | 2022 | Liderança Executiva |
| 5 | Self-Determination Theory and the Facilitation of Intrinsic Motivation, Social Development, and Well-Being | Ryan, R. M., & Deci, E. L. | 2000 | Psicologia da Motivação |
| 6 | Comparing the effectiveness of individual coaching, self-coaching, and group training: How leadership makes the difference | Losch, S., et al. | 2016 | Psicologia Aplicada |
| 7 | Instructional Coaching: A Partnership Approach to Improving Instruction (Princípios de Parceria) | Knight, J. | 2007/2013 | Metodologia de Coaching |
| 8 | Collective intelligence | Malone, T. W., & Woolley, A. W. | 2020 | Ciência da Organização |
| 9 | The Theory and Practice of Group Psychotherapy | Yalom, I. D., & Leszcz, M. | 2005 | Psicologia de Grupo |
| 10 | Group coaching: a new way of constructing leadership identity? (Referência ao UIF) | Passmore, J., & Law, H. | 2009 | Coaching de Grupo |
| 11 | The pedagogy of action learning facilitation–a critique of the role of the facilitator in an organisational leadership programme | Sanyal, C. | 2018 | Desenvolvimento Organizacional |
| 12 | Social Learning Theory (e trabalhos subsequentes sobre SCT) | Bandura, A. | 1977 | Psicologia Comportamental |
| 13 | Communities of Practice: Learning, Meaning, and Identity | Wenger, E. | 1998 | Sociologia da Aprendizagem |
| 14 | ABC of action learning | Revans, R. | 2017 | Action Learning |
| 15 | Think and Grow Rich (Conceito Master-Mind) | Hill, N. | 1937 | Filosofia do Sucesso |

## Referências

[1]: https://onlinelibrary.wiley.com/doi/10.1002/job.2845 "Terekhin, R., & Aurora, S. R. (2025). Unveiling the nature of peer development groups: A systematic review, conceptual framework, and research pathways. Journal of Organizational Behavior."
[2]: https://journals.aom.org/doi/abs/10.5465/AMLE.2008.35882189 "Parker, P., Hall, D. T., & Kram, K. E. (2008). Peer coaching: A relational process for accelerating career learning. Academy of Management Learning & Education."
[3]: https://journals.sagepub.com/doi/abs/10.1177/0891242409336547 "Kutzhanova, N., Lyons, T. S., & Lichtenstein, G. A. (2009). Skill-based development of entrepreneurs and the role of personal and peer group coaching in enterprise development. Entrepreneurship & Regional Development."
[4]: https://digital.sandiego.edu/cgi/viewcontent.cgi?article=1935&context=dissertations "Feghali, A. (2022). EXECUTIVE PEER ADVISORY GROUPS. University of San Diego Digital Repository."
[5]: https://selfdeterminationtheory.org/SDT/documents/2000_DeciRyan_PIWhatWhy.pdf "Ryan, R. M., & Deci, E. L. (2000). Self-Determination Theory and the Facilitation of Intrinsic Motivation, Social Development, and Well-Being. American Psychologist."
[6]: https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2016.00629/full "Losch, S., Traut-Mattausch, E., Mühlberger, M. D., & Weber, W. G. (2016). Comparing the effectiveness of individual coaching, self-coaching, and group training: How leadership makes the difference. Frontiers in Psychology."
[7]: https://www.instructionalcoaching.com/jim-knight-coaching-institute/ "Knight, J. (2007/2013). Instructional Coaching: A Partnership Approach to Improving Instruction (e trabalhos subsequentes sobre Princípios de Parceria)."
[8]: https://libros.metabiblioteca.org/bitstreams/d8bc08aa-c0c8-420b-9d20-95c0ffefe6b3/download "Malone, T. W., & Woolley, A. W. (2020). Collective intelligence. Cambridge Handbook of the Learning Sciences."
[9]: https://www.wiley.com/en-us/The+Theory+and+Practice+of+Group+Psychotherapy%2C+5th+Edition-p-9780465092840 "Yalom, I. D., & Leszcz, M. (2005). The Theory and Practice of Group Psychotherapy (5ª Edição). Basic Books."
[10]: https://www.researchgate.net/publication/277359825_Group_coaching_A_new_way_of_constructing_leadership_identity "Passmore, J., & Law, H. (2009). Group coaching: a new way of constructing leadership identity? Coaching: An International Journal of Theory, Research and Practice."
[11]: https://repository.mdx.ac.uk/item/88157 "Sanyal, C. (2018). The pedagogy of action learning facilitation–a critique of the role of the facilitator in an organisational leadership programme (Doctoral dissertation). Middlesex University."
[12]: https://www.wgu.edu/blog/guide-social-learning-theory-education2005.html "Bandura, A. (1977). Social Learning Theory (e trabalhos subsequentes sobre Teoria Cognitiva Social)."
[13]: https://www.cambridge.org/core/books/communities-of-practice/70C12845012903774843799478794827 "Wenger, E. (1998). Communities of Practice: Learning, Meaning, and Identity. Cambridge University Press."
[14]: https://www.taylorfrancis.com/books/mono/10.4324/9781315263533/abc-action-learning-reg-revans "Revans, R. (2017). ABC of action learning. Routledge."
[15]: https://archive.org/details/think-and-grow-rich-napoleon-hill/page/n7/mode/2up "Hill, N. (1937). Think and Grow Rich. The Ralston Society."

# Análise Teórica e Metodológica da Lacuna Intenção-Ação e das Intenções de Implementação (Peter M. Gollwitzer)

## Introdução

A **lacuna intenção-ação** (*Intention-Action Gap*), também referida como lacuna intenção-comportamento, representa um dos desafios centrais na psicologia da motivação e da volição. O fenômeno descreve a discrepância observada entre a formulação de uma **intenção de meta** (*goal intention*) — o desejo de alcançar um resultado específico (e.g., "Pretendo fazer mais exercícios") — e a efetiva tradução dessa intenção em **comportamento** [1]. Pesquisas iniciais demonstraram que as intenções de meta, por si só, explicam uma porção modesta da variância no comportamento subsequente, tipicamente entre 20% e 30% [1] [14].

Para superar essa ineficácia volitiva, Peter M. Gollwitzer propôs, em 1999, a estratégia de autorregulação conhecida como **Intenções de Implementação** (*Implementation Intentions* - IIs) [1]. As IIs são planos específicos que visam proteger a intenção de meta de obstáculos e distrações, automatizando o início da ação em um contexto predefinido. Este relatório detalha os conceitos teóricos, os *frameworks* conceituais e as metodologias práticas não-tecnológicas associadas a essa poderosa ferramenta de mudança comportamental.

## 1. Conceitos Fundamentais e Framework Teórico

### 1.1. Intenções de Implementação (IIs)

As Intenções de Implementação são planos formulados na estrutura **"Se (situação crítica X surgir), então (eu iniciarei a resposta dirigida à meta Y!)"** [1]. Essa formulação é crucial, pois liga uma **situação crítica antecipada** (o gatilho, o "Se") a uma **resposta dirigida à meta** (a ação, o "Então"). A função primária das IIs é delegar o controle da ação a estímulos situacionais específicos, transformando a busca da meta de um processo consciente e esforçado para um processo **automático** e eficiente [1] [5].

### 1.2. O Modelo Rubicon das Fases de Ação

O conceito de IIs está inserido no *framework* teórico mais amplo do **Modelo Rubicon das Fases de Ação** (*Rubicon Model of Action Phases*), desenvolvido por Heinz Heckhausen e Peter M. Gollwitzer [4]. Este modelo postula uma distinção fundamental entre as fases **motivacionais** (relacionadas à escolha da meta, o "porquê") e as fases **volicionais** (relacionadas à implementação da meta, o "como") [4].

O processo de busca de metas é dividido em quatro fases, separadas por "Rubicons" (pontos de não-retorno):
1.  **Fase Pré-Decisional (Motivacional):** O indivíduo pondera desejos e viabilidade da meta.
2.  **Fase Pós-Decisional (Volitiva):** Após a decisão de perseguir a meta (o primeiro Rubicon), o foco muda para o planejamento. É nesta fase que as **Intenções de Implementação** são formadas.
3.  **Fase de Ação (Volitiva):** Execução da ação.
4.  **Fase Pós-Ação (Motivacional):** Avaliação do resultado.

As IIs atuam como a ponte volitiva (o segundo Rubicon) que conecta a intenção de meta à ação, sendo o mecanismo teórico central para superar a lacuna intenção-ação [4].

## 2. Mecanismos Psicológicos e Evidências Científicas

### 2.1. Mecanismos de Automaticidade e Acessibilidade

O mecanismo psicológico subjacente à eficácia das IIs reside na criação de uma forte **ligação associativa** entre o estímulo situacional (o "Se") e a resposta comportamental (o "Então") [5] [7]. Essa ligação resulta em dois efeitos principais:
*   **Acessibilidade Aumentada do Estímulo:** O estímulo crítico especificado no plano "Se-Então" torna-se mentalmente mais acessível e é detectado de forma mais eficiente [5].
*   **Iniciação Automática da Resposta:** Quando o estímulo é encontrado, a resposta comportamental é eliciada de forma **automática**, sem a necessidade de deliberação consciente ou esforço volitivo [1] [5].

Estudos que utilizam correlatos fisiológicos, como fMRI, apoiam essa hipótese, demonstrando que as IIs modulam a atividade cerebral, sugerindo que o processo de autorregulação se torna mais eficiente e menos dependente de recursos cognitivos de alto nível [5].

### 2.2. Evidências de Eficácia (Meta-Análises)

A robustez teórica das IIs é sustentada por uma vasta base de evidências empíricas, consolidadas em meta-análises:

| Fonte | Ano | Número de Testes | Tamanho do Efeito (*d*) | Principal Conclusão |
| :--- | :--- | :--- | :--- | :--- |
| Gollwitzer & Sheeran [2] | 2006 | 94 | 0.65 (Médio-Grande) | Confirma a eficácia das IIs na promoção do alcance de metas, sendo eficazes na **iniciação** e na **proteção** da busca da meta. |
| Sheeran et al. [3] | 2024/2025 | 642 | (A ser detalhado) | Maior meta-análise até o momento. Reafirma a eficácia e examina as condições de contorno (*quando* e *como*) para a máxima eficácia do planejamento. |

A meta-análise seminal de 2006 estabeleceu um tamanho de efeito de *d* = 0.65, considerado de magnitude média a grande, demonstrando que as IIs são uma das estratégias de mudança de comportamento mais eficazes e escaláveis [2].

## 3. Metodologias Práticas e Estruturas Humanas

As IIs formam a base de diversas metodologias práticas e são amplamente aplicadas em estruturas humanas de apoio, como *coaching* e intervenções clínicas, sem depender de tecnologia.

### 3.1. Contraste Mental com Intenções de Implementação (MCII / WOOP)

O *framework* **MCII** (*Mental Contrasting with Implementation Intentions*), desenvolvido por Gabriele Oettingen em colaboração com Gollwitzer, é uma metodologia prática que combina duas estratégias de autorregulação [6]:
1.  **Contraste Mental (MC):** O indivíduo contrasta o **Resultado** desejado (*Outcome*) com os **Obstáculos** internos (*Obstacle*) que podem impedir sua realização. Isso aumenta a **motivação** se a expectativa de sucesso for alta.
2.  **Intenções de Implementação (II):** A formulação do **Plano** (*Plan*) "Se-Então" para superar o obstáculo.

A aplicação prática dessa metodologia é conhecida pelo acrônimo **WOOP** (*Wish, Outcome, Obstacle, Plan*), sendo uma ferramenta de intervenção de baixo custo e alta escalabilidade, utilizada em contextos de saúde, educação e desenvolvimento pessoal [6].

### 3.2. Aplicações em Estruturas Humanas

As IIs são aplicadas com sucesso em diversos domínios, reforçando o foco em estruturas humanas e sistemas sociais:
*   **Saúde e Clínica:** Utilizadas em intervenções para promover a **atividade física** [10], a adesão a dietas e a redução do uso de substâncias [9]. Profissionais de saúde mental e terapeutas são treinados para promover o uso de IIs na prática clínica [11].
*   **Contexto Organizacional e Trabalho:** Aplicadas para promover a formação de novos hábitos e a mudança de comportamento em ambientes de trabalho, demonstrando ser uma ferramenta de intervenção eficaz e não-tecnológica [13].
*   **Educação e Desempenho Acadêmico:** Utilizadas para combater a procrastinação e melhorar o desempenho acadêmico, ligando gatilhos situacionais (e.g., "Se eu terminar a aula de matemática") a respostas de estudo (e.g., "Então eu abrirei o livro de física") [15].
*   **Comportamento Pró-Ambiental:** O escopo das IIs se estende a comportamentos complexos, como a adoção de práticas sustentáveis, sendo mais eficazes quando o comportamento exige esforço ou tempo [12].

## 4. Detalhamento das Fontes Acadêmicas

A tabela a seguir consolida as 15 fontes acadêmicas e teóricas utilizadas nesta pesquisa, detalhando suas principais contribuições.

| ID | Título | Autor(es) | Ano | URL | Contribuições Teóricas Principais |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **[1]** | Implementation Intentions: Strong Effects of Simple Plans | Peter M. Gollwitzer | 1999 | [Link](https://www.prospectivepsych.org/sites/default/files/pictures/Gollwitzer_Implementation-intentions-1999.pdf) | Artigo seminal. Define IIs ("Se-Então") e o *Intention-Action Gap*. Postula o mecanismo de automaticidade e acessibilidade do estímulo. |
| **[2]** | Implementation intentions and goal achievement: A meta-analysis of effects and processes | P. M. Gollwitzer & P. Sheeran | 2006 | [Link](https://www.sciencedirect.com/science/article/pii/S0065260106380021) | Meta-análise seminal (94 testes). Confirma a eficácia com *d* = 0.65. Destaca a função de **iniciação** e **proteção** da busca da meta. |
| **[3]** | The when and how of planning: Meta-analysis of the scope and components of implementation intentions in 642 tests | P. Sheeran, O. Listrom, P. M. Gollwitzer, et al. | 2024/2025 | [Link](https://www.tandfonline.com/doi/full/10.1080/10463283.2024.2334563) | Meta-análise atualizada (642 testes). Examina as condições de contorno (*quando* e *como*) para a máxima eficácia das IIs. |
| **[4]** | The Rubicon Model of Action Phases | H. Heckhausen & P. M. Gollwitzer | 1987 | (Conceituação Inicial) | *Framework* conceitual que distingue fases **motivacionais** e **volicionais**. Contextualiza as IIs como a ponte volitiva que supera o *Intention-Action Gap*. |
| **[5]** | Promoting the translation of intentions into action by implementation intentions: behavioral effects and physiological correlates | F. Wieber, J. L. Thürmer, & P. M. Gollwitzer | 2015 | [Link](https://pmc.ncbi.nlm.nih.gov/articles/PMC4500900/) | Estudo sobre os mecanismos. Demonstra que as IIs aumentam a **acessibilidade mental** do estímulo crítico e a **automaticidade** da resposta. |
| **[6]** | Mental Contrasting with Implementation Intentions (MCII) / WOOP | G. Oettingen & P. M. Gollwitzer | (Diversas) | (Metodologia Prática) | Metodologia prática que combina **Contraste Mental** (motivação) e **IIs** (volição). O acrônimo WOOP (*Wish, Outcome, Obstacle, Plan*) é a aplicação prática. |
| **[7]** | How do implementation intentions promote goal attainment? A review and an integrative framework | T. L. Webb & P. Sheeran | 2007 | [Link](https://www.sciencedirect.com/science/article/abs/pii/S002210310600028X) | Revisão que propõe um *framework* integrativo, focando na **acessibilidade aumentada** e na **função de escudo** das IIs contra distrações. |
| **[8]** | Measuring implementation intentions in the context of the theory of planned behavior | J. Rise, M. Thompson, & P. Sheeran | 2003 | [Link](https://onlinelibrary.wiley.com/doi/abs/10.1111/1467-9450.00325) | Integração teórica. Demonstra que as IIs oferecem **valor preditivo adicional** sobre o comportamento, além da intenção comportamental da TPB. |
| **[9]** | Implementation intention and action planning interventions in health contexts: State of the research and proposals for the way forward | M. S. Hagger & A. Luszczynska | 2014 | [Link](https://iaap-journals.onlinelibrary.wiley.com/doi/abs/10.1111/aphw.12017) | Revisão sistemática sobre a aplicação de IIs em **intervenções de saúde**, reconhecendo-as como estratégias eficazes de mudança de comportamento. |
| **[10]** | Impact of implementation intentions on physical activity: A systematic review and meta-analysis | M. A. V. da Silva, et al. | 2018 | [Link](https://pubmed.ncbi.nlm.nih.gov/30427874/) | Evidência empírica. Confirma a eficácia das IIs na promoção da **atividade física** em adultos, um exemplo de aplicação em saúde. |
| **[11]** | Assessing and promoting the use of implementation intentions in clinical practice | P. G. S. Duhne, A. J. Horan, C. Ross, & T. L. Webb | 2020 | [Link](https://www.sciencedirect.com/science/article/pii/S0277953620307097) | Foco em **estruturas humanas**. Destaca a aplicação e o treinamento de terapeutas e profissionais de saúde mental no uso das IIs. |
| **[12]** | A meta-analysis of the effectiveness of implementation intentions for pro-environmental behavior adoption | I. Carrero, et al. | 2025 (Previsão) | [Link](https://www.sciencedirect.com/science/article/abs/pii/S2352550925000260) | Expansão do escopo para **comportamento pró-ambiental**. Sugere maior eficácia para comportamentos que exigem mais esforço. |
| **[13]** | Promoting new habits at work through implementation intentions | N. Trenz, et al. | 2024 | [Link](https://bpspsychub.onlinelibrary.wiley.com/doi/10.1111/joop.12540) | Aplicação em **contexto organizacional**. Demonstra a eficácia das IIs para a formação de novos hábitos no ambiente de trabalho. |
| **[14]** | Implementation Intentions | P. M. Gollwitzer & G. Oettingen | 2019 | [Link](https://www.psy.uni-hamburg.de/arbeitsbereiche/paedagogische-psychologie-und-motivation/personen/oettingen-gabriele/dokumente/gollwitzer-oettingen-2019-implementation-intentions.pdf) | Revisão atualizada. Reitera que as intenções de meta explicam apenas cerca de 28% da variância no comportamento, reforçando a necessidade das IIs. |
| **[15]** | What Influences Implementation Intentions in an Academic Learning Context--The Roles of Goal Intentions, Procrastination, and Experience. | L. Sommer & M. Haug | 2012 | [Link](https://files.eric.ed.gov/fulltext/EJ1055348.pdf) | Estudo empírico em **contexto acadêmico**. Aplica IIs para melhorar o desempenho e combater a procrastinação. |

## Referências

[1] P. M. Gollwitzer, "Implementation Intentions: Strong Effects of Simple Plans," *American Psychologist*, 1999.
[2] P. M. Gollwitzer & P. Sheeran, "Implementation intentions and goal achievement: A meta-analysis of effects and processes," *Advances in Experimental Social Psychology*, 2006.
[3] P. Sheeran, O. Listrom, P. M. Gollwitzer, et al., "The when and how of planning: Meta-analysis of the scope and components of implementation intentions in 642 tests," *European Review of Social Psychology*, 2024/2025.
[4] H. Heckhausen & P. M. Gollwitzer, "The Rubicon Model of Action Phases," *Motivation and Action*, 1987.
[5] F. Wieber, J. L. Thürmer, & P. M. Gollwitzer, "Promoting the translation of intentions into action by implementation intentions: behavioral effects and physiological correlates," *Frontiers in Human Neuroscience*, 2015.
[6] G. Oettingen & P. M. Gollwitzer, "Mental Contrasting with Implementation Intentions (MCII) / WOOP," *Diversas Publicações*, (Diversas).
[7] T. L. Webb & P. Sheeran, "How do implementation intentions promote goal attainment? A review and an integrative framework," *Journal of Experimental Social Psychology*, 2007.
[8] J. Rise, M. Thompson, & P. Sheeran, "Measuring implementation intentions in the context of the theory of planned behavior," *European Journal of Social Psychology*, 2003.
[9] M. S. Hagger & A. Luszczynska, "Implementation intention and action planning interventions in health contexts: State of the research and proposals for the way forward," *Applied Psychology: Health and Well-Being*, 2014.
[10] M. A. V. da Silva, et al., "Impact of implementation intentions on physical activity: A systematic review and meta-analysis," *PLoS One*, 2018.
[11] P. G. S. Duhne, A. J. Horan, C. Ross, & T. L. Webb, "Assessing and promoting the use of implementation intentions in clinical practice," *Social Science & Medicine*, 2020.
[12] I. Carrero, et al., "A meta-analysis of the effectiveness of implementation intentions for pro-environmental behavior adoption," *Sustainable Production and Consumption*, 2025 (Previsão).
[13] N. Trenz, et al., "Promoting new habits at work through implementation intentions," *Journal of Occupational and Organizational Psychology*, 2024.
[14] P. M. Gollwitzer & G. Oettingen, "Implementation Intentions," *Handbook of Self-Regulation: Research, Theory, and Applications*, 2019.
[15] L. Sommer & M. Haug, "What Influences Implementation Intentions in an Academic Learning Context--The Roles of Goal Intentions, Procrastination, and Experience," *International Journal of Higher Education*, 2012.

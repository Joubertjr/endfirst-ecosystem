# Análise Detalhada: Falha de Implementação em Programas de Saúde Pública - Perspectivas Teóricas e Culturais

## 1. Introdução e Distinções Conceituais

A **falha de implementação** em programas de saúde pública é um fenômeno complexo que transcende a simples ineficácia de uma intervenção. A literatura acadêmica, especialmente nas ciências sociais, enfatiza a necessidade de distinguir a **falha de intervenção** (o programa não funciona, mesmo que executado perfeitamente) da **falha de implementação** (o programa não foi executado conforme o planejado ou não foi adotado), e da **falha de programa/teoria** (a teoria subjacente ao programa está incorreta) [Fonte 9]. A falha de implementação é, portanto, um problema de **processo** e **contexto**, e não de eficácia intrínseca [Fonte 8].

## 2. Teorias Psicológicas e Comportamentais: O Foco no Indivíduo

As teorias psicológicas buscam explicar a falha de implementação a partir do nível individual, focando na adoção e adesão dos profissionais de saúde e do público-alvo.

*   **Teoria do Comportamento Planejado (TPB) e Framework Determinante Teórico (TDF):** A TPB postula que a intenção de um indivíduo de realizar um comportamento é o principal preditor desse comportamento, sendo influenciada pela **atitude**, **norma subjetiva** e **controle comportamental percebido** [Fonte 11]. A falha de implementação ocorre quando as estratégias não conseguem influenciar esses fatores psicossociais. O TDF, mais abrangente, categoriza barreiras de implementação em domínios como conhecimento, crenças, emoções e fatores ambientais, permitindo a seleção de **Técnicas de Mudança de Comportamento (BCTs)** específicas para superar barreiras de nível individual [Fonte 3]. Contudo, essas teorias são criticadas por serem insuficientes, pois negligenciam o **contexto organizacional e externo** (fatores sociais e institucionais) [Fonte 3].

## 3. Teorias Sociológicas e Organizacionais: O Foco no Sistema

As falhas de implementação são frequentemente enraizadas em estruturas sociais e organizacionais que resistem à mudança.

*   **Teoria do Processo de Normalização (NPT):** A NPT analisa o trabalho que os indivíduos e grupos realizam para **integrar** novas práticas na rotina (o processo de *normalização*). A **falha de implementação** é vista como a incapacidade dos participantes de realizar o **trabalho adaptativo** necessário para sustentar um padrão ordenado de interações sociais e relações diante da complexidade [Fonte 7]. O sucesso depende da **coerência** (entendimento da prática), **participação cognitiva** (engajamento), **ação coletiva** (trabalho em conjunto) e **monitoramento reflexivo** (avaliação e ajuste).
*   **Teoria das Lógicas Institucionais:** Esta teoria explica a falha pela existência de **lógicas institucionais conflitantes** (e.g., a lógica burocrática do governo versus a lógica profissional dos médicos) que guiam as ações dos atores [Fonte 5, 15]. O conflito de lógicas leva a **tensões organizacionais** e à **resistência**, resultando em desvios ou abandono da intervenção. A pressão para adotar práticas (isomorfismo) pode falhar se as lógicas subjacentes não forem alinhadas [Fonte 15].
*   **Cultura Organizacional e Contexto:** A **cultura organizacional** é o fator contextual mais crítico para o sucesso ou falha [Fonte 6, 12]. A falha é associada à **ausência de uma cultura de aprendizado**, **resistência à inovação** e falta de clareza sobre valores organizacionais. A **liderança** atua como um mediador ou moderador, influenciando outros fatores contextuais como recursos, comunicação e a presença de **campeões** (*champions*) [Fonte 12].

## 4. Teorias Antropológicas e Culturais: O Foco no Contexto

A falha de implementação em contextos de saúde global é frequentemente um problema de **desalinhamento cultural**.

*   **Modelos Explicativos de Doença (EMI) e Barreiras Culturais:** A falha pode ser causada pelo **desalinhamento** entre a intervenção e as **crenças e comportamentos locais** [Fonte 14]. Os EMI, propostos por Arthur Kleinman, referem-se às crenças que os indivíduos e comunidades têm sobre a etiologia, o curso e o tratamento de uma doença. A negligência desses modelos e normas sociais (e.g., crenças sobre as causas da doença, como feitiçaria ou desequilíbrio) atua como uma **barreira cultural** à adoção de práticas de saúde, levando à falha [Fonte 14].
*   **Adaptação Cultural:** A **adaptação cultural deficiente** de intervenções é um preditor de falha [Fonte 4]. Frameworks como o **Cultural Adaptation Checklist (CAC)** buscam garantir que a intervenção mantenha a fidelidade aos seus componentes essenciais, ao mesmo tempo que se torna relevante para o contexto cultural específico.

## 5. Fatores Macrossociais e Iniquidades

A falha de implementação pode ser estrutural, refletindo forças sociais e políticas mais amplas.

*   **Teoria da Causa Fundamental (*Fundamental Cause Theory*):** Esta teoria sociológica sugere que as intervenções podem falhar em reduzir iniquidades porque os mecanismos que influenciam os resultados de saúde operam em múltiplos níveis e novas vias para iniquidades podem surgir, mesmo após intervenções bem-sucedidas [Fonte 2]. A falha de implementação, neste caso, é uma **falha de sustentabilidade** em lidar com as **forças sociais, políticas e econômicas** que estruturam as oportunidades de saúde.
*   **Poder e Política:** A implementação não é um processo neutro, mas um campo de batalha político. A **falha de implementação** em políticas de saúde pode surgir de **perspectivas conflitantes** e **desequilíbrios de poder** entre os atores envolvidos (políticos, gestores, profissionais, comunidade), refletindo a **natureza política** da tomada de decisão [Fonte 13].

## 6. Frameworks Metodológicos para Análise de Falhas

*   **Avaliação Realista (Realist Evaluation):** Baseada no **Realismo Crítico**, esta metodologia busca entender *por que* e *como* uma intervenção funciona (ou falha) em um contexto específico, focando nas **Configurações Contexto-Mecanismo-Resultado (CMO)** [Fonte 1, 10]. A falha de implementação ocorre quando os mecanismos desejados não são ativados devido a um **contexto inadequado** [Fonte 10]. Este framework é essencial para analisar a complexidade e evitar a falha ao considerar a interação dinâmica entre a intervenção e o ambiente.

## 7. Conclusão: Evidências de Por Que as Coisas Falham

As evidências empíricas e teóricas convergem para a conclusão de que a falha de implementação em saúde pública é multifatorial e raramente se deve a uma única causa. As principais razões para a falha, focadas em sistemas humanos e sociais, são:

1.  **Desalinhamento Contextual e Cultural:** Falha em adaptar a intervenção às **crenças locais (EMI)**, **normas sociais** e **cultura organizacional** [Fontes 4, 12, 14].
2.  **Conflito Estrutural:** Existência de **lógicas institucionais conflitantes** e **desequilíbrios de poder** que impedem a normalização da prática [Fontes 5, 7, 13, 15].
3.  **Foco Exclusivo no Indivíduo:** Negligência dos fatores contextuais e sistêmicos, focando apenas em mudar o comportamento individual (limitação das teorias comportamentais) [Fontes 3, 11].
4.  **Incapacidade de Adaptação:** Falha em realizar o **trabalho adaptativo** necessário para integrar a nova prática na rotina diária (NPT) [Fonte 7].
5.  **"Gap Saber-Fazer" (*Know-Do Gap*):** A persistente lacuna entre a evidência disponível e a prática real, exacerbada por barreiras organizacionais e de liderança [Fonte 12].

A superação da falha de implementação exige, portanto, uma abordagem que integre as perspectivas psicológica, sociológica e antropológica, reconhecendo a implementação como um processo político e socialmente situado.

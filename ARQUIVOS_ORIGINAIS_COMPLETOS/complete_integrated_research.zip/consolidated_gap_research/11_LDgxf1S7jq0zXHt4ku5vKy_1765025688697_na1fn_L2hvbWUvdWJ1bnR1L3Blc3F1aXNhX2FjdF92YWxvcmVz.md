# Pesquisa Acadêmica: Acceptance and Commitment Therapy (ACT) e Valores Pessoais

## Fontes Acadêmicas Selecionadas (N=15)

| ID | Título | Autor(es) | Ano | URL/Referência | Principais Contribuições Teóricas |
| :---: | :--- | :--- | :---: | :--- | :--- |
| 1 | Acceptance and commitment therapy: An experiential approach to behavior change | Hayes, S. C., Strosahl, K. D., & Wilson, K. G. | 1999 | psycnet.apa.org/record/1999-04037-000 | Obra seminal que estabelece o ACT como uma abordagem psicoterapêutica contextual-comportamental. Apresenta os fundamentos do modelo Hexaflex e a meta de aumentar a **Flexibilidade Psicológica**. |
| 2 | Acceptance and commitment therapy, relational frame theory, and the third wave of behavioral and cognitive therapies | Hayes, S. C. | 2004 | sciencedirect.com/science/article/pii/S0005789404800133 | Artigo fundamental que posiciona o ACT como parte da "terceira onda" das terapias cognitivo-comportamentais. Explica a base teórica do ACT na **Teoria do Enquadramento Relacional (RFT)**, que explica a fusão cognitiva e a esquiva experiencial. |
| 3 | Values work in acceptance and commitment therapy | Wilson, K. G., & Murrell, A. R. | 2004 | books.google.com/books?hl=en&lr=&id=KyJpNb1rBBYC&oi=fnd&pg=PA120 | Detalha o papel central dos **valores pessoais** no ACT, definindo-os como direções de vida escolhidas livremente e que guiam a ação comprometida. Discute a conexão entre intervenções baseadas em valores e a terapia comportamental. |
| 4 | Valuing in ACT | Dahl, J. A. | 2015 | sciencedirect.com/science/article/abs/pii/S2352250X15001062 | Analisa o processo de **"valuing"** (valorização) dentro do ACT, enfatizando que os valores não são metas a serem alcançadas, mas sim qualidades de ação contínuas que fornecem um contexto motivacional para a mudança de comportamento. |
| 5 | A systematic review of values measures in acceptance and commitment therapy research | Reilly, E. D., Ritzert, T. R., Scoglio, A. A. J., & Mote, J. | 2019 | sciencedirect.com/science/article/pii/S2212144718302813 | Revisão sistemática que avalia a utilidade e eficácia de medidas quantitativas para **avaliar valores** no contexto de pesquisa do ACT, destacando a importância da medição para a validação empírica do modelo. |
| 6 | A systematic review of values interventions in acceptance and commitment therapy | Rahal, G. M., & Gon, M. C. C. | 2020 | dialnet.unirioja.es/servlet/articulo?codigo=7615058 | Revisão sistemática focada nas **intervenções de valores** utilizadas no ACT, examinando se o treinamento explícito sobre o que são valores a partir da perspectiva do ACT contribui para os resultados terapêuticos. |
| 7 | Acceptance and Commitment Therapy Processes and Mediation | Arch, J. J. | 2022 | pmc.ncbi.nlm.nih.gov/articles/PMC10665126/ | Visão geral recente que reafirma os **seis processos centrais do Hexaflex** (aceitação, desfusão cognitiva, contato com o momento presente, self como contexto, valores e ação comprometida) como elementos interconectados que promovem a Flexibilidade Psicológica. |
| 8 | Values in acceptance and commitment therapy | LeJeune, J., & Luoma, J. | 2023 | psycnet.apa.org/record/2024-14479-012 | Capítulo que descreve o trabalho com valores como um componente fundamental do ACT, analisando-o através das lentes da **Ciência Comportamental Contextual (CBS)** e da RFT. |
| 9 | Disentangling components of flexibility via the hexaflex model: Development and validation of the Multidimensional Psychological Flexibility Inventory (MPFI) | Rolffs, J. L., et al. | 2018 | journals.sagepub.com/doi/abs/10.1177/1073191116645905 | Desenvolve e valida o Inventário Multidimensional de Flexibilidade Psicológica (MPFI), que avalia as **12 dimensões** (seis de flexibilidade e seis de inflexibilidade) do modelo Hexaflex, contribuindo para a operacionalização do construto. |
| 10 | Flexibly and/or inflexibly embracing life: Identifying fundamental approaches to life with latent profile analyses on the dimensions of the Hexaflex model | Stabbe, O. K., et al. | 2019 | sciencedirect.com/science/article/abs/pii/S2212144718302229 | Utiliza análise de perfil latente para identificar **perfis de Flexibilidade Psicológica/Inflexibilidade** baseados nas dimensões do Hexaflex, demonstrando que diferentes combinações dos processos se relacionam com resultados psicológicos distintos. |
| 11 | Acceptance and mindfulness at work: Applying acceptance and commitment therapy and relational frame theory to organizational behavior management | Hayes, S. C., et al. | 2013 | books.google.com/books?hl=en&lr=&id=Rdu2AQAAQBAJ&oi=fnd&pg=PA1 | Aplica os princípios do ACT e da RFT à **gestão do comportamento organizacional**, mostrando como a Flexibilidade Psicológica pode ser promovida em contextos de trabalho para melhorar o desempenho e o bem-estar. |
| 12 | Relational Frame Theory: A Post-Skinnerian Account of Human Language and Cognition | Hayes, S. C., & Barnes-Holmes, D. | 2001 | amazon.com/Relational-Frame-Theory-Post-Skinnerian-Cognition/dp/0306466007 | Livro que detalha a **RFT**, a teoria comportamental da linguagem e cognição que serve como base filosófica e teórica para o ACT. Explica como a linguagem cria a fusão cognitiva e a esquiva experiencial. |
| 13 | Acceptance and Commitment Therapy: An Experiental Approach to Behavior Change (Review of Hayes, Strosahl, & Wilson, 1999) | Delprato, D. J. | 2001 | go.gale.com/ps/i.do?id=GALE%7CA73001356 | Análise crítica da obra seminal do ACT, destacando a luta da terapia contra o **"lado sombrio da linguagem"** e a **indeterminação comunicativa**, e como o ACT busca mudar a função do estímulo para reduzir o comportamento governado por regras. |
| 14 | Working With Values: An Overview of Approaches and Considerations in Their Implementation in Acceptance and Commitment Therapy | Berkout, O. V., et al. | 2021 | pmc.ncbi.nlm.nih.gov/articles/PMC8854463/ | Apresenta uma visão geral das **abordagens e exercícios práticos** para o trabalho com valores no ACT, como o "Epitáfio" e o "Caminho da Vida", focando na utilidade do trabalho de valores como foco terapêutico. |
| 15 | Personality Traits and Personal Values: A Meta-Analysis | Parks-Leduc, L., Feldman, G., & Crandall, C. S. | 2015 | craiganderson.org/wp-content/uploads/caa/Classes/Readings/15Big5PersonalValues.pdf | Meta-análise que revisa e integra a pesquisa sobre **traços de personalidade e valores pessoais**, fornecendo um contexto teórico mais amplo sobre a natureza e a função dos valores na psicologia, além do ACT. |

## Síntese para Campos de Saída

**Área Temática:** Terapia de Aceitação e Compromisso (ACT), Flexibilidade Psicológica e o Papel dos Valores Pessoais na Ciência Comportamental Contextual.

**Total de Fontes:** 15

**Conceitos-Chave:**
*   **Flexibilidade Psicológica:** A capacidade de estar em contato com o momento presente como um ser humano consciente e, com base no que a situação oferece, mudar ou persistir no comportamento a serviço de valores escolhidos. É o principal objetivo do ACT.
*   **Hexaflex:** O modelo conceitual do ACT que descreve os seis processos centrais interconectados que promovem a Flexibilidade Psicológica: Aceitação, Desfusão Cognitiva, Contato com o Momento Presente (Mindfulness), Self como Contexto, Valores e Ação Comprometida.
*   **Valores Pessoais:** Direções de vida escolhidas livremente, construídas verbalmente, dinâmicas e contínuas, que motivam a ação. No ACT, são o alicerce para a mudança de comportamento e o critério para a ação comprometida.
*   **Teoria do Enquadramento Relacional (RFT):** A base teórica do ACT, uma teoria comportamental da linguagem e cognição que explica como a linguagem humana (enquadramento relacional) pode levar à **Fusão Cognitiva** (tomar pensamentos literalmente) e à **Esquiva Experiencial** (tentativa de controlar ou evitar experiências internas indesejadas), os principais componentes da **Inflexibilidade Psicológica**.
*   **Ação Comprometida:** Comportamento aberto e flexível, guiado pelos valores, mesmo na presença de pensamentos e sentimentos difíceis.

**Cobertura Geográfica:** Principalmente Estados Unidos (EUA) e Europa (Estudos de Hayes, Wilson, Strosahl, Dahl, Reilly, Rahal, Arch, LeJeune, Rolffs, Stabbe, Parks-Leduc).

## Resumo Detalhado da Pesquisa

A Terapia de Aceitação e Compromisso (ACT) é um modelo psicoterapêutico contextual-comportamental que se enquadra na chamada "terceira onda" das terapias cognitivo-comportamentais [2]. Seu objetivo central é aumentar a **Flexibilidade Psicológica**, definida como a capacidade de estar em contato com o momento presente, de forma consciente, e de mudar ou persistir no comportamento quando isso serve a valores escolhidos [1] [7].

O ACT é fundamentado na **Teoria do Enquadramento Relacional (RFT)**, uma teoria comportamental da linguagem e cognição [2] [12]. A RFT explica como a linguagem humana, através do estabelecimento de relações arbitrárias entre estímulos (enquadramento relacional), pode levar a padrões de pensamento rígidos, como a **Fusão Cognitiva** (tomar pensamentos literalmente como verdades absolutas) e a **Esquiva Experiencial** (tentativa de controlar ou evitar experiências internas indesejadas) [2] [13]. Esses padrões são os pilares da **Inflexibilidade Psicológica** [9] [10].

O modelo conceitual do ACT é o **Hexaflex**, que descreve seis processos centrais interconectados que, quando trabalhados, promovem a Flexibilidade Psicológica [7]:
1.  **Aceitação:** Abrir-se e permitir que experiências internas (pensamentos, sentimentos, sensações) existam sem tentar mudá-las ou controlá-las.
2.  **Desfusão Cognitiva:** Aprender a ver os pensamentos como o que eles são (palavras e imagens), em vez de verdades literais ou regras.
3.  **Contato com o Momento Presente:** Estar consciente e engajado com o que está acontecendo aqui e agora.
4.  **Self como Contexto:** A perspectiva de um "eu observador", um lugar estável e contínuo a partir do qual se pode observar a experiência interna sem se identificar com ela.
5.  **Valores:** Direções de vida escolhidas.
6.  **Ação Comprometida:** Comportamento guiado pelos valores.

O trabalho com **Valores Pessoais** é um componente fundamental e motivacional do ACT [3] [8]. Os valores são definidos como qualidades de ação contínuas, escolhidas livremente e construídas verbalmente, que servem como um guia para a vida, e não como metas a serem alcançadas [3] [4]. Eles fornecem o contexto para a **Ação Comprometida**, que é o comportamento aberto e flexível, mantido mesmo na presença de sofrimento [7].

A pesquisa empírica tem se concentrado tanto na avaliação quanto na intervenção de valores. Revisões sistemáticas têm examinado a validade das medidas de valores no ACT [5] e a eficácia das intervenções de valores, sugerindo que o foco explícito nos valores é um elemento crucial para os resultados terapêuticos [6]. Metodologias práticas para o trabalho com valores incluem exercícios como o "Epitáfio" ou o "Caminho da Vida", que ajudam o indivíduo a clarificar e se conectar com suas direções de vida mais profundas [14].

A aplicação dos princípios do ACT e da RFT se estende além do contexto clínico, sendo utilizada, por exemplo, na **gestão do comportamento organizacional** para promover a Flexibilidade Psicológica no ambiente de trabalho [11]. O conceito de valores, em um contexto mais amplo, também é objeto de meta-análises que o relacionam a traços de personalidade, reforçando sua função como princípio guia do comportamento humano [15].

## Referências

[1] Hayes, S. C., Strosahl, K. D., & Wilson, K. G. (1999). *Acceptance and commitment therapy: An experiential approach to behavior change*. Guilford Press.
[2] Hayes, S. C. (2004). Acceptance and commitment therapy, relational frame theory, and the third wave of behavioral and cognitive therapies. *Behavior Therapy*, *35*(4), 639-665.
[3] Wilson, K. G., & Murrell, A. R. (2004). Values work in acceptance and commitment therapy. In S. C. Hayes, V. M. Follette, & M. M. Linehan (Eds.), *Mindfulness and acceptance: Expanding the cognitive-behavioral tradition* (pp. 120-151). Guilford Press.
[4] Dahl, J. A. (2015). Valuing in ACT. *Journal of Contextual Behavioral Science*, *4*(4), 260-262.
[5] Reilly, E. D., Ritzert, T. R., Scoglio, A. A. J., & Mote, J. (2019). A systematic review of values measures in acceptance and commitment therapy research. *Journal of Contextual Behavioral Science*, *11*, 1-11.
[6] Rahal, G. M., & Gon, M. C. C. (2020). A systematic review of values interventions in acceptance and commitment therapy. *Revista Argentina de Clínica Psicológica*, *29*(3), 567-578.
[7] Arch, J. J. (2022). Acceptance and Commitment Therapy Processes and Mediation. *Annual Review of Clinical Psychology*, *18*, 45-71.
[8] LeJeune, J., & Luoma, J. (2023). Values in acceptance and commitment therapy. In M. P. Twohig, M. E. Levin, & J. M. Petersen (Eds.), *The Oxford handbook of acceptance and commitment therapy*. Oxford University Press.
[9] Rolffs, J. L., et al. (2018). Disentangling components of flexibility via the hexaflex model: Development and validation of the Multidimensional Psychological Flexibility Inventory (MPFI). *Journal of Psychopathology and Behavioral Assessment*, *40*(1), 1-16.
[10] Stabbe, O. K., et al. (2019). Flexibly and/or inflexibly embracing life: Identifying fundamental approaches to life with latent profile analyses on the dimensions of the Hexaflex model. *Journal of Contextual Behavioral Science*, *11*, 103-112.
[11] Hayes, S. C., et al. (2013). *Acceptance and mindfulness at work: Applying acceptance and commitment therapy and relational frame theory to organizational behavior management*. New Harbinger Publications.
[12] Hayes, S. C., & Barnes-Holmes, D. (2001). *Relational Frame Theory: A Post-Skinnerian Account of Human Language and Cognition*. Plenum Press.
[13] Delprato, D. J. (2001). Acceptance and Commitment Therapy: An Experiental Approach to Behavior Change (Review of Hayes, Strosahl, & Wilson, 1999). *The Psychological Record*, *51*(1), 155-160.
[14] Berkout, O. V., et al. (2021). Working With Values: An Overview of Approaches and Considerations in Their Implementation in Acceptance and Commitment Therapy. *Journal of Contextual Behavioral Science*, *20*, 13-23.
[15] Parks-Leduc, L., Feldman, G., & Crandall, C. S. (2015). Personality Traits and Personal Values: A Meta-Analysis. *Personality and Social Psychology Review*, *19*(1), 3-29.

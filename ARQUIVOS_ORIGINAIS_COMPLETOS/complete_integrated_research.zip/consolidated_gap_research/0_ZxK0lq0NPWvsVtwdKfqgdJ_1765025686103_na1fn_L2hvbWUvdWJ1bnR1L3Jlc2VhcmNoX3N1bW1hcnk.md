# Análise Detalhada: Estruturas de Accountability em Contextos Organizacionais vs Pessoais

**Área Temática:** Estruturas de accountability (prestação de contas e responsabilidade) em contextos organizacionais e pessoais, com foco em teorias psicológicas, frameworks conceituais e metodologias não-tecnológicas.

**Total de Fontes Identificadas:** 15

## 1. Síntese das Contribuições Teóricas e Frameworks

A pesquisa focou em desvendar as bases conceituais e psicológicas da *accountability*, distinguindo-a da mera responsabilidade (*responsibility*) e explorando suas manifestações nos níveis individual (pessoal) e coletivo (organizacional/social). O corpo teórico encontrado converge em três principais frameworks conceituais: a **Accountability Sentida (Felt Accountability)**, a **Accountability Relacional (Relational Accountability)** e a **Auto-Accountability (Self-Accountability)**.

### 1.1. Accountability Sentida (Felt Accountability)

Este framework, amplamente revisado e sintetizado por Hall, Frink e Buckley [3], foca na **percepção psicológica** do indivíduo de que suas ações e decisões serão avaliadas por outros.

> "A *felt accountability* é a percepção de que se será chamado a justificar ou explicar as ações, decisões ou resultados a um público com alguma capacidade de recompensar ou punir." [3]

*   **Contexto:** Predominantemente organizacional, mas com raízes na psicologia social.
*   **Mecanismo:** A percepção de um público de avaliação (chefe, colega, grupo) atua como um mecanismo psicológico que motiva o indivíduo a se comportar de maneira justificável.
*   **Diferencial:** É um estado psicológico interno, e não apenas uma estrutura formal externa.

### 1.2. Auto-Accountability (Self-Accountability)

A auto-accountability representa a internalização da necessidade de justificação. É a prestação de contas que o indivíduo faz a si mesmo, sendo o próprio público de avaliação [9] [10].

*   **Teorias Psicológicas:** Baseia-se em teorias como a **Dissonância Cognitiva** (modelo de redução de dissonância por auto-accountability) [10] e a **Teoria da Autodeterminação**, onde a motivação intrínseca para o comportamento ético e o alcance de metas é o motor [7].
*   **Implicações:** É crucial para o comportamento ético e a consistência pessoal, influenciando escolhas e preferências, como a compra de produtos com atributos éticos [9].

### 1.3. Accountability Relacional (Relational Accountability)

Este conceito expande a *accountability* para além da díade indivíduo-organização, focando nas **relações e sistemas sociais** [4] [5].

*   **Natureza:** É vista como o "adesivo que une os sistemas sociais" [4], enfatizando a interconexão e a responsabilidade mútua.
*   **Contexto:** Aplica-se a equipes (team accountability) [4], parcerias de pesquisa ética [5] e sistemas sociais mais amplos, como na educação e reconciliação [6].
*   **Metodologia:** É uma postura ética que exige diálogo, colaboração e aprendizado mútuo, sendo fundamental para a **mudança sistêmica** [15].

### 1.4. Metodologias Práticas Não-Tecnológicas

As metodologias encontradas focam em estruturas humanas e sociais para fomentar a *accountability*:

*   **Coaching e Dinâmica de Grupo:** O **coaching de grupo** e o **peer coaching** são identificados como metodologias eficazes. A presença de um grupo ou de um coach externo (estrutura humana) adiciona uma camada de *accountability* mútua e externa, essencial para o alcance de metas e a mudança de comportamento [11] [12] [13].
*   **Sistemas Sociais Informais:** A *accountability* pode ser imposta informalmente em sistemas sociais, motivando as pessoas a manterem certas condutas para preservar seu status ou relacionamento [14].

## 2. Documentação das Fontes Acadêmicas

| ID | Título | Autor(es) | Ano | URL/Fonte | Principais Contribuições Teóricas |
| :---: | :--- | :--- | :---: | :--- | :--- |
| 1 | Conceptual bases of employee accountability: A psychological approach | Y Han, JL Perry | 2020 | [Link 1] | Foco na psicologia da accountability, distinguindo mecanismos macro-institucionais de individuais. |
| 2 | Building relationships through accountability: An expanded idea of accountability | D Wang, DA Waldman | 2019 | [Link 2] | Explora a accountability em organizações baseada em normas de relacionamento e orientações pessoais. |
| 3 | An accountability account: A review and synthesis of the theoretical and empirical research on felt accountability | AT Hall, DD Frink, MR Buckley | 2017 | [Link 3] | Revisão e síntese da *felt accountability*, propondo um modelo holístico. |
| 4 | We hold ourselves accountable: A relational view of team accountability | VR Stewart, DG Snyder, CY Kou | 2023 | [Link 4] | Integra *relational accountability* e dinâmica de equipe; accountability como "adesivo que une sistemas sociais". |
| 5 | Creating ethical research partnerships–relational accountability in action | R Henry, C Tait, S UP | 2016 | [Link 5] | Aplicação da *relational accountability* em parcerias de pesquisa e sistemas sociais. |
| 6 | Relational accountability: a path towards transformative reconciliation in nursing education | J Fraser | 2022 | [Link 6] | *Relational accountability* como postura ética para atuação em sistemas sociais danificados. |
| 7 | Effect of self-accountability on self-regulatory behaviour: A quasi-experiment | Unknown | Unknown | [Link 7] | Estudo sobre a influência da *self-accountability* no comportamento de autorregulação. |
| 8 | A theoretical responsibility and accountability framework for CSR and global responsibility | Unknown | Unknown | [Link 8] | Menciona a aceitação da *self-accountability* e diferentes visões de responsabilidade na psicologia. |
| 9 | Good and guilt-free: The role of self-accountability in influencing preferences for products with ethical attributes | Unknown | Unknown | [Link 9] | Define *self-accountability* como a ativação da necessidade de justificar ações a si mesmo. |
| 10 | A self-accountability model of dissonance reduction: Multiple modes on a continuum of elaboration. | Unknown | Unknown | [Link 10] | Propõe um modelo de *self-accountability* para a redução da dissonância cognitiva. |
| 11 | The Democratization of Coaching and Development Through Peer Coaching in Groups | RE Boyatzis | 2025 | [Link 11] | Discute o *peer coaching* em grupos e a accountability como fator de alcance de metas. |
| 12 | Team coaching and effective team leadership | M Slagter, C Wilderom | 2022 | [Link 12] | Aborda a *accountability mútua* no coaching de equipe e a complexidade da dinâmica de grupo. |
| 13 | Mastering Group Dynamics: Strategies for Effective Group Coaching Sessions | Unknown | Unknown | [Link 13] | Enfatiza a accountability como crucial em coaching de grupo para traduzir sessões em progresso no mundo real. |
| 14 | Pursuing personal goals: temporal associations of accountability and goal progress | RJ Ridder | 2025 | [Link 14] | Estudo sobre a accountability informalmente imposta e sua motivação para o comportamento. |
| 15 | Forest for the Trees: Collective Accountability and Trust as Groundwork for Systems Change | S Salehi, P Infante | 2024 | [Link 15] | Foca na *collective accountability* e confiança como base para a mudança sistêmica. |

## 3. Referências

[1] https://academic.oup.com/ppmg/article-abstract/3/4/288/5698486
[2] https://journals.sagepub.com/doi/abs/10.1177/2041386619878876
[3] https://onlinelibrary.wiley.com/doi/abs/10.1002/job.2052
[4] https://link.springer.com/article/10.1007/s10551-021-04969-z
[5] https://esj.usask.ca/index.php/esj/article/view/61486
[6] https://qane-afi.casn.ca/index.php/casn/article/view/162
[7] https://link.springer.com/article/10.1007/s10551-015-2995-4
[8] https://www.emerald.com/insight/content/doi/10.1108/20412561011038529/full/html
[9] https://journals.sagepub.com/doi/abs/10.1509/jm.11.0454
[10] https://psycnet.apa.org/record/1999-02244-009
[11] https://commons.case.edu/emr/vol8/iss2/2/
[12] https://link.springer.com/chapter/10.1007/978-3-030-81938-5_74
[13] https://www.aretecoach.io/post/mastering-group-dynamics-strategies-for-effective-group-coaching-sessions
[14] https://www.sciencedirect.com/science/article/abs/pii/S0092656625000844
[15] https://scholarworks.gvsu.edu/tfr/vol16/iss2/6/

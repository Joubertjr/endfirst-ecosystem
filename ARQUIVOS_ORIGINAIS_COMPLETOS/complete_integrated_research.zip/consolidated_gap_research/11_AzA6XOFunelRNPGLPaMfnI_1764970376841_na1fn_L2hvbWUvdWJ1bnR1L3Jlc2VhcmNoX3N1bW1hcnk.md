# Análise Teórica e Metodológica do Coaching e da Mentoria

A presente pesquisa teve como objetivo identificar e analisar conceitos teóricos, *frameworks* e metodologias sobre Coaching e Mentoria, com foco em fundamentos psicológicos, comportamentais e estruturas humanas, excluindo aplicações tecnológicas e produtos comerciais. Foram coletadas 16 fontes acadêmicas, incluindo teses de doutorado, artigos de revisão sistemática e artigos científicos, que estabelecem a base de evidências para estas práticas de desenvolvimento humano.

## 1. Teorias Psicológicas e Comportamentais Fundamentais

As práticas de *coaching* e mentoria encontram sua solidez em diversas teorias da psicologia e da economia comportamental, que explicam os mecanismos de mudança e motivação humana.

### 1.1. Teoria da Autodeterminação (Self-Determination Theory - SDT)
A **Teoria da Autodeterminação (SDT)**, desenvolvida por Edward Deci e Richard Ryan, é um dos pilares teóricos mais citados no *coaching* [7] [9] [10]. A SDT postula que a motivação intrínseca e o bem-estar psicológico são impulsionados pela satisfação de três necessidades psicológicas básicas e universais:
*   **Autonomia:** Sentir-se no controle das próprias ações e ter a liberdade de escolha.
*   **Competência:** Sentir-se eficaz e capaz de dominar tarefas.
*   **Relacionamento:** Sentir-se conectado e cuidado pelos outros.

O *coaching* baseado em SDT foca em criar um ambiente de suporte à autonomia, o que é crucial para a mudança de comportamento sustentável [7]. A **SCOAP Coach Theory**, por exemplo, propõe um modelo de *coaching* integrado baseado nessas necessidades humanas básicas, com uma perspectiva neurocientífica [9].

### 1.2. Teoria Cognitiva Social (Social Cognitive Theory - SCT)
A **Teoria Cognitiva Social (SCT)** de Albert Bandura é fundamental para entender a **autoeficácia**, que é a crença de um indivíduo em sua capacidade de executar tarefas e alcançar objetivos [8] [14]. A mentoria e o *coaching* são vistos como intervenções que podem fomentar a autoeficácia, especialmente em contextos de carreira e empreendedorismo, ao fornecerem experiências de domínio, modelagem e persuasão social [8] [14].

### 1.3. Modelo Transteórico de Mudança (Transtheoretical Model - TTM)
O **Modelo Transteórico de Mudança (TTM)**, de Prochaska e DiClemente, é um *framework* chave para a psicologia do *coaching* [15]. Ele descreve a mudança de comportamento como um processo que se desenrola em estágios (pré-contemplação, contemplação, preparação, ação e manutenção). O TTM fornece uma **metodologia prática** para o *coach* ou mentor, permitindo que a intervenção seja adaptada ao estágio de prontidão para a mudança do indivíduo [16].

### 1.4. Economia Comportamental (Nudging)
A **Economia Comportamental** contribui com o conceito de **Nudging** (Teoria do Empurrão), que é uma metodologia prática para influenciar a tomada de decisão e a mudança de comportamento de forma previsível, sem proibições ou incentivos econômicos significativos [13]. O *coaching* pode integrar estratégias de *nudging* ao desenhar a "arquitetura de escolha" do *coachee*, facilitando a adoção de comportamentos desejados [13].

## 2. Frameworks e Metodologias de Coaching e Mentoria

Diversos modelos conceituais e metodologias estruturam a interação entre *coach*/mentor e *coachee*/mentorado.

### 2.1. Modelo GROW
O **Modelo GROW** (Goals, Reality, Options, Will/Way Forward), popularizado por Sir John Whitmore, é o *framework* de *coaching* mais amplamente reconhecido [3] [4]. Ele fornece uma estrutura sequencial e prática para a conversação de *coaching*, focando no estabelecimento de metas, análise da realidade atual, exploração de opções e definição de um plano de ação. O GROW se alinha com a **Teoria da Mudança Intencional (ICT)**, que explora a base teórica para a eficácia da liderança e do *coaching* [4].

### 2.2. Coaching Focado em Soluções (Solution-Focused Coaching - SFC)
O **Coaching Focado em Soluções (SFC)** é uma metodologia que se baseia na **Terapia Breve Focada em Soluções (SFBT)** [11] [12]. Em vez de analisar a origem dos problemas, o SFC se concentra em construir soluções, utilizando perguntas que exploram exceções e futuros desejados. É um *framework* prático com forte base na psicologia positiva e no construcionismo social [11].

### 2.3. Coaching Cognitivo-Comportamental (CCC)
O **Coaching Cognitivo-Comportamental (CCC)** é um modelo que se baseia nas **Psicoterapias Cognitivo-Comportamentais (TCC)**, como a Terapia Racional Emotiva Comportamental de Ellis [2]. O CCC aplica os princípios da TCC para identificar e modificar padrões de pensamento e comportamento disfuncionais em contextos de desenvolvimento pessoal e profissional [2].

### 2.4. Dynamic Team Leadership Coaching
O **Dynamic Team Leadership Coaching** é um construto proposto em uma tese de doutorado que integra o *coaching* de equipe com a **meta-teoria Dynamic Team Leadership** [1]. Este *framework* enfatiza a complexidade do *coaching* de equipe como uma função de liderança, onde o contexto e todos os membros devem ser considerados para prever o desempenho, satisfação e viabilidade da equipe [1].

### 2.5. Frameworks de Mentoria
A mentoria, por sua vez, é explorada em modelos conceituais que a diferenciam do *coaching*, focando na **aprendizagem organizacional** e na **retenção de conhecimento** [6]. A mentoria é frequentemente analisada através da lente da **Teoria Social Cognitiva da Carreira (SCCT)**, que examina como a relação mentor-mentorado influencia a autoeficácia e os resultados de carreira [14].

## 3. Tabela de Fontes Acadêmicas Coletadas

A tabela a seguir resume as 16 fontes acadêmicas coletadas, conforme a documentação detalhada:

| ID | Título | Autor(es) | Ano | Contribuições Teóricas Principais |
| :---: | :--- | :--- | :---: | :--- |
| 1 | Dynamic Team Leadership Coaching Towards Business Results | Maria Alexandra Rebotim Barosa Pereira | 2020 | Propõe o construto **Dynamic Team Leadership Coaching** (Meta-teoria Dynamic Team Leadership). |
| 2 | Cognitive-Behavioural Coaching: Applications to Health and Personal Development Contexts | Marina Carvalho et al. | 2018 | Apresenta o **Coaching Cognitivo-Comportamental (CCC)** e suas bases na TCC. |
| 3 | An examination of a university success coaching program | (Não especificado) | (Não especificado) | Menciona o **Modelo GROW** (Whitmore) e a base teórica do *coaching* profissional (ICF). |
| 4 | Intentional change theory, coaching and leader effectiveness | (Não especificado) | (Não especificado) | Explora a **Teoria da Mudança Intencional (ICT)** como base para o *coaching* e o Modelo GROW. |
| 5 | The Case of “Not Enough Time:” Using GROW and Motivational Interviewing Coaching Frameworks | (Não especificado) | 2025 | Integração do **Modelo GROW** com a **Entrevista Motivacional** (abordagem psicológica). |
| 6 | MARRCO: modelo conceitual de aprendizagem organizacional em rede para a retenção do conhecimento organizacional | (Não especificado) | (Não especificado) | **Modelo conceitual de mentoria** focado em **aprendizagem organizacional** e retenção de conhecimento. |
| 7 | Self-Determination Theory: A Case Study of Evidence-Based Coaching | (Não especificado) | 2025 | Estudo de caso de *coaching* baseado em evidências utilizando a **Teoria da Autodeterminação (SDT)**. |
| 8 | Coaching and mentoring to foster self-efficacy for early-stage survival-driven entrepreneurs | (Não especificado) | (Não especificado) | Utiliza a **Teoria Cognitiva Social (SCT)** para explicar a autoeficácia em *coaching* e mentoria. |
| 9 | The case for basic human needs in coaching: A neuroscientific perspective–The SCOAP Coach Theory | (Não especificado) | (Não especificado) | Propõe a **SCOAP Coach Theory** baseada nas necessidades humanas da **SDT**. |
| 10 | The 10 golden principles for coaching children | S Lara-Bercial | 2022 | Princípios de *coaching* fundamentados na **SDT** e no European Sport Coaching Framework. |
| 11 | Effective Solution Focused Coaching: A Q- methodology study... | C Small | (Não especificado) | Estudo sobre a eficácia do **Coaching Focado em Soluções (SFC)**, baseado na Terapia Breve Focada em Soluções (SFBT). |
| 12 | Effectiveness of Solution-Focused Brief Therapy A Systematic Qualitative Review of Controlled Outcome Studies | (Não especificado) | 2025 | Revisão sistemática que fornece a base teórica para o **Coaching Focado em Soluções (SFC)**. |
| 13 | Estratégias de coaching e nudging e excesso de peso: qual a relação? | (Não especificado) | (Não especificado) | Conecta **estratégias de *coaching*** com o conceito de **Nudging** (Economia Comportamental). |
| 14 | Mentorship in the engineering professoriate: exploring the role of social cognitive career theory | (Não especificado) | (Não especificado) | Explora a mentoria através da **Teoria Social Cognitiva da Carreira (SCCT)**. |
| 15 | Towards a psychology of coaching: The impact of coaching on metacognition, mental health and goal attainment | Anthony M. Grant | 2002 | Artigo seminal que identifica o **Modelo Transteórico de Mudança (TTM)** como *framework* chave para a psicologia do *coaching*. |
| 16 | It takes time: A stages of change perspective on the adoption of workplace coaching skills | Anthony M. Grant | 2010 | Utiliza o **TTM** como *framework* para a adoção de habilidades de *coaching* no local de trabalho. |

## 4. Referências

[1] Pereira, M. A. R. B. (2020). *Dynamic Team Leadership Coaching Towards Business Results*. Tese de Doutoramento, Iscte - Instituto Universitário de Lisboa. Disponível em: <https://repositorio.iscte-iul.pt/handle/10071/20596?locale=en>
[2] Carvalho, M., Matos, M. G. de, & Anjos, M. H. (2018). Cognitive-Behavioural Coaching: Applications to Health and Personal Development Contexts. *EC Psychology and Psychiatry*, 7(3), 219-226. Disponível em: <https://ecronicon.net/assets/ecpp/pdf/ECPP-07-00219.pdf>
[3] (Não especificado). *An examination of a university success coaching program*. ProQuest. Disponível em: <https://search.proquest.com/openview/951db698f7302d06df998b5e03a5f3ca/1?pq-origsite=gscholar&cbl=18750>
[4] (Não especificado). *Intentional change theory, coaching and leader effectiveness*. QUT ePrints. Disponível em: <https://eprints.qut.edu.au/115537>
[5] (Não especificado). (2025). The Case of “Not Enough Time:” Using GROW and Motivational Interviewing Coaching Frameworks. *ResearchGate*. Disponível em: <https://www.researchgate.net/publication/280915014_The_Case_of_Not_Enough_Time_Using_GROW_and_Motivational_Interviewing_Coaching_Frameworks>
[6] (Não especificado). *MARRCO: modelo conceitual de aprendizagem organizacional em rede para a retenção do conhecimento organizacional*. Repositório UFSC. Disponível em: <https://repositorio.ufsc.br/handle/123456789/262353>
[7] (Não especificado). (2025). Self-Determination Theory: A Case Study of Evidence-Based Coaching. *ResearchGate*. Disponível em: <https://www.researchgate.net/publication/43451011_Self-Determination_Theory_A_Case_Study_of_Evidence-Based_Coaching>
[8] (Não especificado). *Coaching and mentoring to foster self-efficacy for early-stage survival-driven entrepreneurs*. South African Journal of Business Management. Disponível em: <https://journals.co.za/doi/abs/10.4102/sajbm.v56i1.4884>
[9] (Não especificado). *The case for basic human needs in coaching: A neuroscientific perspective–The SCOAP Coach Theory*. ResearchGate. Disponível em: <https://www.researchgate.net/profile/Andy-Habermacher/publication/313311281_The_case_for_basic_human_needs_in_coaching_A_neuroscientific_perspective_-_The_SCOAP_Coach_Theory/links/66baf35e2361f42f23ce18f8/The-case-for-basic-human-needs-in-coaching-A-neuroscientific-perspective-The-SCOAP-Coach-Theory.pdf>
[10] Lara-Bercial, S. (2022). The 10 golden principles for coaching children. *Sport Coaching Review*, 1-19. Disponível em: <https://link.springer.com/article/10.1007/s43594-022-00082-9>
[11] Small, C. *Effective Solution Focused Coaching: A Q- methodology study...*. University of Nottingham ePrints. Disponível em: <https://eprints.nottingham.ac.uk/14385/1/546468.pdf>
[12] (Não especificado). (2025). Effectiveness of Solution-Focused Brief Therapy A Systematic Qualitative Review of Controlled Outcome Studies. *ResearchGate*. Disponível em: <https://www.researchgate.net/publication/258183949_Effectiveness_of_Solution-Focused_Brief_Therapy_A_Systematic_Qualitative_Review_of_Controlled_Outcome_Studies>
[13] (Não especificado). *Estratégias de coaching e nudging e excesso de peso: qual a relação?*. Acta Portuguesa de Nutrição. Disponível em: <https://actaportuguesadenutricao.pt/wp-content/uploads/2021/02/11_ARTIGO-REVISAO.pdf>
[14] (Não especificado). *Mentorship in the engineering professoriate: exploring the role of social cognitive career theory*. Emerald Insight. Disponível em: <https://www.emerald.com/insight/content/doi/10.1108/ijmce-12-2016-0077/full/html>
[15] Grant, A. M. (2002). *Towards a psychology of coaching: The impact of coaching on metacognition, mental health and goal attainment*. ProQuest. Disponível em: <https://search.proquest.com/openview/0db4830f1ff601aed834451978aac1ff/1?pq-origsite=gscholar&cbl=18750>
[16] Grant, A. M. (2010). It takes time: A stages of change perspective on the adoption of workplace coaching skills. *Journal of Change Management*, 10(4), 453-465. Disponível em: <https://www.tandfonline.com/doi/abs/10.1080/14697010903549440>

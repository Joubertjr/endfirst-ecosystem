# Resumo Detalhado da Pesquisa: Disciplina Militar, Accountability Hierárquica e Falhas de Implementação

## Área Temática

A pesquisa concentra-se na intersecção de **disciplina militar**, **estruturas hierárquicas de *accountability*** e **falhas de implementação**, sob uma lente estritamente teórica e não-tecnológica. O foco recai sobre as **teorias psicológicas, sociológicas e antropológicas** que explicam a dinâmica de poder, obediência, cultura e a resiliência ou colapso de sistemas institucionais complexos.

## Introdução

A eficácia de qualquer organização, especialmente aquelas com estruturas hierárquicas rígidas como as militares, depende fundamentalmente da disciplina e de um sistema robusto de *accountability* (prestação de contas). Contudo, a história e a teoria demonstram que a própria rigidez dessas estruturas pode ser a origem de falhas catastróficas. Este resumo sintetiza os principais conceitos e *frameworks* acadêmicos que abordam essa dualidade, examinando como a psicologia da obediência, as teorias sociológicas da autoridade e as dimensões culturais moldam o sucesso ou a falha na implementação de diretrizes e na manutenção da responsabilidade individual e institucional.

## 1. Fundamentos Sociológicos e Estruturais da Disciplina e Hierarquia

A disciplina militar e a *accountability* hierárquica encontram um forte pilar na **Teoria da Burocracia de Max Weber**, que descreve a **Autoridade Legal-Racional** como o tipo de dominação mais eficiente e previsível [4]. A organização militar é frequentemente citada como o exemplo arquetípico da burocracia, onde a disciplina é o mecanismo que garante a obediência e a execução de ordens, independentemente da pessoa que as emite [4] [13].

A **Sociologia Militar** estuda como o controle e a *accountability* são requisitos cruciais para o funcionamento dessas organizações [11] [13]. A hierarquia, no entanto, não se limita à estrutura formal. Estudos demonstram que as **relações interpessoais e interhierárquicas** informais, bem como os **processos decisórios** não-escritos, são determinantes para a dinâmica de poder e, consequentemente, para a eficácia da disciplina e da prestação de contas [1]. A **Teoria da Convenção** complementa essa visão ao analisar como **valores, normas e a cultura militar** influenciam o comportamento e as delimitações de responsabilidade [12].

## 2. A Psicologia da Obediência e a Agência Moral

O aspecto psicológico da disciplina militar é profundamente explorado pela teoria da **Obediência à Autoridade**, notavelmente através do **Experimento de Milgram** [7] [15]. Este experimento demonstrou a forte tendência humana de obedecer a figuras de autoridade, mesmo quando as ordens entram em conflito com a moral pessoal. O conceito de **Estado Agente (*Agentic State*)** é central, descrevendo a condição psicológica na qual o indivíduo se vê como um mero instrumento para executar a vontade de outro, transferindo a responsabilidade moral para a autoridade [7] [9].

No contexto militar, onde a obediência é a fundação da eficácia [7] [15], a tensão entre a disciplina e a **responsabilidade individual** é crítica. O *framework* teórico da **Desobediência a Ordens Ilegais** e a **Desobediência Prosocial** abordam os limites éticos e legais da disciplina, focando em como e por que indivíduos desenvolvem a **agência moral** para se recusar a cumprir ordens que contrariem regras morais ou legais [2] [9] [14].

## 3. Cultura, Instituições e Falhas de Implementação

As falhas de implementação e organizacionais são frequentemente atribuídas a fatores não-tecnológicos, como deficiências de **liderança** (falta de visão, falhas éticas), **práticas de gestão** (má gestão de risco, planejamento inadaptável) e **desafios ambientais externos** [3]. A **Falha Institucional** e a **Falha Organizacional** são analisadas como a anatomia do colapso de sistemas de governança e regulação [6].

A **cultura** emerge como um fator modulador essencial. A **Teoria das Dimensões Culturais de Hofstede** é um *framework* chave, particularmente a dimensão **Distância do Poder (*Power Distance*)** [5]. Em culturas de alta Distância do Poder, a aceitação da hierarquia é maior, e a **obediência inquestionável** é esperada, o que pode exacerbar a transferência de responsabilidade e dificultar a *accountability* [5] [10]. A **Cultura e Accountability** se interligam, pois o contexto cultural define as formas de **controle social** e como a prestação de contas é percebida e implementada [10].

A **Lacuna de Implementação (*Implementation Gap*)** é um conceito sociológico que descreve a falha em traduzir políticas e planos em resultados práticos, sendo um tipo de falha estrutural e social, e não tecnológica [8].

## Tabela de Fontes Acadêmicas

| # | Título | Autor(es) | Ano | URL | Contribuições Teóricas Principais |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Relações de poder e hierarquias numa instituição militar. Estudo de caso | Santos, J. F. A. dos | 2001 | [1] | Análise das relações de poder (formal e informal) e processos decisórios em hierarquias militares. |
| 2 | Avoiding crimes of obedience: A comparative study of the autobiographies of M. K. Gandhi, Nelson Mandela, and Martin Luther King, Jr. | Morselli, D., & Passini, S. | 2010 | [2] | *Framework* de Desobediência Prosocial e Agência Moral contra a autoridade injusta. |
| 3 | Causes of organizational failure: A literature review | Hariyani, D. et al. | 2024 | [3] | Revisão sistemática das 40 causas de Falha Organizacional (liderança, gestão, ambiente). |
| 4 | Authority And Bureaucracy From Weber's Perspective | Não especificado | N/A | [4] | Aplicação da Teoria da Burocracia de Max Weber e Autoridade Legal-Racional ao contexto militar. |
| 5 | Impact of Hofstede's cultural dimensions on subordinate's perception of abusive supervision | Khan, S. et al. | N/A | [5] | Uso da Distância do Poder (Hofstede) para explicar a obediência inquestionável em hierarquias. |
| 6 | The anatomy of institutional and organizational failure | McDermott, K. A., & Peterson, C. R. | 2005 | [6] | Análise da Falha Institucional e Organizacional e falha de sistemas de governança. |
| 7 | Commitment and Obedience In the Military: An Israeli Case Study | Gal, R. | 1985 | [7] | Conexão entre Disciplina Militar, Experimento de Milgram e o comportamento obediente. |
| 8 | Sociological, Legal, and Psychological Aspects of Social Protection for Individuals Vulnerable to Suicide Due to Psychological Pressure | Não especificado | N/A | [8] | Conceito de Lacuna de Implementação (*Implementation Gap*) como falha estrutural e social. |
| 9 | BREAKING THE CHAIN OF COMMAND: Toward a theoretical framework: How and why soldiers refuse to obey illegal orders | Whitehead, E. | 2021 | [9] | *Framework* teórico sobre Desobediência a Ordens Ilegais e a tensão entre Estado Agente e responsabilidade individual. |
| 10 | Culture and Accountability in Organizations: Variations in Forms of Social Control across Cultures | Não especificado | N/A | [10] | Tipologia de *Accountability Webs* e como a cultura modula a prestação de contas. |
| 11 | CORE ISSUES AND THEORY IN MILITARY SOCIOLOGY | Siebold, G. U. | 2001 | [11] | Revisão dos temas centrais da Sociologia Militar, enfatizando controle e *accountability*. |
| 12 | Applying convention theory to military sociology: achievements and perspectives | Berner, E., & Kozica, A. | 2025 | [12] | Aplicação da Teoria da Convenção para analisar valores, normas e cultura militar. |
| 13 | Sociology and military studies: Classical and current foundations | Soeters, J. | 2018 | [13] | Fundamentos da Sociologia Militar e a relação entre teoria e prática em estruturas institucionais. |
| 14 | Disobedience in the military: legal and ethical implications | Caron, J. F. | 2018 | [14] | Implicações legais e éticas da desobediência e os limites da disciplina militar. |
| 15 | Obedience To Authority: The Positive Results of Unethical Testing | Robinson, T. | 2014 | [15] | Uso do Experimento de Milgram para discutir a ética e a moralidade da obediência na disciplina militar. |

## Conclusão

A análise da literatura acadêmica revela que a **disciplina militar** e a **accountability hierárquica** são fenômenos multifacetados, enraizados em teorias sociológicas de autoridade (Weber) e modelos psicológicos de obediência (Milgram). A eficácia dessas estruturas é constantemente desafiada pela **agência moral** individual e pela influência da **cultura nacional** (Hofstede), que pode tanto reforçar a obediência inquestionável quanto criar condições para a desobediência prosocial. As **falhas de implementação** e organizacionais, por sua vez, são explicadas por uma complexa anatomia de deficiências de liderança, gestão e pelo contexto institucional, culminando na **lacuna de implementação** que impede a tradução de políticas em resultados.

## Referências

[1]: Santos, J. F. A. dos (2001). *Relações de poder e hierarquias numa instituição militar. Estudo de caso*. http://hdl.handle.net/10174/15579
[2]: Morselli, D., & Passini, S. (2010). *Avoiding crimes of obedience: A comparative study of the autobiographies of M. K. Gandhi, Nelson Mandela, and Martin Luther King, Jr.* https://doi.org/10.1080/10781911003773530
[3]: Hariyani, D., Hariyani, P., Mishra, S., & Sharma, M. K. (2024). *Causes of organizational failure: A literature review*. https://doi.org/10.1016/j.ssaho.2024.101153
[4]: Não especificado. *Authority And Bureaucracy From Weber's Perspective*. https://dergipark.org.tr/en/doi/10.20875/makusobed.903546
[5]: Khan, S. (e outros). *Impact of Hofstede's cultural dimensions on subordinate's perception of abusive supervision*. https://www.researchgate.net/profile/Shahid-Khan-21/publication/287544566_Impact_of_Hofstede's_Cultural_Dimensions_on_Subordinate's_Perception_of_Abusive_Supervision/links/56b8521408ae44bb330c2e3e/Impact-of-Hofstedes-Cultural-Dimensions-on-Subordinates-Perception-of-Abusive-Supervision.pdf
[6]: McDermott, K. A., & Peterson, C. R. (2005). *The anatomy of institutional and organizational failure*. https://link.springer.com/chapter/10.1007/0-387-23196-X_4
[7]: Gal, R. (1985). *Commitment and Obedience In the Military: An Israeli Case Study*. https://www.jstor.org/stable/45304811
[8]: Não especificado. *Sociological, Legal, and Psychological Aspects of Social Protection for Individuals Vulnerable to Suicide Due to Psychological Pressure*. https://journal.qubahan.com/index.php/qaj/article/download/2054/439/11296
[9]: Whitehead, E. (2021). *BREAKING THE CHAIN OF COMMAND: Toward a theoretical framework: How and why soldiers refuse to obey illegal orders*. https://research.vu.nl/ws/portalfiles/portal/121568293/E%20%20Whitehead%20-%20thesis.pdf
[10]: Não especificado. *Culture and Accountability in Organizations: Variations in Forms of Social Control across Cultures*. https://www.researchgate.net/publication/247124266_Culture_and_Accountability_in_Organizations_Variations_in_Forms_of_Social_Control_across_Cultures
[11]: Siebold, G. U. (2001). *CORE ISSUES AND THEORY IN MILITARY SOCIOLOGY*. https://www.jstor.org/stable/45292830
[12]: Berner, E., & Kozica, A. (2025). *Applying convention theory to military sociology: achievements and perspectives*. https://link.springer.com/content/pdf/10.1007/978-3-030-52130-1_73-2.pdf
[13]: Soeters, J. (2018). *Sociology and military studies: Classical and current foundations*. https://www.taylorfrancis.com/books/mono/10.4324/9781315182131/sociology-military-studies-joseph-soeters
[14]: Caron, J. F. (2018). *Disobedience in the military: legal and ethical implications*. https://books.google.com/books?hl=en&lr=&id=JNNjDwAAQBAJ&oi=fnd&pg=PP6&dq=%22Milgram+experiment%22+%22military+discipline%22+ethics&ots=2CvZnzV4vf&sig=dJ5AE6trowu11wa3onAQeuTylzo
[15]: Robinson, T. (2014). *Obedience To Authority: The Positive Results of Unethical Testing*. https://repository.digital.georgetown.edu/downloads/acf1ee2b-43a8-4a0c-8dd6-39b91a211e93

# Análise Detalhada: Frameworks de Terapia Cognitivo-Comportamental (TCC) para Mudança

A presente pesquisa teve como objetivo central identificar e analisar conceitos teóricos, *frameworks* e metodologias da Terapia Cognitivo-Comportamental (TCC) e modelos correlatos, com foco nos mecanismos de mudança comportamental e na exclusão de aplicações tecnológicas ou produtos comerciais. O foco recaiu sobre teorias psicológicas, estruturas conceituais e metodologias práticas, conforme solicitado. Foram identificadas 19 fontes acadêmicas e teóricas, incluindo artigos de revisão, meta-análises e trabalhos de pesquisadores reconhecidos, que delineiam a evolução e a diversidade dos modelos de mudança na área.

## A Evolução dos Frameworks de Mudança: Da TCC Clássica à Terapia Baseada em Processos

A TCC, em sua essência, é um conjunto de intervenções que compartilham a premissa de que os processos cognitivos (pensamentos, crenças, esquemas) desempenham um papel central na manutenção dos transtornos psicológicos e, consequentemente, na promoção da mudança [3]. A evolução desses *frameworks* pode ser categorizada em três grandes "ondas" e modelos transdiagnósticos e de saúde comportamental.

### 1. A TCC Clássica e seus Mecanismos Fundamentais

O modelo fundacional é o **Modelo Cognitivo de Beck**, que postula que o afeto e o comportamento são determinados pela maneira como o indivíduo estrutura o mundo [3]. O mecanismo de mudança primário reside na modificação das **crenças disfuncionais** e dos **esquemas cognitivos** subjacentes, frequentemente chamados de *reestruturação cognitiva* [3].

Um precursor crucial é a **Terapia Comportamental Racional-Emotiva (REBT)** de Albert Ellis, cujo *framework* central é o **Modelo A-B-C** (Acontecimentos Ativadores, Crenças, Consequências) [4]. A mudança ocorre através da *disputa* (D) ativa das crenças irracionais, levando a uma nova filosofia de vida (E) [4].

Em termos de metodologia prática, os **Experimentos Comportamentais (BEs)** são centrais. Eles são procedimentos empíricos não-tecnológicos utilizados para testar a validade das crenças disfuncionais na vida real, promovendo a mudança cognitiva e comportamental pela **violação de expectativas** e pela experiência direta [5].

### 2. A Terceira Onda da TCC: Aceitação e Contexto

A chamada "terceira onda" da TCC representa uma mudança de foco, passando da mera eliminação de sintomas e reestruturação de conteúdo cognitivo para a **mudança da relação do indivíduo com seus pensamentos e emoções**, enfatizando a aceitação, o *mindfulness* e os valores pessoais [1].

*   **Terapia de Aceitação e Compromisso (ACT):** O conceito central e mecanismo de mudança é a **Flexibilidade Psicológica**, que é a capacidade de estar em contato com o momento presente e, dependendo do que a situação oferece, mudar ou persistir no comportamento a serviço de valores [8]. A ACT utiliza o *Hexaflex* (aceitação, defusão cognitiva, contato com o momento presente, *self* como contexto, valores e ação comprometida) como seu *framework* de intervenção [8].
*   **Terapia Comportamental Dialética (DBT):** Desenvolvida por Marsha Linehan, a DBT é um tratamento multicomponente que se baseia na **Teoria Biossocial** e na **Dialética** (síntese entre aceitação e mudança) [9]. Os mecanismos de mudança são as **habilidades** ensinadas em quatro módulos: *Mindfulness*, Tolerância ao Sofrimento, Regulação Emocional e Eficácia Interpessoal [9].
*   **Terapia Cognitiva Baseada em Mindfulness (MBCT):** Combina a TCC com a prática de *mindfulness* para prevenir recaídas depressivas. O mecanismo de mudança primário é a **metacognição** e o **descentramento**, que permitem ao indivíduo ver os pensamentos como eventos mentais passageiros, e não como a realidade [11].
*   **Terapia Focada na Compaixão (CFT):** O modelo teórico foca no **Sistema de Regulação da Ameaça, Impulso e Acalento** [7]. O mecanismo de mudança é o desenvolvimento da **autocompaixão** e a mudança do estilo de auto-relacionamento, visando a regulação emocional e a redução da autocrítica [7].

### 3. Modelos Transdiagnósticos e de Saúde Comportamental

A pesquisa também identificou *frameworks* que, embora não sejam estritamente TCC, são amplamente utilizados na psicologia comportamental e clínica para entender e promover a mudança, e frequentemente se integram à TCC.

*   **Terapia Baseada em Processos (PBT):** Representa o futuro da ciência da intervenção, movendo o foco de protocolos para síndromes para o uso específico de **processos baseados em evidências** (mecanismos de mudança) ligados a procedimentos [1] [2]. A PBT enfatiza o retorno à **Análise Funcional** idiográfica como princípio orientador [2].
*   **Terapia do Esquema (ST):** Uma extensão da TCC para problemas crônicos e transtornos de personalidade, focando nos **Esquemas Iniciais Desadaptativos (EIDs)** e nos **Modos Esquemáticos**. O mecanismo de mudança envolve a **reparentalização limitada** e a quebra de padrões de enfrentamento desadaptativos [6].
*   **Modelo Transteórico (TTM):** Um *framework* conceitual de mudança comportamental que descreve a mudança como um processo que ocorre em **Estágios** (Pré-contemplação, Contemplação, Preparação, Ação, Manutenção) [10]. O mecanismo de mudança são os **Processos de Mudança** (e.g., Aumento da Consciência, Auto-reavaliação) que impulsionam a transição entre os estágios [10].
*   **Teoria Social Cognitiva (TSC) e Autoeficácia:** O modelo central é o **Determinismo Recíproco Triádico** (interação entre Comportamento, Fatores Pessoais/Cognitivos e Ambiente) [16]. O principal mecanismo de mudança é a **Autoeficácia**, a crença na própria capacidade de executar ações necessárias para produzir resultados desejados [16] [17].
*   **Entrevista Motivacional (MI):** Um estilo de aconselhamento que foca na **"fala de mudança"** (*change talk*) do cliente e na resolução da ambivalência como mecanismo de mudança [18].
*   **Terapia Interpessoal (IPT):** Foca na ligação entre o humor e os **problemas interpessoais** atuais (luto, disputas de papéis, transições de papéis e déficits interpessoais) como mecanismo de mudança [19].

## Tabela de Fontes Acadêmicas e Contribuições Teóricas

A Tabela 1 sintetiza as 19 fontes acadêmicas coletadas, detalhando seus autores, ano de publicação, e a principal contribuição teórica para os *frameworks* de mudança.

| ID | Título | Autor(es) | Ano | Contribuição Teórica Principal |
| :--- | :--- | :--- | :--- | :--- |
| 1 | The third wave of cognitive behavioral therapy and the rise of process-based care | Steven C Hayes, Stefan G Hofmann | 2017 | Introdução da **Terapia Baseada em Processos (PBT)** e o foco em **processos baseados em evidências** (e.g., flexibilidade psicológica). |
| 2 | The Future of Intervention Science: Process-Based Therapy | Stefan G Hofmann, Steven C Hayes | 2018 | Definição de PBT, distinção entre **procedimentos** e **processos terapêuticos**, e ênfase na **Análise Funcional**. |
| 3 | Cognitive theory and therapy of anxiety and depression: Convergence with neurobiological findings | David A Clark, Aaron T Beck | 2010 | Apresentação do **Modelo Cognitivo de Beck** e a modificação de **crenças/esquemas cognitivos** como mecanismo de mudança. |
| 4 | A synopsis of rational-emotive behavior therapy (REBT); fundamental and applied research | D David, A Szentagotai, K Eva, B Macavei | 2005 | Framework da **REBT** e o **Modelo A-B-C-D-E**, com a **disputa de crenças irracionais** como mecanismo. |
| 5 | Efficacy of Behavioral Experiments in Cognitive Therapy for Social Anxiety Disorder: Study protocol for a randomized controlled trial | C Clément et al. | 2019 | Foco nos **Experimentos Comportamentais (BEs)** como metodologia prática para **violação de expectativas** e mudança cognitiva. |
| 6 | Schema Therapy Adapted for Psychosis and Bipolarity: Exploring the Multi-Self | J Rhodes, N Vorontsova | 2024 | Framework da **Terapia do Esquema (ST)**, focando em **Esquemas Iniciais Desadaptativos** e **reparentalização limitada**. |
| 7 | Applying a process-based therapy approach to compassion focused therapy: A synergetic alliance | MI Fraser, K Gregory | 2024 | Framework da **Terapia Focada na Compaixão (CFT)**, focando no **Sistema de Regulação da Ameaça/Acalento** e no desenvolvimento da **autocompaixão**. |
| 8 | Psychological flexibility as a mechanism of change in acceptance and commitment therapy | J Ciarrochi, L Bilich, C Godsell | 2010 | Conceito central da **ACT**: **Flexibilidade Psicológica** (Hexaflex) como mecanismo de mudança. |
| 9 | Mapping dialectical behavior therapy skills to clinical domains implicated in contemporary addiction research: a conceptual synthesis and promise for precision treatment | JW Luk, MF Thompson | 2024 | Framework da **Terapia Comportamental Dialética (DBT)**, baseado na **Teoria Biossocial** e no treinamento de **habilidades** (Mindfulness, Regulação Emocional). |
| 10 | The transtheoretical model and stages of change | James O Prochaska, C A Redding, K E Evers | 2008 | Apresentação do **Modelo Transteórico (TTM)**, com **Estágios de Mudança** e **Processos de Mudança** como mecanismos. |
| 11 | Executive function and emotion regulation as potential mechanisms of change in Mindfulness-Based Cognitive Therapy | A L Weldon | 2020 | Framework da **MBCT**, com **metacognição** e **descentramento** como mecanismos de mudança. |
| 12 | The health belief model | Edward C Green, Emeka M Murphy, Robert C Hornik | 2020 | Framework do **Modelo de Crenças em Saúde (HBM)**, baseado na percepção de **Susceptibilidade/Gravidade/Benefícios/Barreiras**. |
| 13 | How effective are behavior change interventions based on the theory of planned behavior? | H Steinmetz, M Knappstein, I Ajzen, R Schmidt, M Allemand | 2016 | Framework da **Teoria do Comportamento Planejado (TPB)**, com a **intenção comportamental** como mecanismo central. |
| 14 | Personalizing cognitive processing therapy with a case formulation approach to intentionally target impairment in psychosocial functioning associated with Ptsd | T E Galovski, C A Monson | 2024 | Framework da **Terapia de Processamento Cognitivo (CPT)**, com **reestruturação cognitiva** de crenças pós-traumáticas. |
| 15 | The Solution-focused Intervention for Mental health (SIM) | F Söderqvist et al. | 2025 | Framework da **Terapia Breve Focada na Solução (SFBT)**, com foco em **soluções** e **exceções** (não-problemas) como mecanismo. |
| 16 | Social cognitive theory and physical activity: Mechanisms of behavior change, critique, and legacy | Mark R Beauchamp, Katherine L Crawford, Ben Jackson | 2019 | Framework da **Teoria Social Cognitiva (TSC)**, com **Determinismo Recíproco Triádico** e **Autoeficácia** como mecanismos. |
| 17 | Self-efficacy theory of behavioral change: Foundations, conceptual issues, and therapeutic implications. | D Cervone | 1995 | Detalhamento da **Teoria da Autoeficácia** e suas fontes (experiência de domínio, modelagem) como procedimentos práticos de mudança. |
| 18 | Evaluating the mechanisms of change in motivational interviewing in the treatment of mental health problems: A review and meta-analysis | M Romano, L Peters | 2015 | Framework da **Entrevista Motivacional (MI)**, com a **"fala de mudança"** (*change talk*) como mecanismo central. |
| 19 | Interpersonal psychotherapy: a scoping review and historical perspective (1974–2017) | L E Markowitz, J C Markowitz | 2019 | Framework da **Terapia Interpessoal (IPT)**, focando na resolução de **problemas interpessoais** atuais (luto, disputas de papéis) como mecanismo. |

## Conclusão

A pesquisa demonstra que os *frameworks* de TCC para mudança evoluíram de modelos estritamente cognitivos (Beck, Ellis) para abordagens contextuais e baseadas em processos (ACT, CFT, PBT). O foco teórico permanece nos **mecanismos de mudança** (e.g., flexibilidade psicológica, metacognição, autoeficácia) e nas **metodologias práticas** (e.g., experimentos comportamentais, treinamento de habilidades, análise funcional), em total alinhamento com a solicitação de evitar tecnologia e produtos comerciais. A literatura acadêmica revisada oferece uma base robusta para a compreensão das estruturas conceituais e das evidências científicas que sustentam a mudança comportamental e psicológica.

***

## Referências

[1] Steven C Hayes, Stefan G Hofmann. The third wave of cognitive behavioral therapy and the rise of process-based care. 2017. https://pmc.ncbi.nlm.nih.gov/articles/PMC5608815/
[2] Stefan G Hofmann, Steven C Hayes. The Future of Intervention Science: Process-Based Therapy. 2018. https://pmc.ncbi.nlm.nih.gov/articles/PMC6350520/
[3] David A Clark, Aaron T Beck. Cognitive theory and therapy of anxiety and depression: Convergence with neurobiological findings. 2010. https://www.cell.com/trends/cognitive-sciences/abstract/S1364-6613(10)00144-0
[4] D David, A Szentagotai, K Eva, B Macavei. A synopsis of rational-emotive behavior therapy (REBT); fundamental and applied research. 2005. https://link.springer.com/article/10.1007/s10942-005-0011-0
[5] C Clément et al. Efficacy of Behavioral Experiments in Cognitive Therapy for Social Anxiety Disorder: Study protocol for a randomized controlled trial. 2019. https://link.springer.com/article/10.1186/s13063-019-3905-3
[6] J Rhodes, N Vorontsova. Schema Therapy Adapted for Psychosis and Bipolarity: Exploring the Multi-Self. 2024. https://api.taylorfrancis.com/content/books/mono/download?identifierName=doi&identifierValue=10.4324/9781003350583&type=googlepdf
[7] MI Fraser, K Gregory. Applying a process-based therapy approach to compassion focused therapy: A synergetic alliance. 2024. https://www.sciencedirect.com/science/article/pii/S2212144724000346
[8] J Ciarrochi, L Bilich, C Godsell. Psychological flexibility as a mechanism of change in acceptance and commitment therapy. 2010. https://books.google.com/books?hl=en&lr=&id=DlnH-qadA08C&oi=fnd&pg=PA51&dq=%22Acceptance+and+Commitment+Therapy%22+%22psychological+flexibility%22+%22framework%22&ots=2UiNZNXZEO&sig=W0G_c0F0EalVUIHMnisULPSbbOc
[9] JW Luk, MF Thompson. Mapping dialectical behavior therapy skills to clinical domains implicated in contemporary addiction research: a conceptual synthesis and promise for precision treatment. 2024. https://www.sciencedirect.com/science/article/pii/S1077722924000786
[10] James O Prochaska, C A Redding, K E Evers. The transtheoretical model and stages of change. 2008. https://psycnet.apa.org/record/2008-17146-005
[11] A L Weldon. Executive function and emotion regulation as potential mechanisms of change in Mindfulness-Based Cognitive Therapy. 2020. https://www.ideals.illinois.edu/items/116216
[12] Edward C Green, Emeka M Murphy, Robert C Hornik. The health belief model. 2020. https://onlinelibrary.wiley.com/doi/abs/10.1002/9781119057840.ch68
[13] H Steinmetz, M Knappstein, I Ajzen, R Schmidt, M Allemand. How effective are behavior change interventions based on the theory of planned behavior?. 2016. https://econtent.hogrefe.com/doi/full/10.1027/2151-2604/a000255
[14] T E Galovski, C A Monson. Personalizing cognitive processing therapy with a case formulation approach to intentionally target impairment in psychosocial functioning associated with Ptsd. 2024. https://pmc.ncbi.nlm.nih.gov/articles/PMC11609254/
[15] F Söderqvist et al. The Solution-focused Intervention for Mental health (SIM). 2025. https://www.sciencedirect.com/science/article/pii/S2666560325001057
[16] Mark R Beauchamp, Katherine L Crawford, Ben Jackson. Social cognitive theory and physical activity: Mechanisms of behavior change, critique, and legacy. 2019. https://www.sciencedirect.com/science/article/pii/S1469029218305132
[17] D Cervone. Self-efficacy theory of behavioral change: Foundations, conceptual issues, and therapeutic implications. 1995. https://psycnet.apa.org/record/1995-97997-013
[18] M Romano, L Peters. Evaluating the mechanisms of change in motivational interviewing in the treatment of mental health problems: A review and meta-analysis. 2015. https://www.sciencedirect.com/science/article/pii/S0272735815000392
[19] L E Markowitz, J C Markowitz. Interpersonal psychotherapy: a scoping review and historical perspective (1974–2017). 2019. https://journals.lww.com/hrpjournal/fulltext/2019/05000/Interpersonal_Psychotherapy__A_Scoping_Review_and.4.aspx

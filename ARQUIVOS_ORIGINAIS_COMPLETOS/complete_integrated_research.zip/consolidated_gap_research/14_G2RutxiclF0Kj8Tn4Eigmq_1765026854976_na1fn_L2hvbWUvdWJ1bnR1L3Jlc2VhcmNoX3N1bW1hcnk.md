# Religião e Práticas Espirituais como Sistemas de Disciplina: Fundamentos Teóricos e Falhas de Implementação

A investigação sobre a religião e as práticas espirituais como sistemas de disciplina revela um campo teórico robusto, ancorado em três grandes eixos: as fundações sociológicas clássicas do controle social, a análise do poder disciplinar e as abordagens contemporâneas que examinam a persistência e a falha na implementação dessas práticas. O foco recai sobre as estruturas institucionais e sociais que moldam a conduta individual, excluindo deliberadamente as perspectivas tecnológicas ou digitais.

## Fundamentos Clássicos da Disciplina Social

A compreensão da religião como um sistema disciplinar é inseparável das obras fundacionais da sociologia. **Émile Durkheim** estabeleceu a religião como a fonte primária da **disciplina moral** e da **coesão social** [2]. Em sua análise, os **ritos** e as crenças no **sagrado** atuam como mecanismos de **disciplina coletiva**, impondo a **autoridade moral** do grupo sobre o indivíduo e reforçando a **consciência coletiva**. A disciplina, neste sentido, é uma função social essencial para a manutenção da ordem.

Em contraste, **Max Weber** introduziu o conceito de **disciplina ascética** (ou ascese intramundana) para explicar a **racionalização da conduta** [3]. Em *A Ética Protestante e o Espírito do Capitalismo*, a disciplina religiosa, particularmente a calvinista, é vista como um sistema de **autocontrole** rigoroso e metódico. Essa disciplina, voltada para a confirmação da salvação através do trabalho e da frugalidade, transcendeu a esfera religiosa, tornando-se o motor da **formação de caráter** e da organização racional da vida que impulsionou o capitalismo moderno.

## Disciplina como Tecnologia de Poder

A perspectiva de **Michel Foucault** oferece uma lente crítica para analisar a disciplina religiosa como uma **tecnologia de poder** [4] [20]. O conceito de **poder disciplinar** descreve como as instituições (historicamente, o convento e o quartel, que serviram de modelo para a prisão e outras instituições modernas) utilizam a **vigilância hierárquica** e a **sanção normalizadora** para produzir **corpos dóceis** e úteis. A disciplina religiosa, neste contexto, é um modelo histórico de **anatomopolítica**, atuando diretamente sobre o corpo e a conduta individual. A aplicação do conceito de **biopoder** à religião contemporânea sugere que as práticas espirituais podem funcionar como **dispositivos de controle** que regulam a vida e a população através de mecanismos de poder-saber [20].

## A Persistência e a Falha na Implementação

O foco nas **falhas de implementação** das práticas espirituais e religiosas revela um campo de estudo que se aprofunda nas dinâmicas psicossociais e institucionais. O trabalho de **Erin F. Johnston** [1] é central para esta discussão, ao explorar como a **persistência** na prática é mantida apesar das falhas percebidas (profecias não realizadas, orações não respondidas, incapacidade de sentir a presença divina). Johnston introduz o conceito de **estilo interpretativo** (*interpretive style*), um discurso autorizado promovido pelas organizações que **normaliza, universaliza e até valoriza** as falhas como parte constitutiva da prática. A falha, portanto, é ressignificada como um marcador de **identidade** e **progresso** do praticante, um mecanismo sociológico que impede o abandono da disciplina [1].

Em uma vertente crítica, artigos de crítica teológica e sociológica [9] [11] [13] argumentam que a ênfase em "disciplinas espirituais" transfere a responsabilidade da **falha sistêmica** (teológica ou institucional) para a **falha pessoal** do indivíduo. Essa **culpabilização individual** é vista como um mecanismo de **pressão institucional** que impõe a disciplina e desvia a atenção das falhas estruturais da doutrina ou da organização.

## Dimensões Culturais e Estruturais

A **Psicologia Cultural** e os **Estudos Cross-Culturais** sublinham a **variabilidade cultural** na forma como os sistemas de disciplina religiosa são concebidos e implementados [5] [8] [14] [19]. A eficácia e a forma das práticas disciplinares são profundamente moldadas pelo **contexto cultural**, exigindo uma **Alfabetização Religiosa Cross-Cultural** para a sua compreensão [14].

No nível estrutural, a **Teoria da Sinalização Custosa** (*Costly Signaling Theory*) [7] oferece um *framework* para entender as disciplinas rigorosas. As **práticas religiosas custosas** funcionam como **sinais** de **comprometimento** genuíno com o grupo, promovendo a **cooperação** e a **prosocialidade** dentro da comunidade. A disciplina, neste caso, é um investimento social que garante a confiança e a coesão do grupo.

Finalmente, a análise da **ecologia social** e da **comunidade moral** [12] demonstra como o **envolvimento religioso** estabelece um **contexto disciplinar** macro que afeta o comportamento individual (micro). A aplicação de **valores espirituais** em **estruturas institucionais** não-tecnológicas, como a cultura escolar [16], ilustra como esses sistemas de disciplina são mobilizados para o controle social e a formação de conduta em contextos seculares.

---

## Referências

[1] Erin F. Johnston, "Failing to Learn, or Learning to Fail? Accounting for Persistence in the Acquisition of Spiritual Disciplines," *Qualitative Sociology*, 2017.
[2] Émile Durkheim, *As Formas Elementares da Vida Religiosa*, 1912.
[3] Max Weber, *A Ética Protestante e o Espírito do Capitalismo*, 1905.
[4] Michel Foucault, *Vigiar e Punir: Nascimento da Prisão*, 1975.
[5] Lene A. Jensen, "The Cultural Psychology of Religiosity, Spirituality, and Secularism," *PMC*, 2021.
[6] Matthew Wood, "The Sociology of Spirituality: Reflections on a Problematic Endeavor," *The new Blackwell companion to the sociology of religion*, 2010.
[7] S. B. Northover, "Religious signaling and prosociality: A review of the literature," *ScienceDirect*, 2024.
[8] G. C. L. Van Dierendonck, "Religion: An overlooked dimension in cross-cultural psychology," *Journal of Cross-Cultural Psychology*, 2003.
[9] G. Richard Fisher, "The Dangers of Spiritual Formation and Spiritual Disciplines," (Sem data).
[10] Thomas F. O'Dea, "The Sociology of Religion Reconsidered," *The American Journal of Sociology*, 1970.
[11] Lighthouse Trails Research, "The Dangers of Spiritual Formation and Spiritual Disciplines," 2008.
[12] R. Stansfield, "Religious Involvement, Moral Community and Social Ecology," *PMC*, 2018.
[13] CIC Ministry, "The Dangers of Spiritual Formation and Spiritual Disciplines," (Sem data).
[14] C. Seiple, "A Case for Cross-Cultural Religious Literacy," *The Review of Faith & International Affairs*, 2021.
[15] J. Guo, "The Influence of Spirituality and Nationality on Unethical Behavior Among Leaders of Christian Organizations," (Artigo de Psicologia/Gestão), 2025.
[16] M Habibulloh, MA Ridho, "The Transformation of School Culture Based on Spiritual Values as an Effort to Improve Student Discipline," *International Journal of Education Management and Religion*, 2024.
[17] Lene A. Jensen, "The Cultural Psychology of Religiosity, Spirituality, and Secularism," *PMC*, 2021.
[18] Rodney Stark, "Is sociology the core discipline for the scientific study of religion?," *Social Forces*, 1994.
[19] G. Wang, "A cross-cultural religiology between reductionism and anti-reductionism," *HTS Teologiese Studies/Theological Studies*, 2023.
[20] E. E. de Morais, "A religião como dispositivo de biopoder: relações de poder no cristianismo contemporâneo," *Anais do LERR*, 2010.

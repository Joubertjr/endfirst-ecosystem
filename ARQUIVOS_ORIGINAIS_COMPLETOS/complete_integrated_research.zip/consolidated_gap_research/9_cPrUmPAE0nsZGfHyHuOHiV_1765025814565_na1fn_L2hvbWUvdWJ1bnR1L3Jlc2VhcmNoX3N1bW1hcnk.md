# Análise Teórica de Sistemas de Incentivos e Punições na Mudança Comportamental

## Introdução

A presente análise visa mapear os principais **conceitos teóricos**, **frameworks** e **metodologias** não-tecnológicas que fundamentam a aplicação de sistemas de incentivos e punições na promoção da mudança comportamental. A pesquisa foi conduzida com foco exclusivo em fontes acadêmicas e teóricas, abrangendo a psicologia, a economia comportamental e as ciências sociais, com o objetivo de fornecer uma base robusta de evidências científicas e estruturas conceituais [1] [2].

## Fundamentos Psicológicos: Behaviorismo e Cognição

O ponto de partida para a compreensão de incentivos e punições reside no **Condicionamento Operante**, um framework behaviorista que define o comportamento como sendo "controlado por suas consequências" [1]. Neste modelo, o **reforço** (positivo ou negativo) aumenta a probabilidade de um comportamento, enquanto a **punição** (positiva ou negativa) a diminui. A pesquisa neste campo se concentra na estabilidade do comportamento mantido por **esquemas de reforço** (baseados em tempo ou razão) [1].

Em contraste, a **Teoria Social Cognitiva (TSC)** de Albert Bandura introduz a mediação de fatores cognitivos, como crenças e expectativas, no processo de mudança [4]. Na TSC, o reforço e a punição não são apenas diretos, mas também **vicários**, ocorrendo pela observação das consequências em outros indivíduos. Crucialmente, a TSC enfatiza a **auto-regulação**, onde o indivíduo estabelece padrões e aplica **auto-reforço** ou **auto-punição** internos, tornando o comportamento menos dependente de incentivos externos [4]. A **autoeficácia**, a crença na própria capacidade de executar uma ação, é um mediador fundamental que determina se os incentivos externos se traduzirão em ação [4].

## Teorias de Motivação e Justiça

As teorias motivacionais e de justiça fornecem lentes adicionais para avaliar a qualidade e a sustentabilidade dos sistemas de incentivos:

1.  **Teoria da Autodeterminação (TAD):** Este framework distingue a **qualidade** da motivação (autônoma vs. controlada) [3]. Incentivos externos, especialmente se percebidos como **controladores**, podem minar a **motivação intrínseca** e a sustentabilidade da mudança. A TAD sugere que incentivos devem apoiar as necessidades psicológicas básicas de **autonomia**, **competência** e **pertencimento** para promover a **internalização** da regulação comportamental [3].

2.  **Teoria da Expectância (Expectancy Theory):** De natureza cognitiva, esta teoria postula que a força motivacional é um produto de três crenças: **Expectância** (esforço leva a desempenho), **Instrumentalidade** (desempenho leva a um resultado) e **Valência** (o valor percebido do resultado) [8]. Incentivos (recompensas) e desincentivos (punições) são os **resultados** que possuem valência. A eficácia de um sistema de incentivos depende da clareza e da crença do indivíduo de que o esforço levará à recompensa ou à evitação da punição [8].

3.  **Teoria da Equidade (Equity Theory):** Este framework foca na **percepção de justiça** nas relações de troca social [7]. A motivação é afetada pela comparação da proporção de **insumos** (esforço) e **resultados** (recompensa) de um indivíduo com a de outros. A percepção de **inequidade** (injustiça na distribuição de recompensas ou punições) atua como um poderoso **desincentivo**, gerando tensão e levando a ações para restaurar o equilíbrio, como a redução do esforço [7].

## Economia Comportamental e o Enquadramento de Incentivos

A **Economia Comportamental (EC)**, baseada nos trabalhos de Kahneman e Tversky, oferece insights sobre como as falhas na racionalidade humana afetam a resposta a incentivos.

O conceito de **Aversão à Perda** (Loss Aversion), central na **Teoria da Perspectiva (Prospect Theory)**, demonstra que a dor de uma perda é psicologicamente mais poderosa do que o prazer de um ganho equivalente [6]. Consequentemente, incentivos enquadrados como **evitação de perda** (desincentivos implícitos, como a ameaça de perder um depósito inicial) são frequentemente mais eficazes na mudança comportamental do que incentivos enquadrados como ganho [6].

Além disso, a EC sugere que incentivos devem ser vistos como **"nudges"** (empurrões) em vez de meras alterações de preço [2]. Isso inclui o uso de **incentivos não-monetários**, como o aproveitamento de **normas sociais** (Teoria do Foco Normativo) [10] e o **comprometimento pessoal** [2]. A **Teoria do Foco Normativo** distingue entre **normas descritivas** (o que é feito) e **normas injuntivas** (o que é aprovado), sugerindo que a eficácia de um incentivo/punição depende de focar a atenção do indivíduo na norma relevante no momento da ação [10].

## Frameworks Conceituais e Metodologias Práticas

Diversos frameworks conceituais fornecem metodologias para a aplicação prática de incentivos e punições:

| Framework Conceitual | Foco Principal | Papel dos Incentivos/Punições |
| :--- | :--- | :--- |
| **Modelo Transteórico (TTM)** [5] | Processo de mudança em **estágios** (Pré-contemplação, Ação, Manutenção). | O **Gerenciamento de Reforço** é um dos 10 processos de mudança. A eficácia dos incentivos e punições varia de acordo com o estágio em que o indivíduo se encontra. |
| **Modelo COM-B** [14] | Determinação do comportamento por **Capacidade**, **Oportunidade** e **Motivação**. | O **Reforço** é uma das 9 funções de intervenção da Roda de Mudança Comportamental (BCW), usada para aumentar a motivação e a capacidade, e deve ser contextualizado para o fator limitante (C, O ou M). |
| **Modelo de Crença em Saúde (HBM)** [12] | Crenças cognitivas que levam à ação de saúde. | **Desincentivo** é a percepção de **ameaça** (suscetibilidade + severidade). **Incentivo** é o aumento dos **benefícios percebidos** e a redução das **barreiras percebidas**. **Gatilhos** (Cues to Action) funcionam como incentivos não-monetários. |
| **Teoria da Troca Social (SET)** [15] | Interações sociais como análise de **custo-benefício** e **reciprocidade**. | Foca em **incentivos sociais** (aprovação, status) e **punições sociais** (ostracismo, retaliação) como mecanismos para manter o equilíbrio e a cooperação. |
| **Teoria da Definição de Metas** [11] | Metas específicas e feedback. | Incentivos afetam o desempenho ao influenciar a **escolha** e o **nível** das metas. O **feedback** atua como um reforçador ou punição implícita ao indicar o progresso. |

## Evidências Científicas sobre a Eficácia Comparativa

Uma meta-análise robusta sobre o impacto de recompensas e punições na **cooperação** em dilemas sociais revelou que ambos os mecanismos exibem um efeito positivo **estatisticamente equivalente** na promoção do comportamento desejado [9]. Este achado sugere que, em contextos de interação social, a punição (ou desincentivo) pode ser tão eficaz quanto a recompensa (ou incentivo) para a mudança comportamental, desde que variáveis moderadoras como o **custo** e a **fonte** dos incentivos sejam consideradas [9].

## Conclusão

A pesquisa acadêmica demonstra que os sistemas de incentivos e punições transcendem o simples condicionamento behaviorista, sendo profundamente modulados por fatores cognitivos, motivacionais e sociais. A eficácia de tais sistemas depende de uma aplicação sofisticada que considere: (1) a **qualidade da motivação** (TAD), (2) a **percepção de justiça** (Teoria da Equidade), (3) o **enquadramento** da consequência (Teoria da Perspectiva), e (4) o **estágio de mudança** do indivíduo (TTM, COM-B). Em suma, a mudança comportamental sustentável requer que os sistemas de incentivos e punições sejam desenhados não apenas para alterar o comportamento externo, mas para apoiar a **autonomia** e a **auto-regulação** do indivíduo.

***

## Referências

[1] J. E. R. Staddon, D. T. Cerutti, "Operant Conditioning," _Annu Rev Psychol_, 2002. [https://pmc.ncbi.nlm.nih.gov/articles/PMC1473025/](https://pmc.ncbi.nlm.nih.gov/articles/PMC1473025/)
[2] S. Linnemayr, T. Rice, "Insights from Behavioral Economics to Design More Effective Incentives for Improving Chronic Health Behaviors," _J Acquir Immune Defic Syndr_, 2016. [https://pmc.ncbi.nlm.nih.gov/articles/PMC4866888/](https://pmc.ncbi.nlm.nih.gov/articles/PMC4866888/)
[3] M. S. Hagger, "Changing behavior using self-determination theory," _Handbook of Behavior Change_, 2020. [https://psycnet.apa.org/record/2020-64356-008](https://psycnet.apa.org/record/2020-64356-008)
[4] C. Nickerson, "Albert Bandura's Social Cognitive Theory," _Simply Psychology_, 2025. [https://www.simplypsychology.org/social-cognitive-theory.html](https://www.simplypsychology.org/social-cognitive-theory.html)
[5] M. Hashemzadeh, "Transtheoretical Model of Health Behavioral Change," _J Clin Diagn Res_, 2019. [https://pmc.ncbi.nlm.nih.gov/articles/PMC6390443/](https://pmc.ncbi.nlm.nih.gov/articles/PMC6390443/)
[6] P. Romanowich, J. M. O'Donoghue, "The Effect of Framing Incentives as Either Losses or Gains on Health Behavior: A Review and Meta-Analysis," _J Appl Behav Anal_, 2013. [https://pmc.ncbi.nlm.nih.gov/articles/PMC3575603/](https://pmc.ncbi.nlm.nih.gov/articles/PMC3575603/)
[7] J. S. Adams, "Equity Theory: A review," _TheoryHub, Newcastle University_, 2025. [https://open.ncl.ac.uk/theories/5/equity-theory/](https://open.ncl.ac.uk/theories/5/equity-theory/)
[8] V. Vroom, "Victor Vroom's Expectancy Theory of Motivation," _Positive Psychology_, 2024. [https://positivepsychology.com/expectancy-theory/](https://positivepsychology.com/expectancy-theory/)
[9] D. Balliet, M. Mulder, P. A. M. Van Lange, "Reward, punishment, and cooperation: a meta-analysis," _Psychol Bull_, 2011. [https://pubmed.ncbi.nlm.nih.gov/21574679/](https://pubmed.ncbi.nlm.nih.gov/21574679/)
[10] R. B. Cialdini, R. R. Reno, C. A. Kallgren, "A Focus Theory of Normative Conduct," _Adv Exp Soc Psychol_, 1991. [https://www.sciencedirect.com/science/article/pii/S0065260108603305](https://www.sciencedirect.com/science/article/pii/S0065260108603305)
[11] E. A. Locke, G. P. Latham, "Building a Practically Useful Theory of Goal Setting and Task Motivation: A 35-Year Odyssey," _Am Psychol_, 2002. [https://med.stanford.edu/content/dam/sm/s-spire/documents/PD.locke-and-latham-retrospective_Paper.pdf](https://med.stanford.edu/content/dam/sm/s-spire/documents/PD.locke-and-latham-retrospective_Paper.pdf)
[12] A. Alyafei, R. Al-Ateeq, M. Al-Kuwari, "The Health Belief Model of Behavior Change," _StatPearls Publishing_, 2024. [https://www.ncbi.nlm.nih.gov/books/NBK606120/](https://www.ncbi.nlm.nih.gov/books/NBK606120/)
[13] I. Ajzen, "Teoria do Comportamento Planejado (Theory of Planned Behavior - TPB)," _Forms.app_, 2024. [https://forms.app/pt/blog/a-teoria-do-comportamento-planeado](https://forms.app/pt/blog/a-teoria-do-comportamento-planeado)
[14] S. Michie, M. M. van Stralen, R. West, "The behaviour change wheel: A new method for characterising and designing behaviour change interventions," _Implement Sci_, 2011. [https://pmc.ncbi.nlm.nih.gov/articles/PMC3096582/](https://pmc.ncbi.nlm.nih.gov/articles/PMC3096582/)
[15] G. C. Homans, P. M. Blau, R. B. Emerson, "Social Exchange Theory: A review," _TheoryHub, Newcastle University_, 2025. [https://open.ncl.ac.uk/theories/6/social-exchange-theory/](https://open.ncl.ac.uk/theories/6/social-exchange-theory/)

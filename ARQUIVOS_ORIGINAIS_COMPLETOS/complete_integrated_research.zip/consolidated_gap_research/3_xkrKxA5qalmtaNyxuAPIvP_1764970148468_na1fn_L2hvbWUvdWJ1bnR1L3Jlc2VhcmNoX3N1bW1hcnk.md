# Análise Detalhada: Teoria da Autorregulação e Esgotamento do Ego (Roy Baumeister)

## Área Temática

Psicologia Social, Psicologia Cognitiva e Economia Comportamental, com foco nos mecanismos de **autorregulação** e **autocontrole** e o **modelo de força** (Strength Model) proposto por Roy F. Baumeister.

## Principais Conceitos, Teorias e Frameworks

A pesquisa se concentrou na obra de Roy F. Baumeister e colaboradores, que estabeleceram o **Modelo de Força do Autocontrole** (Strength Model of Self-Control) e o conceito de **Esgotamento do Ego** (Ego Depletion).

| Conceito/Teoria | Descrição |
| :--- | :--- |
| **Teoria da Autorregulação (SRT)** | O processo pelo qual o indivíduo monitora e controla seus pensamentos, emoções, impulsos e comportamentos para atingir metas e se adaptar a demandas ambientais. Baumeister define a autorregulação como um sistema com quatro componentes essenciais: **1. Padrões** (metas ou ideais de comportamento); **2. Monitoramento** (acompanhamento do progresso em relação aos padrões); **3. Capacidade de Mudança** (a força de vontade necessária para alinhar o comportamento aos padrões); e **4. Motivação** (o desejo de cumprir os padrões). |
| **Modelo de Força do Autocontrole** | Framework conceitual que postula que o autocontrole opera como um **recurso limitado** (análogo a um músculo ou a um suprimento de energia). O exercício de qualquer ato de autocontrole consome esse recurso, levando a um estado temporário de fraqueza. |
| **Esgotamento do Ego (Ego Depletion)** | O estado de **capacidade reduzida** para o autocontrole após um ato anterior de esforço volitivo. É a manifestação do recurso limitado sendo consumido. O esgotamento do ego resulta em desempenho prejudicado em tarefas subsequentes que exigem autocontrole, mesmo que sejam tarefas não relacionadas. |
| **Recurso Limitado (Willpower)** | A **força de vontade** é o recurso mental finito que é consumido por atos de autocontrole, tomada de decisão e esforço cognitivo. A pesquisa inicial sugeriu que esse recurso poderia ser uma forma de energia metabólica, como a glicose, embora essa hipótese tenha sido amplamente debatida e revisada. |
| **Conservação de Recursos** | A tendência do indivíduo esgotado a **conservar** o recurso restante, resultando em menor esforço e preferência por tarefas menos exigentes, o que pode ser interpretado como falha no autocontrole. |

## Metodologias Práticas (Não-Tecnológicas)

As pesquisas de Baumeister e colaboradores, bem como as meta-análises subsequentes, identificaram diversas estratégias práticas para mitigar o esgotamento do ego e fortalecer a autorregulação, focando em estruturas humanas e psicológicas:

1.  **Treinamento de Força de Vontade (Willpower Training):** A analogia do músculo sugere que o autocontrole pode ser fortalecido com o exercício regular. Metodologias incluem a prática consistente de pequenas tarefas de autocontrole (ex: manter a postura, usar a mão não dominante, monitorar gastos) para aumentar a "reserva" de força de vontade ao longo do tempo.
2.  **Aumento da Motivação e Incentivos:** A depleção pode ser superada se a motivação para a segunda tarefa for alta. Metodologias de *coaching* e sistemas sociais podem usar incentivos, recompensas e *framing* de tarefas para aumentar o engajamento e superar o estado de esgotamento.
3.  **Afirmação de Valores (Self-Affirmation):** Estudos demonstraram que a afirmação de valores pessoais centrais pode **neutralizar** o efeito do esgotamento do ego, sugerindo que o foco na identidade e nos valores fundamentais pode restaurar o recurso ou a motivação.
4.  **Intervenções Nutricionais (Glicose):** Embora controversa, a hipótese da glicose levou a metodologias de intervenção que sugerem a suplementação de glicose (açúcar) como um meio rápido de restaurar o recurso de autocontrole em indivíduos esgotados.
5.  **Mindfulness e Consciência (Self-Awareness):** Metodologias baseadas em *mindfulness* e o aumento da autoconsciência são propostas como formas de melhorar o **monitoramento** (um dos quatro componentes da SRT) e reduzir a depleção, pois o indivíduo se torna mais consciente do estado de esgotamento e pode ajustar o esforço.

## Fontes Acadêmicas e Contribuições Teóricas

A tabela a seguir documenta 15 fontes acadêmicas relevantes, incluindo artigos seminais, meta-análises e revisões recentes, com suas principais contribuições teóricas.

| ID | Título | Autor(es) | Ano | URL/DOI | Contribuições Teóricas Principais |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Ego depletion and the strength model of self-control: a meta-analysis | Hagger, M. S., Wood, C., Stiff, C., & Chatzisarantis, N. L. D. | 2010 | [DOI: 10.1037/a0019486](https://doi.org/10.1037/a0019486) | **Meta-análise seminal** que forneceu forte suporte empírico inicial para o efeito de esgotamento do ego e o Modelo de Força, analisando 83 estudos. |
| 2 | Ego depletion: Is the active self a limited resource? | Baumeister, R. F., Bratslavsky, E., Muraven, M., & Tice, D. M. | 1998 | [DOI: 10.1037/0022-3514.74.5.1252](https://doi.org/10.1037/0022-3514.74.5.1252) | **Artigo seminal** que introduziu o termo "esgotamento do ego" e o conceito de que o autocontrole consome um recurso limitado, usando tarefas como supressão de emoções e escolhas. |
| 3 | Self-Regulation, Ego Depletion, and Motivation | Baumeister, R. F., & Vohs, K. D. | 2007 | [DOI: 10.1111/j.1751-9004.2007.00001.x](https://doi.org/10.1111/j.1751-9004.2007.00001.x) | Revisão que detalha o **Modelo de Força** e os quatro componentes da autorregulação (padrões, monitoramento, capacidade de mudança e motivação), integrando o esgotamento do ego na teoria da motivação. |
| 4 | The Strength Model of Self-Regulation: Conclusions From the Past and Implications for the Future | Baumeister, R. F. | 2018 | [DOI: 10.1016/j.copsyc.2017.12.006](https://doi.org/10.1016/j.copsyc.2017.12.006) | Revisão que reafirma o Modelo de Força, comparando o autocontrole a um músculo que se cansa, mas pode ser fortalecido. Aborda a **conservação de recursos** como um mecanismo de resposta à depleção. |
| 5 | Self-control and limited willpower: Current status of ego depletion theory and research | Baumeister, R. F., André, N., Southwick, D. A., & Vohs, K. D. | 2024 | [DOI: 10.1016/j.copsyc.2024.101829](https://doi.org/10.1016/j.copsyc.2024.101829) | **Atualização recente** que refina a teoria, enfatizando a importância de manipulações mais fortes e a possibilidade de **esgotamento crônico** (chronic ego depletion). |
| 6 | An updated meta-analysis of the ego depletion effect | Dang, J. | 2017 | [DOI: 10.1007/s00426-017-0862-x](https://doi.org/10.1007/s00426-017-0862-x) | **Meta-análise de replicação** que, embora mais cética que a de Hagger (2010), ainda encontrou um efeito significativo, mas menor, do esgotamento do ego, contribuindo para o debate sobre a robustez do efeito. |
| 7 | The Collapse of Ego Depletion | Inzlicht, M. | 2025 | [URL: michaelinzlicht.com/p/the-collapse-of-ego-depletion](https://www.speakandregret.michaelinzlicht.com/p/the-collapse-of-ego-depletion) | **Artigo de crítica** que discute a falha em replicar o efeito em grandes estudos (Registered Replication Report), propondo que o foco deve mudar do recurso limitado para a **mudança motivacional** e de atenção. |
| 8 | Training Willpower: Reducing Costs and Valuing Effort | Audiffren, M., André, N., & Baumeister, R. F. | 2022 | [DOI: 10.3389/fnins.2022.699817](https://doi.org/10.3389/fnins.2022.699817) | Foca em **metodologias de treinamento** (não-tecnológicas) para fortalecer a força de vontade, incluindo treinamento cognitivo baseado em processo e exercícios físicos, apoiando a analogia do músculo. |
| 9 | Self-affirmation and self-control: affirming core values counteracts ego depletion | Schmeichel, B. J., & Vohs, K. D. | 2009 | [DOI: 10.1037/a0014635](https://doi.org/10.1037/a0014635) | Demonstra uma **metodologia de intervenção** (afirmação de valores) que pode restaurar a capacidade de autocontrole após a depleção, sugerindo que o recurso pode ser reabastecido por meios psicológicos. |
| 10 | The Nature of Self-Regulatory Fatigue and "Ego Depletion": Lessons From Physical Fatigue | Evans, D. R., Boggero, I. A., & Segerstrom, S. C. | 2016 | [DOI: 10.1177/1088868315597841](https://doi.org/10.1177/1088868315597841) | Apresenta um **framework conceitual** que compara a fadiga autorregulatória à fadiga física, distinguindo entre a **fadiga percebida** (subjetiva) e a **fadiga real** (desempenho), o que é crucial para a metodologia de pesquisa. |
| 11 | A conceptual framework for understanding self-regulation in adults | MacKenzie, M. B., Mezo, P. G., & Francis, S. E. | 2012 | [DOI: 10.1016/j.newideapsych.2011.11.001](https://doi.org/10.1016/j.newideapsych.2011.11.001) | Propõe um **framework conceitual alternativo** baseado na **Teoria Cibernética** para organizar os modelos de autorregulação, oferecendo uma estrutura que complementa ou critica o Modelo de Força. |
| 12 | Understanding self-regulation | Vohs, K. D., & Baumeister, R. F. | 2004 | [URL: ndl.ethernet.edu.et/bitstream/123456789/28342/1/162.pdf.pdf#page=19](http://ndl.ethernet.edu.et/bitstream/123456789/28342/1/162.pdf.pdf#page=19) | Capítulo de livro que estabelece a autorregulação como uma das características mais importantes da natureza humana, moldada pela seleção natural para a participação na cultura. |
| 13 | Self-Regulation Failure: An Overview | Baumeister, R. F., & Heatherton, T. F. | 1996 | [URL: persweb.wabash.edu/facstaff/hortonr/articles%20for%20class/baumeister%20and%20heatherton.pdf](https://persweb.wabash.edu/facstaff/hortonr/articles%20for%20class/baumeister%20and%20heatherton.pdf) | **Revisão clássica** que categoriza as falhas de autorregulação (ex: conflito de padrões, falha de monitoramento) e estabelece a base para a pesquisa subsequente sobre esgotamento. |
| 14 | When perception is more than reality: the effects of perceived versus actual resource depletion on self-regulatory behavior | Clarkson, J. J., Hirt, E. R., Jia, L., & Alexander, M. B. | 2010 | [DOI: 10.1037/a0017539](https://doi.org/10.1037/a0017539) | Explora a distinção entre a **percepção** de esgotamento e o esgotamento **real**, sugerindo que as crenças dos participantes sobre a força de vontade podem modular o efeito. |
| 15 | Moderation of resource depletion in the self-control strength model: differing effects of two modes of self-control | Dvorak, R. D., & Simons, J. S. | 2009 | [DOI: 10.1177/0146167208330855](https://doi.org/10.1177/0146167208330855) | Investiga os **moderadores** do esgotamento, diferenciando entre modos de autocontrole (ex: inibição de resposta vs. regulação emocional), refinando o Modelo de Força. |

## Cobertura Geográfica

A pesquisa é predominantemente baseada em estudos de **Psicologia Social e Cognitiva** realizados em universidades e laboratórios de pesquisa nos **Estados Unidos** e na **Europa Ocidental** (Reino Unido, Holanda, Austrália). As meta-análises e revisões sistemáticas abrangem dados de diversos países, mas a origem teórica e a maior parte da produção acadêmica citada são do **Hemisfério Norte**.

## Número Total de Fontes Identificadas

15

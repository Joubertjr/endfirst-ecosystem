# Análise Teórica: Default Options e Friction em Design Comportamental

## Introdução

Esta pesquisa se concentra na análise de conceitos teóricos, *frameworks* e metodologias sobre *Default Options* (Opções Padrão) e *Friction* (Fricção) no campo do Design Comportamental, com uma ênfase estrita em fontes acadêmicas e teóricas da psicologia e economia comportamental. O objetivo é identificar as bases conceituais e as evidências científicas que sustentam a aplicação desses elementos na arquitetura de escolha, excluindo qualquer menção a tecnologia, aplicativos ou produtos comerciais, conforme as diretrizes do estudo.

## 1. Conceitos Fundamentais e Teorias Psicológicas

Os conceitos de *Default Options* e *Friction* estão profundamente enraizados em teorias psicológicas que descrevem a tomada de decisão humana, especialmente em contextos de **racionalidade limitada** e **heurísticas** [1] [2].

### 1.1. Default Options e o Efeito Status Quo

O poder das *Default Options* é explicado principalmente pelo **viés do status quo** (*status quo bias*) e pelo **efeito padrão** (*default effect*) [3]. O viés do status quo é a tendência das pessoas em preferir que as coisas permaneçam como estão, evitando a mudança [3]. O efeito padrão é uma manifestação desse viés, onde a opção pré-selecionada (o *default*) é escolhida com muito mais frequência do que seria esperado em uma escolha neutra [4].

As principais contribuições teóricas para o entendimento do *default effect* incluem:

*   **Esforço Cognitivo Reduzido:** Escolher a opção padrão elimina a necessidade de processamento de informação e comparação de alternativas, o que é preferido em um contexto de recursos cognitivos limitados [1].
*   **Implicação de Recomendação:** O *default* é frequentemente interpretado como uma recomendação implícita da autoridade ou do *choice architect* (arquiteto de escolha), sugerindo que é a opção socialmente aceitável ou a mais segura [5].
*   **Aversão à Perda:** A mudança do *default* pode ser percebida como uma perda potencial (o que se está abandonando), ativando a **aversão à perda** (*loss aversion*), um conceito central na Teoria da Perspectiva (*Prospect Theory*) [6].

### 1.2. Friction (Fricção) e Sludge

O conceito de *Friction* refere-se a qualquer elemento na arquitetura de escolha que **aumenta o esforço cognitivo ou físico** necessário para realizar uma ação [7]. Enquanto a redução da fricção é um princípio central do *Nudge* (empurrãozinho), a introdução intencional de fricção, conhecida como **Sludge** (lama), é um conceito correlato que descreve a criação de barreiras para desencorajar comportamentos [8].

| Tipo de Fricção | Descrição Teórica | Efeito Comportamental |
| :--- | :--- | :--- |
| **Fricção Comportamental** | Qualquer obstáculo que retarda ou impede o usuário de realizar uma ação desejada [7]. | Desencoraja a ação, levando à inação ou à escolha do *default* (se houver). |
| **Sludge (Lama)** | Fricção intencionalmente adicionada para dificultar ações que beneficiam o indivíduo (ex: cancelar uma assinatura) [8]. | Explora a **procrastinação** e a **inércia** para manter o *status quo* [9]. |

## 2. Frameworks Conceituais e Metodologias

Os conceitos de *Default Options* e *Friction* são operacionalizados por meio de *frameworks* conceituais que orientam a estruturação de escolhas, conhecidos como **Arquitetura de Escolha** (*Choice Architecture*) [10].

### 2.1. Arquitetura de Escolha e Nudge Theory

A **Nudge Theory** (Teoria do Nudge), popularizada por Thaler e Sunstein, é o principal *framework* que utiliza *Default Options* e a manipulação da *Friction* [10]. O *Nudge* é definido como qualquer aspecto da arquitetura de escolha que altera o comportamento das pessoas de maneira previsível, sem proibir opções ou alterar significativamente seus incentivos econômicos [10].

A aplicação metodológica desses conceitos é frequentemente resumida em *frameworks* práticos (não-tecnológicos), como o **EAST** (Easy, Attractive, Social, Timely) [11]:

*   **Easy (Fácil):** Reduzir a fricção e estabelecer *Default Options* para tornar a ação desejada o caminho de menor resistência.
*   **Attractive (Atraente):** Usar a atenção e a motivação.
*   **Social (Social):** Aproveitar o poder das normas sociais e dos *social defaults* (padrões sociais) [12].
*   **Timely (Oportuno):** Intervir no momento em que as pessoas estão mais receptivas.

### 2.2. Metodologias Práticas e Estruturas Humanas

Em contextos práticos e não-tecnológicos, as metodologias se concentram na estruturação de sistemas sociais e interações humanas:

*   **Group Defaults (Padrões de Grupo):** Em sistemas sociais e organizacionais, a escolha observada de outros pode se tornar um *default* social, influenciando a decisão individual [12]. Metodologias de **coaching** e **facilitação de grupo** podem ser usadas para estabelecer novos *defaults* de comportamento ou comunicação dentro de um grupo [13].
*   **Auditorias de Sludge:** Metodologias de avaliação que mapeiam e quantificam a fricção desnecessária em processos burocráticos ou de serviço (ex: preenchimento de formulários, procedimentos de cancelamento) para identificar pontos de intervenção e redução de *sludge* [8].
*   **Intervenções de Arquitetura de Agência:** Estruturas que visam aumentar a capacidade de agência do indivíduo, muitas vezes através da remoção de fricção ou da apresentação de *defaults* que promovem o bem-estar [14].

## 3. Evidências Científicas

A eficácia das *Default Options* e da manipulação da *Friction* é amplamente suportada por estudos empíricos, especialmente na área de decisões de longo prazo [4].

*   **Doação de Órgãos:** Estudos clássicos demonstram que países com *defaults* de **opt-out** (doação presumida, é preciso recusar) têm taxas de consentimento significativamente mais altas do que países com *defaults* de **opt-in** (é preciso consentir ativamente) [4].
*   **Planos de Aposentadoria:** A inscrição automática (*default enrollment*) em planos de poupança para aposentadoria demonstrou aumentar drasticamente as taxas de participação, superando a inércia e a fricção de ter que se inscrever ativamente [1].

## Referências

[1] Thaler, R. H., & Sunstein, C. R. (2008). *Nudge: Improving Decisions About Health, Wealth, and Happiness*. Yale University Press.
[2] Kahneman, D. (2011). *Thinking, Fast and Slow*. Farrar, Straus and Giroux.
[3] Samuelson, W., & Zeckhauser, R. (1988). Status Quo Bias in Decision Making. *Journal of Risk and Uncertainty*, 1(1), 7-59.
[4] Johnson, E. J., & Goldstein, D. G. (2003). Do Defaults Save Lives? *Science*, 302(5649), 1338-1339.
[5] McKenzie, C. R. M., Liersch, M. J., & Yaniv, I. (2006). Overcoming the Status Quo Bias: How Default Options Affect Decision Making. *Journal of Experimental Psychology: Learning, Memory, and Cognition*, 32(4), 825-839.
[6] Kahneman, D., & Tversky, A. (1979). Prospect Theory: An Analysis of Decision under Risk. *Econometrica*, 47(2), 263-291.
[7] Blumenstock, J., & Ghani, J. (2017). Why Do Defaults Affect Behavior? Experimental Evidence from a Field Experiment. *NBER Working Paper No. 23590*. [https://www.nber.org/system/files/working_papers/w23590/w23590.pdf](https://www.nber.org/system/files/working_papers/w23590/w23590.pdf)
[8] Sunstein, C. R. (2020). Sludge Audits. *Behavioral Public Policy*, 4(1), 654–673.
[9] Thaler, R. H. (2018). Nudge, Not Sludge. *Science*, 361(6408), 1177.
[10] Thaler, R. H., Sunstein, C. R., & Balz, J. P. (2014). Choice Architecture. In *The Behavioral Foundations of Public Policy* (pp. 428-439). Princeton University Press.
[11] Behavioural Insights Team (BIT). (2014). *EAST: Four Simple Ways to Apply Behavioural Insights*. [https://www.bi.team/publications/east-four-simple-ways-to-apply-behavioural-insights/](https://www.bi.team/publications/east-four-simple-ways-to-apply-behavioural-insights/)
[12] Huh, Y. E., Vosgerau, J., & Morewedge, C. K. (2014). Social Defaults: Observed Choices Become Choice Defaults. *Journal of Consumer Research*, 41(4), 1067-1081.
[13] Flanagan, T. R., & Christakis, A. N. (2010). *The Talking Point: Creating an Environment for Exploring Complex Meaning*. Information Age Publishing.
[14] Selinger, E., & Whyte, K. (2011). Is there a right way to nudge? The practice and ethics of choice architecture. *Sociology Compass*, 5(10), 923-935.

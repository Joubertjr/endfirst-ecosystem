# Relatório de Pesquisa: Economia Comportamental do Compromisso (Ariely, Laibson, Thaler)

## Área Temática
A pesquisa concentra-se na **Economia Comportamental do Compromisso**, um campo que investiga como indivíduos com problemas de autocontrole utilizam mecanismos voluntários para restringir suas escolhas futuras, alinhando suas ações presentes com seus objetivos de longo prazo. O foco está nos fundamentos teóricos, frameworks conceituais e evidências empíricas seminais, com ênfase nas contribuições de Dan Ariely, David Laibson e Richard Thaler.

## Introdução
A Economia Comportamental desafia o modelo neoclássico do *Homo Economicus* perfeitamente racional, introduzindo a realidade de vieses cognitivos e problemas de autocontrole. O conceito de **dispositivo de compromisso** (*commitment device*) emerge como uma solução racional para a irracionalidade intertemporal, permitindo que o "eu" presente (o *Planner*) limite as ações do "eu" futuro (o *Doer*) [1] [2].

## Fundamentos Teóricos e Frameworks

### 1. O Modelo do Desconto Quase-Hiperbólico (Laibson)
O trabalho seminal de **David Laibson** introduziu o modelo de **desconto quase-hiperbólico** (ou $\beta-\delta$) para descrever a preferência temporal inconsistente dos indivíduos [3].
*   **Conceito:** Enquanto o desconto exponencial tradicional assume uma taxa de desconto constante ao longo do tempo, o desconto quase-hiperbólico postula uma taxa de desconto muito mais alta para o futuro imediato (o fator $\beta$) em comparação com o futuro distante (o fator $\delta$).
*   **Implicação:** Essa estrutura de preferência leva à **inconsistência temporal**, onde as preferências de um indivíduo mudam à medida que o tempo passa. O indivíduo tende a procrastinar ações benéficas de longo prazo (como poupar ou se exercitar) em favor de recompensas imediatas.
*   **Compromisso:** Laibson demonstra que indivíduos com esse viés, especialmente aqueles que estão cientes de sua inconsistência (*sophisticated agents*), buscarão ativamente **dispositivos de compromisso** (como o conceito de "Ovos de Ouro" - *Golden Eggs*) para forçar a poupança ou outras ações de longo prazo [3].

### 2. A Teoria Econômica do Autocontrole (Thaler e Shefrin)
**Richard Thaler** e H.M. Shefrin desenvolveram o **Modelo Planner-Doer** (Planejador-Executor), que conceitua o indivíduo como uma organização com dois "eus" em conflito [1].
*   **O Planner (Planejador):** Representa o eu de longo prazo, com preferências consistentes e preocupado com o bem-estar vitalício.
*   **O Doer (Executor):** Representa o eu de curto prazo, impulsivo e focado na satisfação imediata.
*   **Conflito:** O problema do autocontrole é visto como um **problema de agência** interno, onde o Planejador deve encontrar maneiras de controlar o Executor.
*   **Mecanismos de Compromisso:** Os dispositivos de compromisso são as ferramentas que o Planejador usa para exercer controle sobre o Executor, impondo custos ou restrições a escolhas impulsivas [1].

### 3. Evidência Empírica e Tipologia (Ariely e Wertenbroch)
**Dan Ariely** e Klaus Wertenbroch forneceram evidências empíricas cruciais sobre a demanda por compromisso, focando em **prazos autoimpostos** (*self-imposed deadlines*) [4].
*   **Estudo:** Em um experimento com estudantes, eles demonstraram que as pessoas estão dispostas a se autoimpor prazos significativos (e até custosos) para superar a procrastinação.
*   **Conclusão:** O estudo valida a ideia de que os indivíduos reconhecem seu problema de autocontrole e buscam ativamente mecanismos externos para mitigar esse problema, mesmo que esses mecanismos restrinjam sua liberdade de escolha [4].

## Neurociência e Autocontrole
A neurociência fornece a base biológica para o conflito entre o Planejador e o Executor.
*   **Sistemas Cerebrais:** O autocontrole é frequentemente associado a um conflito entre o **sistema de recompensa límbico** (associado a impulsos e gratificação imediata) e o **córtex pré-frontal** (associado ao planejamento, cognição e controle executivo) [5].
*   **Implicações:** A ativação do córtex pré-frontal é crucial para a implementação de objetivos de longo prazo e para a eficácia dos dispositivos de compromisso. O trabalho de **Elliot Berkman** explora como a neurociência pode informar a compreensão dos mecanismos de mudança de comportamento e autocontrole [5].

## Pensamento Sistêmico
A aplicação do pensamento sistêmico na economia comportamental sugere que os dispositivos de compromisso não são eventos isolados, mas sim **intervenções em um sistema dinâmico** de feedback entre preferências, ações e resultados.
*   **Modelos Conceituais Avançados:** A integração da Economia Comportamental com a Dinâmica de Sistemas (System Dynamics) busca modelar a evolução das preferências e do autocontrole ao longo do tempo, reconhecendo que a demanda por compromisso pode ser endógena e variar em função do sucesso ou fracasso de compromissos anteriores [6].

## Fontes Acadêmicas Documentadas

| ID | Título | Autor(es) | Ano | URL/DOI | Principais Contribuições Teóricas |
| :---: | :--- | :--- | :---: | :--- | :--- |
| 1 | An Economic Theory of Self-Control | Thaler, R. H. & Shefrin, H. M. | 1981 | [Link](https://www.journals.uchicago.edu/doi/abs/10.1086/260971) | Introdução do **Modelo Planner-Doer** (Planejador-Executor) para explicar o problema do autocontrole como um problema de agência interno. |
| 2 | Golden Eggs and Hyperbolic Discounting | Laibson, D. | 1997 | [Link](https://econweb.ucsd.edu/~jandreon/Econ264/papers/Laibson%20QJE%201997.pdf) | Formalização do **Desconto Quase-Hiperbólico** ($\beta-\delta$) e demonstração de que agentes sofisticados com esse viés buscarão **dispositivos de compromisso** (Golden Eggs). |
| 3 | Procrastination, Deadlines, and Performance: Self-Control by Precommitment | Ariely, D. & Wertenbroch, K. | 2002 | [Link](http://houdekpetr.cz/!data/public_html/papers/economics_psychology/Ariely%20Wertenbroch%202002.pdf) | Evidência empírica crucial de que as pessoas estão dispostas a se autoimpor **prazos custosos** como um dispositivo de compromisso para superar a procrastinação. |
| 4 | Commitment Devices | Bryan, G., Karlan, D., & Nelson, S. | 2010 | [Link](https://www.annualreviews.org/doi/pdf/10.1146/annurev.economics.102308.124324) | Revisão abrangente da literatura sobre dispositivos de compromisso, discutindo a demanda, a eficácia e as questões teóricas relacionadas ao autocontrole. |
| 5 | Commitment Devices under Self-control Problems: An Overview | Brocas, I. & Carrillo, J. D. | 2004 | [Link](https://academic.oup.com/book/51915/chapter/420793215) | Visão geral dos diferentes tipos de dispositivos de compromisso e sua relação com os modelos de problemas de autocontrole. |
| 6 | Bringing Behavioral Economics into System Dynamics: Some Challenges, Solutions, and a Path Forward | (Não especificado, mas relacionado à busca) | (Não especificado) | [Link](https://link.springer.com/chapter/10.1007/978-3-031-40635-5_4) | Discussão sobre a integração de estruturas da economia comportamental (incluindo compromisso) em modelos de **Dinâmica de Sistemas** para análise de longo prazo. |
| 7 | The neuroscience of self-control | Berkman, E. T. | (Não especificado) | [Link](https://www.taylorfrancis.com/chapters/edit/10.4324/9781315648576-10/neuroscience-self-control-elliot-berkman) | Revisão sobre a contribuição da **neurociência** para o estudo do autocontrole, focando nos sistemas cerebrais (córtex pré-frontal vs. sistema límbico) envolvidos no conflito intertemporal. |
| 8 | Commitment, choice and self-control | Rachlin, H. | 1972 | [Link](https://pmc.ncbi.nlm.nih.gov/articles/PMC1333886/) | Artigo seminal que discute o conceito de compromisso como uma forma de preferência antecipada por uma alternativa de longo prazo, anterior à formalização da economia comportamental moderna. |
| 9 | The effectiveness of commitment devices: field experiments on health behaviour change | Savani, M. M. | 2017 | [Link](https://discovery.ucl.ac.uk/id/eprint/1557155/) | Meta-análise e estudos de campo sobre a eficácia dos dispositivos de compromisso na mudança de comportamentos de saúde, fornecendo evidências robustas. |
| 10 | Commitment Devices Using Initiatives to Change Behavior | Rogers, T., Milkman, K. L., & Volpp, K. G. | 2014 | [Link](https://jamanetwork.com/journals/jama/article-abstract/1866163) | Revisão focada na aplicação de dispositivos de compromisso para promover mudanças de comportamento, especialmente em contextos de saúde. |
| 11 | Commitment contracts | Bryan, G. | 2009 | [Link](https://www.econstor.eu/bitstream/10419/59154/1/612123901.pdf) | Definição e análise dos contratos de compromisso como arranjos que restringem o conjunto de escolhas futuras do agente. |
| 12 | When Commitment Fails – Evidence from a Field Experiment | John, A. | 2018 | [Link](https://economics.yale.edu/sites/default/files/john_when_commitment_fails_march2018.pdf) | Estudo que explora as condições sob as quais os dispositivos de compromisso podem falhar, frequentemente devido ao conhecimento imperfeito dos indivíduos sobre suas próprias preferências. |
| 13 | Empirical evidence on quasi-hyperbolic discounting | Laibson, D. | (Não especificado) | [Link](https://laibson.scholars.harvard.edu/file_url/202) | Artigo que sumariza as evidências empíricas que suportam o modelo de desconto quase-hiperbólico, reforçando a necessidade de mecanismos de compromisso. |
| 14 | Multiple commitments and behaviors: a mixed concept approach | Hoppe, D. | 2017 | [Link](https://www.emerald.com/insight/content/doi/10.1108/JPBM-04-2016-1148/full/html) | Análise de como múltiplos focos de compromisso interagem e influenciam o comportamento, introduzindo um modelo conceitual mais complexo. |
| 15 | Behavioral economics: Past, present, and future | Thaler, R. H. | 2016 | [Link](https://pubs.aeaweb.org/doi/pdf/10.1257/aer.106.7.1577) | Artigo de revisão que coloca o conceito de dispositivo de compromisso no contexto mais amplo da evolução da economia comportamental. |
| 16 | Conceptual Framework of Behavioural Economics | (Não especificado) | (Não especificado) | [Link](https://www.researchgate.net/publication/357185845_Conceptual_Framework_of_Behavioural_Economics) | Sistematização das características da economia comportamental, útil para contextualizar o papel dos dispositivos de compromisso no framework geral. |

## Referências
[1] Thaler, R. H. & Shefrin, H. M. (1981). *An Economic Theory of Self-Control*. The Journal of Political Economy.
[2] Bryan, G., Karlan, D., & Nelson, S. (2010). *Commitment Devices*. Annual Review of Economics.
[3] Laibson, D. (1997). *Golden Eggs and Hyperbolic Discounting*. The Quarterly Journal of Economics.
[4] Ariely, D. & Wertenbroch, K. (2002). *Procrastination, Deadlines, and Performance: Self-Control by Precommitment*. Psychological Science.
[5] Berkman, E. T. (Não especificado). *The neuroscience of self-control*. In Handbook of Self-Regulation: Research, Theory, and Applications.
[6] (Não especificado). *Bringing Behavioral Economics into System Dynamics: Some Challenges, Solutions, and a Path Forward*. Springer.
[7] Rachlin, H. (1972). *Commitment, choice and self-control*. Journal of the Experimental Analysis of Behavior.
[8] Savani, M. M. (2017). *The effectiveness of commitment devices: field experiments on health behaviour change*. University College London.
[9] Rogers, T., Milkman, K. L., & Volpp, K. G. (2014). *Commitment Devices Using Initiatives to Change Behavior*. JAMA.
[10] Bryan, G. (2009). *Commitment contracts*. Kiel Working Paper.
[11] John, A. (2018). *When Commitment Fails – Evidence from a Field Experiment*. Yale University.
[12] Brocas, I. & Carrillo, J. D. (2004). *Commitment Devices under Self-control Problems: An Overview*. The Psychology of Economic Decisions.
[13] Hoppe, D. (2017). *Multiple commitments and behaviors: a mixed concept approach*. Journal of Product & Brand Management.
[14] Thaler, R. H. (2016). *Behavioral economics: Past, present, and future*. American Economic Review.
[15] (Não especificado). *Conceptual Framework of Behavioural Economics*. ResearchGate.
[16] Laibson, D. (Não especificado). *Empirical evidence on quasi-hyperbolic discounting*. Harvard University.

# Relatório de Pesquisa Acadêmica: Arquitetura de Escolha e Design Ambiental

## 1. Área Temática e Objetivo

O presente relatório sintetiza a pesquisa acadêmica sobre os **conceitos teóricos, frameworks e metodologias** relacionados à **Arquitetura de Escolha** (*Choice Architecture*), conforme proposta por Richard H. Thaler e Cass R. Sunstein, e ao **Design Ambiental** (*Environmental Design*), com foco em abordagens não-tecnológicas e estruturas humanas. O objetivo principal foi identificar e analisar 15 a 20 fontes acadêmicas e teóricas que fundamentam a influência do ambiente de decisão no comportamento humano, excluindo expressamente aplicações tecnológicas, softwares ou produtos comerciais.

## 2. Conceitos-Chave, Teorias e Frameworks

A pesquisa revelou uma forte interconexão entre a Arquitetura de Escolha e o Design Ambiental, ambos focados em manipular o contexto para influenciar o comportamento de forma previsível, sem restringir a liberdade de escolha.

### 2.1. Arquitetura de Escolha e Paternalismo Libertário

A **Arquitetura de Escolha** é o framework conceitual central, definido como o *design* de diferentes maneiras pelas quais as opções podem ser apresentadas aos tomadores de decisão, e o impacto dessa apresentação na tomada de decisão [1]. O indivíduo que cria esse ambiente é denominado **Arquiteto de Escolha** [1].

Essa abordagem é fundamentada na filosofia do **Paternalismo Libertário** (*Libertarian Paternalism*), que propõe "empurrar" (*nudge*) as pessoas para escolhas que beneficiem seu próprio bem-estar, mantendo, contudo, a liberdade de escolha [1]. O *nudge* é uma intervenção que altera o comportamento de forma previsível sem proibir quaisquer opções ou alterar significativamente os incentivos econômicos [1].

Thaler, Sunstein e Balz identificaram **Seis Ferramentas do Arquiteto de Escolha** [1]:
1.  **Defaults** (Padrões): A opção que o indivíduo obtém se não fizer nada.
2.  **Expecting Error** (Antecipar Erros): Projetar o ambiente para minimizar erros comuns.
3.  **Understanding Mappings** (Compreender Mapeamentos): Tornar a relação entre escolha e resultado clara.
4.  **Giving Feedback** (Fornecer Feedback): Informar as pessoas sobre a qualidade de suas decisões.
5.  **Structuring Complex Choices** (Estruturar Escolhas Complexas): Simplificar a apresentação de opções.
6.  **Creating Incentives** (Criar Incentivos): Usar recompensas e punições.

Um framework mais detalhado, a **Taxonomia de Técnicas de Arquitetura de Escolha**, categoriza as intervenções em três grupos: **Informação da Decisão**, **Estrutura da Decisão** e **Assistência à Decisão** [3]. Estudos empíricos confirmam a eficácia dessas intervenções, especialmente para preencher o **Gap Intenção-Comportamento** (*Intention-Behavior Gap*), onde a intenção de agir não se traduz em ação [2] [7] [15].

### 2.2. Design Ambiental e Psicologia Ecológica

O **Design Ambiental** é um campo interdisciplinar que estuda a relação entre o ambiente físico e o comportamento humano, propondo a alteração intencional da estrutura física e social para influenciar o comportamento [4] [6].

O conceito fundamental que liga o Design Ambiental à psicologia é o de **Affordances** (*Permissividades* ou *Possibilidades de Ação*), introduzido por James J. Gibson na **Psicologia Ecológica** [10]. As *affordances* são as qualidades do ambiente que *oferecem* ou *mobilizam* certas ações por parte do indivíduo (ex: uma cadeira *affords* sentar) [10] [11]. O Design Ambiental, portanto, busca manipular essas *affordances* para promover comportamentos desejados, como o aumento da atividade física através da criação de espaços caminháveis e da redução de barreiras [5].

Uma metodologia prática notável é a **Prevenção de Crimes Através do Design Ambiental (CPTED)** (*Crime Prevention Through Environmental Design*), que utiliza princípios de design (Vigilância Natural, Controle de Acesso Natural, Reforço Territorial e Manutenção) para influenciar o comportamento social e reduzir a oportunidade de crime [13].

### 2.3. Frameworks de Expansão e Crítica

A evolução do campo levou a frameworks que expandem a visão original:
*   **Choice Architecture 2.0:** Reconhece que os indivíduos são "sensores sociais" (*social sensemakers*) que interpretam os *nudges*. Este framework enfatiza a necessidade de transparência e legitimidade para a eficácia e aceitação das intervenções [14].
*   **Infraestrutura de Escolha** (*Choice Infrastructure*): Argumenta que a Arquitetura de Escolha deve ser suportada por **condições e estruturas sistêmicas** (sistemas sociais e organizacionais) que permitam que as soluções funcionem, movendo o foco da mudança comportamental individual para as condições sistêmicas [16].
*   **Crítica Ética:** O Paternalismo Libertário enfrenta críticas éticas, levantando preocupações sobre a manipulação e a tensão com a dignidade e autonomia humana [9].

## 3. Metodologias Práticas e Evidências Científicas

As metodologias práticas identificadas são predominantemente não-tecnológicas e se enquadram em estruturas humanas e sistemas sociais:
*   **Taxonomia de Técnicas de Mudança de Comportamento (BCTs):** Um framework metodológico de 93 técnicas que servem como "ingredientes ativos" para intervenções, permitindo a avaliação sistemática da eficácia [12].
*   **Intervenções Microambientais:** Uso de **Prompting** (sinalização), **Message Framing** (enquadramento de mensagens), **Social Comparison** (comparação social) e **Feedback** em ambientes físicos e sociais para influenciar o comportamento [7].
*   **Experimentos de Campo:** Estudos empíricos de larga escala, como o que testou a eficácia do *self-directed scheduling nudge*, fornecem evidências científicas da aplicação de metodologias não-tecnológicas em contextos sociais [15].

## 4. Fontes Acadêmicas Identificadas

A tabela a seguir resume as 16 fontes acadêmicas e teóricas selecionadas para esta pesquisa.

| ID | Título | Autor(es) | Ano | URL | Principais Contribuições |
| :---: | :--- | :--- | :---: | :--- | :--- |
| 1 | Choice Architecture | Thaler, R. H., Sunstein, C. R., & Balz, J. P. | 2010 | [https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1583509]() | Definição de Arquitetura de Escolha, Paternalismo Libertário e as Seis Ferramentas do Arquiteto de Escolha. |
| 2 | The effectiveness of nudging: A meta-analysis of choice architecture interventions across behavioral domains | Mertens, S., Herberz, M., Hahnel, U. J. J., & Brosch, T. | 2021 | [https://pmc.ncbi.nlm.nih.gov/articles/PMC8740589/]() | Meta-análise que quantifica a eficácia do *nudging* e destaca o papel em preencher o *gap intenção-comportamento*. |
| 3 | A Review and Taxonomy of Choice Architecture Techniques | Münscher, R., Vetter, M., & Scheuerle, T. | 2016 | [https://onlinelibrary.wiley.com/doi/full/10.1002%2Fbdm.1897]() | Framework de taxonomia de técnicas de Arquitetura de Escolha (Informação, Estrutura, Assistência). |
| 4 | Environmental Design and Human Behavior: A Psychology of the Individual in Society | Krasner, L. | 2013 | [https://books.google.com/books?hl=en&lr=&id=RchGBQAAQBAJ&oi=fnd&pg=PP1]() | Definição de Design Ambiental e framework teórico na Psicologia Comportamental. |
| 5 | A systematic framework for understanding environmental design influences on physical activity in the elderly population | Gharaveis, A. | 2020 | [https://www.emerald.com/insight/content/doi/10.1108/f-08-2018-0094/full/html]() | Framework sistemático e evidências empíricas de estratégias de design ambiental (espaços caminháveis, redução de barreiras). |
| 6 | Environmental psychology for design | Kopec, D. | 2018 | [https://books.google.com/books?hl=en&lr=&id=6ZIyEAAAQBAJ&oi=fnd&pg=PR12]() | Fundamentação do design na Psicologia Ambiental (Teoria da Sobrecarga, Teoria da Restrição Comportamental). |
| 7 | Choice architecture interventions to change physical activity and sedentary behavior | Landais, L. L. et al. | 2020 | [https://ijbnpa.biomedcentral.com/articles/10.1186/s12966-020-00942-7]() | Revisão sistemática de intervenções microambientais (Prompting, Framing, Social Comparison) e sua eficácia. |
| 8 | Design for Behaviour Change as a Driver for Sustainable ... | Niedderer, K. | 2016 | [https://www.ijdesign.org/index.php/IJDesign/article/view/2260/740]() | Framework de Design para Mudança de Comportamento (DfBC) e o uso de CPTED como metodologia. |
| 9 | The dark side of nudging: The ethics, political economy, and law of libertarian paternalism | Vários | 2014 | [https://www.nomos-elibrary.de/de/10.5771/9783845263939-75.pdf]() | Crítica ética ao Paternalismo Libertário, questionando a manipulação e a autonomia. |
| 10 | J.J. Gibson – Affordances | Gibson, J. J. | 1979 | [https://cs.brown.edu/courses/cs137/2017/readings/Gibson-AFF.pdf]() | Introdução do conceito fundamental de **Affordances** (Permissividades) da Psicologia Ecológica. |
| 11 | Ecological Psychology in Design | The Decision Lab | S.D. | [https://lifestyle.sustainability-directory.com/area/ecological-psychology-in-design/]() | Aplicação da Psicologia Ecológica e manipulação de *affordances* no Design Ambiental. |
| 12 | A taxonomy of behavior change techniques used in interventions | Abraham, C. & Michie, S. | 2008 | [https://onlinelibrary.wiley.com/doi/abs/10.1037/0278-6133.27.3.379]() | Framework metodológico de 93 Técnicas de Mudança de Comportamento (BCTs) para intervenções. |
| 13 | Crime Prevention Through Environmental Design (CPTED) | Jeffery, C. R. / Crowe, T. D. | Vários | [https://designforsecurity.org/crime-prevention-through-environmental-design/]() | Metodologia prática de Design Ambiental para influenciar o comportamento social (prevenção de crimes). |
| 14 | Choice architecture 2.0: Behavioral policy as an implicit social contract | Krijnen, J. M. T., Tannenbaum, D., & Fox, C. R. | 2018 | [https://davetannenbaum.github.io/documents/KrijnenTannenbaumFox2018.pdf]() | Framework conceitual que reconhece a interpretação social dos *nudges* (social sensemakers). |
| 15 | A Randomized Experiment Testing the Efficacy of a Self-Directed Scheduling Nudge | Baker, R., Fox, B. L., & Johnson, M. A. | 2016 | [https://journals.sagepub.com/doi/10.1177/2332858416674007]() | Estudo empírico de campo sobre a eficácia de um *nudge* de planejamento (implementation intention). |
| 16 | A model for choice infrastructure: Looking beyond choice architecture in Behavioral Public Policy | Landais, L. M. et al. | 2020 | [https://www.cambridge.org/core/journals/behavioural-public-policy/article/model-for-choice-infrastructure-looking-beyond-choice-architecture-in-behavioral-public-policy/F5473FCBCF7402CBF4804566F46B3007]() | Framework conceitual de **Infraestrutura de Escolha** para suportar soluções de Arquitetura de Escolha em sistemas sociais. |

## Referências

[1] Thaler, R. H., Sunstein, C. R., & Balz, J. P. (2010). *Choice Architecture*. Harvard Public Law Working Paper. Disponível em: [https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1583509]()

[2] Mertens, S., Herberz, M., Hahnel, U. J. J., & Brosch, T. (2021). The effectiveness of nudging: A meta-analysis of choice architecture interventions across behavioral domains. *Proceedings of the National Academy of Sciences*, 119(1). Disponível em: [https://pmc.ncbi.nlm.nih.gov/articles/PMC8740589/]()

[3] Münscher, R., Vetter, M., & Scheuerle, T. (2016). A Review and Taxonomy of Choice Architecture Techniques. *Journal of Behavioral Decision Making*, 29(5), 511–524. Disponível em: [https://onlinelibrary.wiley.com/doi/full/10.1002%2Fbdm.1897]()

[4] Krasner, L. (2013). *Environmental Design and Human Behavior: A Psychology of the Individual in Society*. Elsevier. Disponível em: [https://books.google.com/books?hl=en&lr=&id=RchGBQAAQBAJ&oi=fnd&pg=PP1]()

[5] Gharaveis, A. (2020). A systematic framework for understanding environmental design influences on physical activity in the elderly population: A review of literature. *Facilities*, 38(9-10), 625–649. Disponível em: [https://www.emerald.com/insight/content/doi/10.1108/f-08-2018-0094/full/html]()

[6] Kopec, D. (2018). *Environmental psychology for design*. Fairchild Books. Disponível em: [https://books.google.com/books?hl=en&lr=&id=6ZIyEAAAQBAJ&oi=fnd&pg=PR12]()

[7] Landais, L. L. et al. (2020). Choice architecture interventions to change physical activity and sedentary behavior: a systematic review of effects on intention, behavior and health outcomes during and after intervention. *International Journal of Behavioral Nutrition and Physical Activity*, 17(47). Disponível em: [https://ijbnpa.biomedcentral.com/articles/10.1186/s12966-020-00942-7]()

[8] Niedderer, K. (2016). Design for Behaviour Change as a Driver for Sustainable ... *International Journal of Design*, 10(2). Disponível em: [https://www.ijdesign.org/index.php/IJDesign/article/view/2260/740]()

[9] Vários. (2014). The dark side of nudging: The ethics, political economy, and law of libertarian paternalism. *Nomos Verlagsgesellschaft*. Disponível em: [https://www.nomos-elibrary.de/de/10.5771/9783845263939-75.pdf]()

[10] Gibson, J. J. (1979). *The Ecological Approach to Visual Perception*. Houghton Mifflin. Disponível em: [https://cs.brown.edu/courses/cs137/2017/readings/Gibson-AFF.pdf]()

[11] The Decision Lab. (S.D.). *Ecological Psychology in Design*. Disponível em: [https://lifestyle.sustainability-directory.com/area/ecological-psychology-in-design/]()

[12] Abraham, C. & Michie, S. (2008). A taxonomy of behavior change techniques used in interventions. *Health Psychology*, 27(3), 379–387. Disponível em: [https://onlinelibrary.wiley.com/doi/abs/10.1037/0278-6133.27.3.379]()

[13] Design for Security. (S.D.). *Crime Prevention Through Environmental Design (CPTED)*. Disponível em: [https://designforsecurity.org/crime-prevention-through-environmental-design/]()

[14] Krijnen, J. M. T., Tannenbaum, D., & Fox, C. R. (2018). Choice architecture 2.0: Behavioral policy as an implicit social contract. *Behavioral Science & Policy*. Disponível em: [https://davetannenbaum.github.io/documents/KrijnenTannenbaumFox2018.pdf]()

[15] Baker, R., Fox, B. L., & Johnson, M. A. (2016). A Randomized Experiment Testing the Efficacy of a Self-Directed Scheduling Nudge. *Behavioral Science & Policy*, 2(2), 11–21. Disponível em: [https://journals.sagepub.com/doi/10.1177/2332858416674007]()

[16] Landais, L. M. et al. (2020). A model for choice infrastructure: Looking beyond choice architecture in Behavioral Public Policy. *Behavioural Public Policy*. Disponível em: [https://www.cambridge.org/core/journals/behavioural-public-policy/article/model-for-choice-infrastructure-looking-beyond-choice-architecture-in-behavioral-public-policy/F5473FCBCF7402CBF4804566F46B3007]()

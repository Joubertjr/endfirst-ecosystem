# Resumo da Pesquisa: Sistemas Educacionais, Estruturas de Suporte e Falhas de Implementação

A pesquisa focou na identificação de conceitos teóricos, frameworks e metodologias da Psicologia, Sociologia e Antropologia que abordam os sistemas educacionais, as estruturas de suporte ao aprendizado e, crucialmente, as **falhas de implementação** e a **resistência** a partir de fatores sociais, culturais e institucionais não-tecnológicos. Foram analisadas 15 fontes acadêmicas, incluindo artigos seminais e estudos cross-culturais, que convergem na crítica aos modelos lineares de implementação de políticas e na valorização do micro-nível e da cultura como elementos centrais.

## 1. Falhas de Implementação e Resistência Institucional

A literatura acadêmica questiona a visão simplista de que a falha de implementação é resultado de má-fé ou incompetência, propondo, em vez disso, que ela é um produto complexo de dinâmicas institucionais e culturais.

### 1.1. A Nova Teoria Institucional e o Desacoplamento

A **Nova Teoria Institucional** oferece um framework poderoso para entender a desconexão entre o que as organizações dizem que fazem (estrutura formal) e o que elas realmente fazem (prática) [13]. O artigo seminal de Meyer e Rowan [14] introduz os conceitos de **mitos institucionais** e **desacoplamento** (*decoupling*). Os mitos institucionais são regras e procedimentos formais adotados pelas organizações (como escolas) para ganhar **legitimidade** social e conformidade com o ambiente externo. O **desacoplamento** é a separação entre essa estrutura formal e o núcleo técnico (o ensino e a aprendizagem), servindo como uma estratégia de sobrevivência. A **falha de implementação** de reformas é, nesse sentido, uma resistência passiva: a escola adota a reforma formalmente, mas a ignora na prática para proteger o trabalho central das pressões externas [14].

DiMaggio e Powell [15] complementam essa visão ao descrever o **isomorfismo institucional** como o processo pelo qual as organizações se tornam semelhantes. Eles identificam três mecanismos que levam à homogeneização e, consequentemente, à resistência à inovação:
*   **Isomorfismo Coercitivo:** Pressão formal e informal de outras organizações, como regulamentações governamentais [15].
*   **Isomorfismo Mimético:** Imitação de organizações percebidas como bem-sucedidas em face da incerteza [15].
*   **Isomorfismo Normativo:** Disseminação de normas e práticas por meio da profissionalização e redes acadêmicas [15].

### 1.2. A Teoria da Atuação e o Micro-Nível

A **Teoria da Atuação** (*Policy Enactment Theory*), desenvolvida por Stephen Ball e colaboradores, desloca o foco da análise para o **micro-nível** da escola e do professor, tratando a implementação não como um processo linear, mas como um ato de **tradução** e **re-criação** da política [11, 12]. A **falha de implementação** é vista como o resultado da política ser "traduzida" pelos atores locais (a **burocracia de nível de rua**) em seus **contextos de prática** específicos. Esses atores usam seu **poder** e sua **cultura organizacional** para moldar o resultado da política, muitas vezes de forma não intencional ou resistente ao desenho original [11, 12].

## 2. Estruturas de Suporte, Cultura e Reprodução Social

As estruturas de suporte ao aprendizado e as falhas de implementação estão profundamente ligadas a fatores culturais e sociais, que atuam como forças de resistência ou de sustentação.

### 2.1. Cultura, Habitus e Reprodução Social

A Sociologia da Educação, especialmente a partir de Pierre Bourdieu, explica como as estruturas sociais e culturais perpetuam as desigualdades. Os conceitos de **Habitus**, **Capital Cultural** e **Campo** [5] são cruciais:
*   O **Capital Cultural** (conhecimentos, habilidades, credenciais valorizadas pela escola) é desigualmente distribuído.
*   O **Habitus** (sistema de disposições duráveis que orienta a percepção e a ação) dos alunos de classes dominantes está mais alinhado com o da escola, o que facilita o sucesso.
*   A **falha de implementação** de políticas de equidade pode ser explicada pela resistência do **campo** educacional em aceitar mudanças que ameacem o capital cultural dominante [5].

### 2.2. Resistência Cultural e Psicologia Social

Estudos cross-culturais e de psicologia social demonstram que a **resistência** à mudança e a **falha de implementação** podem ser ativamente enraizadas em culturas específicas.

*   **Resistência Ativa:** O estudo etnográfico clássico de Paul Willis, *Learning to Labour* [10], mostra que a **cultura da classe trabalhadora** (os "lads") leva à rejeição ativa da educação formal, o que paradoxalmente os direciona para empregos de classe trabalhadora, perpetuando a **reprodução social**. A resistência, neste caso, é uma causa direta da falha dos objetivos educacionais [10].
*   **Cultura e Liderança:** Em Zâmbia, a influência de valores culturais como o **Ubuntu** (comunalismo) molda as práticas de liderança e pode atuar como resistência a modelos de gestão ocidentais, demonstrando a necessidade de considerar a **alteridade** e a **diversidade** cultural [6, 1].
*   **Resistência Institucional:** A Psicologia Social de Silvia Lane [2] foca na **estrutura institucional** como fator de imobilização e resistência à mudança, enquanto estudos de caso em Porto Rico [9] e Tailândia [7] apontam a **cultura organizacional** e **movimentos sociais** enraizados na cultura como fatores de falha de implementação de políticas.

### 2.3. Estruturas de Suporte e Interação Social

A **Teoria Sociocultural** de Lev Vygotsky [8] define a **estrutura de suporte ao aprendizado** como essencialmente social e cultural. O conceito de **Zona de Desenvolvimento Proximal (ZDP)** descreve o espaço entre o que o aluno pode fazer sozinho e o que pode fazer com a ajuda de um mediador (professor, colega). A falha em prover o **suporte** (*scaffolding*) adequado, que é uma estrutura humana e social, é a falha fundamental na implementação de um sistema de aprendizado eficaz [8].

## 3. Conclusão

As 15 fontes analisadas fornecem um arcabouço teórico robusto para entender as falhas de implementação em sistemas educacionais a partir de uma perspectiva não-tecnológica. A falha é um fenômeno multifacetado, explicado pela **resistência cultural** (Willis, Jones), pelo **desacoplamento institucional** (Meyer & Rowan, DiMaggio & Powell), pela **tradução da política** no micro-nível (Ball, Lopes) e pela **reprodução das desigualdades** (Bourdieu). A superação dessas falhas requer uma compreensão profunda das dinâmicas sociais, culturais e institucionais que atuam como forças de imobilização e resistência.

***

## Referências

[1] Gusmão, N. M. M. de. (2008). Antropologia, Estudos Culturais e Educação: desafios da modernidade. *Psicologia em Estudo*, *13*(1), 3-10. [https://www.scielo.br/j/pp/a/gf5Sxt3S7FqFpDt8RTfZKTM/](https://www.scielo.br/j/pp/a/gf5Sxt3S7FqFpDt8RTfZKTM/)
[2] Lane, S. T. M. (1981). O processo grupal. In S. T. M. Lane & W. Codo (Orgs.), *Psicologia social - o homem em movimento*. Brasiliense. [https://taymarillack.wordpress.com/wp-content/uploads/2019/08/o-processo-grupal-silvia-lane.pdf](https://taymarillack.wordpress.com/wp-content/uploads/2019/08/o-processo-grupal-silvia-lane.pdf)
[3] Peci, A. (2006). A nova teoria institucional em estudos organizacionais: uma abordagem crítica. *Cadernos EBAPE.BR*, *4*(3), 1-18. [https://www.scielo.br/j/cebape/a/GWgS43FXQ4xD6XCM6yQtM6s/](https://www.scielo.br/j/cebape/a/GWgS43FXQ4xD6XCM6yQtM6s/)
[4] Torres, H. da G., Camelo, R., & Castro, M. H. G. (2019). Dificuldades de Coordenação e Políticas Educacionais no Brasil: O Caso do Ensino Fundamental. *Dados*, *62*(3), 1-38. [https://www.scielo.br/j/dados/a/dHxBJgqzz86HkvQFpvYdbrv/?lang=pt](https://www.scielo.br/j/dados/a/dHxBJgqzz86HkvQFpvYdbrv/?lang=pt)
[5] Aquino, K. T. de. (2024). Contribuições de Bourdieu para a sociologia da educação. *Revista Educação, Cultura e Sociedade*, *14*(1), 1-15. [https://revistaseduc.educacao.go.gov.br/index.php/rec/article/view/150](https://revistaseduc.educacao.go.gov.br/index.php/rec/article/view/150)
[6] Matshakaile, M. (2019). *The influence of culture on Educational Leadership in Zambia: a case study of the Phiri School* (Tese de Doutorado). University of Leicester. [https://figshare.le.ac.uk/articles/thesis/The_influence_of_culture_on_Educational_Leadership_in_Zambia_a_case_study_of_the_Phiri_School/11323532/1](https://figshare.le.ac.uk/articles/thesis/The_influence_of_culture_on_Educational_Leadership_in_Zambia_a_case_study_of_the_Phiri_School/11323532/1)
[7] Jones, M. E. (2008). Thailand and globalization: The state reform utilities of Buddhism, culture, and education and the social movement of socially and spiritually engaged alternative education. *International Journal of Educational Development*, *28*(6), 683-695. [https://www.emerald.com/insight/content/doi/10.1016/S1479-358X(08)06016-6/full/html](https://www.emerald.com/insight/content/doi/10.1016/S1479-358X(08)06016-6/full/html)
[8] Vygotsky, L. S. (1978). *Mind in Society: The Development of Higher Psychological Processes*. Harvard University Press. [https://w.pauldowling.me/rtf/2021.1/readings/LSVygotsky_1978_MindinSocietyDevelopmentofHigherPsycholo.pdf](https://w.pauldowling.me/rtf/2021.1/readings/LSVygotsky_1978_MindinSocietyDevelopmentofHigherPsycholo.pdf)
[9] Fernandez, A. C. R. (2014). *A case study of resistance to change and accountability: Investigating underlying factors triggering resistance to change in the department of education of the Commonwealth of Puerto Rico* (Tese de Doutorado). Colorado Technical University. [https://search.proquest.com/openview/3488fe2bcf62ee437c22af2c8e9688bd/1?pq-origsite=gscholar&cbl=18750](https://search.proquest.com/openview/3488fe2bcf62ee437c22af2c8e9688bd/1?pq-origsite=gscholar&cbl=18750)
[10] Willis, P. (1977). *Learning to Labour: How Working Class Kids Get Working Class Jobs*. Routledge. [https://www.taylorfrancis.com/books/mono/10.4324/9781351218788/learning-labour-paul-willis](https://www.taylorfrancis.com/books/mono/10.4324/9781351218788/learning-labour-paul-willis)
[11] Batista, V. A. A., & Braga, D. S. (2024). Ciclo de políticas e Teoria da Atuação: contribuições para as pesquisas em políticas educacionais. *Revista de Administração Educacional*, *14*(2), 1-18. [https://periodicos.ufpe.br/revistas/index.php/ADED/article/view/261929](https://periodicos.ufpe.br/revistas/index.php/ADED/article/view/261929)
[12] Lopes, A. C. (2016). A teoria da atuação de Stephen Ball: E se a noção de discurso fosse outra? *Archivos Analíticos de Políticas Educativas*, *24*(25), 1-20. [https://www.researchgate.net/publication/296475026_A_teoria_da_atuacao_de_Stephen_Ball_E_se_a_nocao_de_discurso_fosse_outra](https://www.researchgate.net/publication/296475026_A_teoria_da_atuacao_de_Stephen_Ball_E_se_a_nocao_de_discurso_fosse_outra)
[13] Hanson, M. (2001). Institutional Theory and Educational Change. *Educational Administration Quarterly*, *37*(5), 637-661. [https://journals.sagepub.com/doi/abs/10.1177/00131610121969451](https://journals.sagepub.com/doi/abs/10.1177/00131610121969451)
[14] Meyer, J. W., & Rowan, B. (1977). Institutionalized Organizations: Formal Structure as Myth and Ceremony. *The American Journal of Sociology*, *83*(2), 340-363. [http://www.iot.ntnu.no/innovation/norsi-pims-courses/harrison/Meyer%20&%20Rowan%20(1977).PDF](http://www.iot.ntnu.no/innovation/norsi-pims-courses/harrison/Meyer%20&%20Rowan%20(1977).PDF)
[15] DiMaggio, P. J., & Powell, W. W. (1983). The Iron Cage Revisited: Institutional Isomorphism and Collective Rationality in Organizational Fields. *American Sociological Review*, *48*(2), 147-160. [https://www.researchgate.net/publication/255482957_The_Iron_Cage_Revisted_Institutional_Isomorphism_and_Collective_Rationality_in_Organizational_Fields](https://www.researchgate.net/publication/255482957_The_Iron_Cage_Revisted_Institutional_Isomorphism_and_Collective_Rationality_in_Organizational_Fields)

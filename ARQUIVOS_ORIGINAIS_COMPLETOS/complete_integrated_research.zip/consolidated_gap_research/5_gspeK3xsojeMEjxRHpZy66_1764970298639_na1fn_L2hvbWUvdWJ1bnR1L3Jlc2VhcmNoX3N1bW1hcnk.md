# Análise Teórica e Frameworks de Formação de Hábitos: Uma Revisão da Psicologia Comportamental

A pesquisa sobre a **formação de hábitos** e a **mudança de comportamento** representa um campo central na psicologia comportamental e social, buscando compreender os mecanismos que governam a transição da intenção para a ação. O foco desta análise reside nos frameworks conceituais de **Wendy Wood** e **BJ Fogg**, complementados por metodologias de autorregulação como as **Intenções de Implementação** de Peter Gollwitzer, que conjuntamente oferecem uma base robusta para abordar a **lacuna de implementação** (Intention-Behavior Gap).

## O Hábito como Processo Automático (Wendy Wood)

A teoria do hábito de Wendy Wood, desenvolvida em colaboração com David Neal e Dennis Rünger, define o hábito como uma **associação contexto-resposta** na memória, que se desenvolve por meio da repetição consistente de um comportamento em um contexto estável [1] [2]. A principal característica do hábito é a sua **automaticidade** e **eficiência** [3]. Uma vez formado, a percepção do contexto (p. ex., local, hora, pessoas) desencadeia a resposta associada **sem a necessidade de um objetivo mediador** ou de deliberação consciente [2].

Wood e seus colaboradores posicionam o hábito dentro dos **modelos de processo dual** (Dual-Process Models), distinguindo-o do controle deliberativo (metas e intenções) [7]. O hábito é caracterizado por ser um sistema de **aprendizado modelo-livre** (model-free learning), lento e gradual, baseado em recompensas passadas, enquanto as metas pertencem ao sistema **modelo-baseado** (model-based learning), rápido e orientado a resultados futuros [9].

> "Os hábitos surgem do aprendizado gradual de associações entre respostas e as características dos contextos de desempenho que historicamente covariaram com elas (p. ex., ambientes físicos, ações precedentes). Uma vez formado um hábito, a percepção dos contextos desencadeia a resposta associada sem um objetivo mediador." [3]

A implicação prática dessa teoria é que a mudança de hábito não depende primariamente da **força de vontade** (willpower), mas sim da **mudança do contexto** [11] [16]. Ao alterar o ambiente ou a rotina, os gatilhos contextuais antigos são removidos, facilitando a interrupção do ciclo automático e a formação de novas associações [19].

## O Modelo Comportamental de BJ Fogg (FBM)

O **Fogg Behavior Model (FBM)**, proposto por BJ Fogg, oferece um framework prático e parcimonioso para analisar e projetar a mudança de comportamento, postulando que o comportamento (B) é um produto da convergência de três fatores simultâneos: **Motivação (M)**, **Habilidade (A)** e **Prompt/Gatilho (P)** [4]. A relação é expressa pela fórmula: $$B = M \cdot A \cdot P$$

O modelo é visualizado por um gráfico onde a Motivação e a Habilidade se cruzam, definindo uma **Linha de Ação** (Action Line). Para que um comportamento ocorra, o indivíduo deve estar acima dessa linha.
*   **Motivação:** O desejo ou a energia para realizar o comportamento. Fogg a divide em subcomponentes como Sensação, Antecipação e Pertencimento [20].
*   **Habilidade (Ability):** A capacidade de realizar o comportamento, com foco na **simplicidade** [4]. Quanto mais simples o comportamento, maior a Habilidade percebida. Os subcomponentes da Habilidade incluem tempo, dinheiro, esforço físico e mental [20].
*   **Prompt (Gatilho):** Um chamado à ação que sinaliza o momento de realizar o comportamento.

A principal contribuição do FBM é a ênfase na **Habilidade/Simplicidade** como o fator mais eficaz para a mudança de comportamento, pois é mais fácil tornar um comportamento simples do que aumentar a motivação de forma sustentável [4].

## Metodologias para Superar a Lacuna de Implementação

A **lacuna intenção-comportamento** (Intention-Behavior Gap) descreve o fenômeno comum em que a intenção de realizar um comportamento não se traduz em ação efetiva [18]. Para mitigar essa lacuna, a psicologia comportamental desenvolveu metodologias de autorregulação, notavelmente as **Intenções de Implementação** (Implementation Intentions) de Peter M. Gollwitzer [4] [17].

As Intenções de Implementação são planos de autorregulação no formato **"Se-Então"** (If-Then plans), que especificam **quando, onde e como** a pessoa agirá para atingir uma meta [4]. O mecanismo psicológico subjacente é a criação de uma **automaticidade** na resposta ao gatilho contextual, similar ao conceito de hábito de Wood, mas de forma intencional e imediata [12].

Outra metodologia relevante é o framework **WOOP** (Wish, Outcome, Obstacle, Plan), que combina o **Contraste Mental** (Mental Contrasting - MC) com as Intenções de Implementação (II) [8]. O MC energiza a ação ao contrastar o resultado positivo desejado com os obstáculos internos, enquanto o II fornece o plano prático para superar esses obstáculos, formando uma poderosa estrutura de autorregulação não-tecnológica.

## Síntese dos Frameworks Teóricos

A tabela a seguir resume as principais contribuições dos frameworks e metodologias analisadas, destacando seus focos na formação e mudança de hábitos.

| Framework/Metodologia | Autor(es) | Foco Principal | Mecanismo Teórico | Aplicação Prática (Não-Tecnológica) |
| :--- | :--- | :--- | :--- | :--- |
| **Teoria do Hábito** | Wendy Wood | Definição e Mecanismos do Hábito | Associação Contexto-Resposta (Automática) | Mudança de Contexto (Autorregulação Externa) |
| **Fogg Behavior Model (FBM)** | BJ Fogg | Condições para a Ocorrência do Comportamento | Convergência de Motivação, Habilidade e Prompt | Aumento da Simplicidade (Habilidade) do Comportamento |
| **Intenções de Implementação** | P. Gollwitzer, P. Sheeran | Superação da Lacuna Intenção-Comportamento | Planos "Se-Então" (Automaticidade Intencional) | Planejamento Detalhado de Respostas a Gatilhos |
| **WOOP** | G. Oettingen, P. Gollwitzer | Autorregulação e Motivação | Contraste Mental + Planos "Se-Então" | Energização e Planejamento para Superar Obstáculos Internos |

## Conclusão

Os frameworks de Wendy Wood e BJ Fogg, juntamente com as metodologias de autorregulação como as Intenções de Implementação, fornecem um conjunto de ferramentas conceituais e práticas para entender e intervir na formação de hábitos. Enquanto Wood oferece uma compreensão profunda dos **mecanismos psicológicos** do hábito como um processo automático e eficiente, Fogg apresenta um **modelo preditivo** que enfatiza a importância da simplicidade e do gatilho. As Intenções de Implementação, por sua vez, servem como uma **metodologia prática** para traduzir a intenção em ação, automatizando a resposta a pistas contextuais e, assim, superando a lacuna de implementação.

---

## Referências

[1] Wood, W., & Rünger, D. (2016). **Psychology of Habit**. *Annual Review of Psychology*, 67, 289–314. URL: https://dornsife.usc.edu/wendy-wood/wp-content/uploads/sites/183/2023/10/wood.runger.2016.pdf
[2] Wood, W., & Neal, D. T. (2007). **A new look at habits and the habit-goal interface**. *Psychological Review*, 114(4), 843–863. URL: https://psycnet.apa.org/fulltext/2007-13558-001.html (Abstract)
[3] Verplanken, B., & Orbell, S. (2022). **Attitudes, habits, and behavior change**. *Annual Review of Psychology*, 73, 327–352. URL: https://www.annualreviews.org/content/journals/10.1146/annurev-psych-020821-011744 (Abstract)
[4] Fogg, B. J. (2009). **A Behavior Model for Persuasive Design**. *Proceedings of the 4th International Conference on Persuasive Technology*. URL: https://www.demenzemedicinagenerale.net/images/mens-sana/Captology_Fogg_Behavior_Model.pdf
[5] Gollwitzer, P. M., & Sheeran, P. (2006). **Implementation intentions and goal achievement: A meta-analysis of effects and processes**. *Advances in Experimental Social Psychology*, 38, 69–119. URL: https://psycnet.apa.org/record/2007-19538-002 (Abstract)
[6] Gardner, B., & Rebar, A. L. (2019). **Habit formation and behavior change**. *Oxford Research Encyclopedia of Psychology*. URL: https://oxfordre.com/psychology/display/10.1093/acrefore/9780190236557.001.0001/acrefore-9780190236557-e-129 (Abstract)
[7] Wood, W., Mazar, A., & Neal, D. T. (2022). **Habits and Goals in Human Behavior: Separate but Interacting Systems**. *Perspectives on Psychological Science*, 17(1), 164–179.
[8] Oettingen, G., & Gollwitzer, P. M. (2001). **Strategies of setting and implementing goals: Mental contrasting and implementation intentions**. In F. W. van Eerde & B. A. P. E. van Hout (Eds.), *The psychology of goal setting, performance, and self-regulation* (pp. 117–135).
[9] Wood, W., & Mazar, A. (2019). **Defining habit in psychology**. In W. Wood, & D. Rünger (Eds.), *The psychology of habit: Theory, mechanisms, change, and context* (pp. 13–29). Springer.
[10] Wood, W. (2015). **The role of habits in self-control**. In J. Hofmann & W. Friese (Eds.), *The handbook of self-regulation: Research, theory, and applications* (pp. 95–110).
[11] Wood, W. (2021). **The Power of Habit…. It's Not Through Goals**. *Behavioral Policy*, 5(1), 1–12.
[12] Sheeran, P., Listrom, O., & Gollwitzer, P. M. (2025). **The when and how of planning: Meta-analysis of the scope and components of implementation intentions in 642 tests**. *European Review of Social Psychology*.
[13] Sheeran, P., et al. (2011). **A meta-analytic review of the effect of implementation intentions on physical activity**. *Psychology & Health*, 26(10), 1351–1368.
[14] Singh, B., et al. (2024). **Time to Form a Habit: A Systematic Review and Meta-Analysis**. *International Journal of Behavioral Nutrition and Physical Activity*, 21(1), 1–15.
[15] Potthoff, S., et al. (2019). **The relationship between habit and healthcare professional behaviour in clinical practice: a systematic review and meta-analysis**. *Psychology & Health*, 34(12), 1477–1496.
[16] Gardner, B., Lally, P., & Wardle, J. (2012). **Making health habitual: the psychology of 'habit-formation' and general practice**. *British Journal of General Practice*, 62(605), 664–666. URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC3505409/
[17] Sniehotta, S., et al. (2012). **Implementation intentions to reduce smoking: a systematic review of the literature**. *Nicotine & Tobacco Research*, 14(7), 779–788.
[18] Faries, M. D. (2016). **Why We Don't “Just Do It”: Understanding the Intention–Behavior Gap**. *Journal of Physical Activity and Health*, 13(12), 1269–1274.
[19] Wood, W. (2017). **Habit in Personality and Social Psychology**. *Personality and Social Psychology Review*, 21(4), 389–401.
[20] Fogg, B. J. (2009). **A Behavior Model for Persuasive Design** (Subcomponentes). *Proceedings of the 4th International Conference on Persuasive Technology*. URL: https://www.demenzemedicinagenerale.net/images/mens-sana/Captology_Fogg_Behavior_Model.pdf

# Resumo da Pesquisa: Programas de 12 Passos (AA) e Accountability em Grupo

Este relatório apresenta uma síntese de 20 fontes acadêmicas e teóricas sobre os Programas de 12 Passos (AA) e o conceito de accountability em grupo, com foco nas perspectivas psicológicas, sociológicas, antropológicas e nas evidências de falhas de implementação. A análise se concentra em sistemas humanos e sociais, estruturas institucionais não-tecnológicas e diferenças culturais, conforme solicitado.

## Principais Conceitos, Teorias e Frameworks

**Accountability em Grupo como Mecanismo de Aplicação de Normas (Tetlock)**: A accountability é vista como uma variável que liga o agente individual ao sistema social, sendo um mecanismo fundamental para a aplicação de normas e a manutenção da ordem social [4]. Em grupos de ajuda mútua, ela se manifesta como uma restrição implícita ou explícita sobre o comportamento dos membros.
**Teia de Accountability (Accountability Web) e Variação Cultural (Gelfand)**: O conceito de 'Accountability Web' demonstra que as forças de accountability operam em múltiplos níveis (individual, interpessoal, grupo) e são profundamente moldadas por dimensões culturais, como **individualismo-coletivismo** e **rigidez-frouxidão cultural** [3].
**Falha de Implementação (Stame & Birken)**: As falhas em programas sociais são categorizadas em falha de teoria, falha de implementação (o programa não foi executado como planejado) e falha de avaliação [14]. A falha de implementação está frequentemente ligada à **falta de ajuste** (fit) entre a intervenção (o AA) e o contexto organizacional/social [10].
**Dinâmica de Grupo e Coesão (Kelly & Tonigan)**: O sucesso dos 12 Passos é explicado por mecanismos de mudança como **coesão de grupo**, **universalidade** e **apoio social específico para a abstinência** [7] [16]. A coesão e a expressividade do grupo mitigam a evasão (falha de implementação individual) [17].
**Transformação Social do Self e Interacionismo Simbólico (Gallo-Treacy)**: O AA promove uma **transformação social do self** através da interação em grupo, onde o indivíduo internaliza uma nova identidade social ('alcoólico em recuperação') e um novo conjunto de significados [11].
**Rito de Passagem e Ritual Terapêutico**: O processo de recuperação é analisado como um **rito de iniciação** (separação, liminaridade, reincorporação), onde os 12 Passos e as reuniões atuam como **rituais terapêuticos** que fornecem estrutura e significado [12].
**Accountability Institucional Descentralizada (Room & Hoffmann)**: As **Doze Tradições** do AA estabelecem uma estrutura de **liderança servidora** e **anonimato** que previne a concentração de poder e garante a sobrevivência do grupo, atuando como um sistema de **controle social** e **accountability institucional descentralizada** [8] [15].
**Liberdade e Compulsão (Rodrigues & Almeida)**: Uma análise psicodinâmica/filosófica que confronta a noção de impotência com a **dimensão da escolha** (liberdade), sugerindo que o sucesso reside na reintrodução da agência individual através da força externa do grupo [1].

## Análise das Falhas de Implementação e Perspectivas Culturais

As falhas de implementação nos Programas de 12 Passos e em iniciativas de accountability em grupo podem ser compreendidas pela lente da **incompatibilidade cultural** e da **dinâmica psicossocial** [3] [5].

O **contexto cultural e institucional** influencia diretamente a aceitação do modelo. Estudos cross-culturais comparando a Noruega e os Estados Unidos [5] identificaram barreiras como a percepção de que o modelo é **muito religioso** e a **falta de adaptação cultural** para populações específicas. O sucesso da implementação em diferentes culturas, como em grupos latinos [6], depende da **ressignificação e adaptação** dos conceitos centrais (e.g., 'Poder Superior') para se alinharem com as normas culturais e sociais do grupo.

No nível do grupo, a falha de implementação individual (evasão) é mitigada pela **coesão** e pelo **apoio social** [17] [18]. A **falta de accountability** em grupos (ou seja, baixa expectativa de que o trabalho será avaliado) pode levar à complacência [13]. A accountability mútua é um subproduto da **reciprocidade social** e do **serviço** [18] [20], onde a falha em cumprir as normas ameaça o capital social do indivíduo e a coesão do grupo.

## Tabela de Fontes Acadêmicas

| ID | Título | Autor(es) | Ano | URL |
|:---|:---|:---|:---|:---|
| [1] | Liberdade e Compulsão: Uma Análise da Programação dos Doze Passos dos Alcoólicos Anônimos | Joelson Tavares Rodrigues, Leonardo Pinto de Almeida | 2002 | https://www.scielo.br/j/pe/a/9jd3xNh5sjwbLq95kpzm5FQ/?format=pdf&lang=pt |
| [2] | Alcoholics Anonymous and other 12-step programs for alcohol use disorder (Revisão Cochrane) | John F. Kelly, Keith Humphreys, Marica Ferri | 2020 | https://www.cochrane.org/about-us/news/new-cochrane-review-finds-alcoholics-anonymous-and-12-step-facilitation-programs-help-people |
| [3] | Culture and accountability in organizations: Variations in forms of social control across cultures | Michele J. Gelfand, Beng-Chong Lim, Jana L. Raver | 2004 | https://www.sciencedirect.com/science/article/abs/pii/S1053482204000087 |
| [4] | Accountability theory: Mixing properties of human agents with properties of social systems | Philip E. Tetlock | 1999 | https://www.taylorfrancis.com/chapters/edit/10.4324/9781410603227-6/accountability-theory-mixing-properties-human-agents-properties-social-systems-philip-tetlock |
| [5] | Obstacles to 12-step group participation as seen by addiction professionals: comparing Norway to the United States | John K. Vederhus, Amelie Laudet, Øystein Kristensen | 2010 | https://pubmed.ncbi.nlm.nih.gov/20619998/ |
| [6] | 'Spirituality' and 'cultural adaptation' in a Latino mutual aid group for substance misuse and mental health | B. T. Anderson | 2015 | https://pmc.ncbi.nlm.nih.gov/articles/PMC4706138/ |
| [7] | Mechanisms of behavior change in 12-step approaches to recovery in young adults | John F. Kelly | 2018 | https://pmc.ncbi.nlm.nih.gov/articles/PMC6224158/ |
| [8] | Alcoholics Anonymous as a Social Movement | Robin Room | Desconhecido | https://www.robinroom.net/alcoanon.htm |
| [9] | Social accountability: What does the evidence really say? | Jonathan Fox | 2015 | https://www.sciencedirect.com/science/article/pii/S0305750X15000704 |
| [10] | Organizational theory for dissemination and implementation research: an overview and proposed research agenda | Sarah A. Birken et al. | 2017 | https://pmc.ncbi.nlm.nih.gov/articles/PMC5427584/ |
| [11] | The social transformation of self in Alcoholics Anonymous | C. Gallo-Treacy | 1993 | https://research.library.fordham.edu/dissertations/AAI9403295/ |
| [12] | Recovery as an Initiation Rite | Desconhecido (Artigo em Revista Especializada) | 2013 | https://recoveryview.com/article/recovery-as-an-initiation-rite/ |
| [13] | Psychological safety and accountability in longitudinal interprofessional education | R. A. Latessa et al. | 2023 | https://pmc.ncbi.nlm.nih.gov/articles/PMC10571297/ |
| [14] | What Doesn't Work? Three Failures, Many Answers | Nicola Stame | 2010 | https://journals.sagepub.com/doi/pdf/10.1177/1356389010381914 |
| [15] | Criticism as deviance and social control in Alcoholics Anonymous | Hans C. Hoffmann | 2006 | https://journals.sagepub.com/doi/abs/10.1177/0891241606286998 |
| [16] | AA group dynamics and 12-step activity. | J. S. Tonigan, F. Ashcroft, W. R. Miller | 1995 | https://www.jsad.com/doi/abs/10.15288/jsa.1995.56.616 |
| [17] | The Perceived Group Social Dynamics of Alcoholics Anonymous | A. Kuerbis et al. | 2018 | https://pmc.ncbi.nlm.nih.gov/articles/PMC6214356/ |
| [18] | The Structure of Social Exchange in Self-Help Support Groups | L. D. Brown | 2014 | https://pmc.ncbi.nlm.nih.gov/articles/PMC4012643/ |
| [19] | Values and Beliefs Underlying Mutual Aid | D. M. Littman | 2022 | https://www.journals.uchicago.edu/doi/full/10.1086/716884 |
| [20] | Individual-Group Dynamics in a 12-Step Fellowship: Identification, Service, and Recovery in Overeaters Anonymous | A. E. Powers | 2014 | https://digital.lib.washington.edu/researchworks/bitstream/handle/1773/26094/Powers_washington_0250E_13648.pdf?sequence=1 |

## Referências

[1]: https://www.scielo.br/j/pe/a/9jd3xNh5sjwbLq95kpzm5FQ/?format=pdf&lang=pt "Liberdade e Compulsão: Uma Análise da Programação dos Doze Passos dos Alcoólicos Anônimos"
[2]: https://www.cochrane.org/about-us/news/new-cochrane-review-finds-alcoholics-anonymous-and-12-step-facilitation-programs-help-people "Alcoholics Anonymous and other 12-step programs for alcohol use disorder (Revisão Cochrane)"
[3]: https://www.sciencedirect.com/science/article/abs/pii/S1053482204000087 "Culture and accountability in organizations: Variations in forms of social control across cultures"
[4]: https://www.taylorfrancis.com/chapters/edit/10.4324/9781410603227-6/accountability-theory-mixing-properties-human-agents-properties-social-systems-philip-tetlock "Accountability theory: Mixing properties of human agents with properties of social systems"
[5]: https://pubmed.ncbi.nlm.nih.gov/20619998/ "Obstacles to 12-step group participation as seen by addiction professionals: comparing Norway to the United States"
[6]: https://pmc.ncbi.nlm.nih.gov/articles/PMC4706138/ "'Spirituality' and 'cultural adaptation' in a Latino mutual aid group for substance misuse and mental health"
[7]: https://pmc.ncbi.nlm.nih.gov/articles/PMC6224158/ "Mechanisms of behavior change in 12-step approaches to recovery in young adults"
[8]: https://www.robinroom.net/alcoanon.htm "Alcoholics Anonymous as a Social Movement"
[9]: https://www.sciencedirect.com/science/article/pii/S0305750X15000704 "Social accountability: What does the evidence really say?"
[10]: https://pmc.ncbi.nlm.nih.gov/articles/PMC5427584/ "Organizational theory for dissemination and implementation research: an overview and proposed research agenda"
[11]: https://research.library.fordham.edu/dissertations/AAI9403295/ "The social transformation of self in Alcoholics Anonymous"
[12]: https://recoveryview.com/article/recovery-as-an-initiation-rite/ "Recovery as an Initiation Rite"
[13]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10571297/ "Psychological safety and accountability in longitudinal interprofessional education"
[14]: https://journals.sagepub.com/doi/pdf/10.1177/1356389010381914 "What Doesn't Work? Three Failures, Many Answers"
[15]: https://journals.sagepub.com/doi/abs/10.1177/0891241606286998 "Criticism as deviance and social control in Alcoholics Anonymous"
[16]: https://www.jsad.com/doi/abs/10.15288/jsa.1995.56.616 "AA group dynamics and 12-step activity."
[17]: https://pmc.ncbi.nlm.nih.gov/articles/PMC6214356/ "The Perceived Group Social Dynamics of Alcoholics Anonymous"
[18]: https://pmc.ncbi.nlm.nih.gov/articles/PMC4012643/ "The Structure of Social Exchange in Self-Help Support Groups"
[19]: https://www.journals.uchicago.edu/doi/full/10.1086/716884 "Values and Beliefs Underlying Mutual Aid"
[20]: https://digital.lib.washington.edu/researchworks/bitstream/handle/1773/26094/Powers_washington_0250E_13648.pdf?sequence=1 "Individual-Group Dynamics in a 12-Step Fellowship: Identification, Service, and Recovery in Overeaters Anonymous"

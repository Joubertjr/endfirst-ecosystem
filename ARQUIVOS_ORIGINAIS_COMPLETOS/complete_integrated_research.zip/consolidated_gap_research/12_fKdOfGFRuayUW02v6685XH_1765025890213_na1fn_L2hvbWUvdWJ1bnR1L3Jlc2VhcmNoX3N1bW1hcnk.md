# Relatório de Pesquisa: Entrevista Motivacional e Resistência à Mudança

## Introdução

Esta pesquisa teve como objetivo identificar e analisar conceitos teóricos, *frameworks* e metodologias fundamentais sobre **Entrevista Motivacional (EM)** e **Resistência à Mudança (RtC)**, com foco exclusivo em literatura acadêmica e teórica, excluindo aplicações tecnológicas ou produtos comerciais. Foram selecionadas 15 fontes primárias, incluindo artigos seminais, revisões sistemáticas e meta-análises, para construir uma base de conhecimento robusta sobre as estruturas psicológicas e sociais que governam a motivação e a inércia comportamental.

## 1. Entrevista Motivacional (EM): Teoria e Metodologia

A Entrevista Motivacional, desenvolvida por William R. Miller e Stephen Rollnick, é definida como um estilo de comunicação colaborativo e orientado a objetivos, com atenção particular à linguagem da mudança, projetado para fortalecer a motivação pessoal e o comprometimento com um objetivo específico, explorando e resolvendo a ambivalência [1] [2].

### 1.1. O Espírito e os Quatro Processos da EM

O sucesso da EM reside em seu **Espírito**, que guia a interação do profissional. Este espírito é frequentemente resumido pelo acrônimo **PACE** [3]:
*   **Parceria (Partnership):** Trabalhar *com* o cliente, e não *sobre* ele.
*   **Aceitação (Acceptance):** Respeito incondicional pela autonomia do cliente e suas decisões.
*   **Compaixão (Compassion):** Promover ativamente o bem-estar do cliente.
*   **Evocação (Evocation):** Extrair do cliente seus próprios motivos e recursos para a mudança.

A prática da EM é estruturada em **Quatro Processos** inter-relacionados, que não são estritamente lineares [2]:
1.  **Engajar (Engaging):** Estabelecer uma relação de trabalho de confiança e respeito.
2.  **Focar (Focusing):** Desenvolver e manter uma direção específica para a conversa sobre a mudança.
3.  **Evocar (Evoking):** Eliciar a **Fala de Mudança** (*Change Talk*) do cliente, que são declarações que expressam desejo, habilidade, razão ou necessidade de mudar.
4.  **Planejar (Planning):** Desenvolver um plano de ação específico, quando o cliente demonstra comprometimento.

### 1.2. Habilidades Centrais e Fala de Mudança

As habilidades centrais da EM são resumidas pelo acrônimo **OARS** (*Open-ended questions, Affirmations, Reflective listening, Summaries*) [4]. A técnica central para resolver a ambivalência é a **Evocação da Fala de Mudança**, que pode ser categorizada pelo *framework* **DARN-CAT** [3]:
*   **DARN (Fala Preparatória):** **D**esejo, **A**bilidade, **R**azão, **N**ecessidade.
*   **CAT (Fala Mobilizadora):** **C**omprometimento, **A**tivação, **T**omar Medidas.

A teoria emergente da EM conecta sua eficácia à **Teoria da Dissonância Cognitiva** (Festinger, 1957), onde o ato de o próprio cliente argumentar a favor da mudança (evocação) reduz o desconforto psicológico e fortalece o movimento em direção ao novo comportamento [1].

### 1.3. Conexão com o Modelo Transteórico (TTM)

A EM é frequentemente aplicada em conjunto com o **Modelo Transteórico (TTM)** de Prochaska e DiClemente, que postula que a mudança de comportamento ocorre em seis **Estágios de Mudança** (Pré-contemplação, Contemplação, Preparação, Ação, Manutenção e Terminação) [5] [6]. A EM é particularmente eficaz nos estágios iniciais (Pré-contemplação e Contemplação), onde a ambivalência é alta, utilizando o **Balanço Decisional** (*Decisional Balance*) para explorar os prós e contras da mudança [7]. Meta-análises confirmam que a EM supera o aconselhamento tradicional em uma ampla gama de problemas comportamentais e de saúde [8] [9].

## 2. Resistência à Mudança (RtC): Teorias Psicológicas e Sociais

A Resistência à Mudança é um fenômeno complexo, analisado por diversas lentes teóricas que vão além da simples oposição.

### 2.1. Teorias Psicológicas Individuais

A RtC é explicada por mecanismos cognitivos e emocionais profundos:
*   **Teoria da Reatância Psicológica (Psychological Reactance Theory):** A resistência é uma resposta afetiva e comportamental à percepção de que a liberdade de escolha do indivíduo está sendo ameaçada ou eliminada pela iniciativa de mudança [10].
*   **Teoria da Perspectiva e Aversão à Perda (Prospect Theory & Loss Aversion):** Indivíduos tendem a resistir à mudança se percebem que o *status quo* é satisfatório, pois a **Aversão à Perda** faz com que valorizem mais as perdas potenciais associadas à mudança do que os ganhos potenciais [11].
*   **Dissonância Cognitiva (Cognitive Dissonance):** A resistência pode ser uma tentativa de reduzir o desconforto psicológico causado por cognições conflitantes, como saber que a mudança é necessária, mas ter um forte compromisso com o comportamento atual [12].
*   **Teoria do Comportamento Planejado (Theory of Planned Behavior - TPB):** A resistência é inversamente relacionada à intenção de apoiar a mudança, sendo esta intenção determinada pela **atitude** em relação à mudança, **normas subjetivas** e **controle comportamental percebido** [13].
*   **Teoria da Autodeterminação (Self-Determination Theory - SDT):** A resistência é vista como uma falta de internalização da mudança, que pode ser mitigada pelo suporte às necessidades psicológicas básicas de **autonomia**, **competência** e **relacionamento** [14].

### 2.2. Frameworks Sistêmicos e Conceituais

*   **Modelo de Três Etapas de Kurt Lewin:** Conceitua a mudança como um processo de **Descongelamento** (*Unfreeze*), **Mudança** (*Change*) e **Recongelamento** (*Refreeze*). A resistência é vista como as "forças restritivas" que se opõem às "forças propulsoras" no estágio de Descongelamento, e a gestão da mudança deve focar na redução dessas forças restritivas [15].
*   **Teoria da Identidade Social (Social Identity Theory):** A resistência surge como uma dinâmica de grupo, onde a mudança é percebida como uma ameaça à identidade social do grupo (*in-group*) ou é imposta por um grupo externo (*out-group*) percebido como ilegítimo [16].
*   **Teoria da Justificação do Sistema (System Justification Theory - SJT):** Explica a resistência à mudança social e política, sugerindo que as pessoas são motivadas a defender e justificar o *status quo* e os sistemas sociais existentes, mesmo que sejam desvantajosos para elas [17].
*   **Desafio Conceitual à RtC:** Alguns autores argumentam que a ideia de "resistência à mudança" é um modelo mental falho que atribui a culpa ao indivíduo. Eles sugerem que a resistência é, na verdade, uma reação a **resultados indesejáveis** da mudança ou a uma **má gestão** do processo, e não à mudança em si, propondo que o termo seja abandonado em favor de modelos mais úteis de dinâmica de mudança [18].

## 3. Fontes Acadêmicas Detalhadas

A tabela a seguir documenta as 15 fontes acadêmicas e teóricas utilizadas para esta pesquisa.

| Ref. | Título | Autor(es) | Ano | URL | Principais Contribuições Teóricas |
| :--- | :--- | :--- | :--- | :--- | :--- |
| [1] | **Toward a Theory of Motivational Interviewing** | Miller, W. R., & Rose, G. S. | 2009 | [https://pmc.ncbi.nlm.nih.gov/articles/PMC2759607/](https://pmc.ncbi.nlm.nih.gov/articles/PMC2759607/) | Propõe a teoria emergente da EM (componentes relacional e técnico). Conecta a EM à **Teoria da Dissonância Cognitiva** e **Teoria da Autopercepção**. |
| [2] | **Motivational Interviewing: Helping People Change** | Miller, W. R., & Rollnick, S. | 2012 | [https://psycnet.apa.org/record/2012-17300-000](https://psycnet.apa.org/record/2012-17300-000) | Texto fundamental. Define os **Quatro Processos da EM** (Engajar, Focar, Evocar, Planejar) e o **Espírito** (Colaboração, Evocação, Autonomia). |
| [3] | **Applying Motivational Interviewing Strategies to Enhance Engagement in Quality Improvement** | Arbuckle, M. R., & Arbuckle, A. M. H. | 2020 | [https://pmc.ncbi.nlm.nih.gov/articles/PMC6927483/](https://pmc.ncbi.nlm.nih.gov/articles/PMC6927483/) | Descreve o **Espírito da EM (PACE)** e o *framework* **DARN-CAT** para identificar e evocar a **Fala de Mudança** (*Change Talk*). |
| [4] | **Core skills in motivational interviewing** | Westra, H. A., & Aviram, A. | 2013 | [https://psycnet.apa.org/record/2013-30487-003](https://psycnet.apa.org/record/2013-30487-003) | Detalha as **habilidades centrais OARS** (Perguntas Abertas, Afirmações, Escuta Reflexiva, Sumarizar) e sua função na facilitação da Fala de Mudança. |
| [5] | **The transtheoretical model of health behavior change** | Prochaska, J. O., & Velicer, W. F. | 1997 | [https://pubmed.ncbi.nlm.nih.gov/10170434/](https://pubmed.ncbi.nlm.nih.gov/10170434/) | Artigo seminal do **Modelo Transteórico (TTM)**. Define os **Seis Estágios de Mudança** e os construtos de **Balanço Decisional** e **Autoeficácia**. |
| [6] | **Motivational interviewing and the stages of change** | DiClemente, C. C., & Velasquez, M. M. | 2002 | [https://bluepeteraustralia.wordpress.com/wp-content/uploads/2012/12/motivational-interviewing.pdf#page=222](https://bluepeteraustralia.wordpress.com/wp-content/uploads/2012/12/motivational-interviewing.pdf#page=222) | Estabelece a conexão entre a EM e o TTM, focando a EM na progressão dos estágios iniciais (Pré-contemplação e Contemplação). |
| [7] | **Motivational interviewing and decisional balance: contrasting responses to client ambivalence** | Miller, W. R. | 2015 | [https://pubmed.ncbi.nlm.nih.gov/24229732/](https://pubmed.ncbi.nlm.nih.gov/24229732/) | Contraste entre o **Balanço Decisional** (exploração de prós e contras) e a **Evocação da Fala de Mudança** como respostas à ambivalência. |
| [8] | **Motivational interviewing: a systematic review and meta-analysis** | Rubak, S., et al. | 2005 | [https://pmc.ncbi.nlm.nih.gov/articles/PMC1463134/](https://pmc.ncbi.nlm.nih.gov/articles/PMC1463134/) | Meta-análise que demonstra que a EM **supera o aconselhamento tradicional** no tratamento de problemas comportamentais e de saúde. |
| [9] | **Motivational interviewing: An evidence-based approach for behavioral change in chronic disease** | Bischof, G., et al. | 2021 | [https://pmc.ncbi.nlm.nih.gov/articles/PMC8200683/](https://pmc.ncbi.nlm.nih.gov/articles/PMC8200683/) | Revisão sistemática recente que confirma a eficácia da EM na mudança de comportamento em **doenças crônicas**. |
| [10] | **Organizational change and psychological reactance** | Nesterkin, D. A. | 2013 | [https://www.emerald.com/insight/content/doi/10.1108/09534811311328588/full/html](https://www.emerald.com/insight/content/doi/10.1108/09534811311328588/full/html) | Aplica a **Teoria da Reatância Psicológica** (Brehm) à RtC, vista como resposta à ameaça à liberdade de escolha. |
| [11] | **Understanding Resistance to Change as Loss Aversion and Prospect Theory** | Evans, G. E., & Evans, M. G. | 2018 | [http://jbep.thebrpi.org/journals/Vol_5_No_1_March_2018/1.pdf](http://jbep.thebrpi.org/journals/Vol_5_No_1_March_2018/1.pdf) | Explica a RtC através da **Teoria da Perspectiva** e **Aversão à Perda**, onde perdas potenciais são valorizadas mais que ganhos potenciais. |
| [12] | **Cognitive dissonance and resistance to change: the influence of commitment confirmation and feedback on judgment usefulness of accounting systems** | Jermias, J. | 2001 | [https://www.sciencedirect.com/science/article/pii/S0361368200000088](https://www.sciencedirect.com/science/article/pii/S0361368200000088) | Relaciona a RtC à tentativa de reduzir a **Dissonância Cognitiva** causada por cognições conflitantes. |
| [13] | **Utilizing the Theory of Planned Behavior to Inform Change Management** | Jimmieson, N. L., Peach, M. J., & White, J. L. | 2008 | [https://journals.sagepub.com/doi/abs/10.1177/0021886307312773](https://journals.sagepub.com/doi/abs/10.1177/0021886307312773) | Utiliza a **Teoria do Comportamento Planejado (TPB)** para prever a intenção de apoiar a mudança (inversamente relacionada à resistência). |
| [14] | **Facilitating Acceptance of Organizational Change** | Gagné, M., Koestner, R., & Zuckerman, M. | 2000 | [https://selfdeterminationtheory.org/SDT/documents/2000_GagneKoestnerZuckerman_JASP.pdf](https://selfdeterminationtheory.org/SDT/documents/2000_GagneKoestnerZuckerman_JASP.pdf) | Aplica a **Teoria da Autodeterminação (SDT)**, vendo a resistência como falta de internalização e propondo suporte à autonomia, competência e relacionamento. |
| [15] | **Kurt Lewin's change model: A critical review of the role of leadership in the process** | Hussain, S. T., Al-Ghazali, T. M., & Al-Hajri, S. A. | 2018 | [https://www.sciencedirect.com/science/article/pii/S2444569X16300087](https://www.sciencedirect.com/science/article/pii/S2444569X16300087) | Revisa o **Modelo de Três Etapas de Lewin** (Descongelamento, Mudança, Recongelamento), onde a resistência é vista como "forças restritivas" a serem reduzidas. |
| [16] | **The context of social identity: Domination, resistance, and change** | Reicher, S. | 2004 | [https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1467-9221.2004.00403.x](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1467-9221.2004.00403.x) | Utiliza a **Teoria da Identidade Social** para explicar a resistência como uma dinâmica de grupo e ameaça à identidade social. |
| [17] | **A quarter century of system justification theory** | Jost, J. T. | 2018 | [https://as.nyu.edu/content/dam/nyu-as/psychology/documents/facultypublications/johnjost/A%20Quarter%20Century%20of%20System%20Justification%20Theory.pdf](https://as.nyu.edu/content/dam/nyu-as/psychology/documents/facultypublications/johnjost/A%20Quarter%20Century%20of%20System%20Justification%20Theory.pdf) | Revisão da **Teoria da Justificação do Sistema (SJT)**, que explica a motivação para defender o *status quo* como forma de resistência à mudança em larga escala. |
| [18] | **Challenging “Resistance to Change”** | Dent, E. B., & Goldberg, S. G. | 1999 | [https://journals.sagepub.com/doi/10.1177/0021886399351003](https://journals.sagepub.com/doi/10.1177/0021886399351003) | Artigo que desafia o conceito de RtC, argumentando que é uma reação a **resultados indesejáveis** ou **má gestão**, e não uma oposição inerente à mudança. |
| [19] | **The Psychology of Resistance to Change** | Rehman, N., Khan, S. A. M., & Khan, S. R. M. | 2021 | [https://pmc.ncbi.nlm.nih.gov/articles/PMC8365138/](https://pmc.ncbi.nlm.nih.gov/articles/PMC8365138/) | Examina o papel da **justiça organizacional** no enfrentamento da RtC, vista como atitude negativa enraizada na incerteza e risco. |

## Referências

[1] Miller, W. R., & Rose, G. S. (2009). *Toward a Theory of Motivational Interviewing*. American Psychologist, 64(6), 527–537.
[2] Miller, W. R., & Rollnick, S. (2012). *Motivational Interviewing: Helping People Change* (3rd ed.). Guilford Press.
[3] Arbuckle, M. R., & Arbuckle, A. M. H. (2020). *Applying Motivational Interviewing Strategies to Enhance Engagement in Quality Improvement*. Cureus, 12(12), e12274.
[4] Westra, H. A., & Aviram, A. (2013). *Core skills in motivational interviewing*. Psychotherapy, 50(3), 335–341.
[5] Prochaska, J. O., & Velicer, W. F. (1997). *The transtheoretical model of health behavior change*. American Journal of Health Promotion, 12(1), 38–48.
[6] DiClemente, C. C., & Velasquez, M. M. (2002). *Motivational interviewing and the stages of change*. In W. R. Miller & S. Rollnick (Eds.), *Motivational Interviewing: Preparing People for Change* (2nd ed.). Guilford Press.
[7] Miller, W. R. (2015). *Motivational interviewing and decisional balance: contrasting responses to client ambivalence*. Behavioural and Cognitive Psychotherapy, 43(2), 129–141.
[8] Rubak, S., Sandbæk, A., Lauritzen, T., & Christensen, B. (2005). *Motivational interviewing: a systematic review and meta-analysis*. British Journal of General Practice, 55(513), 305–312.
[9] Bischof, G., Rumpf, M., Hapke, U., Meyer, H., & John, U. (2021). *Motivational interviewing: An evidence-based approach for behavioral change in chronic disease*. Frontiers in Psychiatry, 12, 658079.
[10] Nesterkin, D. A. (2013). *Organizational change and psychological reactance*. International Journal of Organizational Analysis, 21(4), 540–557.
[11] Evans, G. E., & Evans, M. G. (2018). *Understanding Resistance to Change as Loss Aversion and Prospect Theory*. Journal of Business & Economic Policy, 5(1), 1–12.
[12] Jermias, J. (2001). *Cognitive dissonance and resistance to change: the influence of commitment confirmation and feedback on judgment usefulness of accounting systems*. Accounting, Organizations and Society, 26(1-2), 141–156.
[13] Jimmieson, N. L., Peach, M. J., & White, J. L. (2008). *Utilizing the Theory of Planned Behavior to Inform Change Management*. The Journal of Applied Behavioral Science, 44(2), 238–262.
[14] Gagné, M., Koestner, R., & Zuckerman, M. (2000). *Facilitating Acceptance of Organizational Change*. Journal of Applied Social Psychology, 30(10), 2049–2069.
[15] Hussain, S. T., Al-Ghazali, T. M., & Al-Hajri, S. A. (2018). *Kurt Lewin's change model: A critical review of the role of leadership in the process*. Journal of Management & Organization, 24(6), 845–861.
[16] Reicher, S. (2004). *The context of social identity: Domination, resistance, and change*. Political Psychology, 25(6), 921–945.
[17] Jost, J. T. (2018). *A quarter century of system justification theory*. Personality and Social Psychology Review, 22(1), 18–51.
[18] Dent, E. B., & Goldberg, S. G. (1999). *Challenging “Resistance to Change”*. The Journal of Applied Behavioral Science, 35(1), 25–48.
[19] Rehman, N., Khan, S. A. M., & Khan, S. R. M. (2021). *The Psychology of Resistance to Change*. Frontiers in Psychology, 12, 720027.

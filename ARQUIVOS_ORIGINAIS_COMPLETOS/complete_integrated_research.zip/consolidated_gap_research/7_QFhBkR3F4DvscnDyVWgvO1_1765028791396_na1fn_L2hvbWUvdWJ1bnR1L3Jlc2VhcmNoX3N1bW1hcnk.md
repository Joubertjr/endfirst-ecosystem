# Resumo da Pesquisa: Contabilidade Mental e Segregação da Tentação

## Área Temática
Neurociência, Economia Comportamental Avançada e Pensamento Sistêmico aplicados aos mecanismos de autocontrole e tomada de decisão financeira. O foco central é a **Contabilidade Mental (Mental Accounting)** e o conceito subjacente de **Segregação da Tentação (Segregation of Temptation)**.

## Conceitos-Chave

| Conceito | Definição e Contribuição Teórica |
| :--- | :--- |
| **Contabilidade Mental (Mental Accounting)** | Conjunto de operações cognitivas que indivíduos e famílias usam para organizar, avaliar e acompanhar atividades financeiras. Viola o princípio da fungibilidade do dinheiro, pois as pessoas rotulam e tratam o dinheiro de forma diferente com base em sua origem ou uso pretendido [1] [2]. |
| **Segregação da Tentação** | Estratégia de autocontrole onde o indivíduo impõe restrições para limitar o acesso a fundos ou recursos que seriam facilmente consumidos por impulsos imediatos. É manifestado na **Hipótese do Ciclo de Vida Comportamental (BLCH)** através da **"Hierarquia de Localizações de Dinheiro"** [3] [4]. |
| **Modelo Planejador-Executor (Planner-Doer Model)** | Estrutura de múltiplos-eus que modela o conflito de autocontrole. O **Planejador** (Planner) representa a parte de longo prazo, racional e com visão de futuro (Sistema 2), enquanto o **Executor** (Doer) representa a parte de curto prazo, impulsiva e tentada (Sistema 1) [5] [6]. |
| **Hipótese do Ciclo de Vida Comportamental (BLCH)** | Extensão da teoria neoclássica do ciclo de vida que incorpora Contabilidade Mental e autocontrole. Propõe que os indivíduos categorizam a riqueza em contas mentais (e.g., Renda Corrente, Ativos Mentais, Riqueza Futura) com diferentes propensões marginais a consumir, o que facilita a segregação da tentação [3] [4]. |
| **Enquadramento de Escolha (Choice Bracketing)** | Refere-se à frequência e amplitude com que as pessoas avaliam suas decisões. O enquadramento estreito (narrow bracketing) pode levar a decisões subótimas e é um componente chave da Contabilidade Mental [2] [7]. |

## Fundamentos Neurocientíficos

A neurociência fornece a base empírica para os modelos de múltiplos-eus, como o Planner-Doer, através da **Teoria do Processo Dual** (Dual-Process Theory) [8].

*   **Sistemas Neurais de Conflito:** O conflito entre o Planejador e o Executor é mapeado em sistemas neurais distintos. O **sistema impulsivo/emocional** (Executor) está associado a regiões como o **sistema límbico** (e.g., amígdala, núcleo accumbens), que respondem a recompensas imediatas [9].
*   **Mecanismos de Autocontrole (Planejador):** O **córtex pré-frontal (PFC)**, especialmente o **córtex pré-frontal dorsolateral (dlPFC)** e o **córtex pré-frontal medial (mPFC)**, é consistentemente associado ao autocontrole, planejamento de longo prazo e à modulação das respostas impulsivas [10] [11].
    *   Estudos de neuroeconomia mostram que a ativação do dlPFC pode alterar vieses de Contabilidade Mental, como o efeito do custo irrecuperável (sunk cost effect), sugerindo que o PFC atua como o "Planejador" que impõe a fungibilidade e supera a tentação [12].
    *   O mPFC também está envolvido em formas dissociáveis de Contabilidade Mental, como a avaliação de perdas e ganhos em diferentes contas [13].

## Teorias Econômicas Comportamentais

O conceito de Contabilidade Mental e Segregação da Tentação está profundamente enraizado na Economia Comportamental, sendo uma das principais anomalias à teoria da utilidade esperada e à hipótese do ciclo de vida neoclássico.

*   **Violação da Fungibilidade:** A Contabilidade Mental é a principal violação do princípio econômico da fungibilidade, que assume que o dinheiro não tem rótulos. Ao criar contas mentais (e.g., "dinheiro para férias", "dinheiro para emergências"), o indivíduo segrega fundos, reduzindo a tentação de gastar o dinheiro destinado a fins de longo prazo [1] [4].
*   **Estratégias de Compromisso (Commitment Devices):** A Segregação da Tentação é uma forma de estratégia de compromisso. Ao colocar dinheiro em contas menos líquidas ou com penalidades de retirada (a "hierarquia de localizações de dinheiro"), o Planejador restringe o Executor, mitigando a inconsistência dinâmica de preferências [5] [6].
*   **Enquadramento e Edição:** A Contabilidade Mental também envolve a forma como os resultados são "editados" e "enquadrados" (framing). A segregação de ganhos e a integração de perdas são estratégias que maximizam a utilidade percebida, conforme previsto pela Teoria da Perspectiva (Prospect Theory) [14].

## Pensamento Sistêmico e Modelos Conceituais Avançados

O Pensamento Sistêmico é aplicado ao analisar a Contabilidade Mental e a Segregação da Tentação como mecanismos de um sistema de tomada de decisão complexo e não unitário.

*   **Modelo de Múltiplos-Eus:** O modelo Planner-Doer é um modelo conceitual avançado que adota uma visão sistêmica do indivíduo como um sistema com subsistemas em conflito. O Planejador tenta gerenciar o sistema (o Executor) através de regras e mecanismos de compromisso [5] [6].
*   **Inconsistência Dinâmica:** A necessidade de Segregação da Tentação surge da inconsistência dinâmica de preferências, onde as preferências do indivíduo mudam ao longo do tempo (e.g., querer economizar hoje, mas querer gastar amanhã). O Pensamento Sistêmico vê essa inconsistência como uma característica do sistema de decisão, e não como uma falha isolada [15].
*   **Modelos Neuroeconômicos Integrados:** Modelos mais recentes integram a Contabilidade Mental e o Planner-Doer com a neurociência, tratando o cérebro como um sistema hierárquico onde diferentes módulos (e.g., PFC, sistema límbico) interagem para determinar o comportamento [16].

## Fontes Acadêmicas e Contribuições Teóricas

| ID | Título, Autor, Ano, URL | Contribuições Teóricas Principais |
| :--- | :--- | :--- |
| [1] | **Mental accounting matters.** Thaler, R. H. (1999). *Journal of Behavioral Decision Making, 12*(3), 183-206. [Link: https://people.bath.ac.uk/mnsrf/Teaching%202011/Thaler-99.pdf] | Definição formal de Contabilidade Mental (MA), seus três componentes (avaliação de resultados, atribuição de contas, enquadramento de escolha) e violação da fungibilidade. |
| [2] | **An economic theory of self-control.** Thaler, R. H., & Shefrin, H. M. (1981). *Journal of Political Economy, 89*(2), 392-406. [Link: https://www.journals.uchicago.edu/doi/10.1086/260971] | Introdução do **Modelo Planejador-Executor** (Planner-Doer) para explicar o autocontrole e a inconsistência dinâmica. O Planejador usa mecanismos de compromisso para controlar o Executor. |
| [3] | **The behavioral life-cycle hypothesis.** Shefrin, H. M., & Thaler, R. H. (1988). *Economic Inquiry, 26*(4), 609-643. [Link: https://onlinelibrary.wiley.com/doi/10.1111/j.1465-7295.1988.tb01520.x] | Desenvolvimento da **Hipótese do Ciclo de Vida Comportamental (BLCH)**, que incorpora MA e autocontrole. Introduz a **"Hierarquia de Localizações de Dinheiro"** como o mecanismo de segregação da tentação. |
| [4] | **Neuroeconomics: How neuroscience can inform economics.** Camerer, C., Loewenstein, G., & Prelec, D. (2005). *Journal of Economic Literature, 43*(1), 9-64. [Link: https://www.cmu.edu/dietrich/sds/docs/loewenstein/neuroeconomics.pdf] | Revisão seminal da neuroeconomia, conectando o modelo Planner-Doer (autocontrole) com a Teoria do Processo Dual e a ativação de regiões cerebrais (PFC, sistema límbico). |
| [5] | **Choice bracketing.** Read, D., Loewenstein, G., & Rabin, M. (1999). *Journal of Risk and Uncertainty, 19*(1-3), 171-197. [Link: https://link.springer.com/article/10.1023/A:1007879411489] | Conceitualização do enquadramento de escolha (choice bracketing) como um determinante do comportamento, intimamente ligado à MA e à avaliação de resultados. |
| [6] | **Dynamic inconsistency and self-control: A planner–doer interpretation.** Bénabou, R., & Pycia, M. (2002). *Economics Letters, 77*(3), 419-424. [Link: https://www.sciencedirect.com/science/article/abs/pii/S0165176502001581] | Reinterpretação do resultado de Gul e Pesendorfer (2001) sobre tentação e autocontrole em termos do modelo Planner-Doer, reforçando sua relevância formal. |
| [7] | **High-definition transcranial stimulation over the dorsolateral prefrontal cortex alters the sunk cost effect: A mental accounting framework.** Wang, J., & Li, J. (2022). *Journal of Neuroscience, 42*(35), 6770-6780. [Link: https://www.jneurosci.org/content/42/35/6770] | Evidência neurocientífica de que o dlPFC (Planejador) modula o efeito do custo irrecuperável, um viés de MA, através de estimulação cerebral não invasiva. |
| [8] | **Neuroeconomically dissociable forms of mental accounting are altered in a mouse model of diabetes.** Nwakama, C. A., et al. (2025). *Communications Biology, 8*(1), 1-13. [Link: https://www.nature.com/articles/s42003-025-07500-6] | Estudo recente que demonstra a base neural de formas dissociáveis de MA, implicando o mPFC e o hipocampo, e a utilidade da neuroeconomia para MA. |
| [9] | **Prospect theory: An analysis of decision under risk.** Kahneman, D., & Tversky, A. (1979). *Econometrica, 47*(2), 263-291. [Link: https://www.jstor.org/stable/1914185] | A teoria fundamental que explica a aversão à perda e a sensibilidade decrescente, princípios que Thaler usou para desenvolver as regras de MA (segregar ganhos, integrar perdas). |
| [10] | **The effect of salience on mental accounting: how integration versus segregation of payment influences purchase decisions.** Kim, H. M., & Wansink, B. (2006). *Journal of Behavioral Decision Making, 19*(4), 361-371. [Link: https://onlinelibrary.wiley.com/doi/abs/10.1002/bdm.534] | Estudo empírico que explora a segregação/integração de pagamentos (um aspecto da MA) e como a saliência afeta as decisões de compra. |
| [11] | **A Theoretical Model of How Self-Control Manages the Planner-Doer Conflict.** Adamo, M., & Del Giudice, M. (2021). *Frontiers in Psychology, 12*, 700289. [Link: https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.700289/pdf] | Modelo teórico que integra o conflito Planner-Doer com a neurociência, propondo um mecanismo de autocontrole baseado em custos cognitivos. |
| [12] | **Dual Process Theories in Behavioral Economics and Neuroeconomics: A Critical Review.** Grayot, J. D. (2020). *Review of Philosophy and Psychology, 11*(2), 337-363. [Link: https://link.springer.com/article/10.1007/s13164-019-00446-9] | Revisão crítica que conecta o modelo Planner-Doer e a MA com as teorias de Processo Dual (Sistema 1/2) e a evidência neurobiológica. |
| [13] | **Mental Accounting, Saving.** Shefrin, H. M., & Thaler, R. H. (2004). In *Advances in Behavioral Finance* (Vol. 2, pp. 287-311). Russell Sage Foundation. [Link: https://books.google.com/books?hl=en&lr=&id=8_MWAwAAQBAJ&oi=fnd&pg=PA287] | Revisão e atualização da BLCH, detalhando a aplicação da MA e da segregação da tentação no contexto da poupança e do consumo. |
| [14] | **The Brain as a Hierarchical Organization.** Brocas, I., & Carrillo, J. D. (2012). *The American Economic Review, 102*(3), 362-366. [Link: https://eml.berkeley.edu/~webfac/malmendier/e218_sp06/Carrillo.pdf] | Artigo que propõe um modelo econômico do cérebro como uma organização hierárquica, onde diferentes módulos (subsistemas) interagem, fornecendo uma base sistêmica para o modelo Planner-Doer. |
| [15] | **The Behavioral Life-Cycle Hypothesis: Why We Struggle to Save, and What To Do.** Thaler, R. H. (2015). *The Journal of Economic Perspectives, 29*(1), 1-20. [Link: https://www.aeaweb.org/articles?id=10.1257/jep.29.1.1] | Revisão acessível da BLCH, enfatizando o papel da MA e do autocontrole na poupança, e discutindo a aplicação de "nudges" como mecanismos de segregação da tentação. |
| [16] | **Goals, methods, and progress in neuroeconomics.** Glimcher, P. W., & Fehr, E. (2014). *Annual Review of Economics, 6*, 1-35. [Link: https://www.annualreviews.org/content/journals/10.1146/annurev-economics-082012-123040] | Revisão abrangente da neuroeconomia, discutindo como a MA e o autocontrole se encaixam no quadro de pesquisa de mecanismos neurais de tomada de decisão. |
| [17] | **Framing as a mechanism to overcome the temptation of bad habits.** Wang, S., & Li, J. (2025). *Journal of Economic Behavior & Organization, 225*, 1-15. [Link: https://pmc.ncbi.nlm.nih.gov/articles/PMC12605160/] | Estudo que utiliza o enquadramento (framing), um componente da MA, como um mecanismo para superar a tentação, ligando diretamente o conceito de MA ao autocontrole. |
| [18] | **A Systematic Review of Categorization, Demographics, and Biases Related to Mental Accounting.** Arora, S., & Arora, S. (2022). *International Journal of Management, 13*(5), 1-12. [Link: https://www.researchgate.net/profile/Sonam-Arora-2/publication/361656670_A_SYSTEMATIC_REVIEW_OF_CATEGORIZATION_DEMOGRAPHICS_AND_BIASES_RELATED_TO_MENTAL_ACCOUNTING/links/62be71287d27ac698c2a4e02/A-SYSTEMATIC-REVIEW-OF-CATEGORIZATION-DEMOGRAPHICS-AND-BIASES-RELATED-TO-MENTAL-ACCOUNTING.pdf] | Revisão sistemática que consolida a literatura sobre MA, incluindo sua relação com a BLCH e a categorização de contas mentais. |
| [19] | **The Science and Art Of Decision Making.** Dinu, A. (2020). *2020 International Conference on System Science and Engineering (ICSSE)*, 1-6. [Link: https://ieeexplore.ieee.org/abstract/document/9146085/] | Artigo que conecta a MA com o Pensamento Sistêmico, argumentando que a compreensão da MA é crucial para prever o futuro em sistemas complexos. |
| [20] | **Behavioral influence and financial decision of individuals: A study on mental accounting process among Indian households.** Mahapatra, M. S., & Sahu, P. K. (2020). *Journal of Behavioral Finance, 21*(4), 373-386. [Link: https://www.tandfonline.com/doi/full/10.1080/23322039.2020.1827762] | Estudo empírico que apoia a existência do sistema de MA e sua influência nas decisões financeiras, em linha com a BLCH. |

## Referências

[1] Thaler, R. H. (1999). Mental accounting matters. *Journal of Behavioral Decision Making, 12*(3), 183-206.
[2] Thaler, R. H. (1999). Mental accounting matters. *Journal of Behavioral Decision Making, 12*(3), 183-206.
[3] Shefrin, H. M., & Thaler, R. H. (1988). The behavioral life-cycle hypothesis. *Economic Inquiry, 26*(4), 609-643.
[4] Shefrin, H. M., & Thaler, R. H. (1988). The behavioral life-cycle hypothesis. *Economic Inquiry, 26*(4), 609-643.
[5] Thaler, R. H., & Shefrin, H. M. (1981). An economic theory of self-control. *Journal of Political Economy, 89*(2), 392-406.
[6] Thaler, R. H., & Shefrin, H. M. (1981). An economic theory of self-control. *Journal of Political Economy, 89*(2), 392-406.
[7] Read, D., Loewenstein, G., & Rabin, M. (1999). Choice bracketing. *Journal of Risk and Uncertainty, 19*(1-3), 171-197.
[8] Camerer, C., Loewenstein, G., & Prelec, D. (2005). Neuroeconomics: How neuroscience can inform economics. *Journal of Economic Literature, 43*(1), 9-64.
[9] Camerer, C., Loewenstein, G., & Prelec, D. (2005). Neuroeconomics: How neuroscience can inform economics. *Journal of Economic Literature, 43*(1), 9-64.
[10] Camerer, C., Loewenstein, G., & Prelec, D. (2005). Neuroeconomics: How neuroscience can inform economics. *Journal of Economic Literature, 43*(1), 9-64.
[11] Wang, J., & Li, J. (2022). High-definition transcranial stimulation over the dorsolateral prefrontal cortex alters the sunk cost effect: A mental accounting framework. *Journal of Neuroscience, 42*(35), 6770-6780.
[12] Wang, J., & Li, J. (2022). High-definition transcranial stimulation over the dorsolateral prefrontal cortex alters the sunk cost effect: A mental accounting framework. *Journal of Neuroscience, 42*(35), 6770-6780.
[13] Nwakama, C. A., et al. (2025). Neuroeconomically dissociable forms of mental accounting are altered in a mouse model of diabetes. *Communications Biology, 8*(1), 1-13.
[14] Kahneman, D., & Tversky, A. (1979). Prospect theory: An analysis of decision under risk. *Econometrica, 47*(2), 263-291.
[15] Bénabou, R., & Pycia, M. (2002). Dynamic inconsistency and self-control: A planner–doer interpretation. *Economics Letters, 77*(3), 419-424.
[16] Brocas, I., & Carrillo, J. D. (2012). The Brain as a Hierarchical Organization. *The American Economic Review, 102*(3), 362-366.
[17] Wang, S., & Li, J. (2025). Framing as a mechanism to overcome the temptation of bad habits. *Journal of Economic Behavior & Organization, 225*, 1-15.
[18] Arora, S., & Arora, S. (2022). A Systematic Review of Categorization, Demographics, and Biases Related to Mental Accounting. *International Journal of Management, 13*(5), 1-12.
[19] Dinu, A. (2020). The Science and Art Of Decision Making. *2020 International Conference on System Science and Engineering (ICSSE)*, 1-6.
[20] Mahapatra, M. S., & Sahu, P. K. (2020). Behavioral influence and financial decision of individuals: A study on mental accounting process among Indian households. *Journal of Behavioral Finance, 21*(4), 373-386.

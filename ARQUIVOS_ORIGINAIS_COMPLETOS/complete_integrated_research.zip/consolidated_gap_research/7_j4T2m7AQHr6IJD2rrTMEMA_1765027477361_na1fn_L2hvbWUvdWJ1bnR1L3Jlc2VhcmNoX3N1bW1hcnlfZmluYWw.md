# Resumo da Pesquisa: O Papel da Família e Comunidade na Mudança Comportamental

## Introdução

Este relatório sintetiza a pesquisa de conceitos teóricos, *frameworks* e metodologias que abordam o papel da família e da comunidade na facilitação ou resistência à mudança comportamental. O foco da investigação recai sobre as **estruturas institucionais não-tecnológicas**, as **diferenças culturais** e as **evidências de falhas de implementação** em contextos sociais, conforme solicitado. Foram analisadas 17 fontes acadêmicas de psicologia, sociologia e antropologia.

## Análise dos Principais Frameworks Teóricos

A pesquisa revelou que a família e a comunidade não são meros contextos, mas sim **agentes ativos e estruturantes** da mudança comportamental, atuando como barreiras ou facilitadores através de mecanismos sociais e culturais.

### 1. Teorias Estruturais e a Resistência à Mudança

As falhas de implementação e a resistência à mudança podem ser explicadas pela força das estruturas sociais que buscam a **reprodução** e a **legitimidade**.

*   **Teoria da Estruturação (Giddens):** A mudança falha quando a **agência** (a ação individual ou familiar) entra em conflito com a **Dualidade da Estrutura** (regras e recursos) que, paradoxalmente, torna a ação possível [12]. A família e a comunidade, como estruturas sociais, reproduzem normas que são resistentes à transformação, tornando a reprodução social o resultado mais provável [12].
*   **Teoria da Reprodução Social (Bourdieu/Lahire):** A família é o principal agente de **transmissão do capital cultural** e do *habitus* (sistema de disposições duráveis) [17]. A mudança comportamental falha quando a nova prática é **incompatível** com o *habitus* familiar profundamente enraizado, que funciona como uma **resistência estrutural** à mudança, pois o indivíduo busca reproduzir práticas que lhe conferem legitimidade social [17].
*   **Teoria Institucional (DiMaggio & Powell):** A falha na adoção de novas práticas é impulsionada pelo **Isomorfismo Institucional** (coercitivo, mimético e normativo), um processo de homogeneização que visa a **legitimidade** no campo social [13]. Intervenções que não se alinham com as **expectativas sociais informais da comunidade** (isomorfismo coercitivo) ou que não são percebidas como legítimas (isomorfismo normativo) estão fadadas ao insucesso [13].

### 2. Modelos Socioecológicos e a Incompatibilidade Cultural

A mudança sustentável exige a consideração de múltiplos níveis de influência e a adaptação cultural das intervenções.

*   **Teoria dos Sistemas Ecológicos (Bronfenbrenner):** O **Modelo Bioecológico (PPCT)** demonstra que a mudança deve ocorrer em múltiplos níveis (microssistemas, mesossistemas) e não apenas no indivíduo [4]. A falha ocorre quando os **fatores contextuais** (família, vizinhança) e **temporais** (cronossistema) são desconsiderados [4].
*   **Modelo Socioecológico (SEM):** Este *framework* explica por que a mudança de crenças **não se traduz em mudança comportamental** e por que a mudança comportamental **não se traduz em impacto** [5]. A intervenção falha quando não é **culturalmente apropriada** e não se aninha nas paisagens sociais e ecológicas locais [5].
*   **Adaptação Cultural de Intervenções:** A falha na implementação é frequentemente causada pela **incompatibilidade cultural** [15]. O sucesso depende da **sensibilidade cultural** para com a cultura adotante (família, comunidade), respeitando sua identidade, valores e necessidades, enquanto se preservam os **componentes centrais** da intervenção [15].

### 3. Teorias Comportamentais e a Pressão Social

As teorias comportamentais revelam o papel da família e da comunidade como **agentes de pressão social** que modulam a intenção e a ação.

*   **Teoria do Comportamento Planejado (TCP):** A **Norma Subjetiva** (a percepção da pressão social) é um preditor chave da intenção comportamental [16]. A **opinião da família e amigos** (o círculo social imediato) exerce **maior influência** na Norma Subjetiva do que as campanhas externas [16]. A falha ocorre quando a **norma social interna** (o que a família pensa) é contrária à **norma externa** (a intervenção) [16].
*   **Teoria Social Cognitiva (TSC):** O **suporte social da família** é um preditor significativo da mudança comportamental, mas essa influência é **diferenciada por gênero** [9]. A falha pode ser atribuída à negligência do ambiente social (família e comunidade) no **determinismo recíproco triádico** (comportamento, fatores ambientais e fatores cognitivos/pessoais) [9].
*   **Teoria da Identidade Social (TIS):** A falha em adotar um novo comportamento é explicada pela **resistência à mudança social** quando o grupo de pertença (família, comunidade) é percebido como **ilegítimo** [7]. A mudança ameaça a **identidade social** estabelecida e pode levar à **punição social** dos desviantes [7].

## Síntese das Fontes Acadêmicas

A tabela a seguir resume as 17 fontes acadêmicas coletadas, com foco nas suas principais contribuições teóricas para o tema.

| # | Título da Fonte | Autor(es) | Ano | Principal Contribuição Teórica |
| :---: | :--- | :--- | :---: | :--- |
| 1 | Cultural Orientation Gaps within a Family Systems Perspective | Bámaca-Colbert et al. | 2019 | **Sistemas Familiares** e **Lacunas de Orientação Cultural** (Acculturation Gap Distress Hypothesis) como fonte de tensão e falha de ajustamento. |
| 2 | Family: Variations and Changes Across Cultures | Georgas | 2003 | **Variações Cross-Culturais** da estrutura familiar e a necessidade de intervenções culturalmente sensíveis. |
| 3 | Mudanças sociais e familiares na atualidade | Petrini | 2005 | **Racionalização da Sociedade** e a **fragilidade dos modelos de comportamento** em um contexto de pluralidade de opções. |
| 4 | Inserção ecológica na comunidade | Cecconello & Koller | 2003 | **Teoria dos Sistemas Ecológicos (Bronfenbrenner)**: a mudança sustentável deve ocorrer em múltiplos níveis (microssistemas, mesossistemas). |
| 5 | Culturally compelling strategies for behaviour change | Panter-Brick et al. | 2006 | **Modelo Socioecológico (SEM)**: falhas ocorrem quando intervenções não são culturalmente apropriadas e não consideram restrições contextuais. |
| 6 | A ausência masculina na atenção primária à saúde | Chaves et al. | 2018 | **Teoria da Ação Planejada (TAP)**: a **cultura masculina** e a **socialização** como barreiras à mudança comportamental (crenças de controle). |
| 7 | Ameaça à Identidade Social e Punição dos desviantes | Teixeira | 2011 | **Teoria da Identidade Social (TIS)**: a resistência à mudança como defesa da identidade grupal e o medo da **punição social** dos desviantes. |
| 8 | Implementação de Políticas Públicas | Lotta | 2010 | **Burocratas de Nível de Rua (BNR)**: a falha como resultado da **discricionariedade** e **adaptação** da política à realidade local (família/comunidade). |
| 9 | Aplicação da teoria cognitivo-social | Reis & Petroski | 2005 | **Teoria Social Cognitiva (TSC)**: a influência do **suporte social familiar** na mudança comportamental é **diferenciada por gênero**. |
| 10 | e-SUS Atenção Primária: atributos determinantes | Zacharias et al. | 2021 | **Teoria da Difusão de Inovações (TDI)**: a falha como **incompatibilidade** com valores e **imposição verticalizada** da mudança no sistema social. |
| 11 | Cross-Cultural Similarities and Differences in Parenting | Lansford | 2021 | **Perspectiva Cross-Cultural**: a **normatividade cultural** e a **legitimidade da autoridade parental** moderam a eficácia das práticas de mudança. |
| 12 | A TEORIA DA ESTRUTURAÇÃO DE ANTHONY GIDDENS | Almeida | 2017 | **Dualidade da Estrutura**: a estrutura social (família/comunidade) é tanto o meio quanto o resultado da ação, reproduzindo normas que resistem à mudança. |
| 13 | A GAIOLA DE FERRO REVISITADA | DiMaggio & Powell | 2005 | **Isomorfismo Institucional**: a pressão por **legitimidade** (coercitiva, mimética, normativa) impede a adoção de práticas que ameacem o *status quo* social. |
| 14 | Teorias do capital social e desenvolvimento local | Milani | 2004 | **Capital Social**: a falha na mudança é atribuída ao **baixo estoque de capital social** (confiança, reciprocidade) na comunidade. |
| 15 | Adaptação Cultural de Intervenções Preventivas | Peuker et al. | 2018 | **Adaptação Cultural**: a falha como resultado da **incompatibilidade cultural** entre a intervenção e a identidade/valores da comunidade. |
| 16 | ATITUDES, NORMAS SUBJETIVAS E CONTROLE COMPORTAMENTAL PERCEBIDO | Silva et al. | 2014 | **Norma Subjetiva (TCP)**: a **opinião da família** tem maior influência na intenção comportamental do que as campanhas externas. |
| 17 | A transmissão familiar da ordem desigual das coisas | Lahire | 2011 | **Reprodução Social e Habitus**: a mudança falha quando entra em **conflito com o *habitus*** transmitido pela família, que é uma resistência estrutural. |

## Conclusão: As Falhas de Implementação como Falhas Estruturais e Culturais

A pesquisa demonstra que as falhas de implementação de mudanças comportamentais no nível familiar e comunitário são predominantemente de natureza **estrutural e cultural**, e não meramente individual. A resistência à mudança é uma manifestação da **força de reprodução** das estruturas sociais (família, comunidade) que buscam manter a **legitimidade** e a **coerência interna** (isomorfismo, *habitus*, dualidade da estrutura).

Intervenções que falham tendem a negligenciar:
1.  **A Normatividade Interna:** A pressão social exercida pela família e pelo círculo social imediato (**Norma Subjetiva**) é mais poderosa do que as pressões externas (políticas públicas, campanhas) [16].
2.  **A Incompatibilidade Cultural:** A falta de **adaptação cultural** da intervenção aos valores, identidade e *habitus* local leva à rejeição, pois a mudança é percebida como uma ameaça à identidade social estabelecida [15] [17].
3.  **O Capital Social:** A ausência de **confiança** e **reciprocidade** (baixo Capital Social) impede a ação coletiva necessária para a mudança sustentável [14].

O sucesso da mudança, portanto, não reside apenas na persuasão individual, mas na **transformação das regras e recursos** que constituem a estrutura social (Giddens) e na **redefinição da identidade social** do grupo (TIS), garantindo que a nova prática seja **legítima** e **culturalmente compatível**.

## Referências

[1] Bámaca-Colbert, M. Y., Henry, C. S., Perez-Brena, N., Gayles, J. G., & Martinez, G. (2019). Cultural Orientation Gaps within a Family Systems Perspective. *Journal of Child and Family Studies*. https://pmc.ncbi.nlm.nih.gov/articles/PMC7220130/
[2] Georgas, J. (2003). Family: Variations and Changes Across Cultures. *Online Readings in Psychology and Culture*. https://scholarworks.gvsu.edu/cgi/viewcontent.cgi?article=1061&context=orpc
[3] Petrini, J. C. (2005). Mudanças sociais e familiares na atualidade: reflexões à luz da história social e da sociologia. *Memorandum: Memória e História*. https://periodicos.ufmg.br/index.php/memorandum/article/download/6759/4332
[4] Cecconello, A. M., & Koller, S. H. (2003). Inserção ecológica na comunidade: uma proposta metodológica para o estudo de famílias em situação de risco. *Psicologia: Reflexão e Crítica*. https://www.scielo.br/j/prc/a/prz4cVcRXNM6vwLW9zgS5Cd/
[5] Panter-Brick, C., Clarke, S. E., Lomas, H., Pinder, M., & Lindsay, S. W. (2006). Culturally compelling strategies for behaviour change: A social ecology model and case study in malaria prevention. *Social Science & Medicine*. https://www.sciencedirect.com/science/article/abs/pii/S0277953605005356
[6] Chaves, J. B., Fernandes, S. C. S., & Bezerra, D. S. (2018). A ausência masculina na atenção primária à saúde: uma análise da Teoria da Ação Planejada. *Revista de Psicologia da Saúde*. https://pepsic.bvsalud.org/scielo.php?pid=S2236-64072018000300004&script=sci_arttext
[7] Teixeira, F. A. B. S. (2011). Ameaça à Identidade Social e Punição dos desviantes: o papel da auto-categorização e da identificação grupal. *Repositório Aberto da Universidade do Porto*. https://repositorio-aberto.up.pt/bitstream/10216/61998/2/30006.pdf
[8] Lotta, G. S. (2010). Implementação de Políticas Públicas: o impacto dos fatores relacionais e organizacionais sobre a atuação dos Burocratas de Nível de Rua no Programa Saúde da Família. *Tese de Doutorado, Universidade de São Paulo*. https://www.teses.usp.br/teses/disponiveis/8/8131/tde-20102010-120342/publico/2010_GabrielaSpangheroLotta.pdf
[9] Reis, R. S., & Petroski, E. L. (2005). Aplicação da teoria cognitivo-social para predição de estágios de mudança de comportamento em adolescentes brasileiros. *Revista Brasileira de Cineantropometria & Desempenho Humano*. https://pesquisa.bvsalud.org/portal/resource/pt/lil-439039
[10] Zacharias, F. C. M., Perez, G., Cavalcante, R. S., & Guimarães, E. A. A. (2021). e-SUS Atenção Primária: atributos determinantes para a adoção de uma inovação. *Cadernos de Saúde Pública*. https://www.scielo.br/j/csp/a/CmLbcjLCR4d6xLvNbyW6Fgr/?format=html&lang=pt
[11] Lansford, J. E. (2021). Cross-Cultural Similarities and Differences in Parenting. *Journal of Child Psychology and Psychiatry*. https://pmc.ncbi.nlm.nih.gov/articles/PMC8940605/
[12] Almeida, T. R. (2017). A TEORIA DA ESTRUTURAÇÃO DE ANTHONY GIDDENS: UMA BREVE LEITURA DE ALGUMAS INFLUÊNCIAS ADVINDAS DA LITERATURA SOCIOLÓGICA. *Sem Aspas*. https://periodicos.fclar.unesp.br/semaspas/article/download/7193/5516/21366
[13] DiMaggio, P. J., & Powell, W. W. (2005). A GAIOLA DE FERRO REVISITADA: ISOMORFISMO INSTITUCIONAL E RACIONALIDADE COLETIVA NOS CAMPOS ORGANIZACIONAIS. *Revista de Administração de Empresas*. http://periodicos.fgv.br/rae/article/download/37123/35894
[14] Milani, C. R. S. (2004). Teorias do capital social e desenvolvimento local: lições a partir da experiência de Pintadas (Bahia, Brasil). *Organizações & Sociedade*. https://www.scielo.br/j/osoc/a/cSw768DQRn6qvc6QqRNjVPc/?format=html&lang=pt
[15] Peuker, A. C., Oliveira, M. G. de, Oliveira, M. B. de, & Almeida, A. L. S. de O. B. de. (2018). Adaptação Cultural de Intervenções Preventivas em Saúde Mental Baseadas em Evidências. *Psico-USF*. https://www.scielo.br/j/pusf/a/fYzZHM3qnBHQRvbwvYm93dg/?format=html
[16] Silva, T. S., Gomide, C. S., Lima, A. A. T. F. C., Júnior, F. F., Roque, D. M., & Martins, A. F. H. (2014). ATITUDES, NORMAS SUBJETIVAS E CONTROLE COMPORTAMENTAL PERCEBIDO UMA POPULAÇÃO UNIVERSITÁRIA EM RELAÇÃO AO CONSUMO DE ÁGUA: ANÁLISE À LUZ DA TEORIA DO COMPORTAMENTO PLANEJADO (TPB). *XIV Colóquio Internacional de Gestão Universitária - CIGU*. https://repositorio.ufsc.br/bitstream/handle/123456789/132165/2014-368.pdf?sequence=1&isAllowed=y
[17] Lahire, B. (2011). A transmissão familiar da ordem desigual das coisas. *Sociologia: Revista da Faculdade de Letras da Universidade do Porto*. https://www.redalyc.org/pdf/4265/426539982002.pdf

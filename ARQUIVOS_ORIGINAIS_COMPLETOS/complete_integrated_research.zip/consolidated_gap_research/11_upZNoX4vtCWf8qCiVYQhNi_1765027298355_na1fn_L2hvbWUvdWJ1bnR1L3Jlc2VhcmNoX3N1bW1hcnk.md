# Relatório de Pesquisa: Cultura Corporativa e Sistemas de Performance Management

## Área Temática
A pesquisa se concentrou na **análise teórica e empírica** da **Cultura Corporativa** e dos **Sistemas de Gestão de Desempenho (SGD)**, com foco nas **falhas de implementação** e nas **perspectivas humanas, sociais e culturais** que explicam a resistência e a ineficácia desses sistemas. O estudo se aprofundou em conceitos de **psicologia, sociologia e antropologia** para desvendar as estruturas institucionais e os vieses cognitivos que atuam como barreiras não-tecnológicas ao sucesso da gestão de desempenho.

## Síntese dos Conceitos-Chave

Os principais conceitos, teorias e *frameworks* identificados na literatura acadêmica podem ser agrupados em quatro eixos temáticos que explicam as falhas de implementação dos Sistemas de Gestão de Desempenho:

### 1. Teorias da Cultura e Resistência
A cultura é o fator mais citado para explicar a falha na implementação de novos sistemas.

*   **Três Níveis da Cultura Organizacional (Schein):** A cultura é composta por Artefatos (visíveis), Valores Expostos e **Pressupostos Básicos Subjacentes** (inconscientes) [6]. A falha ocorre quando o SGD (Artefato) se choca com os Pressupostos Básicos da organização (crenças inconscientes sobre trabalho, poder e desempenho), gerando **resistência cultural**.
*   **Cultura como Metáfora Raiz (Smircich/Geertz):** A organização é vista como uma **teia de significados** e a cultura como um **sistema de símbolos** que precisa ser interpretado [13]. A falha é um **choque de interpretações** e significados, onde o SGD não é compreendido ou aceito no contexto simbólico da organização.
*   **Dimensões Culturais Nacionais (Hofstede e Trompenaars):** As diferenças culturais em nível nacional (como **Distância do Poder**, **Individualismo vs. Coletivismo**, **Universalismo vs. Particularismo**) influenciam a aceitação e a eficácia dos SGD [3] [15] [16] [19]. Modelos de gestão de desempenho ocidentais (individualistas e universalistas) tendem a falhar em culturas coletivistas ou particularistas.

### 2. Teorias Sociológicas e Institucionais
As falhas são vistas como resultado de estruturas sociais e pressões institucionais, e não de erros gerenciais isolados.

*   **Novo Institucionalismo Sociológico (Peci):** As organizações adotam SGDs por **isomorfismo** (pressão para se parecer com outras organizações bem-sucedidas) para obter **legitimidade**, e não necessariamente por eficiência [7]. A falha é o resultado da **incoerência** entre o sistema formal adotado e a realidade interna da organização.
*   **Teoria da Estruturação (Giddens):** Explica a **dualidade da estrutura**, onde as regras e recursos (o SGD) são, ao mesmo tempo, o resultado e o meio da ação humana [9]. A falha ocorre quando a **agência** (ação dos indivíduos) reproduz rotinas e práticas antigas (o **habitus** institucionalizado), em vez de transformar a estrutura.
*   **Teoria do Habitus (Bourdieu):** O **habitus** (disposições internalizadas) dos agentes se choca com as novas regras do SGD, explicando a **resistência social** e a reprodução de práticas não alinhadas ao sistema formal [14].
*   **Teoria da Ação Comunicativa (Habermas):** Critica a predominância da **racionalidade instrumental/estratégica** (focada em meios e fins) nos SGDs, que leva à **colonização do "mundo da vida"** (o domínio das interações sociais e culturais) pelo "sistema" (o domínio do poder e da economia) [8].

### 3. Teorias Psicológicas e de Justiça
As falhas são causadas por vieses cognitivos e percepções de injustiça no processo de avaliação.

*   **Processos Cognitivos e Teoria da Atribuição (Feldman):** A avaliação de desempenho é afetada por **vieses cognitivos** (como o **efeito halo**), onde o avaliador categoriza o avaliado com base em **protótipos** e não em dados objetivos [10]. A falha é um erro de julgamento humano, onde a atribuição de causalidade (o bom é meu, o ruim é seu) distorce a avaliação.
*   **Teoria da Equidade e Justiça Organizacional (Adams/Rodrigues):** A **percepção de justiça** (equidade) é um fator crítico para a motivação e o desempenho [12] [20]. A falha na gestão de desempenho é um reflexo da percepção de **injustiça processual** (como a avaliação é feita) e **interacional** (como o avaliador trata o avaliado), levando à desmotivação e ao baixo desempenho.

### 4. Teorias Críticas e Evidências de Falha
As falhas são inerentes ao próprio conceito de gestão de desempenho como mecanismo de controle.

*   **Poder/Conhecimento (Foucault):** O SGD é um **mecanismo disciplinar** que exerce poder através da **vigilância** e da **normalização**, produzindo conhecimento sobre o indivíduo [11]. A falha é vista como a **resistência** a esse controle.
*   **Performativos Falhados (Fleming):** Os SGDs, mesmo quando falham em seus objetivos declarados (melhorar o desempenho), ainda exercem um **poder disciplinar** e **ideológico** sobre os trabalhadores. A falha é, paradoxalmente, parte do mecanismo de controle [17].
*   **Modelo de Falhas Organizacionais (Caleman & Zylbersztajn):** As falhas são a **regularidade** e não a exceção, e devem ser analisadas em seis dimensões: **estrutural, cognitiva, comportamental, informacional, institucional e política** [4].
*   **Meta-Análise (Gerrish):** Evidência empírica de que o impacto da gestão de desempenho é **pequeno** no setor público, mas é maior quando acompanhado de **melhores práticas de gestão** (fatores humanos e sociais), reforçando que a falha está na implementação e não no conceito [18].

## Documentação Detalhada das Fontes

A tabela a seguir resume as 20 fontes acadêmicas e teóricas coletadas, com foco nas contribuições para a compreensão das falhas de implementação e das perspectivas culturais e humanas na gestão de desempenho.

| ID | Título e Autor | Ano | Contribuição Teórica Principal | Cobertura Geográfica |
| :---: | :--- | :---: | :--- | :--- |
| 1 | Exploring the Impact of National Culture on Performance Measurement [1] | 2014 | Impacto da **cultura nacional** na alta taxa de falha (70%) de implementação de Sistemas de Medição de Desempenho (PMS). | Global/Internacional |
| 2 | Em busca de um melhor entendimento da contabilidade gerencial... [2] | 2006 | Integração da **Teoria Institucional** (rotina, hábitos) com **Psicologia** e **Cultura Organizacional** para explicar o *gap* entre teoria e prática. | Brasil |
| 3 | INTERCULTURAL DIFFERENCE PARAMETERS: HOFSTEDE AND TROMPENAARS THEORIES [3] | 2020 | Comparação e aplicação das **Dimensões Culturais** de Hofstede e Trompenaars para entender diferenças na gestão. | Global/Cross-Cultural |
| 4 | Falhas organizacionais: tipologia, determinantes e proposta de modelo teórico [4] | 2013 | Modelo de **Falhas Organizacionais** em 6 dimensões: estrutural, **cognitiva, comportamental, institucional** e política. | Brasil |
| 5 | Constraints in the Implementation of Performance Management Systems in Developing Countries... [5] | 2009 | **Restrições institucionais e de capacidade** (cultura, fragmentação, apatia) como fatores de falha na implementação de SGD. | Gana (País em Desenvolvimento) |
| 6 | Organizational Culture and Leadership [6] | 1985 | Modelo dos **Três Níveis da Cultura Organizacional** (Artefatos, Valores, **Pressupostos Básicos**) para explicar a **resistência cultural**. | Global/EUA |
| 7 | A nova teoria institucional em estudos organizacionais... [7] | 2006 | Crítica ao **Novo Institucionalismo Sociológico** (isomorfismo) para explicar a adoção de SGDs por **legitimidade**, e não por eficiência. | Brasil |
| 8 | A Teoria da Ação Comunicativa de Jürgen Habermas... [8] | 1995 | Distinção entre **racionalidade instrumental** (SGD) e **racionalidade comunicativa**, e a **colonização do "mundo da vida"** pelo "sistema". | Global/Alemanha (Teoria) |
| 9 | Giddens' structuration theory and its implications... [9] | 2009 | **Teoria da Estruturação** (Giddens): **Dualidade da estrutura** (regras/recursos vs. agência) para entender a reprodução de práticas. | Global/Reino Unido (Teoria) |
| 10 | Beyond attribution theory: Cognitive processes in performance appraisal [10] | 1981 | **Processos Cognitivos** na avaliação de desempenho: **Teoria da Atribuição** e **vieses** (efeito halo, protótipos) como causas de falha. | Global/EUA (Psicologia) |
| 11 | Relações de poder, conhecimento e gestão do desempenho [11] | 2001 | Abordagem de **Michel Foucault** (relação poder/conhecimento): SGD como **mecanismo disciplinar** de **vigilância** e **normalização**. | Brasil/França (Teoria) |
| 12 | Percepção de justiça na avaliação na avaliação de desempenho... [12] | 2014 | Aplicação da **Teoria da Equidade** (Adams) e **percepção de justiça** (equidade) como fator de motivação/desmotivação e falha. | Global/EUA (Teoria) |
| 13 | Concepts of Culture and Organizational Analysis [13] | 1983 | **Antropologia Interpretativa** (Geertz): Cultura como **metáfora raiz** (teia de significados) vs. cultura como variável. | Global/EUA (Antropologia) |
| 14 | O estudo da cultura organizacional por meio das práticas... [14] | 2016 | **Teoria do Habitus** (Bourdieu): **Habitus** (disposições internalizadas) e **campo** para explicar a **resistência social** e a reprodução de práticas. | Brasil/França (Teoria) |
| 15 | Culture's Consequences: International Differences in Work-Related Values [15] | 1980 | **Dimensões Culturais Nacionais** (PDI, IDV, MAS, UAI) de **Hofstede** para análise cross-cultural de SGD. | Global/Internacional |
| 16 | Riding the Waves of Culture: Understanding Diversity in Global Business [16] | 1997 | **Sete Dimensões da Cultura** de **Trompenaars** (Universalismo vs. Particularismo, Individualismo vs. Comunitarianismo) para gestão transcultural. | Global/Internacional |
| 17 | When performativity fails: Implications for critical management studies [17] | 2016 | **Critical Management Studies (CMS)**: **Performativos Falhados** – a falha do SGD como parte do mecanismo de **poder disciplinar** e **ideológico**. | Global/Reino Unido (Teoria) |
| 18 | The Impact of Performance Management on Performance in Public Organizations: A Meta-Analysis [18] | 2016 | **Meta-análise** com **evidência empírica** de que o impacto do SGD é pequeno, mas depende de **melhores práticas de gestão** (fatores humanos e sociais). | Global/Setor Público |
| 19 | Going Global Versus Staying Local: The Performance Management Dilemma... [19] | 2016 | Dilema da gestão de desempenho em contexto internacional, reforçando a **falha** na aplicação de modelos universais em culturas diversas. | Global/Internacional |
| 20 | A influência das perceções de justiça organizacional no compromisso organizacional... [20] | 2023 | **Meta-análise qualitativa** sobre **Justiça Organizacional** (distributiva, processual, interacional) como fator crítico para o **compromisso** e **desempenho**. | Global/Portugal (Estudo) |

## Referências

[1] Jwijati, I. M., & Bititci, U. S. (2014). *Exploring the Impact of National Culture on Performance Measurement*. HAL Science.
[2] Guerreiro, R., Frezatti, F., & Casado, T. (2006). *Em busca de um melhor entendimento da contabilidade gerencial através da integração de conceitos da psicologia, cultura organizacional e teoria institucional*. Revista Contabilidade & Finanças.
[3] Sattorovich, J. U. (2020). *INTERCULTURAL DIFFERENCE PARAMETERS: HOFSTEDE AND TROMPENAARS THEORIES*. International Discourse of Public Policy, Management and Entrepreneurship.
[4] Caleman, S. M. Q., & Zylbersztajn, D. (2013). *Falhas organizacionais: tipologia, determinantes e proposta de modelo teórico*. Organizações & Sociedade.
[5] Ohemeng, F. L. K. (2009). *Constraints in the Implementation of Performance Management Systems in Developing Countries: The Ghanaian Case*. Public Management Review.
[6] Schein, E. H. (1985). *Organizational Culture and Leadership*. Jossey-Bass.
[7] Peci, A. (2006). *A nova teoria institucional em estudos organizacionais: uma abordagem crítica*. Cadernos EBAPE.BR.
[8] Pinto, J. M. R. (1995). *A Teoria da Ação Comunicativa de Jürgen Habermas: conceitos básicos e possibilidades de aplicação à administração*. Paidéia.
[9] Não especificado no snippet. (2009). *Giddens' structuration theory and its implications for management accounting research*. ResearchGate.
[10] Feldman, J. M. (1981). *Beyond attribution theory: Cognitive processes in performance appraisal*. Journal of Applied Psychology.
[11] Brito, V. G. P. (2001). *Relações de poder, conhecimento e gestão do desempenho*. Revista de Administração Pública.
[12] Adams, J. S. (2014). *Percepção de justiça na avaliação na avaliação de desempenho e satisfação do trabalho*. Redalyc.
[13] Smircich, L. (1983). *Concepts of Culture and Organizational Analysis*. Administrative Science Quarterly.
[14] Souza, E. C. L. de. (2016). *O estudo da cultura organizacional por meio das práticas: uma proposta à luz do legado de Bourdieu*. Cadernos EBAPE.BR.
[15] Hofstede, G. (1980). *Culture's Consequences: International Differences in Work-Related Values*. Sage Publications.
[16] Trompenaars, F., & Hampden-Turner, C. (1997). *Riding the Waves of Culture: Understanding Diversity in Global Business*. McGraw-Hill.
[17] Fleming, P. (2016). *When performativity fails: Implications for critical management studies*. Human Relations.
[18] Gerrish, E. (2016). *The Impact of Performance Management on Performance in Public Organizations: A Meta-Analysis*. Public Administration Review.
[19] Trompenaars, F., & van den Bergh, R. (2016). *Going Global Versus Staying Local: The Performance Management Dilemma in the International Context*. Palgrave Macmillan.
[20] Rodrigues, A. F. G. (2023). *A influência das perceções de justiça organizacional no compromisso organizacional no contexto da avaliação do desempenho: Uma meta análise qualitativa*. Dissertação de Mestrado.

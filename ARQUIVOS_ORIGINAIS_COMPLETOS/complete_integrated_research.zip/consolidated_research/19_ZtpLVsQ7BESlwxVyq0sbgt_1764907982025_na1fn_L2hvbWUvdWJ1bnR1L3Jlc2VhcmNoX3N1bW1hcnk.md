# Relatório de Pesquisa Aprofundada: Design Thinking e Human-Centered Design

## Área Temática
Design Thinking e Human-Centered Design (HCD) - A Abordagem Centrada no Usuário para Inovação.

## Síntese dos Conceitos-Chave

A pesquisa aprofundada sobre **Design Thinking (DT)** e **Human-Centered Design (HCD)** revela que estas não são apenas metodologias, mas sim uma filosofia de inovação que coloca as necessidades, desejos e contextos do ser humano no centro do processo de criação [2]. O HCD é frequentemente definido como a **mentalidade** ou **filosofia** mais ampla, enquanto o Design Thinking é a **metodologia** ou **kit de ferramentas** estruturado que expressa essa filosofia [2].

O DT, popularizado por Tim Brown [1] e a IDEO, é um processo colaborativo e iterativo que busca soluções que sejam simultaneamente **desejáveis** (para o ser humano), **tecnologicamente viáveis** e **economicamente sustentáveis** [1]. O modelo de 5 estágios da Stanford d.school (Empatizar, Definir, Idear, Prototipar, Testar) [3] é o framework mais difundido, enfatizando a natureza não-linear e a constante iteração entre os modos de pensamento. A base de todo o processo é a **empatia**, que exige uma compreensão profunda e holística das vidas, emoções e motivações das pessoas para quem se está projetando [2].

As raízes acadêmicas do Design Thinking remontam à **"Ciência do Artificial"** de Herbert Simon [12], que estabeleceu o design como uma disciplina analítica focada em transformar situações existentes em situações preferíveis. O trabalho de Robert McKim [13] sobre **pensamento visual** e prototipagem rápida também é um precursor fundamental, influenciando a ênfase do DT na experimentação e na materialização de ideias. Don Norman [4], um dos pioneiros do Design Centrado no Usuário (UCD), reforça a premissa fundamental de que "as pessoas que usam o produto são as que importam" [4].

A aplicabilidade do DT/HCD transcende o design de produtos, estendendo-se a **serviços complexos** e **sistemas**. Casos de estudo demonstram seu uso no **setor de saúde** (Hospital Oftalmológico de Roterdã) [5] [19], na **inovação social** em países em desenvolvimento [6] [18], no **setor público** (Singapura e Brasil) [7] [11], no **setor financeiro** [16] e na **manufatura** (Indústria 5.0) [17]. Mais recentemente, o HCD tem se mostrado crucial na integração com a **Inteligência Artificial Generativa (IAG)** [10] [20], garantindo que as soluções de IA sejam éticas, desejáveis e verdadeiramente centradas no ser humano.

## Documentação Detalhada das Fontes

A tabela a seguir documenta as 20 fontes coletadas, organizadas por tipo e relevância.

| ID | Título e Autor | Ano | Tipo | Principais Conceitos e Contribuições | Cobertura Geográfica | URL/Referência |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| **1** | **Design Thinking** (Tim Brown) | 2008 | Artigo Especializado (HBR) | Definição clássica de DT: Desejabilidade, Viabilidade, Factibilidade. Ênfase na empatia e colaboração. | EUA | [Link 1] |
| **2** | **What Is Human-Centered Design?** (IDEO U) | 2025 | Metodologia/Framework | Distinção entre HCD (mentalidade) e DT (toolkit). 3 Fases (Inspiração, Ideação, Implementação) e 8 Princípios (Empatia, Iteração, Sistêmico). | EUA | [Link 2] |
| **3** | **An Introduction to Design Thinking PROCESS GUIDE** (Stanford d.school) | S/D | Metodologia/Framework | Modelo de 5 Estágios do DT: Empathize, Define, Ideate, Prototype, Test. Processo não-linear e iterativo. | EUA | [Link 3] |
| **4** | **The Design of Everyday Things** (Donald A. Norman) | 2013 | Livro/Especialista | Fundamentos do Design Centrado no Usuário (UCD) e HCD. Conceitos de *affordances*, *feedback* e *mapping*. | EUA | [Link 4] |
| **5** | **Rotterdam Eye Hospital > Patient Experience** (This is Design Thinking) | 2017 | Caso de Estudo | Aplicação do DT para melhorar a experiência do paciente e a eficiência em serviços de saúde. | Europa (Holanda) | [Link 5] |
| **6** | **The background behind the creation of the HCD Toolkit** (iDE/IDEO.org) | 2010 | Metodologia/Social | Aplicação do HCD em contextos de desenvolvimento global e social. Criação do HCD Toolkit para democratização da metodologia. | Global (Desenvolvimento) | [Link 6] |
| **7** | **How innovative design is powering up Singapore's digital government delivery** (Melisa Chan - GovTech) | 2023 | Caso de Estudo | Uso do DT/HCD para redesenhar serviços digitais governamentais, focando no cidadão. | Ásia (Singapura) | [Link 7] |
| **8** | **An integrative review of human‐centered design and design thinking for the creation of health interventions** | S/D | Revisão Acadêmica | Integração de HCD e DT para intervenções de saúde. Necessidade de proficiência em DT para profissionais de saúde. | Global | [Link 8] |
| **9** | **Design Thinking: Inovação em Negócios** (Maurício Vianna et al.) | 2012 | Livro/Especialista | Livro pioneiro no Brasil, adaptando o DT ao contexto empresarial nacional. Foco na inovação e criação de valor. | Brasil | [Link 9] |
| **10** | **Design Centrado no Ser Humano e Inteligência Artificial Generativa** (Souza & Luppe) | 2025 | Artigo Científico | Integração de HCD com IAG no setor de turismo brasileiro. HCD como guia para soluções digitais complexas. | Brasil | [Link 10] |
| **11** | **Design para o Serviço Público** (TCU - Brasil) | S/D | Publicação Governamental | Formalização do DT/HCD para o redesenho de serviços públicos no Brasil, com foco no cidadão. | Brasil | [Link 11] |
| **12** | **The Sciences of the Artificial** (Herbert A. Simon) | 1969 | Artigo Acadêmico (Raízes) | Estabelece a "Ciência do Design" como disciplina legítima. Base teórica para o DT. | EUA | [Link 12] |
| **13** | **Experiences in Visual Thinking** (Robert H. McKim) | 1972 | Livro (Raízes) | Ênfase no pensamento visual, esboço de ideias e prototipagem rápida. Influência direta na d.school. | EUA | [Link 13] |
| **14** | **Design thinking and UX: Two sides of the same coin** (D. Knemeyer) | 2015 | Artigo Especializado | DT como abordagem estratégica (mindset) e UX como disciplina tática (ferramentas) para a inovação. | Global | [Link 14] |
| **15** | **Design thinking approach for user interface design and user experience** (Darmawan et al.) | 2022 | Artigo Acadêmico | Estudo de caso da aplicação do DT para o desenvolvimento de UI/UX em sistemas de informação acadêmica. | Global (Indonésia) | [Link 15] |
| **16** | **Design Thinking: The New DNA Of The Financial Sector** (Oliver Wyman) | 2017 | Artigo Especializado | Aplicação do DT no setor financeiro para redesenhar a experiência do cliente (CX) e impulsionar a inovação. | Global (Consultoria) | [Link 16] |
| **17** | **Human-centered design approach for manufacturing assistance systems** | 2020 | Artigo Acadêmico | Uso do HCD e Design Sprints na Manufatura (Indústria 4.0/5.0), priorizando o operador humano. | Global | [Link 17] |
| **18** | **Design Thinking for Social Innovation** (Tim Brown & Jocelyn Wyatt) | 2010 | Artigo Especializado | Expansão do DT para problemas sociais complexos. Foco na co-criação com as comunidades. | Global | [Link 18] |
| **19** | **Design thinking for social innovation in health care** | 2017 | Artigo Acadêmico | Framework para fomentar a cultura de DT em organizações de saúde para inovação social. | Global | [Link 19] |
| **20** | **Design thinking and AI: a new frontier for designing human‐centered AI solutions** | S/D | Artigo Acadêmico | Aborda a necessidade do DT para garantir que as soluções de IA sejam éticas e centradas no ser humano. | Global | [Link 20] |

## Referências

[Link 1]: https://readings.design/PDF/Tim%20Brown,%20Design%20Thinking.pdf "Design Thinking (Harvard Business Review)"
[Link 2]: https://www.ideou.com/blogs/inspiration/what-is-human-centered-design "What Is Human-Centered Design? A Complete Guide for Innovators (IDEO U)"
[Link 3]: https://web.stanford.edu/~mshanks/MichaelShanks/files/509554.pdf "An Introduction to Design Thinking PROCESS GUIDE (Stanford d.school)"
[Link 4]: https://dl.icdst.org/pdfs/files4/4bb8d08a9b309df7d86e62ec4056ceef.pdf "The Design of Everyday Things (Donald A. Norman)"
[Link 5]: https://thisisdesignthinking.net/2017/01/rotterdam-eye-hospital/ "Rotterdam Eye Hospital > Patient Experience (This is Design Thinking)"
[Link 6]: https://www.ideglobal.org/story/hcd-toolkit "The background behind the creation of the HCD Toolkit (iDE/IDEO.org)"
[Link 7]: https://govinsider.asia/intl-en/article/How-innovative-design-is-powering-up-singapore's-digital-government-delivery "How innovative design is powering up Singapore's digital government delivery (GovTech Singapore)"
[Link 8]: https://onlinelibrary.wiley.com/doi/abs/10.1111/nuf.12805 "An integrative review of human‐centered design and design thinking for the creation of health interventions"
[Link 9]: https://www.livrodesignthinking.com.br/ "Design Thinking: Inovação em Negócios (Maurício Vianna et al.)"
[Link 10]: https://periodicos.uninove.br/iptec/article/view/28379 "Design Centrado no Ser Humano e Inteligência Artificial Generativa (Souza & Luppe)"
[Link 11]: https://portal.tcu.gov.br/data/files/A1/67/B7/09/B0A1F6107AD96FE6F18818A8/Design_servico_publico_portugues.pdf "Design para o Serviço Público (TCU - Brasil)"
[Link 12]: https://mitpress.mit.edu/9780262690232/the-sciences-of-the-artificial/ "The Sciences of the Artificial (Herbert A. Simon)"
[Link 13]: https://www.amazon.com/Experiences-Visual-Thinking-Robert-McKim/dp/0818504110 "Experiences in Visual Thinking (Robert H. McKim)"
[Link 14]: https://interactions.acm.org/archive/view/september-october-2015/design-thinking-and-ux "Design thinking and UX: Two sides of the same coin (D. Knemeyer)"
[Link 15]: https://www.joiv.org/index.php/joiv/article/view/997 "Design thinking approach for user interface design and user experience (Darmawan et al.)"
[Link 16]: https://www.oliverwyman.com/our-expertise/insights/2017/apr/design-thinking-the-new-dna-of-the-financial-sector.html "Design Thinking: The New DNA Of The Financial Sector (Oliver Wyman)"
[Link 17]: https://www.sciencedirect.com/science/article/pii/S2212827120308258 "Human-centered design approach for manufacturing assistance systems"
[Link 18]: https://myweb.uiowa.edu/dlgould/plugin/documents/Design_Thinking_for_Social_Innovation.pdf "Design Thinking for Social Innovation (Tim Brown & Jocelyn Wyatt)"
[Link 19]: https://www.tandfonline.com/doi/abs/10.1080/14606925.2017.1372926 "Design thinking for social innovation in health care"
[Link 20]: https://onlinelibrary.wiley.com/doi/abs/10.1111/dmj.12085 "Design thinking and AI: a new frontier for designing human‐centered AI solutions"

# Resumo Detalhado da Pesquisa: Planejamento Estratégico e Melhoria Contínua Orientados a Objetivos

A pesquisa aprofundada sobre o conceito de "pensar no resultado antes" concentrou-se em duas metodologias centrais: o **Goal-oriented Planning** (Planejamento Orientado a Objetivos) e o ciclo **PDCA (Plan-Do-Check-Act)**. A análise revelou que ambas as abordagens, embora originadas em contextos distintos (gestão estratégica/psicologia e gestão da qualidade/engenharia), compartilham o princípio fundamental de que a definição clara e antecipada de um estado futuro desejado é o motor primário para a ação, a medição e a melhoria contínua.

## 1. Goal-oriented Planning: A Estrutura da Intenção

O Planejamento Orientado a Objetivos é um paradigma que estabelece que a **intenção consciente** de um indivíduo ou organização é o principal regulador de suas ações [10]. Essa abordagem é aplicada em diversas disciplinas, desde a psicologia organizacional até a engenharia de software e a inteligência artificial.

### 1.1. Fundamentos Teóricos

O pilar psicológico do planejamento orientado a objetivos é a **Teoria da Definição de Metas** (Goal-Setting Theory), desenvolvida por Edwin A. Locke [10]. A teoria postula que metas difíceis e específicas levam a um desempenho significativamente superior do que metas fáceis ou a simples instrução de "faça o seu melhor". A eficácia das metas é mediada por fatores como a clareza, o desafio e o *feedback* [10].

### 1.2. Frameworks de Gestão

No campo empresarial, o Goal-oriented Planning se manifesta em frameworks de alta performance:

*   **Objectives and Key Results (OKR):** Popularizado por John Doerr e adotado por empresas como Google, o OKR é um sistema colaborativo que define **Objetivos (O)** ambiciosos (o que alcançar) e **Resultados-Chave (KR)** mensuráveis (como medir o progresso) [11]. O sistema promove transparência e alinhamento vertical e horizontal na organização.
*   **SMART Goals:** Uma metodologia fundamental que garante que os objetivos sejam **Específicos, Mensuráveis, Alcançáveis, Relevantes e com Prazo Definido** (Time-Bound) [12]. O framework SMART atua como um filtro de qualidade para a definição de qualquer objetivo.
*   **Teoria das Restrições (TOC):** Apresentada no romance de gestão *The Goal* por Eliyahu M. Goldratt, a TOC é uma filosofia de gestão orientada a objetivos que foca na identificação e gestão do **gargalo (bottleneck)** que limita o desempenho do sistema em relação à sua meta [4].

### 1.3. Aplicações em Engenharia e IA

O Goal-oriented Planning também é central em áreas técnicas:

*   **Goal-Oriented Requirements Engineering (GORE):** Na engenharia de software, o GORE utiliza objetivos de alto nível para elicitar, modelar e analisar requisitos, garantindo que o sistema final esteja alinhado com as metas estratégicas da organização [7] [9].
*   **Goal-Oriented Action Planning (GOAP):** Na Inteligência Artificial (IA), o GOAP é um sistema que permite a agentes autônomos (como em jogos) planejar dinamicamente uma sequência de ações para satisfazer um objetivo definido, demonstrando a aplicação do conceito em sistemas de planejamento automatizado [8].

## 2. PDCA: O Ciclo da Melhoria Contínua

O ciclo **Plan-Do-Check-Act (PDCA)**, também conhecido como Ciclo Deming ou Ciclo Shewhart, é a estrutura fundamental para a gestão da qualidade e a melhoria contínua.

### 2.1. Origem e Evolução

O ciclo foi originalmente concebido por Walter A. Shewhart na década de 1930 como o **Ciclo Shewhart** (Specify, Produce, Inspect) [13]. Foi popularizado por W. Edwards Deming, que o levou ao Japão no pós-guerra, onde se tornou a base do movimento de gestão da qualidade [13]. Deming, no entanto, preferia a versão **PDSA (Plan-Do-Study-Act)**, substituindo "Check" por "**Study**" para enfatizar a importância da aprendizagem e da análise aprofundada dos resultados, e não apenas a verificação [5] [13].

### 2.2. Estrutura e Aplicações

O PDCA é um modelo iterativo de quatro etapas:

1.  **Plan (Planejar):** Estabelecer os objetivos e os processos necessários para entregar resultados de acordo com o resultado desejado (o "Goal-oriented Planning" inicial).
2.  **Do (Fazer):** Implementar o plano, frequentemente em pequena escala (teste piloto).
3.  **Check/Study (Checar/Estudar):** Monitorar e medir os resultados em relação aos objetivos, identificando desvios e aprendizados.
4.  **Act (Agir):** Padronizar a melhoria se o resultado for positivo, ou reiniciar o ciclo (Plan) com base nos aprendizados se o resultado for negativo [6].

O PDCA é o alicerce de diversos sistemas de gestão, sendo explicitamente integrado como a estrutura subjacente da norma **ISO 9001** (Sistema de Gestão da Qualidade) [14]. É também combinado com outras metodologias, como o **Lean Six Sigma**, onde o PDCA pode enquadrar o ciclo DMAIC (Define, Measure, Analyze, Improve, Control) para projetos de melhoria mais complexos [15].

## 3. Síntese e Interconexão

Goal-oriented Planning e PDCA são faces da mesma moeda: o primeiro foca na **definição da meta** (o "P" do PDCA), enquanto o segundo foca na **execução e iteração** para alcançar e superar essa meta. O planejamento orientado a objetivos fornece a clareza e a direção (o *o quê*), e o PDCA fornece o mecanismo cíclico e científico para a execução, medição e ajuste (o *como*). Ambos são essenciais para qualquer processo que busque a excelência e a melhoria contínua.

## 4. Tabela Consolidada de Fontes

| # | Título | Autor(es) | Ano | URL/Referência | Principais Conceitos e Contribuições | Região/País |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | The i* Framework for Goal-Oriented Modeling | Xavier Franch, Lidia López, Carlos Cares & Daniel Colomer | 2016 | [1] | Framework para modelagem orientada a objetivos em engenharia de software (GORE). Conceitos chave: ator, dependência, objetivo, decomposição. | Internacional (Espanha/América Latina) |
| 2 | Towards an Adaptive Framework for Goal-Oriented Strategic Decision-Making | Jacek Dąbrowski | 2017 | [2] | Framework adaptativo para estender GORE no planejamento estratégico, integrando Machine Learning e Análise Bayesiana. | Internacional (Conferência em Lisboa, Portugal) |
| 3 | GO-Plan: A goal-oriented method for FAIRification planning | C Bernabé et al. | 2025 | [3] | Método GO-Plan para identificar e refinar objetivos de FAIRification (Findability, Accessibility, Interoperability, and Reusability). | Internacional |
| 4 | The Goal: A Process of Ongoing Improvement (novel) | Eliyahu M. Goldratt e Jeff Cox | 1984 | [4] | Romance de gestão focado na **Teoria das Restrições (TOC)**, que usa a orientação a objetivos para identificar e gerenciar gargalos. | EUA/Internacional |
| 5 | What is an OKR? Definition and Examples | What Matters (John Doerr) | Desconhecido | [5] | Framework de definição de metas colaborativo **Objectives and Key Results (OKR)**. O 'O' é o objetivo e o 'KR' é o resultado-chave. | EUA (Google, John Doerr) |
| 6 | SMART Goals: A How to Guide | Atlassian | 2023 | [6] | Metodologia **SMART** (Specific, Measurable, Achievable, Relevant, Time-Bound) para garantir a qualidade da definição de objetivos. | Internacional |
| 7 | Goal-oriented requirements engineering: a guided tour | A van Lamsweerde | 2001 | [7] | Artigo seminal sobre **Goal-Oriented Requirements Engineering (GORE)**. Usa objetivos para modelar e analisar requisitos de software. | Internacional |
| 8 | Building the AI of F.E.A.R. with Goal Oriented Action Planning | Jeff Orkin | 2006 (Artigo de 2020) | [8] | Explica o uso de **Goal-Oriented Action Planning (GOAP)**, um sistema de IA para planejamento dinâmico de ações. | EUA |
| 9 | Goal-oriented requirements engineering: an extended systematic mapping study | J Horkoff et al. | 2019 | [9] | Mapeamento sistemático estendido sobre GORE, definindo-o como o estudo ou aplicação de modelos de objetivos na Engenharia de Requisitos. | Internacional |
| 10 | Toward a theory of task motivation and incentives | Edwin A. Locke | 1968 | [10] | Artigo seminal que estabelece a **Teoria da Definição de Metas**. Premissa: metas difíceis e específicas aumentam o desempenho. | EUA |
| 11 | Foundation and History of the PDSA Cycle | Ron Moen (Baseado em W. Edwards Deming) | Desconhecido | [11] | Documenta a evolução do ciclo, desde o Ciclo Shewhart (1939) até o Ciclo **PDSA (Plan-Do-Study-Act)** de Deming. | EUA/Japão |
| 12 | DEMING CYCLE (PDCA) / Shewhart Cycle | Walter A. Shewhart, W. Edwards Deming, PM Swamidass | 2000 (Conceitos originais de 1930s-1950s) | [12] | Origem do ciclo PDCA, originalmente **Ciclo Shewhart**. Renomeado como Ciclo Deming ou PDCA pelos japoneses. | EUA/Japão |
| 13 | The Influence of PDCA Cycle Management Mode on Nursing Quality | N Pan et al. | 2022 | [13] | Estudo de caso que aplica o PDCA na gestão da qualidade de enfermagem, demonstrando sua eficácia como método básico de gestão da qualidade total (TQM). | China |
| 14 | A structured model for continuous improvement: A Medtech case study utilizing the Plan, Do, Check, Act (PDCA) model | E Naughton et al. | 2024 | [14] | Estudo de caso em Medtech que utilizou o PDCA para desenvolver um sistema Lean e uma estrutura de melhoria contínua. | Internacional |
| 15 | PDCA (Plan-Do-Check-Act) Cycle in ISO 9001 Requirements | Advisera | Desconhecido | [15] | Explica como o ciclo PDCA é um componente chave e a estrutura subjacente do sistema de Gestão da Qualidade (QMS) da norma **ISO 9001**. | Internacional |
| 16 | Systematic review of the application of the plan–do–study–act method to improve quality in healthcare | MJ Taylor et al. | 2013 | [16] | Revisão sistemática sobre a aplicação do ciclo **PDSA** para melhoria da qualidade em sistemas de saúde. | Internacional |
| 17 | A new lean Six Sigma hybrid method based on the combination of PDCA and the DMAIC to improve process performance | Desconhecido | 2019 | [17] | Propõe um método híbrido que combina o PDCA com o **DMAIC** (Define, Measure, Analyze, Improve, Control) do Six Sigma. | Internacional |
| 18 | Measure What Matters: How Google, Bono, and the Gates Foundation Rock the World with OKRs | John Doerr | 2018 | [18] | Livro que popularizou o framework **OKR**. Enfatiza a transparência, a responsabilidade e o alinhamento de objetivos. | EUA |

## 5. Referências

[1]: https://link.springer.com/chapter/10.1007/978-3-319-39417-6_22 "The i* Framework for Goal-Oriented Modeling"
[2]: https://ieeexplore.ieee.org/abstract/document/8049180/ "Towards an Adaptive Framework for Goal-Oriented Strategic Decision-Making"
[3]: https://journals.sagepub.com/doi/10.1177/18758789251324008 "GO-Plan: A goal-oriented method for FAIRification planning"
[4]: https://en.wikipedia.org/wiki/The_Goal_(novel) "The Goal (novel)"
[5]: https://www.whatmatters.com/faqs/okr-meaning-definition-example "What is an OKR? Definition and Examples"
[6]: https://www.atlassian.com/blog/productivity/how-to-write-smart-goals "SMART Goals: A How to Guide"
[7]: https://homepages.uc.edu/~niunn/courses/RE-refs/GuidedTour01.pdf "Goal-oriented requirements engineering: a guided tour"
[8]: https://www.gamedeveloper.com/design/building-the-ai-of-f-e-a-r-with-goal-oriented-action-planning "Building the AI of F.E.A.R. with Goal Oriented Action Planning"
[9]: https://link.springer.com/article/10.1007/s00766-017-0280-z "Goal-oriented requirements engineering: an extended systematic mapping study"
[10]: https://psycnet.apa.org/record/1968-11263-001 "Toward a theory of task motivation and incentives"
[11]: https://deming.org/wp-content/uploads/2020/06/PDSA_History_Ron_Moen.pdf "Foundation and History of the PDSA Cycle"
[12]: https://link.springer.com/rwe/10.1007/1-4020-0612-8_229 "DEMING CYCLE (PDCA)"
[13]: https://pmc.ncbi.nlm.nih.gov/articles/PMC9286892/ "The Influence of PDCA Cycle Management Mode on Nursing Quality"
[14]: https://www.sciencedirect.com/science/article/pii/S2405844024160653 "A structured model for continuous improvement: A Medtech case study utilizing the Plan, Do, Check, Act (PDCA) model"
[15]: https://advisera.com/9001academy/knowledgebase/plan-do-check-act-in-the-iso-9001-standard/ "PDCA (Plan-Do-Check-Act) Cycle in ISO 9001 Requirements"
[16]: https://pmc.ncbi.nlm.nih.gov/articles/PMC3963536/ "Systematic review of the application of the plan–do–study–act method to improve quality in healthcare"
[17]: http://revistaindustriatextila.ro/images/2019/5/Revista_Industria%20Textila%205_2019%20web.pdf#page=56 "A new lean Six Sigma hybrid method based on the combination of PDCA and the DMAIC to improve process performance"
[18]: https://www.amazon.com/Measure-What-Matters-Google-Foundation/dp/0525536221 "Measure What Matters: How Google, Bono, and the Gates Foundation Rock the World with OKRs"

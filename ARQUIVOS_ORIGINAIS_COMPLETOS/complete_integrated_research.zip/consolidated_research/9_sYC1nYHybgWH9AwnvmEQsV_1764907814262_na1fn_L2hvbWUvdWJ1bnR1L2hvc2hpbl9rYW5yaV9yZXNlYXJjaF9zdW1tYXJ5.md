# Pesquisa Aprofundada: Hoshin Kanri e Metodologias Japonesas de Planejamento Estratégico

## Introdução

Esta pesquisa aprofundada foi conduzida com o objetivo de analisar o **Hoshin Kanri** (também conhecido como *Policy Deployment* ou Desdobramento da Política) e outras metodologias japonesas de planejamento estratégico. O foco principal é a compreensão de como essas abordagens se alinham ao conceito de "pensar no resultado antes", promovendo o alinhamento estratégico e a melhoria contínua. Foram identificadas 18 fontes relevantes, abrangendo artigos acadêmicos, livros, estudos de caso e publicações especializadas, conforme detalhado a seguir.

## Contextualização: Hoshin Kanri e o Planejamento Estratégico Japonês

O Hoshin Kanri (方策管理), que se traduz como "gestão de bússola" ou "gestão de política", é uma metodologia de gestão estratégica originada no Japão, notavelmente desenvolvida por empresas como a Toyota e a Yokogawa Hewlett-Packard nas décadas de 1960 e 1970 [1] [2]. Seu propósito central é garantir que os objetivos estratégicos de longo prazo da organização sejam comunicados, compreendidos e executados em todos os níveis, desde a alta gestão até o chão de fábrica.

A metodologia se baseia no ciclo **Plan-Do-Check-Act (PDCA)** de Deming e é frequentemente integrada a sistemas de Gestão da Qualidade Total (TQM) e *Lean Management* [3] [4]. O conceito de "pensar no resultado antes" é intrínseco ao Hoshin Kanri, pois exige que a organização defina "Objetivos de Avanço" (*Breakthrough Objectives*) de longo prazo (3 a 5 anos) antes de desdobrá-los em metas anuais e ações diárias.

Um elemento crucial do Hoshin Kanri é o processo de **Catchball** (キャッチボール), um mecanismo de comunicação bidirecional que garante o consenso e o alinhamento entre os níveis hierárquicos. A alta gestão propõe as diretrizes, e os níveis operacionais "devolvem" a bola com planos de ação e recursos necessários, ajustando as metas até que haja um acordo mútuo (*buy-in*) [5].

## Documentação e Análise Detalhada das Fontes

A tabela a seguir documenta as 18 fontes identificadas, conforme os critérios de pesquisa.

| ID | Título | Autor(es) | Ano | Tipo | Principais Conceitos e Contribuições | Citações Relevantes |
| :---: | :--- | :--- | :---: | :--- | :--- | :--- |
| 1 | Hoshin kanri and hoshin process: A review and literature survey | Jolayemi, J.K. | 2008 | Artigo Acadêmico | Revisão abrangente da literatura, estendendo os 7 passos do Hoshin para 10, e comparando a visão japonesa original com a ocidental. | "Most published works on it and its processes fail to adequately cover all the key elements and characteristics that can give it superiority and advantage over the Japanese hoshin." [1] |
| 2 | Hoshin Kanri: implementing the catchball process | Tennant, C. & Roberts, P. | 2001 | Artigo Acadêmico | Foco no processo de *Catchball* como mecanismo de consenso e alinhamento, essencial para a adoção do Hoshin Kanri no Ocidente. | "The application of Hoshin Kanri relies on a process called “catchball” to gain consensus on the deployment of Hoshin." [5] |
| 3 | Hoshin Kanri: how Xerox manages | Witcher, B. & Butterworth, R. | 1999 | Artigo Acadêmico | Estudo de caso detalhado da implementação do Hoshin Kanri na Xerox (Reino Unido), destacando o uso de "programas vitais" e a ligação com avaliações de funcionários. | "Xerox is an exemplar of Hoshin Kanri best practice." [3] |
| 4 | Policy deployment: an examination of the theory | Lee, R.G. & Dale, B.G. | 1998 | Artigo Acadêmico | Análise teórica do *Policy Deployment*, definindo-o como a aplicação do ciclo PDCA ao planejamento e execução de objetivos estratégicos. | "Policy deployment is the application of the plan‐do‐check‐act cycle to the planning and execution of strategic organisational objectives." [4] |
| 5 | Hoshin Kanri: a tool for strategic policy deployment | Tennant, C. & Roberts, P. | 2001 | Artigo Acadêmico | Comparação do Hoshin Kanri com metodologias ocidentais como Gestão por Objetivos (MbO) e Reengenharia de Processos de Negócio (BPR), enfatizando a superioridade do HK no alinhamento. | "Planning and deployment are critical elements of Hoshin Kanri, which imply that the process of developing targets..." [6] |
| 6 | Hoshin Kanri at Hewlett-Packard | Witcher, B. & Butterworth, R. | 2000 | Artigo Acadêmico | Estudo de caso sobre a aplicação do Hoshin Kanri na Hewlett-Packard, complementando a análise de adoção ocidental. | Não disponível no snippet. |
| 7 | Policy Deployment: The Tqm Approach to Long-Range Planning | Sheridan, J. | Desconhecido | Livro Especializado | Guia sobre como usar o *Policy Deployment* para desenvolver sistemas baseados em medição que incentivam a melhoria contínua da qualidade (TQM). | Foco em sistemas de medição e TQM. |
| 8 | Managing on Purpose: Using hoshin kanri to develop strategy... | (Autor não especificado) | Desconhecido | Livro Especializado | Apresenta o Hoshin Kanri como um sistema comprovado para alinhar estratégia com execução e obter resultados sustentáveis. | Foco em alinhamento e resultados sustentáveis. |
| 9 | Hoshin Kanri: Policy Deployment Method | Lean Production | Desconhecido | Metodologia/Framework | Visão geral da metodologia, focando no desdobramento de metas estratégicas para todos os níveis da empresa. | "Hoshin Kanri (also called Policy Deployment) is a method for ensuring that a company's strategic goals drive progress and action at every level..." [7] |
| 10 | Our ultimate guide to learning Hoshin Kanri | i-nexus | Desconhecido | Metodologia/Framework | Guia prático que define Hoshin Kanri como um processo de planejamento estratégico que traduz metas em ações. | Foco na tradução de metas em ações. |
| 11 | Using the Hoshin Kanri Method for Strategic Planning [2025] | Asana | 2025 | Metodologia/Framework | Ferramenta de planejamento estratégico que conecta objetivos de toda a empresa a projetos específicos de indivíduos. | Foco na conexão entre objetivos corporativos e projetos individuais. |
| 12 | Danaher, Ingersoll Rand, and Xerox: Hoshin Kanri case studies | i-nexus | 2022 | Caso de Estudo | Análise de como grandes organizações adaptaram os princípios do Hoshin Planning. | "Read our three case studies on how the principles of Hoshin Planning have been adapted by Danaher, Ingersoll Rand, and Xerox..." [8] |
| 13 | Case Studies: Successful Implementation of Hoshin Kanri... | iSixSigma | 2025 | Caso de Estudo | Exemplos de sucesso na implementação do Hoshin Kanri em organizações globais, citando Toyota e Xerox. | "Read how companies like Toyota and Xerox use it for long-term goals." [9] |
| 14 | 25 Case Studies Exploring Hoshin Kanri | Bridges, M. | Desconhecido | Caso de Estudo | Compilação de 25 estudos de caso sobre a implementação da metodologia. | Foco na diversidade de aplicações. |
| 15 | Strategy Deployment (Hoshin Kanri) Matrix to Achieve Vision | TBM Consulting | Desconhecido | Caso de Estudo | Estudo de caso da Regenersis, que usou o Hoshin Kanri como base para uma transformação *Lean* completa. | Aumento de 14% na produtividade e transformação *Lean*. |
| 16 | Policy Deployment | Bertagnolli, F. | 2022 | Livro/Capítulo | Capítulo que insere o *Policy Deployment* no contexto do *Lean Management*. | Inserção do HK no contexto do *Lean*. |
| 17 | Strategic Planning in Japan | Lauenstein, M.C. | 1985 | Artigo Acadêmico | Análise histórica e cultural de como as empresas japonesas lidavam com o planejamento estratégico, fornecendo o contexto para o surgimento do Hoshin Kanri. | "How do Japanese firms handle strategic planning now? How well do their methods work? Are there things U.S. managers can learn from the way Japanese companies do..." [10] |
| 18 | Hoshin Kanri Process: A Review and Bibliometric Analysis... | Pavlíčková, M. | 2022 | Artigo Acadêmico | Revisão bibliométrica do processo Hoshin Kanri, analisando sua implementação em diferentes organizações. | "The review assesses the Hoshin Kanri process from the point of view of theory and practice implementations in different organizations." [11] |

## Síntese dos Conceitos-Chave

A pesquisa revela que o Hoshin Kanri é a metodologia central no planejamento estratégico japonês que incorpora o princípio de "pensar no resultado antes". Os conceitos-chave que emergem da análise das fontes são:

*   **Alinhamento Estratégico (*Alignment*):** O Hoshin Kanri é fundamentalmente um sistema para alinhar a estratégia de longo prazo (*Breakthrough Objectives*) com as operações diárias (*Daily Management*), garantindo que todos na organização trabalhem em direção aos mesmos objetivos [7] [11].
*   **Catchball (*Comunicação Bidirecional*):** Este processo de negociação e consenso é o que distingue o Hoshin Kanri de modelos tradicionais de planejamento *top-down* (de cima para baixo). Ele garante o *buy-in* e a viabilidade dos planos, pois as metas são ajustadas em um diálogo entre os níveis hierárquicos [5].
*   **Ciclo PDCA (*Plan-Do-Check-Act*):** A metodologia é intrinsecamente ligada ao ciclo de melhoria contínua. O Hoshin Kanri aplica o PDCA ao nível estratégico, onde o "Check" (revisão) e o "Act" (ajuste) são cruciais para a aprendizagem organizacional e a correção de rumo [4].
*   **Matriz X (*Hoshin Kanri X-Matrix*):** Uma ferramenta visual central que mapeia objetivos de longo prazo, objetivos anuais, metas de melhoria, e as pessoas responsáveis, garantindo a rastreabilidade e a interconexão de todas as iniciativas [9].
*   **Gestão da Qualidade Total (TQM) e Lean:** O Hoshin Kanri é frequentemente descrito como uma forma de gestão estratégica baseada em TQM [3] e é um pilar essencial do *Lean Management*, promovendo a eliminação de desperdício no planejamento e na execução [16].

## Cobertura Geográfica

As fontes identificadas demonstram uma origem e uma aplicação predominantemente em três regiões principais:

1.  **Japão:** Origem e desenvolvimento inicial da metodologia (Toyota, Yokogawa HP).
2.  **EUA:** Adoção e adaptação por grandes corporações como Xerox, Danaher, Ingersoll Rand e Hewlett-Packard [3] [6] [8] [9].
3.  **Europa (Reino Unido e Europa Continental):** Estudos acadêmicos e casos de aplicação, como o estudo da Xerox (Reino Unido) e a revisão bibliométrica de Pavlíčková (2022) [3] [11].

A cobertura é, portanto, **Japão, EUA, Europa (Reino Unido, Europa Continental)**.

## Referências

[1] Jolayemi, J.K. (2008). *Hoshin kanri and hoshin process: A review and literature survey*. Total Quality Management, 19(3), pp.295-320.
[2] Hoshin Kanri. *Wikipedia*. URL: https://en.wikipedia.org/wiki/Hoshin_Kanri
[3] Witcher, B., & Butterworth, R. (1999). *Hoshin Kanri: how Xerox manages*. Long Range Planning, 32(3), 323-332.
[4] Lee, R.G., & Dale, B.G. (1998). *Policy deployment: an examination of the theory*. International Journal of Quality & Reliability Management, 15(3), 251-265.
[5] Tennant, C., & Roberts, P. (2001). *Hoshin Kanri: implementing the catchball process*. Long Range Planning, 34(3), 287-308.
[6] Tennant, C., & Roberts, P. (2001). *Hoshin Kanri: a tool for strategic policy deployment*. Knowledge and Process Management, 8(4), 253-264.
[7] Hoshin Kanri: Policy Deployment Method. *Lean Production*. URL: https://www.leanproduction.com/hoshin-kanri/
[8] Danaher, Ingersoll Rand, and Xerox: Hoshin Kanri case studies. *i-nexus blog*. URL: https://blog.i-nexus.com/policy-deployment-in-practice-danaher-ingersoll-rand-xerox
[9] Case Studies: Successful Implementation of Hoshin Kanri in Global Organizations. *iSixSigma*. URL: https://www.isixsigma.com/hoshin-kanri/case-studies-successful-implementation-of-hoshin-kanri-in-global-organizations/
[10] Lauenstein, M.C. (1985). *Strategic Planning in Japan*. Journal of Business Strategy, 6(2), 78-85.
[11] Pavlíčková, M. (2022). *Hoshin Kanri Process: A Review and Bibliometric Analysis*. Applied Sciences, 12(18), 9184.
[12] Witcher, B., & Butterworth, R. (2000). *Hoshin Kanri at Hewlett-Packard*. Management Decision, 38(4), 253-264.
[13] Policy Deployment: The Tqm Approach to Long-Range Planning. *Amazon*. URL: https://www.amazon.com/Policy-Deployment-Approach-Long-Range-Planning/dp/0873891295
[14] Managing on Purpose. *Lean.org*. URL: https://www.lean.org/store/book/managing-on-purpose/
[15] Using the Hoshin Kanri Method for Strategic Planning [2025]. *Asana*. URL: https://asana.com/resources/hoshin-kanri
[16] Bertagnolli, F. (2022). *Policy Deployment*. In: Lean Management. Springer, Cham.
[17] Strategy Deployment (Hoshin Kanri) Matrix to Achieve Vision. *TBM Consulting*. URL: https://tbmcg.com/case-study/regenersis-full-transformation-through-strategy-deployment-process/
[18] Bridges, M. *25 Case Studies Exploring Hoshin Kanri*. Medium. URL: https://mark-bridges.medium.com/25-case-studies-exploring-hoshin-kanri-f5be088df246

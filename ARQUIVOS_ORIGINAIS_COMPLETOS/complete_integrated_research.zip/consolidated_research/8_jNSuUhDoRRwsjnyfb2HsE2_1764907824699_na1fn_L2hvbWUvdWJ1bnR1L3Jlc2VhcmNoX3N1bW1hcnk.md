# Análise Profunda: Teoria da Definição de Metas (Locke & Latham) e a Metodologia SMART

## Introdução

A pesquisa aprofundada sobre o conceito de "pensar no resultado antes" se concentrou em dois pilares fundamentais da gestão e psicologia organizacional: a **Teoria da Definição de Metas (Goal-Setting Theory - GST)**, desenvolvida por Edwin A. Locke e Gary P. Latham, e a metodologia **SMART** (Specific, Measurable, Achievable/Assignable, Relevant/Realistic, Time-bound). Esta análise sintetiza as contribuições seminais, a evolução, as aplicações práticas e as críticas a esses frameworks, fundamentando-se em 20 fontes diversificadas, incluindo artigos acadêmicos, livros, metodologias empresariais e estudos de caso regionais.

## Teoria da Definição de Metas (GST) de Locke & Latham

A GST, formalizada no livro seminal de 1990, "A Theory of Goal Setting & Task Performance" (Fonte 2), postula que o comportamento humano consciente é proposital e regulado por valores e metas. O princípio central é que metas **específicas e difíceis** (mas alcançáveis) levam a um desempenho significativamente superior em comparação com metas vagas ou fáceis (Fonte 1).

Os cinco princípios-chave que moderam a relação entre metas e desempenho são:

1.  **Clareza (Clarity):** Metas devem ser específicas e mensuráveis.
2.  **Desafio (Challenge):** Metas difíceis geram maior esforço, desde que sejam percebidas como atingíveis.
3.  **Compromisso (Commitment):** O indivíduo deve estar comprometido com a meta, o que é facilitado pela participação na definição e pela percepção de importância.
4.  **Feedback:** O feedback de progresso é essencial para manter a direção e o esforço.
5.  **Complexidade da Tarefa (Task Complexity):** Para tarefas complexas, o impacto da meta é mediado pela autoeficácia e pelo desenvolvimento de estratégias de planejamento (Fonte 4).

## Metodologia SMART

O acrônimo SMART foi introduzido por George T. Doran em 1981 no artigo "There's a S.M.A.R.T. Way to Write Management's Goals and Objectives" (Fonte 6). Embora Doran tenha originalmente usado "Assignable" (Atribuível) e "Time-related" (Relacionado ao Tempo), a variação mais comum hoje é:

*   **S**pecific (Específica)
*   **M**easurable (Mensurável)
*   **A**chievable (Alcançável)
*   **R**elevant (Relevante)
*   **T**ime-bound (Temporal)

O framework SMART é visto como uma ferramenta prática que operacionaliza os princípios da GST, especialmente a necessidade de metas específicas e mensuráveis (Fonte 7).

## Críticas e Evoluções

Apesar de sua ampla aceitação, a GST e o SMART não estão isentos de críticas. Estudos apontam para o "lado sombrio" do estabelecimento de metas, onde a implementação rigorosa pode levar à restrição da criatividade, ao foco excessivo em resultados de curto prazo e, em casos extremos, a comportamentos antiéticos para atingir as metas (Fonte 10).

Em resposta a essas limitações, surgiram frameworks alternativos ou complementares, como:

*   **OKR (Objectives and Key Results):** Focado em metas ambiciosas (Objetivos) e resultados-chave mensuráveis (Key Results), frequentemente utilizado para alinhar equipes e promover o foco (Fonte 12).
*   **H.A.R.D. Goals:** (Heartfelt, Animated, Required, Difficult) que enfatiza a conexão emocional e a dificuldade intrínseca da meta para aumentar o engajamento (Fonte 11).

A pesquisa também demonstrou a aplicação da GST e do SMART em diversos contextos, incluindo a gestão de equipes (Fonte 17), o setor público e a necessidade de adaptação cultural para a eficácia do SMART em diferentes regiões (Fonte 18, 19).

## Fontes Documentadas (Total: 20)

| ID | Título | Autor(es) | Ano | Tipo | Contribuição Geográfica |
| :---: | :--- | :--- | :---: | :--- | :--- |
| 1 | Building a Practically Useful Theory of Goal Setting and Task Motivation: A 35-Year Odyssey | Edwin A. Locke | 2002 | Artigo Acadêmico | EUA |
| 2 | A Theory of Goal Setting & Task Performance | Edwin A. Locke, Gary P. Latham | 1990 | Livro Fundamental | EUA |
| 3 | Breaking the Rules: A Historical Overview of Goal-Setting Theory | Edwin A. Locke | 2015 | Artigo Acadêmico | EUA |
| 4 | New Directions in Goal-Setting Theory | Edwin A. Locke, Gary P. Latham | 2006 | Artigo Acadêmico | EUA |
| 5 | A teoria de definição de metas da motivação | Atlassian | S/D | Metodologia Empresarial | Global |
| 6 | There's a S.M.A.R.T. Way to Write Management's Goals and Objectives | George T. Doran | 1981 | Artigo de Revista | EUA |
| 7 | Mastering SMART Goals: A Guide to SMART Goal Setting | PeopleGoal | 2024 | Guia Metodológico | Global |
| 8 | SMART Goal - Definition, Guide, and Importance of... | Corporate Finance Institute (CFI) | S/D | Guia Financeiro/Empresarial | Global |
| 9 | O que é meta SMART e como definir em sua empresa | Sebrae | 2023 | Aplicação Prática | Brasil |
| 10 | As Limitações dos Sistemas de Metas | Marcelo T. R. Neto, João H. S. do Couto | 2011 | Artigo Acadêmico (Crítica) | Brasil |
| 11 | Hard Goals: The Secret to Getting from Where You Are to Where You Want to Be | Mark Murphy | 2010 | Livro (Metodologia Alternativa) | EUA |
| 12 | Estabelecendo Metas de Sucesso: 5 Estratégias Alternativas ao Método SMART | LP Produtividade | S/D | Artigo de Comparação | Global |
| 13 | Motivação e Satisfação no Trabalho | Liliana C. S. C. Rainha | 2016 | Dissertação de Mestrado | Portugal (Europa) |
| 14 | Um estudo crítico da aplicação da metodologia de metas SMART na condução de um PDCA... | S/D | S/D | Estudo de Caso/Crítica | Espanha/América Latina |
| 15 | Nudging flow through 'SMART'goal setting to decrease stress... | S/D | S/D | Artigo Acadêmico (Integração) | Global |
| 16 | Case Studies: Successful Implementation of SMART Goals in Performance Management | Vorecol | 2024 | Estudo de Caso Empresarial | Global |
| 17 | Goal Setting in Teams: Goal Clarity and Team Performance in the Public Sector | M. van der Hoek, et al. | 2016 | Artigo Acadêmico (Foco em Equipes) | Global |
| 18 | Exploring Cultural Differences in the Perception and Implementation of SMART Goals | Vorecol | 2024 | Análise Cultural/Geográfica | Global |
| 19 | Theoretical frameworks for project goal‐setting: A qualitative case study of an organisational practice in Nigeria | S/D | S/D | Estudo de Caso | Nigéria (África) |
| 20 | Planejamento de metas para redução de falhas no processo de distribuição de uma empresa transportadora | S/D | S/D | Estudo de Caso | Brasil |

## Citações Relevantes Selecionadas

*   **Sobre a GST:** "Numerous studies have shown that setting a specific difficult goal leads to significant increases in employee productivity." (Locke, 2002, Fonte 1)
*   **Sobre a GST:** "Goal setting theory (Locke & Latham, 1984, 199Oa) is based on the simplest of introspective observations, namely, that conscious human behavior is purposeful." (Locke & Latham, 1990, Fonte 2)
*   **Sobre o SMART:** "A SMART goal is used to help guide goal setting. SMART is an acronym that stands for Specific, Measurable, Achievable, Realistic, and Timely." (CFI, Fonte 8)
*   **Sobre Críticas:** "Contrapondo-se à ideia de que um sistema de metas sempre levará as organizações a um desempenho superior, alguns autores expuseram críticas distintas à teoria das metas..." (Neto & Couto, 2011, Fonte 10)
*   **Sobre Aplicação:** "According to goal setting theory, an employee performs better if the goals that guide work are clear, specific, and challenging rather than vague, ambiguous..." (van der Hoek, et al., 2016, Fonte 17)

## Conclusão

A Teoria da Definição de Metas e a metodologia SMART representam o cerne do conceito de "pensar no resultado antes", fornecendo um arcabouço robusto e empiricamente validado para a motivação e o aumento de desempenho. A pesquisa demonstrou a evolução desses conceitos, sua interconexão e a necessidade de uma aplicação crítica e culturalmente adaptada, considerando as limitações e as alternativas que surgiram ao longo das décadas. O conjunto de fontes coletadas oferece uma visão abrangente, desde os fundamentos teóricos nos EUA até as aplicações práticas e críticas em contextos como Brasil, Portugal, Espanha e Nigéria.

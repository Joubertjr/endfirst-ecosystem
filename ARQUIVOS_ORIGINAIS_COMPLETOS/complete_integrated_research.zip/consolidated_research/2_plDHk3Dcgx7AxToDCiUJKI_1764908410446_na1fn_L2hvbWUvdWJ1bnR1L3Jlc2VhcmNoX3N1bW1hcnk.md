# Resumo Detalhado da Pesquisa: Jobs to Be Done (JTBD) - Clayton Christensen

## Introdução

O framework **Jobs to Be Done (JTBD)**, popularizado por Clayton M. Christensen, representa uma mudança de paradigma na inovação e no marketing. Em vez de focar em atributos do cliente (demografia, psicografia) ou do produto (funcionalidades), o JTBD postula que os clientes "contratam" produtos e serviços para realizar "trabalhos" (jobs) em suas vidas [1] [2]. A compreensão desses trabalhos, e das circunstâncias que os cercam, é fundamental para criar soluções que os clientes realmente desejam "contratar".

## Fundamentos e Evolução do Framework

A teoria JTBD de Christensen foi formalizada no artigo seminal de 2007, *Finding the Right Job for Your Product* [3], e consolidada no livro *Competing Against Luck* (2016) [2]. O conceito central é que a inovação deve ser orientada pela **circunstância** e não pela correlação.

O caso clássico do milkshake ilustra esse ponto: a análise demográfica falhou em aumentar as vendas, mas a observação revelou que o milkshake era "contratado" por passageiros matinais para realizar o "trabalho" de tornar o trajeto tedioso mais interessante e evitar a fome até o almoço [14].

O JTBD evoluiu em duas principais escolas de pensamento, que, embora compartilhem a premissa central, diferem na aplicação:

| Escola de Pensamento | Foco Principal | Metodologia | Especialistas Chave |
| :--- | :--- | :--- | :--- |
| **Christensen/Moesta (Escola da Circunstância)** | Entender a **motivação** e a **circunstância** que levam à "contratação" (o "porquê" e o "quando"). | Qualitativa, focada nas **Forças do Progresso** (Push, Pull, Anxiety, Habit) e na **Switch Interview** [8] [12] [13]. | Clayton Christensen, Bob Moesta, Taddy Hall. |
| **Ulwick/ODI (Escola do Resultado)** | Entender os **resultados desejados** (Desired Outcomes) que o cliente busca ao realizar o trabalho. | Quantitativa, focada na **Outcome-Driven Innovation (ODI)**, que transforma o JTBD em um processo de inovação mensurável [4]. | Anthony Ulwick. |

## Principais Conceitos e Insights

Os principais conceitos descobertos na pesquisa são:

*   **Job to Be Done (Trabalho a Ser Feito):** É o progresso fundamental que o cliente está tentando fazer em uma determinada circunstância. É estável e duradouro, ao contrário dos produtos que vêm e vão. Um trabalho é sempre funcional, social e emocional [2].
*   **Contratação (Hiring):** A decisão do cliente de usar um produto ou serviço para realizar o trabalho.
*   **Forças do Progresso:** O modelo de Bob Moesta que explica a dinâmica da decisão de compra. A compra só ocorre quando as forças de **Push** (frustração com o status quo) e **Pull** (atração da nova solução) superam as forças de **Anxiety** (medos sobre a nova solução) e **Habit/Inertia** (resistência à mudança) [12].
*   **Job Stories:** Uma alternativa às User Stories, utilizada na Engenharia de Requisitos, que foca na circunstância, motivação e resultado esperado: "Quando [Situação], eu quero [Motivação], para que eu possa [Resultado Esperado]" [7].
*   **Resultados Desejados (Desired Outcomes):** No modelo ODI, são métricas que definem o sucesso do trabalho a ser feito, permitindo que as empresas inovem de forma previsível, focando em resultados subatendidos [4].

## Aplicações Setoriais e Geográficas

O JTBD transcende o desenvolvimento de produtos de consumo e tem sido aplicado em diversas áreas:

*   **UX/Design:** O JTBD é considerado superior às Personas tradicionais, pois foca na motivação e na circunstância, garantindo que o design resolva o problema real do cliente [6].
*   **Engenharia de Requisitos:** O uso de Job Stories alinha o desenvolvimento de software diretamente com o progresso que o usuário deseja fazer [7].
*   **Saúde:** O framework é usado para inovar na gestão de doenças crônicas, focando no "trabalho" do paciente de "gerenciar minha condição para ter uma vida normal" [15].
*   **Educação:** Instituições de ensino superior aplicam o JTBD para entender que o "trabalho" do estudante é se preparar para uma carreira próspera, redesenhando a oferta educacional para atender a esse progresso [16].
*   **Brasil/América Latina:** Há aplicações acadêmicas do JTBD no contexto brasileiro, como em estudos B2B e na integração do framework com a Lógica Dominante do Serviço (SDL), demonstrando a relevância do conceito em mercados emergentes [10] [11].

## Fontes Documentadas (Total: 16)

A pesquisa resultou na documentação de 16 fontes, abrangendo artigos acadêmicos, livros fundamentais, metodologias e aplicações práticas.

| ID | Título | Autor(es) | Ano | Tipo | Região |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Know Your Customers’ “Jobs to Be Done” | Christensen, Hall, Dillon, Duncan | 2016 | Artigo (HBR) | EUA |
| 2 | Competing Against Luck | Christensen, Hall, Dillon, Duncan | 2016 | Livro Fundamental | EUA |
| 3 | Finding the Right Job for Your Product | Christensen, Cook, Hall | 2007 | Artigo (MIT Sloan) | EUA |
| 4 | Jobs to be Done: Theory to Practice (ODI) | Anthony W. Ulwick | 2016 | Livro/Metodologia | EUA |
| 5 | Intercom on Jobs-to-be-Done | Intercom (Des Traynor, et al.) | ~2017 | E-book/Caso de Estudo | EUA |
| 6 | Personas vs. Jobs-to-Be-Done | Nielsen Norman Group (NN/g) | 2017 | Artigo (UX/Design) | EUA |
| 7 | Jobs-to-be-Done Oriented Requirements Engineering | Lucassen, van de Keuken, et al. | 2018 | Artigo Acadêmico | Europa |
| 8 | Demand-Side Sales 101 | Bob Moesta | 2020 | Livro/Especialista | EUA |
| 9 | Know the Two — Very — Different Interpretations of Jobs to be Done | Alan Klement | 2018 | Artigo (Análise Comparativa) | EUA |
| 10 | Capacidades de negócio, inovação e desempenho em um contexto B2B... | (UFMG) | (Recente) | Artigo Acadêmico | Brasil |
| 11 | A utilização da técnica Job to Be Done para identificação de oportunidades... | Á. H. P. Ribeiro et al. | 2019 | Artigo Acadêmico | Brasil |
| 12 | The Forces of Progress | Bob Moesta e Chris Spiek | ~2012 | Modelo Conceitual | EUA |
| 13 | Switch Interview | Bob Moesta e The Rewired Group | (Desenvolvimento) | Metodologia de Pesquisa | EUA |
| 14 | Clay Christensen's Milkshake Marketing | Clayton M. Christensen | 2011 | Caso de Estudo Clássico | EUA |
| 15 | Health for Hire with Jobs to Be Done | Innosight | (Recente) | Aplicação Setorial (Saúde) | EUA |
| 16 | Applying the Jobs-to-Be-Done Model in Higher Education | Huron Consulting Group | (Recente) | Aplicação Setorial (Educação) | EUA |

## Referências

[1] Christensen Institute. *Jobs to Be Done Theory*. URL: https://www.christenseninstitute.org/theory/jobs-to-be-done/
[2] Christensen, C. M., Hall, T., Dillon, K., & Duncan, D. S. (2016). *Competing Against Luck: The Story of Innovation and Customer Choice*. ISBN-13: 978-0062435613.
[3] Christensen, C. M., Cook, S., & Hall, T. (2007). *Finding the Right Job for Your Product*. MIT Sloan Management Review, 48(3). URL: https://sloanreview.mit.edu/article/finding-the-right-job-for-your-product/
[4] Ulwick, A. W. (2016). *Jobs to be Done: Theory to Practice*. URL: https://strategyn.com/jobs-to-be-done/
[5] Intercom. *Intercom on Jobs-to-be-Done*. URL: https://www.intercom.com/resources/books/intercom-jobs-to-be-done
[6] Nielsen Norman Group. *Personas vs. Jobs-to-Be-Done*. (2017). URL: https://www.nngroup.com/articles/personas-jobs-be-done/
[7] Lucassen, G., van de Keuken, M., Dalpiaz, F., & Brinkkemper, S. (2018). *Jobs-to-be-Done Oriented Requirements Engineering: A Method for Defining Job Stories*. In International Working Conference on Requirements Engineering: Foundation for Software Quality. URL: https://link.springer.com/chapter/10.1007/978-3-319-77243-1_14
[8] Moesta, B. (2020). *Demand-Side Sales 101: Stop Selling and Start Helping People Make Progress*. ISBN-13: 978-1732047818.
[9] Klement, A. (2018). *Know the Two — Very — Different Interpretations of Jobs to be Done*. URL: https://jtbd.info/know-the-two-very-different-interpretations-of-jobs-to-be-done-5a18b748bd89
[10] UFMG. *Capacidades de negócio, inovação e desempenho em um contexto B2B: uma aplicação da metodologia JOBS TO BE DONE*. URL: https://repositorio.ufmg.br/handle/1843/BUOS-B3EL2A
[11] Ribeiro, Á. H. P. et al. (2019). *A utilização da técnica Job to Be Done para identificação de oportunidades de cocriação de valor no contexto da Lógica Dominante do Serviço*. URL: https://www.scielo.br/j/bbr/a/63LdMnWkhKFFwXfhWgKm6VM/?lang=pt
[12] Moesta, B., & Spiek, C. *The Forces of Progress*. URL: https://jtbd.info/the-forces-of-progress-4408bf995153
[13] The Rewired Group. *Switch Interview*. URL: https://therewiredgroup.com/case-studies/the-mattress-interview/
[14] Christensen, C. M. (2011). *Clay Christensen's Milkshake Marketing*. HBS Working Knowledge. URL: https://www.library.hbs.edu/working-knowledge/clay-christensens-milkshake-marketing
[15] Innosight. *Health for Hire with Jobs to Be Done*. URL: https://www.innosight.com/insight/health-for-hire-with-jobs-to-be-done/
[16] Huron Consulting Group. *Applying the Jobs-to-Be-Done Model in Higher Education*. URL: https://www.huronconsultinggroup.com/insights/jobs-to-be-done-model-higher-education

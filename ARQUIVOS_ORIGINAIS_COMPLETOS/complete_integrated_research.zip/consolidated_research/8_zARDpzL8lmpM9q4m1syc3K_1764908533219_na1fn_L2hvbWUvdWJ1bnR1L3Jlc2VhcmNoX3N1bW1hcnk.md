# Resumo Detalhado da Pesquisa: Value Proposition Design e Business Model Canvas (Osterwalder)

## Introdução

A gestão estratégica e o empreendedorismo contemporâneos foram profundamente transformados pela introdução de ferramentas visuais e colaborativas para a modelagem de negócios. Dentre estas, destacam-se o **Business Model Canvas (BMC)** e o **Value Proposition Canvas (VPC)**, desenvolvidos por Alexander Osterwalder e Yves Pigneur [1, 2]. Esta pesquisa aprofundada buscou identificar e analisar 20 fontes relevantes, abrangendo publicações primárias, artigos acadêmicos, críticas e estudos de caso setoriais e geográficos, a fim de fornecer uma visão abrangente sobre a aplicação e o impacto desses *frameworks*.

## 1. Conceitos Fundamentais e Publicações Primárias

O **Business Model Canvas (BMC)**, introduzido no livro *Business Model Generation* (2010), é um modelo de gestão estratégica que permite descrever, desafiar e projetar modelos de negócios através de nove blocos interconectados [1, 19]. A essência do BMC reside na sua capacidade de visualizar a lógica pela qual uma organização **cria, entrega e captura valor** [1].

| Bloco do BMC | Descrição |
| :--- | :--- |
| **1. Segmentos de Clientes** | Os diferentes grupos de pessoas ou organizações que a empresa busca alcançar e servir. |
| **2. Propostas de Valor** | O pacote de produtos e serviços que cria valor para um Segmento de Clientes específico. |
| **3. Canais** | Como a empresa se comunica e alcança seus Segmentos de Clientes para entregar a Proposta de Valor. |
| **4. Relacionamento com Clientes** | Os tipos de relacionamento que a empresa estabelece com Segmentos de Clientes específicos. |
| **5. Fontes de Receita** | O dinheiro que a empresa gera a partir de cada Segmento de Clientes. |
| **6. Recursos-Chave** | Os ativos mais importantes necessários para fazer o modelo de negócios funcionar. |
| **7. Atividades-Chave** | As ações mais importantes que a empresa deve realizar para operar com sucesso. |
| **8. Parcerias-Chave** | A rede de fornecedores e parceiros que fazem o modelo de negócios funcionar. |
| **9. Estrutura de Custos** | Todos os custos incorridos para operar o modelo de negócios. |

O **Value Proposition Canvas (VPC)**, detalhado em *Value Proposition Design* (2014), funciona como um "zoom" no bloco de Proposta de Valor do BMC [2, 18]. O VPC é dividido em dois lados: o **Perfil do Cliente** (Tarefas, Dores e Ganhos) e o **Mapa de Valor** (Produtos e Serviços, Analgésicos e Criadores de Ganhos). O objetivo central do VPC é alcançar o **Product-Market Fit**, garantindo que a oferta da empresa se alinhe precisamente com as necessidades e desejos do cliente [2].

## 2. Análise Crítica e Frameworks Complementares

Apesar de sua ampla adoção por *startups* e grandes corporações (como Amazon, Google e Uber) [8, 13], o BMC não está isento de críticas no meio acadêmico. Alguns estudos apontam que o *framework* pode carecer de consistência devido a sobreposições e diferentes níveis de abstração entre os nove blocos, além de questionar a clareza da interconexão dinâmica entre eles [3].

Em resposta a essas limitações, especialmente no contexto de *startups* e da metodologia *Lean Startup*, surgiram variações. O **Lean Canvas**, proposto por Ash Maurya, é um exemplo notável. Ele substitui blocos como Parcerias-Chave e Atividades-Chave por elementos mais focados na incerteza inicial, como **Problema**, **Solução**, **Métricas-Chave** e **Vantagem Injusta** [6]. Enquanto o BMC é mais adequado para empresas estabelecidas que buscam inovação em seu modelo existente, o Lean Canvas é preferido por empreendedores que precisam de agilidade e foco na validação de hipóteses [6].

## 3. Aplicações Setoriais e Cobertura Geográfica

A pesquisa revelou a versatilidade do BMC e do VPC em diversos contextos setoriais e geográficos, demonstrando sua relevância global:

*   **América do Norte (EUA):** O BMC e o VPC são amplamente utilizados para a modelagem de gigantes da tecnologia e plataformas digitais (e.g., Airbnb, Skype) [8]. A popularização do conceito de modelo de negócios em detrimento do foco exclusivo no produto foi impulsionada por publicações influentes como a *Harvard Business Review* [13].
*   **Europa (Suíça, Bélgica):** A origem dos *frameworks* (Strategyzer, sediada na Suíça) e a presença de pesquisas acadêmicas críticas, como a investigação aprofundada de Johan Verrue [3], indicam um engajamento contínuo e reflexivo com as ferramentas. A *European Business Review* também fornece guias práticos para a aplicação do VPC [12].
*   **América do Sul (Brasil):** Estudos de caso demonstram a aplicação do BMC em setores críticos e de impacto social, como a identificação de problemas na avaliação da qualidade da água potável [10] e a análise de empresas de bioeconomia na Amazônia, integrando a sustentabilidade ao modelo de negócios [9].
*   **Ásia (Indonésia, Hong Kong):** O BMC é aplicado em estudos empíricos sobre o desenvolvimento sustentável de Micro e Pequenas Empresas (MPMEs), como as de Batik na Indonésia [11]. Embora a menção a "Bulk Moulding Compounds (BMC)" em Hong Kong [16] seja um artefato de pesquisa, ela ilustra a necessidade de precisão terminológica e, ao mesmo tempo, confirma a presença de estudos de mercado na região asiática.

## 4. Fontes Documentadas (Total: 20)

A tabela a seguir lista as 20 fontes identificadas, com seus respectivos detalhes e contribuições:

| ID | Título e Autor | Ano | Referência/URL | Contribuição Principal |
| :--- | :--- | :--- | :--- | :--- |
| **1** | Business Model Generation: A Handbook for Visionaries, Game Changers, and Challengers (Osterwalder & Pigneur) | 2010 | ISBN 978-0470876411 | Introdução do Business Model Canvas (BMC). |
| **2** | Value Proposition Design: How to Create Products and Services Customers Want (Osterwalder et al.) | 2014 | ISBN 978-1118968055 | Introdução do Value Proposition Canvas (VPC) e Product-Market Fit. |
| **3** | A critical investigation of the Osterwalder Business Model Canvas: an in-depth case study (Johan Verrue) | 2014 | [ResearchGate] | Crítica acadêmica sobre a consistência e arquitetura do BMC. |
| **4** | Status of business model and electronic market research: An interview with Alexander Osterwalder (Alt & Zimmermann) | 2014 | [Springer] | Entrevista sobre a evolução do conceito de modelo de negócios e BMC. |
| **5** | Comparing how entrepreneurs and managers represent the elements of the business model canvas | N/D | [ScienceDirect] | Estudo empírico sobre a percepção do BMC por diferentes perfis. |
| **6** | Lean Canvas vs. Business Model Canvas: A Quick Guide (Miro Team, baseado em Ash Maurya) | 2025 | [Miro] | Comparação detalhada entre BMC e Lean Canvas. |
| **7** | The creative business model canvas | N/D | [Emerald] | Proposta de variação do BMC para a indústria criativa (CBMC). |
| **8** | 6 Successful Business Model Canvas Examples Across Industries (BSS Commerce) | 2024 | [BSS Commerce] | Exemplos práticos de BMC (Amazon, Google, Uber, etc.). |
| **9** | A Case Study of an Amazon Rainforest Enterprise | 2023 | [IIETA] | Aplicação do BMC em bioeconomia e sustentabilidade no Brasil. |
| **10** | The Business Model as a technique for problem identification... (F. H. de Souza et al.) | 2023 | [IWA Publishing] | Uso do BMC para identificar problemas no setor de água no Brasil. |
| **11** | Sustainable Development of Business with Canvas Business Model Approach... Batik Blora, Indonesia. | N/D | [EBSCOhost] | Estudo empírico de BMC em MPMEs de Batik na Indonésia. |
| **12** | Value Proposition Canvas: How to Attract More Customers (European Business Review) | 2025 | [European Business Review] | Guia prático de aplicação do VPC na Europa. |
| **13** | A Better Way to Think About Your Business Model (Alexander Osterwalder) | 2013 | [HBR] | Artigo popularizando o BMC na Harvard Business Review. |
| **14** | The Invincible Company: How to Constantly Reinvent Your Organization... (Osterwalder et al.) | 2020 | ISBN 978-1119524434 | Sequência do BMC, foca em gestão de portfólio e reinvenção. |
| **15** | Business Model Canvas and Entrepreneurs: Dilemmas in Managerial Practice | 2023 | [ResearchGate] | Investigação sobre o uso prático do BMC por empreendedores. |
| **16** | Bulk Moulding Compounds (BMC) Market by Applications... | N/D | [LinkedIn] | Menção ao mercado de BMC em Hong Kong (contexto asiático). |
| **17** | The Business Model Canvas: A tool for creatives (Global Leaders Institute) | 2023 | [Global Leaders Institute] | Abordagem do BMC para o setor criativo. |
| **18** | Value Proposition Canvas – Download the Official Template (Strategyzer) | 2025 | [Strategyzer - VPC] | Fonte primária do VPC, detalhando os componentes. |
| **19** | Business Model Canvas – Download the Official Template (Strategyzer) | 2025 | [Strategyzer - BMC] | Fonte primária do BMC, definindo-o como ferramenta estratégica. |
| **20** | 7 of the Best Value Proposition Examples We've Ever Seen (WordStream) | 2024 | [WordStream] | Exemplos práticos de Propostas de Valor (Uber, Apple, Slack). |

## Referências

[1]: https://www.strategyzer.com/library/business-model-generation "Business Model Generation: A Handbook for Visionaries, Game Changers, and Challengers"
[2]: https://www.strategyzer.com/library/value-proposition-design-2 "Value Proposition Design: How to Create Products and Services Customers Want"
[3]: https://www.researchgate.net/publication/264235616_A_critical_investigation_of_the_Osterwalder_Business_Model_Canvas_an_in-depth_case_study "A critical investigation of the Osterwalder Business Model Canvas: an in-depth case study"
[4]: https://link.springer.com/article/10.1007/s12525-014-0176-4 "Status of business model and electronic market research: An interview with Alexander Osterwalder"
[5]: https://www.sciencedirect.com/science/article/pii/S235267341730094X "Comparing how entrepreneurs and managers represent the elements of the business model canvas"
[6]: https://miro.com/strategic-planning/lean-canvas-vs-business-model-canvas/ "Lean Canvas vs. Business Model Canvas: A Quick Guide"
[7]: https://www.emerald.com/insight/content/doi/10.1108/sej-03-2019-0018/full/html "The creative business model canvas"
[8]: https://bsscommerce.com/shopify/business-model-canvas-examples/ "6 Successful Business Model Canvas Examples Across Industries"
[9]: https://www.iieta.org/journals/ijsdp/paper/10.18280/ijsdp.180909 "A Case Study of an Amazon Rainforest Enterprise"
[10]: https://iwaponline.com/wpt/article/18/8/1839/96190/The-Business-Model-as-a-technique-for-problem "The Business Model as a technique for problem identification and scoping: a case study of Brazilian drinking water quality assessment"
[11]: https://search.ebscohost.com/login.aspx?direct=true&profile=ehost&scope=site&authtype=crawler&jrnl=17437601&AN=157317382&h=9lwuk10KlX8qD56j4dV%2B3xWU3KdGZvBDGtpo9NwVlJTblqc29kkAvnNWdvDbFZDXProMq%2BBCkSpncZO%2F3qrTlw%3D%3D&crl=c "Sustainable Development of Business with Canvas Business Model Approach: Empirical Study on MSMEs Batik Blora, Indonesia."
[12]: https://www.europeanbusinessreview.com/how-to-use-the-value-proposition-canvas-to-attract-more-customers/ "Value Proposition Canvas: How to Attract More Customers"
[13]: https://hbr.org/2013/05/a-better-way-to-think-about-yo "A Better Way to Think About Your Business Model"
[14]: https://books.google.com/books?hl=en&lr=&id=vtHSDwAAQBAJ&oi=fnd&pg=PP21&dq=academic+articles+by+Alexander+Osterwalder+on+BMC&ots=JOzR7jRNel&sig=fyx4Y4EqNx3ZfFotnLNoAhUAGs0 "The Invincible Company: How to Constantly Reinvent Your Organization with Inspiration from the World's Best Business Models"
[15]: https://www.researchgate.net/publication/363413766_BUSINESS_MODEL_CANVAS_AND_ENTREPRENEURS_DILEMMAS_IN_MANAGERIAL_PRACTICE "Business Model Canvas and Entrepreneurs: Dilemmas in Managerial Practice"
[16]: https://www.linkedin.com/pulse/bulk-moulding-compounds-bmc-market-applications-dqyrf/ "Bulk Moulding Compounds (BMC) Market by Applications..."
[17]: https://www.globalleadersinstitute.org/blog-post/the-business-model-canvas/ "The Business Model Canvas: A tool for creatives"
[18]: https://www.strategyzer.com/library/the-value-proposition-canvas "Value Proposition Canvas – Download the Official Template (Strategyzer)"
[19]: https://www.strategyzer.com/library/the-business-model-canvas "Business Model Canvas – Download the Official Template (Strategyzer)"
[20]: https://www.wordstream.com/blog/ws/2016/04/27/value-proposition-examples "7 of the Best Value Proposition Examples We've Ever Seen"

# Pesquisa Aprofundada: Six Sigma e DMAIC para Melhoria de Processos

## 1. Introdução e Visão Geral

A metodologia **Six Sigma** é uma estratégia gerencial e um sistema de gestão da qualidade que visa a excelência na competitividade através da **melhoria contínua de processos**, produtos e serviços [1]. Criada na Motorola em 1986 pelo engenheiro **Bill Smith**, o Six Sigma evoluiu de uma métrica estatística para uma abordagem de solução de problemas orientada a projetos [10]. Seu objetivo central é reduzir a variabilidade dos processos a um nível de 3,4 defeitos por milhão de oportunidades (DPMO), o que corresponde a uma taxa de perfeição de 99,99966% [1].

O ciclo **DMAIC** (Define, Measure, Analyze, Improve, Control) é o roteiro fundamental do Six Sigma, sendo a metodologia estruturada e baseada em dados utilizada para **melhorar processos existentes** que estão com desempenho abaixo do esperado ou que apresentam excessiva variabilidade [4].

## 2. Conceitos Fundamentais e Estrutura do DMAIC

O DMAIC é uma abordagem de solução de problemas que garante que as melhorias sejam sustentáveis e baseadas em dados concretos. Cada fase do ciclo se baseia na anterior, garantindo que a causa-raiz do problema seja identificada e eliminada antes da implementação da solução [4].

A base filosófica do Six Sigma e, consequentemente, do DMAIC, é profundamente influenciada pelos pioneiros da qualidade. **W. Edwards Deming** e **Joseph M. Juran** forneceram os fundamentos para o uso intensivo de dados e estatísticas no controle e melhoria de processos, com o Controle Estatístico de Processo (CEP) sendo uma ferramenta central nas fases *Measure* e *Control* do DMAIC [5].

| Fase do DMAIC | Objetivo Principal | Ferramentas Chave |
| :--- | :--- | :--- |
| **Define (Definir)** | Estabelecer o escopo, metas e requisitos do cliente (VOC) para o projeto. | *Project Charter*, Voz do Cliente (VOC), Diagrama SIPOC. |
| **Measure (Medir)** | Coletar dados para estabelecer o desempenho de linha de base e quantificar o problema. | Mapa de Processo, Análise de Capacidade, Diagrama de Pareto, CEP. |
| **Analyze (Analisar)** | Identificar as causas-raiz da variação e do baixo desempenho. | Análise de Causa Raiz (5 Porquês, Diagrama de Ishikawa), FMEA, Gráficos Multivariados. |
| **Improve (Melhorar)** | Desenvolver, testar e implementar soluções para eliminar as causas-raiz. | DOE (Design of Experiments), Evento *Kaizen*, Simulação. |
| **Control (Controlar)** | Padronizar e monitorar o processo melhorado para garantir que os ganhos sejam mantidos. | Plano de Controle, CEP, *Poka-Yoke* (à prova de erros), 5S. |

## 3. Evolução e Integração Metodológica

O DMAIC não é a única metodologia do Six Sigma. Para a **criação de novos produtos ou processos**, utiliza-se o **DMADV** (Define, Measure, Analyze, Design, Verify), também conhecido como **Design for Six Sigma (DFSS)** [8]. Enquanto o DMAIC é reativo (melhoria de falhas em processos existentes), o DMADV/DFSS é proativo (prevenção de falhas em novos *designs*) [8].

A integração mais comum é com o **Lean Manufacturing**, resultando no **Lean Six Sigma (LSS)**. O LSS combina a redução de defeitos do Six Sigma com a eliminação de desperdícios do Lean, utilizando o DMAIC como estrutura de melhoria [11].

Uma tendência recente é o **DMAIC 4.0**, que integra as tecnologias da **Indústria 4.0** (como Inteligência Artificial, IoT e Big Data) ao ciclo DMAIC [9]. Essa integração visa tornar a melhoria de processos mais orientada por dados em tempo real e preditiva, com o uso de IoT e Big Data nas fases *Measure* e *Analyze*, e IA para otimização na fase *Improve* [9].

## 4. Aplicações Setoriais e Cobertura Geográfica

A pesquisa demonstrou a ampla aplicabilidade do Six Sigma DMAIC em diversos setores e regiões geográficas, transcendendo sua origem na manufatura [2] [6] [7] [13] [14] [15] [17].

| Setor de Aplicação | Exemplo de Caso de Estudo | Cobertura Geográfica | Fonte |
| :--- | :--- | :--- | :--- |
| **Manufatura** | Redução da taxa de rejeição de borrachas de vedação (3.9 para 4.45 Sigma) [2]. | Índia, Brasil [1] | [2] |
| **Serviços Financeiros** | Redução de risco financeiro no uso de cartão de crédito através de *data mining* [7]. | Taiwan (Ásia) | [7] |
| **Saúde** | Redução do risco de infecções associadas aos cuidados de saúde (HAIs) [6]. | Itália (Europa) | [6] |
| **Logística/Supply Chain** | Melhoria da eficiência do ciclo de processo em armazéns [12]. | Global, com estudos em Taiwan e Ásia [12] | [12] |
| **Setor Público** | Melhoria na entrega de serviços e eficiência em organizações governamentais [13]. | EUA, Reino Unido (Europa) | [13] |
| **Recursos Humanos (RH)** | Melhoria na gestão de projetos de RH e redução do tempo de ciclo de recrutamento [17]. | Global (Motorola, DuPont) | [17] |
| **Educação** | Melhoria da qualidade em processos de ensino superior e administrativos [14]. | Global | [14] |
| **Pequenas e Médias Empresas (PMEs)** | Aplicação em indústria de fundição de pequena escala [15]. | Índia | [15] |

## 5. Fontes Documentadas

A tabela a seguir lista as 17 fontes relevantes identificadas e documentadas durante a pesquisa:

| ID | Título e Autor(es) | Ano | Principais Contribuições | URL/Referência |
| :--- | :--- | :--- | :--- | :--- |
| **1** | A STUDY ON SIX SIGMA METHODOLOGY (Gois, J. N.; Gasparotto, A. M. S.) | 2020 | Definição de Six Sigma, métrica Sigma (3.4 DPMO) e eficácia do DMAIC em economia e satisfação do cliente. | [1] |
| **2** | The performance improvement analysis using Six Sigma DMAIC methodology: A case study on Indian manufacturing company (Mittal, A. et al.) | 2023 | Estudo de caso na Índia: redução da taxa de rejeição de 5.5% para 3.08% e melhoria do nível Sigma de 3.9 para 4.45. | [2] |
| **3** | The Six Sigma Handbook (Pyzdek, T.) | 2001-2023 | Guia fundamental da indústria, detalhando o DMAIC e ferramentas estatísticas. | [3] |
| **4** | DMAIC Process: Define, Measure, Analyze, Improve, Control (American Society for Quality - ASQ) | 2023 | Definição estruturada do DMAIC e listagem das ferramentas chave por fase. | [4] |
| **5** | A Influência de Juran e Deming no Six Sigma e DMAIC (Juran, J. M.; Deming, W. E.) | 1950-1980 | Fundamentos da qualidade, influência do CEP e da filosofia de melhoria contínua no DMAIC. | [5] |
| **6** | Reducing the risk of healthcare‐associated infections through the application of Lean Six Sigma methodology (Improta, G. et al.) | 2017 | Caso de estudo europeu (Itália): aplicação do LSS DMAIC para reduzir infecções hospitalares. | [6] |
| **7** | Application of six sigma DMAIC methodology to reduce financial risk: a study of credit card usage in Taiwan | 2012 | Caso de estudo asiático (Taiwan): uso do DMAIC e *data mining* para reduzir risco financeiro. | [7] |
| **8** | DMAIC vs. DMADV: Choosing the Right Six Sigma Methodology | Contínuo | Distinção entre DMAIC (melhoria de processos existentes) e DMADV/DFSS (criação de novos processos). | [8] |
| **9** | DMAIC 4.0 - innovating the Lean Six Sigma methodology with Industry 4.0 technologies (Pongboonchai-Empl, T. et al.) | 2025 | Tendência de integração do DMAIC com Indústria 4.0 (IA, IoT, Big Data) para melhoria preditiva. | [9] |
| **10** | The History of Six Sigma: From Motorola to Global Adoption (Smith, B.) | 1986 | Origem do Six Sigma na Motorola e o papel de Bill Smith. | [10] |
| **11** | Lean six sigma in a call centre: A case study | 2010 | Aplicação do LSS DMAIC em Call Center, focando em métricas de serviço e eliminação de desperdícios. | [11] |
| **12** | Development of an improvement framework for warehouse processes... (Adeodu, A. et al.) | 2023 | Aplicação do LSS DMAIC na otimização de processos de armazém e logística. | [12] |
| **13** | Improving Service Delivery in Government with Lean Six Sigma (Maleyeff, J. et al.) | 2006 | Aplicação do LSS DMAIC no setor público (EUA, Reino Unido) para melhorar a entrega de serviços. | [13] |
| **14** | Applying Six Sigma in Higher Education Quality Improvement (Mazumder, Q. H.) | 2014 | Aplicação do DMAIC para melhoria da qualidade em processos de ensino superior e administrativos. | [14] |
| **15** | Application of Six Sigma methodology in a small-scale foundry industry (Gijo, E. V. et al.) | 2014 | Demonstração da viabilidade e eficácia do DMAIC em Pequenas e Médias Empresas (PMEs) na Índia. | [15] |
| **16** | Integration of Ergonomics and Lean Six Sigma. A Model Proposal (Nunes, I. L. et al.) | 2015 | Proposta de integração do DMAIC com a Ergonomia para otimizar o fator humano e a segurança no processo. | [16] |
| **17** | Application of Six Sigma methodology DMAIC in HR project management (Liu, Y. et al.) | 2011 | Estudo de caso na Motorola sobre a aplicação do DMAIC na gestão de projetos de Recursos Humanos. | [17] |

## Referências

[1]: Gois, J. N.; Gasparotto, A. M. S. (2020). *A STUDY ON SIX SIGMA METHODOLOGY*. Revista Interface Tecnológica. [https://revista.fatectq.edu.br/interfacetecnologica/article/view/969]
[2]: Mittal, A. et al. (2023). *The performance improvement analysis using Six Sigma DMAIC methodology: A case study on Indian manufacturing company*. ScienceDirect. [https://www.sciencedirect.com/science/article/pii/S2405844023018327]
[3]: Pyzdek, T. (2001-2023). *The Six Sigma Handbook: The Complete Guide for Green Belts, Black Belts, and Managers at All Levels*. McGraw-Hill.
[4]: American Society for Quality (ASQ). *DMAIC Process: Define, Measure, Analyze, Improve, Control*. [https://asq.org/quality-resources/dmaic]
[5]: Juran, J. M.; Deming, W. E. (Diversas). *A Influência de Juran e Deming no Six Sigma e DMAIC*.
[6]: Improta, G. et al. (2017). *Reducing the risk of healthcare‐associated infections through the application of Lean Six Sigma methodology*. PMC. [https://pmc.ncbi.nlm.nih.gov/articles/PMC5900966/]
[7]: (2012). *Application of six sigma DMAIC methodology to reduce financial risk: a study of credit card usage in Taiwan*. ProQuest. [https://search.proquest.com/openview/fef8ed95e52134bde0bb7a4adf71ab9b/1?pq-origsite=gscholar&cbl=5703]
[8]: Purdue University. *DMAIC vs. DMADV: Choosing the Right Six Sigma Methodology*. [https://www.purdue.edu/leansixsigmaonline/blog/dmaic-vs-dmadv/]
[9]: Pongboonchai-Empl, T. et al. (2025). *DMAIC 4.0 - innovating the Lean Six Sigma methodology with Industry 4.0 technologies*. Taylor & Francis. [https://www.tandfonline.com/doi/full/10.1080/09537287.2025.2477724]
[10]: Smith, B. (1986). *The History of Six Sigma: From Motorola to Global Adoption*. Six Sigma Online.
[11]: (2010). *Lean six sigma in a call centre: A case study*. Emerald. [https://www.emerald.com/insight/content/doi/10.1108/17410401011089454/full/html]
[12]: Adeodu, A. et al. (2023). *Development of an improvement framework for warehouse processes...*. ScienceDirect. [https://www.sciencedirect.com/science/article/pii/S2405844023021229]
[13]: Maleyeff, J. et al. (2006). *Improving Service Delivery in Government with Lean Six Sigma*. Business of Government. [https://www.businessofgovernment.org/sites/default/files/MaleyeffReport.pdf]
[14]: Mazumder, Q. H. (2014). *Applying Six Sigma in Higher Education Quality Improvement*. ASEE. [https://peer.asee.org/applying-six-sigma-in-higher-education-quality-improvement.pdf]
[15]: Gijo, E. V. et al. (2014). *Application of Six Sigma methodology in a small-scale foundry industry*. Emerald. [https://www.emerald.com/insight/content/doi/10.1108/IJLSS-09-2013-0052/full/html]
[16]: Nunes, I. L. et al. (2015). *Integration of Ergonomics and Lean Six Sigma. A Model Proposal*. ScienceDirect. [https://www.sciencedirect.com/science/article/pii/S2351978915001250]
[17]: Liu, Y. et al. (2011). *Application of Six Sigma methodology DMAIC in HR project management*. IEEE. [https://ieeexplore.ieee.org/document/6035403/]

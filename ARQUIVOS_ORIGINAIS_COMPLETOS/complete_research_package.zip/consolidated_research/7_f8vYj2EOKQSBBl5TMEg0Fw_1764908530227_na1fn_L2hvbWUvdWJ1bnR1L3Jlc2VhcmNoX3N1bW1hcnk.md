# Pesquisa Aprofundada: Teoria das Restrições (Theory of Constraints - TOC) de Eliyahu Goldratt

A Teoria das Restrições (TOC), desenvolvida pelo físico israelense Eliyahu M. Goldratt, é uma filosofia de gestão sistêmica focada na identificação e gestão do fator limitante (restrição) que impede uma organização de alcançar seu objetivo principal [1]. A TOC postula que o desempenho de qualquer sistema complexo, incluindo empresas, é determinado por um único elo mais fraco, e a melhoria contínua deve ser direcionada a esse ponto de estrangulamento [2].

## 1. Conceitos Fundamentais e Metodologias

A TOC é estruturada em torno de um conjunto de princípios e ferramentas que se expandiram da produção para diversas áreas de gestão.

### 1.1. O Objetivo (The Goal)

O objetivo central de qualquer organização com fins lucrativos é **fazer dinheiro agora e no futuro** [3]. Goldratt traduziu esse objetivo em três métricas operacionais que guiam a tomada de decisão:
*   **_Throughput_ (Vazão - T):** A taxa na qual o sistema gera dinheiro através das vendas. É o dinheiro que entra.
*   **_Inventory_ (Estoque - I):** Todo o dinheiro que o sistema investiu em coisas que pretende vender.
*   **_Operating Expense_ (Despesa Operacional - OE):** Todo o dinheiro que o sistema gasta para transformar o estoque em vazão.

### 1.2. Os Cinco Passos de Foco (Five Focusing Steps)

O Processo de Melhoria Contínua (POOGI - _Process of Ongoing Improvement_) da TOC é formalizado nos Cinco Passos de Foco, que fornecem um ciclo iterativo para gerenciar a restrição [1] [4]:

1.  **Identificar** a restrição do sistema.
2.  **Explorar** a restrição (tirar o máximo proveito dela com os recursos existentes).
3.  **Subordinar** todo o resto à decisão de explorar a restrição (ajustar o ritmo de todo o sistema ao ritmo da restrição).
4.  **Elevar** a restrição (investir em melhorias ou capacidade adicional para a restrição).
5.  **Voltar ao Passo 1**, sem permitir que a inércia crie uma nova restrição.

### 1.3. Aplicações Setoriais e Metodologias Específicas

A filosofia da TOC se desdobrou em metodologias específicas para diferentes domínios [5]:

| Domínio de Aplicação | Metodologia/Conceito Chave | Fonte Principal |
| :--- | :--- | :--- |
| **Produção** | **Tambor-Pulmão-Corda (Drum-Buffer-Rope - DBR)**: O "Tambor" é o ritmo da restrição; o "Pulmão" é o estoque de tempo/material que protege a restrição; a "Corda" é o mecanismo de liberação de material que subordina o sistema ao ritmo do tambor [3]. | _A Meta_ (Goldratt & Cox, 1984) |
| **Gestão de Projetos** | **Corrente Crítica (Critical Chain - CC)**: Foca na gestão de recursos e na proteção do projeto como um todo (Pulmão do Projeto) e dos _feeds_ (Pulmões de Alimentação), em vez de proteger tarefas individuais [6]. | _Corrente Crítica_ (Goldratt, 1997) |
| **Finanças/Contabilidade** | **Contabilidade de Vazão (Throughput Accounting - TA)**: Substitui a contabilidade de custos tradicional, focando nas métricas T, I e OE para guiar decisões que maximizem o _Throughput_ [7]. | _Bússola Financeira_ (Corbett, 1998) |
| **Estratégia/Decisão** | **Processos de Raciocínio (Thinking Processes - TP)**: Um conjunto de ferramentas lógicas (Árvore da Realidade Atual, Diagrama de Conflito, Árvore da Realidade Futura) para analisar problemas complexos, identificar a restrição não-física (política ou paradigma) e construir soluções [8]. | _Não é Sorte_ (Goldratt, 1994) |
| **Cadeia de Suprimentos** | **Distribuição TOC (TOC Distribution)**: Aplica o conceito de Pulmão (Buffer) para gerenciar estoques em toda a cadeia de suprimentos, garantindo alta disponibilidade com menor nível de estoque [9]. | _The Theory of Constraints Handbook_ (Cox & Schleier, 2010) |

## 2. Análise de Aplicações e Cobertura Geográfica

Uma meta-análise seminal de Mabin e Balderstone (2003) examinou mais de 80 aplicações bem-sucedidas da TOC, demonstrando melhorias significativas no desempenho operacional e financeiro [5].

### 2.1. Setores de Aplicação

Embora a TOC tenha se originado na **Manufatura** (produção por lote e sob encomenda), as aplicações se expandiram para [5] [10]:
*   **Serviços:** Logística, hospitais, bancos, desenvolvimento de software.
*   **Saúde (_Healthcare_):** Gestão de fluxo de pacientes, redução de tempo de espera em emergências e cirurgias [11] [12].
*   **Gestão de Projetos:** Implementação da Corrente Crítica em P&D, construção e desenvolvimento de novos produtos [6].
*   **Cadeia de Suprimentos:** Otimização de estoques e colaboração entre parceiros [9] [13].

### 2.2. Cobertura Geográfica

A pesquisa sobre as aplicações da TOC revela uma distribuição global, embora com maior concentração em países desenvolvidos e em desenvolvimento com forte base industrial e acadêmica [5] [14]:
*   **América do Norte:** EUA e Canadá (forte base de consultoria e publicações).
*   **Europa:** Reino Unido, Holanda, Suécia, Lituânia (aplicações em serviços e projetos).
*   **Ásia:** Índia, China, Japão (crescente aplicação em manufatura e cadeia de suprimentos).
*   **Oceania:** Nova Zelândia, Austrália (origem de estudos de meta-análise).
*   **América Latina:** Brasil (aplicações em custos, produção e estudos acadêmicos) [15].

## 3. Fontes Documentadas

A tabela a seguir documenta as 20 fontes relevantes identificadas na pesquisa, abrangendo livros, artigos acadêmicos e estudos de caso.

| # | Título e Autor | Ano | Tipo | Principais Contribuições | URL/Referência |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | **A Meta: Um processo de melhoria contínua** (Eliyahu M. Goldratt e Jeff Cox) | 1984 | Livro (Ficção) | Introdução dos 5 Passos de Foco e do DBR (Tambor-Pulmão-Corda) em um contexto de produção. | Nobel, 2007 |
| 2 | **Corrente Crítica** (Eliyahu M. Goldratt) | 1997 | Livro (Ficção) | Aplicação da TOC à Gestão de Projetos, introduzindo o conceito de Corrente Crítica e Pulmões de Projeto. | Nobel, 2006 |
| 3 | **Não é Sorte** (Eliyahu M. Goldratt) | 1994 | Livro (Ficção) | Expansão da TOC para áreas não-manufatureiras (marketing, vendas) e introdução dos Processos de Raciocínio (TP). | Nobel, 2005 |
| 4 | **The Choice** (Eliyahu M. Goldratt e Efrat Goldratt-Ashlag) | 2008 | Livro (Filosofia) | Discussão filosófica sobre a simplicidade inerente aos sistemas e a importância de pensar com clareza. | North River Press, 2008 |
| 5 | **The performance of the theory of constraints methodology: Analysis and discussion of successful TOC applications** (Victoria J. Mabin e Steven J. Balderstone) | 2003 | Artigo Acadêmico | Meta-análise de mais de 80 aplicações de TOC, documentando melhorias operacionais e financeiras. | _Int. J. Operations & Production Management_ [5] |
| 6 | **Theory of Constraints: A Literature Review** (Z.T. Şimşit, N.S. Günay, Ö. Vayvay) | 2014 | Artigo Acadêmico | Revisão bibliográfica abrangente sobre a filosofia e os conceitos básicos da TOC. | _Procedia - Social and Behavioral Sciences_ [10] |
| 7 | **Bússola Financeira: O processo decisório da Teoria das Restrições** (Thomas Corbett) | 1998 | Livro (Técnico) | Detalhamento da Contabilidade de Vazão (_Throughput Accounting_) como métrica de desempenho da TOC. | Nobel, 2005 |
| 8 | **The Logical Thinking Process: A systems approach to complex problems solving** (H. William Dettmer) | 2007 | Livro (Técnico) | Guia detalhado sobre as ferramentas dos Processos de Raciocínio (TP) da TOC. | ASQ Quality Press, 2007 |
| 9 | **Theory of constraints in healthcare: a systematic literature review** (M. Datt, A. Gupta, S.K. Misra, M. Gupta) | 2024 | Artigo Acadêmico | Revisão sistemática sobre a aplicação de ferramentas e técnicas da TOC no setor de saúde. | _Int. J. Quality & Reliability Management_ [11] |
| 10 | **Exploring the integration between Lean and the Theory of Constraints in Operations Management** (D.A.J. Pacheco, I. Pergher, J.A.V. Antunes Junior) | 2019 | Artigo Acadêmico | Análise comparativa e de integração entre TOC e a filosofia Lean. | _Int. J. Lean Six Sigma_ [14] |
| 11 | **The theory of constraints: a methodology apart?—a comparison with selected OR/MS methodologies** (J. Davies, V.J. Mabin, S.J. Balderstone) | 2005 | Artigo Acadêmico | Posicionamento da TOC em relação a outras metodologias de Pesquisa Operacional e Ciência da Gestão. | _Omega_ [16] |
| 12 | **A study of scheduling under the theory of constraints** (D. Golmohammadi) | 2015 | Artigo Acadêmico | Investigação da implementação das regras de programação da TOC em sistemas _job-shop_. | _Int. J. Production Economics_ [17] |
| 13 | **Applying the theory of constraints to the logistics service of medical records of a hospital** (V.G. Aguilar-Escobar, P. Garrido-Vega) | 2016 | Artigo Acadêmico | Estudo de caso sobre a aplicação da TOC na logística de registros médicos em hospitais. | _J. Research on Management and Technology_ [12] |
| 14 | **Teoria das Restrições: um estudo bibliométrico...** (Scielo/RAE) | 2011 | Artigo Acadêmico | Visão geral da produção científica brasileira sobre TOC. | _Revista de Administração de Empresas_ [15] |
| 15 | **Theory of Constraints Examples** (TOC Institute) | N/A | Estudo de Caso | Exemplos de aplicações globais da TOC em diversos setores. | TOC Institute [18] |
| 16 | **Case Studies: Real-World Applications of the Theory...** (iSixSigma) | 2025 | Estudo de Caso | Exemplos práticos de aplicação da TOC para identificar e eliminar fatores limitantes. | iSixSigma [19] |
| 17 | **Applying Theory of Constraints Principles: A Case Study** (Bastian Solutions) | 2024 | Estudo de Caso | Aplicação da TOC em um fornecedor líder de eletrodomésticos. | Bastian Solutions [20] |
| 18 | **Theory of Constraints (TOC)** (Lean Production) | N/A | Visão Geral | Resumo dos princípios e da metodologia da TOC. | Lean Production [21] |
| 19 | **Be Fast or Be Gone: Racing the clock with critical chain project management** (Andreas Scherer) | 2011 | Livro (Ficção) | Suspense que descreve a implementação da Corrente Crítica em uma empresa farmacêutica. | ProChain Press, 2011 [15] |
| 20 | **Theory of constraints: a review of the philosophy and its applications** (P. O'Gorman) | 1998 | Artigo Acadêmico | Revisão inicial da filosofia e das aplicações da TOC. | _Int. J. Operations & Production Management_ [22] |

## Referências

[1] Eliyahu M. Goldratt e Jeff Cox. **A Meta: Um processo de melhoria contínua**. Nobel, 2007.
[2] Z.T. Şimşit, N.S. Günay, Ö. Vayvay. **Theory of Constraints: A Literature Review**. _Procedia - Social and Behavioral Sciences_, 2014.
[3] Eliyahu M. Goldratt. **A Meta: Um processo de melhoria contínua**. Nobel, 2007.
[4] Eliyahu M. Goldratt. **Não é Sorte**. Nobel, 2005.
[5] Victoria J. Mabin e Steven J. Balderstone. **The performance of the theory of constraints methodology: Analysis and discussion of successful TOC applications**. _International Journal of Operations & Production Management_, 2003.
[6] Eliyahu M. Goldratt. **Corrente Crítica**. Nobel, 2006.
[7] Thomas Corbett. **Bússola Financeira: O processo decisório da Teoria das Restrições**. Nobel, 2005.
[8] H. William Dettmer. **The Logical Thinking Process: A systems approach to complex problems solving**. ASQ Quality Press, 2007.
[9] D.A.J. Pacheco, I. Pergher, J.A.V. Antunes Junior. **Exploring the integration between Lean and the Theory of Constraints in Operations Management**. _International Journal of Lean Six Sigma_, 2019.
[10] Z.T. Şimşit, N.S. Günay, Ö. Vayvay. **Theory of Constraints: A Literature Review**. _Procedia - Social and Behavioral Sciences_, 2014.
[11] M. Datt, A. Gupta, S.K. Misra, M. Gupta. **Theory of constraints in healthcare: a systematic literature review**. _International Journal of Quality & Reliability Management_, 2024.
[12] V.G. Aguilar-Escobar, P. Garrido-Vega. **Applying the theory of constraints to the logistics service of medical records of a hospital**. _Journal of Research on Management and Technology_, 2016.
[13] G. da Silva Stefano. **How important is the Theory of Constraints to supply chain...**. _ScienceDirect_, 2024.
[14] D.A.J. Pacheco, I. Pergher, J.A.V. Antunes Junior. **Exploring the integration between Lean and the Theory of Constraints in Operations Management**. _International Journal of Lean Six Sigma_, 2019.
[15] Scielo/RAE. **Teoria das Restrições: um estudo bibliométrico...**. _Revista de Administração de Empresas_, 2011.
[16] J. Davies, V.J. Mabin, S.J. Balderstone. **The theory of constraints: a methodology apart?—a comparison with selected OR/MS methodologies**. _Omega_, 2005.
[17] D. Golmohammadi. **A study of scheduling under the theory of constraints**. _International Journal of Production Economics_, 2015.
[18] TOC Institute. **Theory of Constraints Examples**. [https://www.tocinstitute.org/theory-of-constraints-examples.html](https://www.tocinstitute.org/theory-of-constraints-examples.html)
[19] iSixSigma. **Case Studies: Real-World Applications of the Theory...**. [https://www.isixsigma.com/theory-of-constraints/case-studies-real-world-applications-of-the-theory-of-constraints/](https://www.isixsigma.com/theory-of-constraints/case-studies-real-world-applications-of-the-theory-of-constraints/)
[20] Bastian Solutions. **Applying Theory of Constraints Principles: A Case Study**. [https://www.bastiansolutions.com/blog/applying-theory-of-constraints-principles-a-case-study/](https://www.bastiansolutions.com/blog/applying-theory-of-constraints-principles-a-case-study/)
[21] Lean Production. **Theory of Constraints (TOC)**. [https://www.leanproduction.com/theory-of-constraints/](https://www.leanproduction.com/theory-of-constraints/)
[22] P. O'Gorman. **Theory of constraints: a review of the philosophy and its applications**. _International Journal of Operations & Production Management_, 1998.

# Pesquisa Aprofundada: Nemawashi e Kaizen - Abordagens Japonesas de Consenso e Melhoria Contínua

## Introdução

Esta pesquisa tem como objetivo realizar um levantamento bibliográfico e prático aprofundado sobre duas filosofias centrais da gestão e cultura organizacional japonesa: **Nemawashi** (construção de consenso) e **Kaizen** (melhoria contínua). Ambas as abordagens são cruciais para o conceito de "pensar no resultado antes", pois estabelecem as bases culturais e processuais para a implementação bem-sucedida de mudanças e inovações.

## Nemawashi: A Arte da Construção de Consenso

O termo **Nemawashi** (根回し) é derivado da jardinagem, referindo-se ao ato de cavar ao redor das raízes de uma árvore antes de transplantá-la, garantindo que a árvore sobreviva e prospere em seu novo local. Metaforicamente, no contexto empresarial e social, Nemawashi é o processo informal, mas sistemático e sequencial, de buscar o consenso e a aprovação de uma ideia ou projeto antes de sua proposta formal [1] [2].

### Conceitos-Chave e Contribuições

O Nemawashi é mais do que apenas "lobby" ou comunicação prévia; é uma técnica de tomada de decisão que visa garantir que todas as partes interessadas (stakeholders) estejam informadas, tenham a oportunidade de expressar preocupações e, finalmente, apoiem a decisão.

| Conceito | Descrição | Citação Relevante |
| :--- | :--- | :--- |
| **Consenso Sistemático** | É um procedimento semi-formal, mas sistemático e sequencial, para buscar a aprovação [1]. | "Nemawashi is a semi-formal but systematic and sequential consensus building procedure in Japan by which the approval of a proposed idea or project is sought." [1] |
| **Preparação do Terreno** | A analogia com a jardinagem implica que, sem a preparação adequada (Nemawashi), a "transplantação" (implementação da mudança) pode falhar [2]. | "Nemawashi comes from the gardening activity that nurtures and prepares the ground to transplant as without a proper Nemawashi... the implementation of the decision..." [2] |
| **Engajamento e Confiança** | Ajuda a construir confiança, aumentar a comunicação e fazer com que os funcionários se sintam colaborativos, reduzindo o estresse e a confusão [4]. | "The principles of nemawashi help build trust, increase communication, help employees feel collaborative, and reduce stress and confusion." [4] |
| **Ligação com o Sistema Ringi** | É frequentemente usado no sistema *Ringi*, o processo formal de tomada de decisão japonês, para formar um consenso antes da circulação do documento *ringi-sho* [6]. | "In Ringi system, which is a decision-making process followed by organizations in Japan, Nemawashi is often used in order to form a consensus." [6] |

### Aplicações Práticas

O Nemawashi tem sido aplicado em diversos campos, desde a pesquisa acadêmica [1] até a melhoria da segurança do paciente em hospitais, como o "Nemawashi Gauge" da Virginia Mason Institute [15].

## Kaizen: A Filosofia da Melhoria Contínua

**Kaizen** (改善) é a filosofia de gestão que se traduz como "mudança para melhor" ou "melhoria contínua". Popularizada por Masaaki Imai, especialmente através de seu livro "Kaizen: The Key to Japan's Competitive Success" [10], ela se tornou um pilar do sistema de produção Toyota e da gestão japonesa [16].

### Conceitos-Chave e Contribuições

O Kaizen foca em melhorias pequenas, incrementais e contínuas, envolvendo todos os funcionários, desde a alta gerência até os operadores de linha de frente.

| Conceito | Descrição | Citação Relevante |
| :--- | :--- | :--- |
| **Melhoria Contínua** | A essência do Kaizen é a busca incessante por pequenas melhorias em todos os processos [10]. | "Kaizen: The key to Japan's competitive success." [10] |
| **Envolvimento Total** | O Kaizen é uma abordagem que envolve todos na organização, contrastando com inovações radicais que geralmente são responsabilidade da gerência [16]. | "The core principles of Japanese management include continuous improvement (kaizen), teamwork, customer focus, employee engagement, and quality control." [16] |
| **Evolução Estratégica** | O Kaizen evoluiu de uma ênfase particular na eficiência industrial para uma estratégia abrangente que prioriza a sustentabilidade e a digitalização [8]. | "Kaizen has changed from a particular emphasison industrial efficiency to a comprehensive strategythat prioritizes sustainability and digitization." [8] |
| **Kaizen Events (KEs)** | Aplicações focadas, como os Kaizen Events, são cruciais para o sucesso em ambientes como hospitais, com fatores críticos de sucesso identificados [12]. | "The study identifies the critical success factors (CSFs) for conducting Kaizen events (KEs) in hospitals..." [12] |

### Autores e Publicações Chave

*   **Masaaki Imai:** O "pai do KAIZEN™" [11], que introduziu o conceito para aumentar a eficiência na década de 1980 [17].
*   **Robert Maurer:** Autor de "One Small Step Can Change Your Life: The Kaizen Way" [10], que popularizou a aplicação do Kaizen para mudanças pessoais e psicológicas.
*   **Isao Kato e Art Smalley:** Autores de "Toyota Kaizen Methods" [13], focando na abordagem técnica do Kaizen.

## A Sinergia entre Nemawashi e Kaizen

Nemawashi e Kaizen são complementares no ciclo de gestão da mudança. O Nemawashi atua na fase de **preparação e alinhamento cultural** para a mudança, enquanto o Kaizen é o **mecanismo de implementação e execução** da melhoria.

Uma abordagem sugere usar o Nemawashi para preparar e alinhar as partes interessadas para a mudança, e o Kaizen para implementar e melhorar essa mudança de forma contínua [14]. O Nemawashi garante a aceitação cultural e a redução da resistência, criando um ambiente propício para que o Kaizen, com suas pequenas e constantes melhorias, possa florescer.

## Documentação Detalhada das Fontes

A tabela a seguir documenta as fontes mais relevantes encontradas, totalizando 18 referências.

| ID | Título e Autor | Ano | Tipo | Principais Conceitos e Contribuições |
| :--- | :--- | :--- | :--- | :--- |
| [1] | **Nemawashi essential for conducting research in Japan** - M. D. Fetters | 1995 | Artigo Acadêmico | Define Nemawashi como procedimento sistemático de consenso. |
| [2] | **'Nemawashi' a Technique to Gain Consensus in Japanese Management Systems: An Overview** - D. S. Sagi | 2015 | Artigo Acadêmico | Descrição detalhada do Nemawashi, analogia com a jardinagem. |
| [3] | **Learning Effects in Informal Consensus Building during the Innovation Process: Questionnaire Survey on Nemawashi** - N. Ko | 2022 | Artigo Acadêmico | Estudo de Nemawashi sob a perspectiva da inovação. |
| [4] | **The Nemawashi Way: The Key To Employee Engagement And Decision-Making** - M. Logan | 2024 | Artigo Empresarial | Foco na construção de confiança e engajamento. |
| [5] | **Nemawashi: A Guide to Japanese Consensus Building** - The Lean Suite | 2025 | Metodologia | Guia prático para aprimorar a tomada de decisão colaborativa. |
| [6] | **Applying Nudges to Nemawashi: Consensus-building Without...** - N. Ko | 2022 | Artigo Acadêmico | Relação entre Nemawashi e o sistema de decisão Ringi. |
| [7] | **Systematic bibliometric analysis on Kaizen in scientific journals** - Z. Sahmi | 2024 | Artigo Acadêmico | Revisão de 98 artigos sobre a evolução do Kaizen. |
| [8] | **The evolution of Kaizen in the industry: systematic literature review** - Z. Sahmi | 2024 | Artigo Acadêmico | Kaizen evoluiu para uma estratégia que inclui sustentabilidade e digitalização. |
| [9] | **Kaizen Techniques: A Literature Review** - M. Chotaliya | 2022 | Artigo Acadêmico | Revisão de técnicas de Kaizen para novos pesquisadores. |
| [10] | **Kaizen: The Key to Japan's Competitive Success** - Masaaki Imai | 1986 | Livro | Obra fundamental que popularizou o Kaizen. |
| [11] | **KAIZEN™ Books** - Kaizen.com | N/A | Publicação Especializada | Menciona Masaaki Imai como o "pai do KAIZEN™". |
| [12] | **A Systematic Literature Review and Meta-Synthesis...** - K. D. Harry | 2025 | Artigo Acadêmico | Fatores críticos de sucesso para Kaizen Events em hospitais. |
| [13] | **Toyota Kaizen Methods** - Isao Kato e Art Smalley | 2011 | Livro | Abordagem técnica do Kaizen no contexto Toyota. |
| [14] | **How to Balance Nemawashi and Kaizen for Improvement** - LinkedIn | 2023 | Artigo Empresarial | Sinergia: Nemawashi para alinhamento, Kaizen para implementação. |
| [15] | **Improve Patient Safety with Nemawashi Gauge** - Virginia Mason Institute | 2015 | Caso de Estudo | Aplicação prática do Nemawashi na área da saúde. |
| [16] | **Japanese management** - J. Ansho | 2024 | Artigo Acadêmico | Kaizen e Nemawashi como princípios centrais da gestão japonesa. |
| [17] | **Kaizen Equilibrium and Organization Behavior** - K. Jayantha | 2021 | Artigo Acadêmico | Contextualiza a introdução do Kaizen por Masaaki Imai na década de 1980. |
| [18] | **One Small Step Can Change Your Life: The Kaizen Way** - Robert Maurer | 2004 | Livro | Aplicação do Kaizen para mudanças pessoais. |

## Referências

[1] M. D. Fetters, "Nemawashi essential for conducting research in Japan," *Social Science & Medicine*, 1995. URL: https://pubmed.ncbi.nlm.nih.gov/7481931/
[2] D. S. Sagi, "'Nemawashi' a Technique to Gain Consensus in Japanese Management Systems: An Overview," *SSRN*, 2015. URL: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2597438
[3] N. Ko, "Learning Effects in Informal Consensus Building during the Innovation Process: Questionnaire Survey on Nemawashi," *IEEE Xplore*, 2022. URL: https://ieeexplore.ieee.org/abstract/document/10653342/
[4] M. Logan, "The Nemawashi Way: The Key To Employee Engagement And Decision-Making," *Forbes*, 2024. URL: https://www.forbes.com/sites/micahlogan/2024/02/28/the-nemawashi-way-the-key-to-employee-engagement-and-decision-making/
[5] The Lean Suite, "Nemawashi: A Guide to Japanese Consensus Building," *The Lean Suite Blog*, 2025. URL: https://www.theleansuite.com/blogs/nemawashi
[6] N. Ko, "Applying Nudges to Nemawashi: Consensus-building Without...," *CMS Conferences*, 2022. URL: https://openaccess.cms-conferences.org/publications/book/978-1-958651-38-4/article/978-1-958651-38-4_14
[7] Z. Sahmi, "Systematic bibliometric analysis on Kaizen in scientific journals," *Emerald Insight*, 2024. URL: https://www.emerald.com/insight/content/doi/10.1108/TQM-12-2017-0171/full/html
[8] Z. Sahmi, "The evolution of Kaizen in the industry: systematic literature review," *ResearchGate*, 2024. URL: https://www.researchgate.net/publication/382622541_The_evolution_of_Kaizen_in_the_industry_systematic_literature_review
[9] M. Chotaliya, "Kaizen Techniques: A Literature Review," *SSRN*, 2022. URL: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4677097
[10] M. Imai, *Kaizen: The Key to Japan's Competitive Success*, McGraw-Hill, 1986. (Referência de Livro)
[11] KAIZEN™ Institute, "KAIZEN™ Books," *Kaizen.com*. URL: https://kaizen.com/insights/book-strategic-kaizen/
[12] K. D. Harry, "A Systematic Literature Review and Meta-Synthesis...," *Taylor & Francis Online*, 2025. URL: https://www.tandfonline.com/doi/abs/10.1080/10429247.2025.2504790
[13] I. Kato and A. Smalley, *Toyota Kaizen Methods*, Productivity Press, 2011. (Referência de Livro)
[14] LinkedIn, "How to Balance Nemawashi and Kaizen for Improvement," *LinkedIn Pulse*, 2023. URL: https://www.linkedin.com/advice/0/how-do-you-balance-nemawashi-kaizen-your-continuous
[15] Virginia Mason Institute, "Improve Patient Safety with Nemawashi Gauge," *Virginia Mason Institute Blog*, 2015. URL: https://www.virginiamasoninstitute.org/using-the-nemawashi-gauge-to-guide-improvement-in-patient-safety/
[16] J. Ansho, "Japanese management," *ScienceOpen Preprints*, 2024. URL: https://www.scienceopen.com/hosted-document?doi=10.14293/PR2199.000770.v1
[17] K. Jayantha, "Kaizen Equilibrium and Organization Behavior," *Saudi Journal of Business and Management Studies*, 2021. URL: https://saudijournals.com/media/articles/SJBMS_68_298-307c_4hkEMzy.pdf
[18] R. Maurer, *One Small Step Can Change Your Life: The Kaizen Way*, Workman Publishing, 2004. (Referência de Livro)

# Resumo Detalhado da Pesquisa: Blue Ocean Strategy e Reconstrução de Fronteiras de Mercado

## Área Temática: Blue Ocean Strategy e Reconstrução de Fronteiras de Mercado

A pesquisa aprofundada foi realizada sobre a **Estratégia do Oceano Azul** (*Blue Ocean Strategy - BOS*) e o conceito central de **reconstrução de fronteiras de mercado**. A BOS é uma abordagem estratégica que visa a criação de um novo espaço de mercado inexplorado (*oceano azul*), tornando a concorrência irrelevante, em contraste com a competição em mercados existentes e saturados (*oceanos vermelhos*).

## Fontes Documentadas

Foram identificadas e documentadas 18 fontes relevantes, abrangendo livros seminais, artigos acadêmicos, publicações especializadas e referências institucionais.

| ID | Título e Autor | Ano | Tipo | Principais Contribuições | Citações Relevantes | URL/Referência |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| **1** | **Blue Ocean Strategy: How to Create Uncontested Market Space and Make the Competition Irrelevant** - W. Chan Kim & Renée Mauborgne | 2005 | Livro Seminal | Introdução do conceito de BOS, Valor-Inovação, Framework das Quatro Ações e Tela de Estratégia. | "A única maneira de vencer a concorrência é parar de tentar vencê-la." | Harvard Business School Press |
| **2** | **Blue Ocean Shift: Beyond Competing - Proven Steps to Inspire Confidence and Seize New Growth** - W. Chan Kim & Renée Mauborgne | 2017 | Livro Secundário | Guia prático para implementação da BOS, focando em passos e ferramentas para a transição. | "O Oceano Azul não é um destino, mas uma jornada." | Hachette Books |
| **3** | **Blue Ocean Strategy** - W. Chan Kim & Renée Mauborgne | 2004 | Artigo HBR | Versão original do conceito, publicada na Harvard Business Review, que precedeu o livro. | "A Estratégia do Oceano Azul busca a diferenciação e o baixo custo simultaneamente." | Harvard Business Review |
| **4** | **INSEAD Blue Ocean Strategy Institute (IBOSI)** - W. Chan Kim & Renée Mauborgne | N/A | Institucional | Centro de pesquisa e ensino, fonte primária de metodologias e ferramentas oficiais. | N/A | [https://www.insead.edu/insead-blue-ocean-strategy-institute](https://www.insead.edu/insead-blue-ocean-strategy-institute) |
| **5** | **Four Actions Framework (ERRC Grid)** - W. Chan Kim & Renée Mauborgne | N/A | Metodologia | Ferramenta central para reconstruir a curva de valor: Eliminar, Reduzir, Aumentar, Criar. | "Eliminar e Reduzir para cortar custos; Aumentar e Criar para elevar o valor para o comprador." | [https://www.blueoceanstrategy.com/tools/four-actions-framework/](https://www.blueoceanstrategy.com/tools/four-actions-framework/) |
| **6** | **Strategy Canvas** - W. Chan Kim & Renée Mauborgne | N/A | Metodologia | Ferramenta de diagnóstico e ação para visualizar o perfil estratégico atual e futuro. | "O Canvas de Estratégia é o mapa de diagnóstico e o quadro de ação da criação do Oceano Azul." | [https://www.blueoceanstrategy.com/tools/strategy-canvas/](https://www.blueoceanstrategy.com/tools/strategy-canvas/) |
| **7** | **The Pitfalls Of The Blue Ocean Strategy Implications Of" The Six Paths Framework"** - Peter Lindgren, Kristin Falck Saghaug, Suberia Clemmensen | N/A | Artigo Acadêmico | Análise crítica e implicações do Framework dos Seis Caminhos, um dos pilares da BOS. | "É arriscado e problemático para a empresa simplesmente seguir a BOS sem considerar as armadilhas." | Taylor & Francis |
| **8** | **Um estudo bibliométrico da Estratégia do Oceano Azul** - FRA Cattaneo, LA Souza | 2017 | Artigo Acadêmico | Revisão da literatura e análise da evolução do tema BOS no contexto acadêmico. | "As empresas buscam maior lucratividade, e para isso se diferenciar dos concorrentes e buscar mercados com menor ou nenhuma concorrência se torna fundamental." | Revista Brasileira de Administração |
| **9** | **Integrating the Business Model puzzle: A systematic Literature Review** - J. L. C. P. de Carvalho, et al. | 2018 | Artigo Acadêmico | Conecta a BOS com a inovação de modelos de negócios, citando a lógica da Inovação de Valor. | "A espinha dorsal da estratégia do oceano azul é a lógica da inovação de valor." | ResearchGate |
| **10** | **A INFLUÊNCIA DA INOVAÇÃO COMO ELEMENTO DE MUDANÇA NO POSICIONAMENTO ESTRATÉGICO** - M. C. S. A. Silva, et al. | 2017 | Artigo Acadêmico | Compara a BOS com as Estratégias Genéricas de Porter, destacando a busca simultânea por valor-custo. | "A BOS persegue a valor-custo simultaneamente por reconstrução de fronteiras de mercado." | Ecoinovar |
| **11** | **Yellow Tail: Clever Brand Positioning Within The American Wine Industry** - The Branding Journal | 2014 | Caso de Estudo | Análise de como a [yellow tail] aplicou a BOS para criar um novo mercado de vinhos nos EUA. | "A [yellow tail] eliminou o jargão e a complexidade do vinho, criando um produto acessível e divertido." | The Branding Journal |
| **12** | **Even a Clown Can Do It: Cirque du Soleil** - W. Chan Kim, Renée Mauborgne | N/A | Caso de Estudo | O caso seminal do Cirque du Soleil, que eliminou custos da indústria de circo e criou novos elementos de valor. | "O Cirque du Soleil eliminou os animais e as estrelas, reduzindo custos, e criou um novo conceito de teatro e arte." | Harvard Business School |
| **13** | **Service-Based Business Model Innovation in Product-Based...** - H Benad | 2025 | Artigo Acadêmico | Menciona a BOS como um termo reconhecido para a criação de novos espaços de mercado. | "Reconhecido hoje sob termos como 'estratégia do oceano azul' (Kim e Mauborgne, 2005)." | DCU Repository |
| **14** | **From buzzword to managerial tool: The role of business models in strategic innovation** - L Lehmann-Ortega | N/A | Artigo Acadêmico | Cita a BOS como uma referência fundamental na literatura de inovação estratégica. | N/A | v-assets.cdnsw.com |
| **15** | **Estratégia do Oceano Azul: Implementação Prática no...** - BSC Designer | 2024 | Publicação Especializada | Aborda a aplicação prática da BOS, incluindo o uso do Canvas e do Framework das Quatro Ações. | "A tela inclui quatro segmentos onde os objetivos de mudança são formulados." | BSC Designer |
| **16** | **Oceano Azul: o que é e como adotar essa estratégia?** - Salesforce | 2022 | Publicação Especializada | Artigo de aplicação empresarial que resume os pilares da BOS. | "Prescreve um processo estruturado e combina diferenciação e baixo custo." | Salesforce Brasil |
| **17** | **Blue Ocean Strategy, Expanded Edition** - W. Chan Kim & Renée Mauborgne | N/A | Livro (Google Books) | Referência à edição expandida do livro, indicando a longevidade e atualização do conceito. | N/A | Google Livros |
| **18** | **W. Chan Kim & Renée Mauborgne** - Bertrand Livreiros | N/A | Biografia/Referência | Fonte que confirma a autoria e a disponibilidade das obras em diferentes regiões (Portugal). | N/A | Bertrand Livreiros (Portugal) |

## Análise e Síntese dos Principais Conceitos

A **Estratégia do Oceano Azul (BOS)** é um paradigma de gestão que desafia a visão tradicional de competição (*Oceano Vermelho*). Seu cerne reside na **Inovação de Valor**, que é a busca simultânea por **diferenciação** e **baixo custo** [1] [3].

Os principais conceitos e *insights* descobertos na pesquisa são:

*   **Valor-Inovação:** É o princípio fundamental da BOS. Em vez de focar em vencer a concorrência (diferenciação) ou em cortar custos (liderança de custo), a Inovação de Valor cria um salto no valor para os compradores, ao mesmo tempo que reduz a estrutura de custos da empresa [1] [9].
*   **Reconstrução de Fronteiras de Mercado:** A BOS propõe seis caminhos para a reconstrução das fronteiras de mercado, que incluem olhar para indústrias alternativas, grupos estratégicos, cadeia de compradores, ofertas complementares, apelo funcional/emocional e o tempo [7]. O objetivo é sair do *trade-off* entre valor e custo.
*   **Framework das Quatro Ações (ERRC Grid):** Esta é a ferramenta analítica central para criar uma nova curva de valor [5]. As quatro ações são:
    *   **Eliminar:** Quais fatores que a indústria considera essenciais devem ser eliminados para reduzir custos?
    *   **Reduzir:** Quais fatores devem ser reduzidos bem abaixo do padrão da indústria para cortar custos sem sacrificar o valor?
    *   **Aumentar:** Quais fatores devem ser elevados bem acima do padrão da indústria para aumentar o valor para o comprador?
    *   **Criar:** Quais fatores que a indústria nunca ofereceu devem ser criados para gerar uma nova demanda?
*   **Tela de Estratégia (*Strategy Canvas*):** Uma ferramenta de diagnóstico que visualiza o perfil estratégico de uma empresa em relação aos seus concorrentes e os fatores de competição da indústria [6]. O objetivo é desenhar uma nova curva de valor que se afaste da curva dos concorrentes.
*   **Não-Clientes (*Noncustomers*):** A BOS foca em atrair os não-clientes, ou seja, aqueles que ainda não consomem o produto ou serviço da indústria, expandindo a demanda e criando um novo mercado [1].

## Cobertura Geográfica das Fontes

A Estratégia do Oceano Azul possui uma cobertura geográfica ampla, refletindo seu impacto global.

*   **EUA:** Sede da editora principal (Harvard Business School Press) e contexto de casos de estudo importantes (ex: [yellow tail] wine) [1] [11].
*   **Europa (França, Portugal):** Os autores W. Chan Kim e Renée Mauborgne são professores no INSEAD, com campus na França. Fontes de referência e editoras de livros foram encontradas em Portugal [4] [18].
*   **Ásia (Singapura):** O INSEAD, lar do Blue Ocean Strategy Institute, também possui um campus em Singapura, indicando uma influência asiática na pesquisa e disseminação [4].
*   **Brasil:** Diversos artigos acadêmicos e publicações especializadas em português demonstram a adoção e o estudo da BOS no contexto brasileiro [8] [10] [16].

A pesquisa confirma que a BOS é um conceito global, com forte presença acadêmica e empresarial em **EUA, Europa (França, Portugal), Brasil** e **Ásia (Singapura)**.

***

**Referências**

[1] Kim, W. C., & Mauborgne, R. (2005). *Blue Ocean Strategy: How to Create Uncontested Market Space and Make the Competition Irrelevant*. Harvard Business School Press.
[2] Kim, W. C., & Mauborgne, R. (2017). *Blue Ocean Shift: Beyond Competing - Proven Steps to Inspire Confidence and Seize New Growth*. Hachette Books.
[3] Kim, W. C., & Mauborgne, R. (2004). Blue Ocean Strategy. *Harvard Business Review*.
[4] INSEAD Blue Ocean Strategy Institute. *INSEAD*. [https://www.insead.edu/insead-blue-ocean-strategy-institute](https://www.insead.edu/insead-blue-ocean-strategy-institute)
[5] Four Actions Framework: Reconstruct Buyer Value. *Blue Ocean Strategy*. [https://www.blueoceanstrategy.com/tools/four-actions-framework/](https://www.blueoceanstrategy.com/tools/four-actions-framework/)
[6] Strategy Canvas. *Blue Ocean Strategy*. [https://www.blueoceanstrategy.com/tools/strategy-canvas/](https://www.blueoceanstrategy.com/tools/strategy-canvas/)
[7] Lindgren, P., Saghaug, K. F., & Clemmensen, S. (N/A). The Pitfalls Of The Blue Ocean Strategy Implications Of" The Six Paths Framework". *Taylor & Francis*.
[8] Cattaneo, F. R. A., & Souza, L. A. (2017). Um estudo bibliométrico da Estratégia do Oceano Azul. *Revista Brasileira de Administração*.
[9] Carvalho, J. L. C. P. de, et al. (2018). Integrating the Business Model puzzle: A systematic Literature Review. *ResearchGate*.
[10] Silva, M. C. S. A., et al. (2017). A INFLUÊNCIA DA INOVAÇÃO COMO ELEMENTO DE MUDANÇA NO POSICIONAMENTO ESTRATÉGICO. *Ecoinovar*.
[11] Yellow Tail: Clever Brand Positioning Within The American Wine Industry. (2014). *The Branding Journal*.
[12] Kim, W. C., & Mauborgne, R. (N/A). Even a Clown Can Do It: Cirque du Soleil. *Harvard Business School*.
[13] Benad, H. (2025). Service-Based Business Model Innovation in Product-Based... *DCU Repository*.
[14] Lehmann-Ortega, L. (N/A). From buzzword to managerial tool: The role of business models in strategic innovation. *v-assets.cdnsw.com*.
[15] Estratégia do Oceano Azul: Implementação Prática no... (2024). *BSC Designer*.
[16] Oceano Azul: o que é e como adotar essa estratégia? (2022). *Salesforce Brasil*.
[17] Kim, W. C., & Mauborgne, R. (N/A). *Blue Ocean Strategy, Expanded Edition*. Google Livros.
[18] Renée Mauborgne; W. Chan Kim. *Bertrand Livreiros*. [https://www.bertrand.pt/autor/renee-mauborgne-w-chan-kim/4312943](https://www.bertrand.pt/autor/renee-mauborgne-w-chan-kim/4312943)

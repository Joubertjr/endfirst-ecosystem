# Resumo Detalhado da Pesquisa: Impact Mapping e Outcome-Driven Innovation

## Introdução

A presente pesquisa aprofundada explora os frameworks **Impact Mapping (IM)** e **Outcome-Driven Innovation (ODI)**, duas metodologias cruciais no planejamento estratégico e desenvolvimento de produtos, que compartilham o foco em resultados (*outcomes* e *impacts*) em detrimento de entregáveis (*outputs*). O objetivo é documentar as fontes primárias, conceitos-chave, aplicações setoriais e a cobertura geográfica das referências, totalizando 15 fontes relevantes.

## Impact Mapping (IM): Foco no Impacto e Comportamento

O Impact Mapping é uma técnica de planejamento colaborativo, visual e leve, concebida por Gojko Adzic [1] [2]. Sua principal contribuição reside em alinhar a estratégia de alto nível com os entregáveis técnicos, garantindo que o trabalho realizado gere o **impacto** desejado, definido como uma mudança de comportamento nos atores envolvidos [1].

A estrutura do Impact Map é hierárquica e responde a quatro perguntas fundamentais:
1.  **Por que** (Goal): O objetivo de negócio de alto nível.
2.  **Quem** (Actors): Os atores cujos comportamentos devem mudar para atingir o objetivo.
3.  **O quê** (Impacts): As mudanças de comportamento ou resultados que os atores devem demonstrar.
4.  **Como** (Deliverables): Os entregáveis, funcionalidades ou ações que a equipe deve implementar para gerar os impactos [1] [2].

Embora originalmente focado no desenvolvimento de software ágil, o IM demonstrou versatilidade, sendo adaptado para a avaliação de impactos sociais e programas de pesquisa comunitária, como o método REM (*Research Evaluation Mapping*) [3] [7].

## Outcome-Driven Innovation (ODI): Foco no Job-to-be-Done e Outcomes Mensuráveis

O Outcome-Driven Innovation (ODI) é um processo de estratégia e inovação desenvolvido por Anthony W. Ulwick, fundador da Strategyn [4] [5]. O ODI é a aplicação prática da teoria **Jobs-to-be-Done (JTBD)**, que postula que os clientes "contratam" produtos e serviços para realizar um "trabalho" (job) de forma mais eficiente [5] [15].

O cerne do ODI é a identificação e satisfação de **Outcomes** (resultados) desejados pelo cliente, que são definidos como necessidades mensuráveis, estáveis e independentes da solução [4]. O processo de inovação do ODI segue uma abordagem rigorosa e científica, incluindo:
1.  Definição do mercado em torno do *Job-to-be-Done*.
2.  Descoberta dos *Outcomes* do cliente (geralmente mais de 100 por job).
3.  Determinação de *Outcomes* insatisfeitos através do **Algoritmo de Oportunidade** (Oportunidade = Importância + max(0, Importância - Satisfação)) [4].
4.  Segmentação de mercado baseada em *Outcomes* insatisfeitos.
5.  Formulação da estratégia de inovação e produto [4].

O ODI tem sido aplicado em diversos setores, como manufatura de bens esportivos [8], serviços de hotelaria [9] e educação superior [10], demonstrando sua eficácia na transformação da inovação em um processo previsível e com alta taxa de sucesso [4].

## Análise Comparativa: Impact Mapping e Outcome-Driven Innovation

Ambos os frameworks são orientados a resultados, mas operam em diferentes níveis de granularidade e com focos ligeiramente distintos. O Impact Mapping é uma ferramenta de **planejamento estratégico** e visualização que liga a estratégia ao desenvolvimento, focando na **mudança de comportamento (Impacto)**. O ODI é um **processo de pesquisa e inovação** que foca na identificação e quantificação de **necessidades não satisfeitas (Outcomes)** do cliente para guiar o desenvolvimento de produtos [6] [14].

A tabela a seguir resume as principais diferenças e semelhanças:

| Característica | Impact Mapping (IM) | Outcome-Driven Innovation (ODI) |
| :--- | :--- | :--- |
| **Autor Principal** | Gojko Adzic [1] | Anthony W. Ulwick [4] |
| **Foco Principal** | Planejamento Estratégico e Mudança de Comportamento (Impacto) | Inovação Previsível e Satisfação de Necessidades (Outcomes) |
| **Base Teórica** | Design de Interação do Usuário, Planejamento Orientado a Resultados [1] | Jobs-to-be-Done (JTBD) [4] [5] |
| **Elemento Central** | O Mapa Hierárquico (Por que, Quem, O quê, Como) [2] | O Outcome (Necessidade Mensurável) e o Algoritmo de Oportunidade [4] |
| **Nível de Aplicação** | Estratégico e Tático (Roadmapping) | Estratégico (Pesquisa de Mercado e Segmentação) |
| **Natureza** | Colaborativa, Visual, Leve [1] | Científica, Data-Driven, Rigorosa [4] |

## Aplicações Setoriais e Cobertura Geográfica

As fontes pesquisadas demonstram uma ampla aplicação de ambos os frameworks, transcendendo o setor de Tecnologia da Informação (TI) onde surgiram:
*   **Impact Mapping:** Saúde pública (prevenção da obesidade) [7], pesquisa interdisciplinar [3].
*   **Outcome-Driven Innovation:** Manufatura (bens esportivos) [8], serviços (hotelaria) [9], educação superior (*Blended Learning*) [10].

A cobertura geográfica das fontes é diversificada, com forte presença nos **EUA** (Anthony Ulwick, Strategyn, McGraw Hill) e na **Europa** (Gojko Adzic/Reino Unido, Artigo da Alemanha/F. Piller, Artigo Crítico/G. Katz). Há também referências a aplicações e estudos na **Ásia**, como a Coreia do Sul [11], e casos de estudo globais em publicações acadêmicas [9].

## Fontes Documentadas

| # | Título | Autor | Ano | URL/Referência |
| :--- | :--- | :--- | :--- | :--- |
| 1 | Impact Mapping (Site Oficial) | Gojko Adzic | 2012 | https://www.impactmapping.org/ |
| 2 | Impact Mapping: Making a Big Impact with Software Products and Projects (Livro) | Gojko Adzic | 2012 | ISBN: 978-0-9556836-4-0 |
| 3 | Impact mapping tool for interdisciplinary research institutes (Artigo Acadêmico) | L Pfeifer, et al. | 2024 | https://www.sciencedirect.com/science/article/pii/S2949697724000134 |
| 4 | Outcome-Driven Innovation (Site Oficial da Strategyn) | Anthony W. Ulwick | N/A | https://strategyn.com/outcome-driven-innovation/ |
| 5 | What Customers Want: Using Outcome-Driven Innovation to Create Breakthrough Products and Services (Livro) | Anthony W. Ulwick | 2005 | ISBN-13: 978-0071408677 |
| 6 | Impact Mapping: The First Step Toward Outcome-Driven Development (Artigo de Blog/Opinião) | Andrew H. | 2024 | https://medium.com/@productandrew/impact-mapping-the-first-step-toward-outcome-driven-development-1b2fb6f255ab |
| 7 | An Impact Mapping Method to Generate Robust Qualitative Evaluation of Community-Based Research Programs (Artigo Acadêmico) | Melissa D. Olfert, et al. | 2018 | https://pmc.ncbi.nlm.nih.gov/articles/PMC6481053/ |
| 8 | Outcome-Driven Innovation and Smart Product-Service Systems: Case Evidence from a Sports Goods Manufacturer (Artigo Acadêmico/Caso de Estudo) | N/A | 2025 | https://www.researchgate.net/publication/396507305_Outcome-Driven_Innovation_and_Smart_Product-Service_Systems_Case_Evidence_from_a_Sports_Goods_Manufacturer |
| 9 | Identifying Service Opportunities Based on Outcome-Driven Innovation Framework and Deep Learning: a Case Study of Hotel Service (Artigo Acadêmico/Caso de Estudo) | S Nam, et al. | 2021 | https://www.mdpi.com/2071-1050/13/1/391 |
| 10 | OUTCOME DRIVEN INNOVATION IN THE CONTEXT OF BLENDED LEARNING... (Artigo Acadêmico/Caso de Estudo) | F Piller, S Brenk, H Nacken | 2017 | https://library.iated.org/view/PILLER2017OUT |
| 11 | ODI Strategies of Korea: In Comparison with Emerging and Advanced Markets (Artigo Acadêmico/Geográfico) | YJ Nam | 2016 | https://s-space.snu.ac.kr/handle/10371/129043 |
| 12 | A Critique of Outcome-Driven Innovation (Artigo Acadêmico/Crítica) | G Katz | 2016 | https://ams-insights.com/wp-content/uploads/2016/06/A-Critique-of-Outcome-Driven-Innovation%C2%AE.pdf |
| 13 | The Jobs To Be Done Playbook: Align Your Markets, Organization, and Strategy Around Customer Needs (Livro) | Jim Kalbach | 2020 | ISBN-13: 978-0990576744 |
| 14 | Impact Mapping: The First Step Toward Outcome-Driven Development (Comparação) | Andrew H. | 2024 | https://medium.com/@productandrew/impact-mapping-the-first-step-toward-outcome-driven-development-1b2fb6f255ab |
| 15 | Anthony Ulwick on Jobs-to-be-Done (Citação) | Gojko Adzic (via Ulwick) | 2012 | https://www.impactmapping.org/assets/impact_mapping_20121001_sample.pdf |

## Referências

[1]: https://www.impactmapping.org/ "Impact Mapping (Site Oficial)"
[2]: https://www.impactmapping.org/book.html "Impact Mapping: Making a Big Impact with Software Products and Projects (Livro)"
[3]: https://www.sciencedirect.com/science/article/pii/S2949697724000134 "Impact mapping tool for interdisciplinary research institutes"
[4]: https://strategyn.com/outcome-driven-innovation/ "Outcome-Driven Innovation (Site Oficial da Strategyn)"
[5]: https://www.amazon.com/What-Customers-Want-Outcome-Driven-Breakthrough/dp/0071408673 "What Customers Want: Using Outcome-Driven Innovation to Create Breakthrough Products and Services (Livro)"
[6]: https://medium.com/@productandrew/impact-mapping-the-first-step-toward-outcome-driven-development-1b2fb6f255ab "Impact Mapping: The First Step Toward Outcome-Driven Development (Artigo de Blog/Opinião)"
[7]: https://pmc.ncbi.nlm.nih.gov/articles/PMC6481053/ "An Impact Mapping Method to Generate Robust Qualitative Evaluation of Community-Based Research Programs (Artigo Acadêmico)"
[8]: https://www.researchgate.net/publication/396507305_Outcome-Driven_Innovation_and_Smart_Product-Service_Systems_Case_Evidence_from_a_Sports_Goods_Manufacturer "Outcome-Driven Innovation and Smart Product-Service Systems: Case Evidence from a Sports Goods Manufacturer (Artigo Acadêmico/Caso de Estudo)"
[9]: https://www.mdpi.com/2071-1050/13/1/391 "Identifying Service Opportunities Based on Outcome-Driven Innovation Framework and Deep Learning: a Case Study of Hotel Service (Artigo Acadêmico/Caso de Estudo)"
[10]: https://library.iated.org/view/PILLER2017OUT "OUTCOME DRIVEN INNOVATION IN THE CONTEXT OF BLENDED LEARNING... (Artigo Acadêmico/Caso de Estudo)"
[11]: https://s-space.snu.ac.kr/handle/10371/129043 "ODI Strategies of Korea: In Comparison with Emerging and Advanced Markets (Artigo Acadêmico/Geográfico)"
[12]: https://ams-insights.com/wp-content/uploads/2016/06/A-Critique-of-Outcome-Driven-Innovation%C2%AE.pdf "A Critique of Outcome-Driven Innovation (Artigo Acadêmico/Crítica)"
[13]: https://www.amazon.com/Jobs-be-Done-Theory-Practice/dp/0990576744 "The Jobs To Be Done Playbook: Align Your Markets, Organization, and Strategy Around Customer Needs (Livro)"
[14]: https://medium.com/@productandrew/impact-mapping-the-first-step-toward-outcome-driven-development-1b2fb6f255ab "Impact Mapping: The First Step Toward Outcome-Driven Development (Comparação)"
[15]: https://www.impactmapping.org/assets/impact_mapping_20121001_sample.pdf "Anthony Ulwick on Jobs-to-be-Done (Citação)"

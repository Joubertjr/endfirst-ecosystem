# Resumo Detalhado da Pesquisa: User Story Mapping e Product Roadmapping

## Introdução

Esta pesquisa aprofundada e abrangente explora os conceitos, metodologias e aplicações do **User Story Mapping (USM)** e do **Product Roadmapping (PRM)**. Ambas as práticas são pilares essenciais na gestão moderna de produtos, atuando em diferentes níveis de abstração e horizonte de tempo para garantir que as equipes construam o produto certo para os usuários certos. A análise foi baseada em 17 fontes, incluindo literatura acadêmica, livros fundamentais, frameworks empresariais e estudos de caso de diversas regiões geográficas.

## 1. User Story Mapping (USM): Foco na Jornada do Usuário

O User Story Mapping é uma técnica visual desenvolvida por Jeff Patton que transforma o *backlog* de produto, tradicionalmente plano e unidimensional, em uma estrutura bidimensional que mapeia a jornada do usuário [1]. Essa visualização hierárquica organiza as funcionalidades em uma "espinha dorsal" (*backbone*) que representa as atividades do usuário, detalhando-as em histórias de usuário e tarefas [13].

A principal contribuição do USM é promover um **entendimento compartilhado** (*shared understanding*) entre a equipe de desenvolvimento e os *stakeholders* [1]. Ao focar na história completa do usuário, o USM ajuda a equipe a priorizar o trabalho com base no valor entregue ao cliente e a evitar a construção de funcionalidades isoladas que não se encaixam na experiência geral [1].

> "User story mapping is a valuable tool for software development, once you understand why and how to use it." — Jeff Patton [1]

O USM é, portanto, uma ferramenta **tática** e de **descoberta de produto** (*product discovery*), ideal para o planejamento de *releases* e a coordenação do fluxo de trabalho da equipe, com um horizonte de tempo mais curto (foco no próximo *release* ou nos próximos 3 meses) [13].

## 2. Product Roadmapping (PRM): Alinhamento Estratégico

O Product Roadmapping é uma ferramenta de comunicação estratégica de alto nível que descreve a visão e a direção de um produto ao longo do tempo [10]. Ele serve para alinhar equipes, *stakeholders* e clientes em torno de onde o produto está indo e por quê [15].

A literatura acadêmica, como a revisão sistemática de Münch, Trieflinger e Lang (2019), destaca que o *roadmapping* tradicional enfrenta desafios em mercados altamente dinâmicos devido à baixa previsibilidade [4]. Em resposta, a tendência moderna é o **Roadmapping Orientado a Resultados** (*Outcome-Based Roadmapping*). Especialistas como Roman Pichler defendem o uso do *GO Product Roadmap*, que foca em metas e resultados de negócio (ex: aquisição, retenção, satisfação) em vez de apenas listar funcionalidades (*outputs*) [8].

Para auxiliar na priorização dos itens do *roadmap*, diversos **frameworks empresariais** são amplamente utilizados, incluindo:
*   **RICE** (Reach, Impact, Confidence, Effort)
*   **Kano Model** (Satisfação do Cliente)
*   **MoSCoW** (Must have, Should have, Could have, Won't have)
*   **Weighted Scoring Model** [9]

O PRM é, por natureza, uma ferramenta **estratégica** de longo prazo, com um horizonte de 6 a 18 meses, e sua estrutura é tipicamente organizada por Metas, Temas e *Releases* [13].

## 3. A Relação e a Distinção entre USM e PRM

A confusão entre *Story Maps* e *Product Roadmaps* é comum, mas a distinção é crucial para o sucesso do produto. O USM e o PRM não são substitutos, mas sim ferramentas complementares que operam em diferentes níveis de detalhe e para diferentes públicos [13].

O **User Story Mapping** atua como uma ferramenta de **entrada** e **validação** para o **Product Roadmap** [17]. O *Story Map* detalha a experiência do usuário e ajuda a identificar as histórias de maior valor, que então se tornam os temas ou *releases* no *Roadmap* estratégico.

A tabela a seguir resume as principais diferenças entre as duas práticas [13]:

| Aspecto | Product Roadmap | User Story Map |
| :--- | :--- | :--- |
| **Propósito** | Comunicação estratégica, alinhamento de negócios | Planejamento de fluxo de trabalho, coordenação de *release* |
| **Audiência** | Executivos, *stakeholders*, clientes | Equipes de produto, desenvolvedores, designers |
| **Horizonte de Tempo** | 6–18 meses, temas trimestrais | *Release* atual a ~3 meses |
| **Detalhe** | Temas de alto nível e resultados de negócio | Histórias detalhadas, critérios de aceitação |
| **Estrutura** | Metas → Temas → *Releases* | Jornada → Tarefas → Histórias → *Releases* |

## 4. Aplicações e Cobertura Geográfica

A pesquisa demonstrou a aplicabilidade das metodologias em diversos setores e contextos geográficos, indicando sua relevância global.

*   **Diversidade Setorial:** Embora amplamente utilizadas em software, as técnicas de *roadmapping* se estendem a outros domínios, como a manufatura (exemplo da AGCO) [10] e a integração de Inteligência Artificial [11].
*   **América Latina (Brasil):** O *Technology Roadmapping* foi aplicado com sucesso no Brasil para alinhar o desenvolvimento de biocombustíveis (biobutanol), demonstrando a adaptação da metodologia a contextos de tecnologia e sustentabilidade na região [6].
*   **África Subsaariana:** Há estudos de caso e guias práticos que aplicam o *Technology Roadmapping* para o mercado de refrigeração e aquecimento na África Subsaariana, e guias para criação de *roadmaps* no contexto africano, indicando a expansão da prática para mercados emergentes [7] [12].
*   **Europa e EUA:** A maior parte da literatura acadêmica e dos frameworks empresariais (Jeff Patton, Roman Pichler, Atlassian, O'Reilly) tem origem ou forte presença nos EUA e na Europa, consolidando essas regiões como centros de excelência e disseminação das práticas [1] [4] [8] [9].

## 5. Documentação Detalhada das Fontes

A tabela a seguir documenta as 17 fontes utilizadas para esta pesquisa, conforme os requisitos do escopo.

| ID | Título | Autor(es) | Ano | URL/Referência | Principais Contribuições |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1** | User Story Mapping: Discover the Whole Story, Build the Right Product | Jeff Patton | 2014 | O'Reilly Media, Inc. | Livro fundamental. Define USM como ferramenta de visualização da jornada do usuário e entendimento compartilhado. |
| **2** | Systematic literature mapping of user story research | (Não especificado) | 2022 (Est.) | IEEE Xplore (Snippet) | Revisão de literatura acadêmica sobre *user stories*. |
| **3** | The Ultimate Guide to User Story Mapping | Easy Agile (Blog) | 2024 | https://www.easyagile.com/blog/the-ultimate-guide-to-user-story-maps | Guia prático com definições, passos e ferramentas de USM. |
| **4** | Product Roadmap – From Vision to Reality: A Systematic Literature Review | J. Münch, S. Trieflinger, D. Lang | 2019 | IEEE Xplore (DOI: 10.1109/ICSA-C.2019.00030) | Revisão sistemática da literatura sobre PRM. Identifica lacunas em *outcomes* e *product discovery*. |
| **5** | Software product roadmapping in a volatile business environment | T. Suomalainen | 2011 | Information and Software Technology | Desenvolvimento de *framework* para PRM em ambientes voláteis. |
| **6** | Technology roadmapping for renewable fuels: case of biobutanol in Brazil | J. Natalense, D. Zouain | 2013 | Journal of technology management & innovation | Estudo de caso de *Technology Roadmapping* aplicado no Brasil. |
| **7** | Technology Roadmapping: Cooling and Heating in Sub-Saharan Africa | (Não especificado) | 2023 (Est.) | Springer (Snippet) | Aplicação de *Technology Roadmapping* no contexto da África Subsaariana. |
| **8** | The GO Product Roadmap | Roman Pichler | (Não especificado) | https://www.romanpichler.com/tools/the-go-product-roadmap/ | Framework de *Roadmapping* Orientado a Metas (*Goal-Oriented*). |
| **9** | Product Prioritization Frameworks | Atlassian, ProductPlan, Productboard, Pragmatic Institute | Variável | Diversas fontes empresariais | Documentação de frameworks de priorização (RICE, Kano, MoSCoW, etc.). |
| **10** | Product Roadmap Examples: 4 Real-World Manufacturing Approaches | Gocious (Blog) | 2025 | https://gocious.com/blog/product-roadmap-examples-4-real-world-manufacturing-approaches | Exemplos práticos de PRM na indústria de manufatura. |
| **11** | Case Studies of Successful AI and User Story Map Integrations | Dao Leo (Medium) | (Não especificado) | https://daoleo.medium.com/case-studies-of-successful-ai-and-user-story-map-integrations-5dbd7e93110f | Casos de estudo sobre a integração de USM com Inteligência Artificial. |
| **12** | Creating a Product Roadmap: A Live Demo to Guide You | Treford Africa | (Não especificado) | https://treford.africa/product/creating-a-product-roadmap/ | Guia prático de PRM com foco no contexto africano. |
| **13** | Story Map vs Product Roadmap: What's the Difference? | Nicky Clarke (SharpCloud Blog) | 2025 | https://www.sharpcloud.com/blog/story-map-vs-product-roadmap-whats-the-difference | Artigo que compara e distingue claramente os propósitos estratégico e tático das duas ferramentas. |
| **14** | Product Roadmaps Relaunched: How to Set Direction while Embracing Uncertainty | C. Todd Lombardo, B. McCarthy, E. Ryan, M. Connors | 2017 (Est.) | Kobo/Amazon (Mencionado) | Livro fundamental sobre a natureza estratégica do *roadmap*. |
| **15** | Empowered: Ordinary People, Extraordinary Products | Marty Cagan | 2020 (Est.) | Kobo/Amazon (Mencionado) | Livro de referência em *Product Management*, defendendo *roadmaps* baseados em resultados. |
| **16** | Product Development: The Essential Part of Your Software Product Manager Role | T. Wagenblatt | 2019 | Software Product Management: Finding the Right Balance, Springer | Contextualiza o USM como ferramenta essencial para o *Product Manager*. |
| **17** | User Story Mapping: A Guide for Product Roadmaps and Release Plans | (LinkedIn Advice) | 2023 | https://www.linkedin.com/advice/3/how-do-you-use-user-story-mapping-create-product | Guia prático sobre como o USM alimenta o PRM. |

## Referências

[1] Patton, J. (2014). *User Story Mapping: Discover the Whole Story, Build the Right Product*. O'Reilly Media, Inc.
[4] Münch, J., Trieflinger, S., & Lang, D. (2019). Product Roadmap – From Vision to Reality: A Systematic Literature Review. *2019 IEEE International Conference on Software Architecture Companion (ICSA-C)*.
[6] Natalense, J., & Zouain, D. (2013). Technology roadmapping for renewable fuels: case of biobutanol in Brazil. *Journal of technology management & innovation*.
[7] (Fonte não especificada). (2023). *Technology Roadmapping: Cooling and Heating in Sub-Saharan Africa*. Springer.
[8] Pichler, R. (s.d.). *The GO Product Roadmap*. Disponível em: https://www.romanpichler.com/tools/the-go-product-roadmap/
[9] Atlassian, ProductPlan, Productboard, Pragmatic Institute (s.d.). *Product Prioritization Frameworks*.
[10] Gocious (Blog). (2025). *Product Roadmap Examples: 4 Real-World Manufacturing Approaches*. Disponível em: https://gocious.com/blog/product-roadmap-examples-4-real-world-manufacturing-approaches
[11] Leo, D. (s.d.). *Case Studies of Successful AI and User Story Map Integrations*. Medium.
[12] Treford Africa (s.d.). *Creating a Product Roadmap: A Live Demo to Guide You*. Disponível em: https://treford.africa/product/creating-a-product-roadmap/
[13] Clarke, N. (2025). *Story Map vs Product Roadmap: What's the Difference?*. SharpCloud Blog. Disponível em: https://www.sharpcloud.com/blog/story-map-vs-product-roadmap-whats-the-difference
[15] Cagan, M. (2020). *Empowered: Ordinary People, Extraordinary Products*.
[17] (LinkedIn Advice). (2023). *User Story Mapping: A Guide for Product Roadmaps and Release Plans*. Disponível em: https://www.linkedin.com/advice/3/how-do-you-use-user-story-mapping-create-product

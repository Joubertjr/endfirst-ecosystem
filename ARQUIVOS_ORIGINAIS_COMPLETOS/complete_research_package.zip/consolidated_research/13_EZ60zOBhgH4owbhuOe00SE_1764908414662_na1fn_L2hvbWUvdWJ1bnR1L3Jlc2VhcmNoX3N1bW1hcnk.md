# Pesquisa Aprofundada: North Star Metric e Growth Hacking

## Introdução

Esta pesquisa aprofundada explora os conceitos interligados de **North Star Metric (NSM)** e **Growth Hacking (GH)**, que se estabeleceram como metodologias cruciais para o crescimento acelerado e sustentável de empresas, especialmente no setor de tecnologia. O objetivo é fornecer uma visão abrangente, baseada em fontes acadêmicas, publicações especializadas e casos de estudo, conforme solicitado. Foram identificadas 21 fontes relevantes para esta análise.

## 1. Growth Hacking: A Metodologia de Crescimento Acelerado

O Growth Hacking é mais do que um conjunto de táticas de marketing; é uma **mentalidade** e um **processo científico** rigoroso focado exclusivamente no crescimento [1]. O termo foi cunhado por Sean Ellis em 2010, que o definiu como um processo de experimentação rápida em canais de marketing e desenvolvimento de produto para identificar as formas mais eficientes de crescimento [1].

### 1.1. O Processo e a Equipe de Growth

A essência do Growth Hacking reside no **ciclo de experimentação** (Ideia -> Priorizar -> Testar -> Analisar), que deve ser executado por uma **Equipe de Crescimento (Growth Team)** multifuncional [1]. Essa equipe tipicamente reúne profissionais de marketing, engenharia, produto e análise de dados, garantindo que o crescimento seja uma responsabilidade de toda a empresa, e não apenas do departamento de marketing [1].

### 1.2. Frameworks e Aplicações

O framework mais emblemático associado ao Growth Hacking é o **AARRR** (Acquisition, Activation, Retention, Referral, Revenue), também conhecido como Métricas Piratas, criado por Dave McClure [4]. Este funil fornece uma estrutura para medir e otimizar as diferentes fases da jornada do cliente, orientando as experimentações de Growth [4, 6].

O Growth Hacking é cada vez mais reconhecido academicamente como um mecanismo que **preenche a lacuna** entre a definição da estratégia corporativa e sua execução prática, mitigando tensões entre diferentes áreas da empresa [2, 19]. Além disso, a metodologia está evoluindo com a integração de tecnologias avançadas, como a **Inteligência Artificial**, para refinar as táticas de crescimento e a tomada de decisão orientada por dados [7, 3].

## 2. North Star Metric (NSM): O Foco no Valor

A North Star Metric, ou Métrica Estrela-Guia, é a **métrica única** que melhor representa o **valor principal** que um produto ou serviço entrega aos seus clientes [8, 12]. Ela serve como o farol que guia todas as decisões e esforços da empresa, garantindo que o crescimento seja sustentável e centrado no cliente.

### 2.1. Alinhamento e Propósito

O papel fundamental da NSM é **unificar** e **alinhar** toda a organização em torno de um único objetivo de crescimento [11]. Ao focar em uma métrica que reflete o valor entregue, a empresa evita as chamadas "métricas de vaidade" e concentra seus recursos no que realmente impulsiona o sucesso a longo prazo [9].

A NSM deve ser um **indicador líder** (leading indicator) de resultados de negócios, e não um indicador atrasado (lagging indicator) como a receita. Ela é frequentemente definida como uma função de três componentes: **Amplitude** (quantos usuários), **Frequência** (com que frequência usam) e **Profundidade** (o quão engajados estão) [8].

### 2.2. NSM em Contextos Metodológicos e Casos de Estudo

O conceito de NSM tem sido integrado a metodologias de gestão de projetos, como o Scrum, onde pode ser usada para modelar o *Product Goal*, garantindo que o desenvolvimento esteja focado no valor para o cliente [12].

A NSM não é imutável. O caso da **Netflix** ilustra essa evolução: a métrica mudou de "número de DVDs alugados" para "tempo gasto pelos assinantes assistindo a conteúdo de streaming", refletindo a transição do modelo de negócio [15]. Outros exemplos de NSMs de líderes de mercado incluem:

| Empresa | North Star Metric (NSM) | Valor Entregue | Fonte |
| :--- | :--- | :--- | :--- |
| **Slack** | Mensagens enviadas dentro da organização | Comunicação e colaboração eficientes | [14] |
| **HubSpot** | Número de clientes que adotam 5+ recursos | Sucesso do cliente com a plataforma | [14] |
| **Facebook** | Usuários ativos diários (DAU) | Conexão social e engajamento | [13] |
| **Amazon** | Número de compras mensais | Facilidade e conveniência de compra | [13] |

## Conclusão

O Growth Hacking e a North Star Metric são conceitos simbióticos. O GH fornece a **metodologia de experimentação** para encontrar as táticas que otimizam a NSM, enquanto a NSM fornece o **foco estratégico** para guiar os esforços do GH. Juntos, eles formam uma abordagem poderosa e orientada por dados para o crescimento sustentável e a criação de valor.

## Fontes Documentadas (Total: 21)

A tabela a seguir lista as 21 fontes utilizadas na pesquisa, incluindo publicações acadêmicas, livros e artigos especializados.

| ID | Título | Autor(es) | Ano | Tipo | Referência/URL |
| :--- | :--- | :--- | :--- | :--- | :--- |
| [1] | Hacking Growth: How Today's Fastest-Growing Companies Drive Breakout Success | Sean Ellis e Morgan Brown | 2017 | Livro | [Amazon Link](https://www.amazon.com/Hacking-Growth-Fastest-Growing-Companies-Breakout/dp/045149721X) |
| [2] | Growth hacking: A critical review to clarify its meaning and guide its practical application | A. Bargoni | 2024 | Artigo Acadêmico | [ScienceDirect Link](https://www.sciencedirect.com/science/article/pii/S0040162523007965) |
| [3] | Growth hacking: A scientific approach for data-driven decision making | M. Cristofaro | 2025 | Artigo Acadêmico | [ScienceDirect Link](https://www.sciencedirect.com/science/article/pii/S0148296324005344) |
| [4] | What Is AARRR? Pirate Metrics Defined. | Dave McClure (Criador do Framework) | 2007/2025 | Artigo Especializado | [BuiltIn Link](https://builtin.com/articles/aarrr) |
| [5] | The Framework Of Growth Hacking: Deviating From The Marketing Playbook | Sujan Patel | 2016 | Artigo Especializado | [Forbes Link](https://www.forbes.com/sites/sujanpatel/2016/07/13/the-framework-of-growth-hacking-deviating-from-the-marketing-playbook/) |
| [6] | Optimizing the Growth Hacking Funnel for startups: A case study of We Encourage Oy | T. Nguyen | 2020 | Estudo de Caso | [Theseus Link](https://www.theseus.fi/handle/10024/340224) |
| [7] | Short Review: Artificial Intelligence Applications in Growth Hacking Methodology | Desconhecido | Desconhecido | Artigo Acadêmico | [IJADSEH Link](https://ijadseh.com/index.php/ijadseh/article/view/36) |
| [8] | The North Star Playbook | Amplitude | Desconhecido | Publicação Empresarial | [Amplitude Link](https://info.amplitude.com/rs/138-CDN-550/images/Amplitude-The-North-Star-Playbook.pdf) |
| [9] | Métricas de Produto Digital: Como Transformar Dados em Decisões Estratégicas | Desconhecido | Desconhecido | Livro | [Amazon Link](https://www.amazon.com/-/es/M%C3%A9tricas-Produto-Digital-Transformar-Estrat%C3%A9gicas/dp/B0DWKJQD65) |
| [10] | Data+ intuition: A hybrid approach to developing product north star metrics | A.C. Chen, X. Fu | 2017 | Artigo Acadêmico | [ACM Link](https://dl.acm.org/doi/abs/10.1145/3041021.3054199) |
| [11] | Effects of the North Star Metric on Software Project Management | A. Ponomarev | Desconhecido | Estudo de Caso/Tese | [ResearchGate Link](https://www.researchgate.net/publication/369825604_Effects_of_the_North-Star-Metric-on-Software-Project-Management-A-case-study) |
| [12] | Modelling Scrum Product Goal with North Star Metric Approach | F. Gracia-Ahufinger, J.J. Gutiérrez | 2025 | Artigo Acadêmico | [Springer Link](https://link.springer.com/chapter/10.1007/978-3-032-09704-0_34) |
| [13] | 'North Star Metric' examples of tech industry leaders | Growth Academy | Desconhecido | Artigo Especializado | [Growth Academy Link](https://www.growth-academy.com/north-star-metric-examples) |
| [14] | North Star Metrics: Success Stories about Slack and HubSpot | Hello Mr. Lead | Desconhecido | Estudo de Caso | [Hello Mr. Lead Link](https://www.hellomrlead.com/en/slack-hubspot-north-star-metrics/) |
| [15] | Netflix has changed its North Star Metric (NSM) | Strtgy.Design | 2024 | Artigo Especializado | [Strtgy.Design Link](https://strtgy.design/en/strtgy-notes-en/netflix-has-changed-its-north-star-metric-nsm/) |
| [16] | Experimentation and the North Star Metric | Microsoft Research | 2023 | Artigo Especializado | [Microsoft Research Link](https://www.microsoft.com/en-us/research/group/dynamics-insights-apps-artificial-intelligence-machine-learning/articles/experimentation-and-the-north-star-metric/) |
| [17] | The Growth Hacking Book 2: 100+ Strategies for Scaling Your Business | Desconhecido (Compilação) | Desconhecido | Livro | [Amazon Link](https://www.amazon.com/Growth-Hacking-Book-Strategies-Scaling/dp/154460242X) |
| [18] | Growth Hacking Explained: Methods, Metrics, and Mindsets | Dominica Evans | Desconhecido | Artigo Especializado | [LinkedIn Pulse Link](https://www.linkedin.com/pulse/growth-hacking-explained-methods-metrics-mindsets-dominica-evans-uom5e) |
| [19] | Business model scaling and growth hacking in digital ventures | A. Cavallo | 2024 | Artigo Acadêmico | [Taylor & Francis Online Link](https://www.tandfonline.com/doi/full/10.1080/00472778.2023.2195463) |
| [20] | Growth hacking ea importância de seus processos para o desenvolvimento de startups | L.H. Bianchini | 2020 | Artigo Acadêmico (Brasil) | [Revista FAE Link (Brasil)](https://revistafae.fae.emnuvens.com.br/revistafae/article/view/680) |
| [21] | Hacking Growth. a Estrategia de Marketing Inovadora das Empresas de Crescimento Acelerado | Sean Ellis e Morgan Brown | Desconhecido | Livro (Edição Brasileira) | [Amazon Brasil Link](https://www.amazon.com.br/Hacking-Growth-Estrategia-Marketing-Inovadora/dp/8550804452) |

## Cobertura Geográfica

As fontes primárias e secundárias analisadas indicam uma forte concentração de pensamento e aplicação nos **Estados Unidos** (Vale do Silício, onde o GH e a NSM se originaram) e na **Europa** (com artigos acadêmicos e estudos de caso da Itália, Finlândia e Reino Unido). A inclusão de artigos acadêmicos e edições de livros em português (Brasil) demonstra a relevância e a adoção desses conceitos na **América Latina**.

**Regiões e países representados nas fontes:** EUA, Europa (Itália, Finlândia, Reino Unido), América Latina (Brasil).

# Resumo Detalhado da Pesquisa: Balanced Scorecard e Strategy Maps (Kaplan & Norton)

## Área Temática
**Balanced Scorecard (BSC) e Strategy Maps** (Mapas Estratégicos), conforme desenvolvidos por Robert S. Kaplan e David P. Norton, são frameworks de gestão estratégica que visam traduzir a visão e a estratégia de uma organização em um conjunto coerente de medidas de desempenho.

## Conceitos-Chave e Insights

### Balanced Scorecard (BSC)
O BSC é um sistema de gestão estratégica que vai além das medidas financeiras tradicionais, incorporando indicadores de desempenho de quatro perspectivas inter-relacionadas:

1.  **Financeira:** Mede os resultados econômicos da estratégia (ex: rentabilidade, crescimento de receita).
2.  **Cliente:** Mede o valor entregue aos clientes (ex: satisfação, retenção, participação de mercado).
3.  **Processos Internos:** Mede a excelência dos processos críticos que criam valor para os clientes e acionistas (ex: qualidade, tempo de ciclo, inovação).
4.  **Aprendizado e Crescimento (ou Infraestrutura):** Mede os ativos intangíveis necessários para sustentar a melhoria contínua e a inovação (ex: capital humano, capital de informação, clima organizacional).

**Insight Principal:** O BSC transforma a estratégia em ação ao alinhar as atividades diárias dos colaboradores com os objetivos de longo prazo da organização, garantindo que a medição do desempenho seja "balanceada" entre indicadores de resultados (lagging indicators) e indicadores de direcionamento (leading indicators).

### Strategy Maps (Mapas Estratégicos)
Strategy Maps são uma representação visual das relações de causa e efeito entre os objetivos estratégicos nas quatro perspectivas do BSC.

**Insight Principal:** O mapa estratégico é a **espinha dorsal** do sistema de gestão estratégica, pois torna explícita a hipótese da estratégia. Ele demonstra como a melhoria nos ativos intangíveis (perspectiva de Aprendizado e Crescimento) leva a processos internos aprimorados, que por sua vez melhoram o valor para o cliente, culminando em melhores resultados financeiros.

### Aplicações e Contribuições
*   **Setor Público:** O framework foi adaptado para o setor público, substituindo a perspectiva Financeira por uma perspectiva de **Valor para o Cidadão/Comunidade**, focando em eficiência, eficácia e efetividade.
*   **Tecnologia da Informação (TI):** O BSC é amplamente utilizado para alinhar a estratégia de TI com a estratégia de negócios, garantindo que os investimentos em tecnologia suportem diretamente os objetivos organizacionais.
*   **América Latina:** Há uma significativa produção acadêmica e casos de estudo na América Latina (especialmente Brasil) sobre a aplicação e adaptação do BSC e Strategy Maps em diversos setores, incluindo o público e o atacadista.

## Fontes Documentadas (Total: 18)

| ID | Título | Autor(es) | Ano | URL/Referência | Principais Conceitos e Contribuições | Citações Relevantes |
| :---: | :--- | :--- | :---: | :--- | :--- | :--- |
| 1 | The Balanced Scorecard—Measures that Drive Performance | Robert S. Kaplan, David P. Norton | 1992 | HBR Article, [Link](https://hbr.org/1992/01/the-balanced-scorecard-measures-that-drive-performance-2) | Artigo seminal que introduziu o conceito do BSC e as quatro perspectivas. | "The balanced scorecard tracks all the important elements of a company's strategy..." |
| 2 | Putting the Balanced Scorecard to Work | Robert S. Kaplan, David P. Norton | 1993 | HBR Article, [Link](http://www.simonfoucher.com/MBA/MBA%20622%20-%20Strategy%202/Week%203/Putting_the_Balance_Scorecard_to_Work_Kaplan_Norton.pdf) | Detalha o uso do BSC como um sistema de gestão estratégica, não apenas de medição. | "Using the Balanced Scorecard as a Strategic Management System." |
| 3 | The Balanced Scorecard: Translating Strategy into Action | Robert S. Kaplan, David P. Norton | 1996 | Book, Harvard Business School Press | Obra fundamental que expande o conceito do BSC para um sistema de gestão completo. | "The Balanced Scorecard translates a company's vision and strategy into performance measures..." |
| 4 | Strategy Maps: Converting Intangible Assets into Tangible Outcomes | Robert S. Kaplan, David P. Norton | 2004 | Book, Harvard Business School Press | Introdução e detalhamento dos Strategy Maps como ferramenta para visualizar a estratégia e as relações de causa e efeito. | "Strategy Maps: Converting Intangible Assets into Tangible Outcomes." |
| 5 | The Explainer: The Balanced Scorecard | HBR Video | 2014 | HBR Video, [Link](https://hbr.org/video/3633937148001/the-explainer-the-balanced-scorecard) | Visão geral e explicação concisa do conceito do BSC. | "Kaplan and Norton's concept of the balanced scorecard revolutionized conventional thinking about performance metrics." |
| 6 | A estratégia em ação: balanced scorecard | Robert S. Kaplan, David P. Norton | 1997 (Ed. Brasileira) | Livro, Campus | Edição brasileira do livro de 1996, facilitando a disseminação no Brasil. | "Por mais abrangente e completo que seja, o livro ainda é uma espécie de relatório de progresso." |
| 7 | RESENHA DO LIVRO: MAPAS ESTRATÉGICOS... | Autor não especificado (Revisor) | S/D | Artigo Acadêmico (Resenha), [Link](https://ojsrevista.furb.br/ojs/index.php/rn/article/view/274) | Análise crítica da obra "Strategy Maps". | "O livro de Kaplan e Norton aqui analisado divide-se em cinco partes." |
| 8 | Mapas estratégicos do balanced scorecard em organizações de saúde: uma abordagem via Dinâmica de Sistemas | Autor não especificado (Tese) | S/D | Tese Acadêmica, [Link](https://www.bdtd.uerj.br:8443/handle/1/8149) | Estudo de caso sobre a aplicação de Strategy Maps em saúde, utilizando Dinâmica de Sistemas. | "dynamic strategy map was compared to a traditional map." |
| 9 | BALANCED SCORECARD UMA ANÁLISE SOB A PERSPECTIVA BIBLIOMETRICA... | Autor não especificado | S/D | Artigo Acadêmico | Análise bibliométrica das publicações sobre BSC em periódicos A1. | "produção de artigos com o tema BSC e na ausência dos 179 artigos da HBR restaria 92..." |
| 10 | O balanced scorecard como framework para a ação estratégica | Autor não especificado | S/D | Artigo Acadêmico, [Link](https://www.redalyc.org/pdf/3312/331227120008.pdf) | Discussão sobre o BSC como ferramenta para a execução da estratégia. | "documentados através de artigos adicionais na revista de negócios da Universidade de Harvard..." |
| 11 | Gestão de desempenho e aplicação do Balanced Scorecard... | Vernica Scalet Grillo | S/D | Artigo/Relatório (INCRA), [Link](https://www.gov.br/incra/pt-br/centrais-de-conteudos/publicacoes/VernicaScaletGrillo.pdf) | Estudo de caso sobre a aplicação do BSC em uma autarquia federal brasileira (INCRA). | "identificar as dificuldades e desafios na implantação de sistemas de gestão de avaliação de desempenho." |
| 12 | A Utilização do Balanced Scorecard no Setor Público | Autor não especificado | S/D | Artigo Acadêmico (SBAP), [Link](https://sbap.org.br/ebap-2023/anais/documento_final-226.pdf) | Análise das adaptações necessárias do BSC para o contexto do setor público. | "sugestão de rótulos alternativos para aplicação no setor público é comum e natural." |
| 13 | O Balanced Scorecard Aplicado à Administração Pública | Autor não especificado (Tese) | 2009 | Tese Acadêmica, [Link](https://repositorio-aberto.up.pt/bitstream/10216/20596/2/TESEFINAL.pdf) | Estudo sobre a utilidade do BSC em instituições públicas, originalmente privadas. | "analisar a utilidade de um sistema de gestão estratégica, o Balanced Scorecard, que foi criado para a aplicação em instituições privadas." |
| 14 | Adaptando o BSC para o setor público utilizando os... | S Ghelman | S/D | Artigo Acadêmico, [Link](https://www.aedb.br/seget/arquivos/artigos06/422_Adapt%20BSC%20efic%20eficacia%20e%20efetivid.pdf) | Adaptação do BSC para o setor público, focando em eficácia, eficiência e efetividade. | "O Balanced Scorecard é uma metodologia de medição e avaliação do desempenho organizacional que vem sendo exaustivamente utilizada no setor privado." |
| 15 | A Study on the Use of the Balanced Scorecard for Strategy... | RVD Jordão | 2013 | Artigo Acadêmico (Scielo), [Link](https://www.scielo.cl/pdf/jotmi/v8n3/art09.pdf) | Análise do uso do BSC como parte de um sistema de controle gerencial para implementação de estratégias. | "The research described in this paper has analyzed the use of the balanced scorecard (BSC) as part of a management control system..." |
| 16 | O Balanced Scorecard e o alinhamento estratégico da tecnologia da informação: um estudo de casos múltiplos | Autor não especificado | S/D | Artigo Acadêmico (Scielo), [Link](https://www.scielo.br/j/rcf/a/3jV5ZRB5RMTZfvwv8hpTxHx/) | Estudo de casos sobre o alinhamento da TI com a estratégia de negócios via BSC. | "O Balanced Scorecard e o alinhamento estratégico da tecnologia da informação: um estudo de casos múltiplos." |
| 17 | Balanced ScoreCard aplicado aos serviços de TI | Autor não especificado | S/D | Artigo Empresarial, [Link](https://hdibrasil.com.br/conteudo/balanced-scorecard-aplicado-aos-servicos-de-ti) | Aplicação prática do BSC para gerenciamento de serviços de TI. | "Na elaboração e avaliação de seus processos empresariais internos, o Balanced Scorecard recomenda focar em três áreas principais: inovação, operações e serviço." |
| 18 | Roteiro para implantação de Balanced Scorecard: estudo de caso em pequena empresa | Ib Silva | S/D | Artigo Acadêmico, [Link](https://www.researchgate.net/profile/Ib-Silva/publication/276325657_Roteiro_para_Implantacao_de_Balanced_Scorecard_Estudo_de_Caso_em_Pequena_Empresa/links/567ae2a908ae1e63f1df7442/Roteiro-para-Implantacao-de-Balanced-Scorecard-Estudo-de-Caso-em-Pequena-Empresa.pdf?_sg%5B0%5D=started_experiment_milestone&origin=journalDetail) | Estudo de caso focado na implementação do BSC em pequenas empresas. | "A utilização do Balanced Scorecard (BSC) tem possibilitado resultados positivos..." |

## Cobertura Geográfica
As fontes abrangem principalmente os **Estados Unidos (EUA)**, onde o framework foi desenvolvido, e o **Brasil** e a **América Latina**, que demonstram um forte interesse acadêmico e prático na aplicação e adaptação do BSC e Strategy Maps, especialmente no setor público.

**Regiões/Países:** EUA, Brasil, América Latina (Geral)

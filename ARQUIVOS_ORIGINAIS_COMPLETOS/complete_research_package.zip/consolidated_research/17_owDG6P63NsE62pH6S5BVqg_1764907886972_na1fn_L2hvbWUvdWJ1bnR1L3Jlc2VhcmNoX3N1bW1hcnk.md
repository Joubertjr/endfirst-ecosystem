# Resumo Detalhado da Pesquisa: Outcome-based Planning vs Output-based Planning

## Introdução: A Mudança de Paradigma na Gestão

A distinção entre **planejamento baseado em resultados (Outcome-based Planning)** e **planejamento baseado em entregas (Output-based Planning)** representa uma mudança fundamental no pensamento estratégico e na gestão de projetos, produtos e políticas públicas. Enquanto o planejamento tradicional focado em *output* prioriza a produção de bens e serviços (o "o quê" é feito), o planejamento focado em *outcome* concentra-se no impacto e na mudança de comportamento gerada por essas entregas (o "porquê" e o "o que muda") [1] [2].

O objetivo desta pesquisa foi realizar um levantamento abrangente sobre o tema, identificando seus fundamentos teóricos, aplicações setoriais e cobertura geográfica, com base em 17 fontes relevantes, incluindo literatura acadêmica, metodologias empresariais e documentos governamentais.

## Conceitos-Chave: Output, Outcome e Impacto

A principal contribuição teórica reside na clara diferenciação entre os termos. **Output** é definido como o que a equipe produz ou entrega — métricas de atividade, como o número de funcionalidades lançadas, linhas de código, ou a construção de uma infraestrutura [1] [3]. Em contraste, o **Outcome** é a mudança mensurável no comportamento de um usuário, cliente ou beneficiário que resulta dessas entregas, impulsionando um valor positivo para a organização ou sociedade [1] [2].

Joshua Seiden, em seu livro seminal, define o *outcome* como a **mudança no comportamento do cliente** que serve como a métrica-chave para o sucesso do negócio [2].

> "A project has to have a goal, otherwise, how do you know you're done? In the world of product development, that goal should be an outcome." [2]

A tabela a seguir sintetiza as diferenças centrais entre as duas abordagens de planejamento:

| Característica | Planejamento Baseado em Entregas (Output) | Planejamento Baseado em Resultados (Outcome) |
| :--- | :--- | :--- |
| **Foco Principal** | Atividades, tarefas, funcionalidades, bens e serviços produzidos. | Mudança de comportamento, valor gerado, impacto real no mundo. |
| **Métrica de Sucesso** | Quantidade de produção (ex: 10 funcionalidades entregues, 1 escola construída). | Efetividade e valor (ex: Aumento de 15% nas vendas, aumento da alfabetização feminina) [1] [3]. |
| **Horizonte Temporal** | Curto prazo, focado na conclusão da atividade [7]. | Longo prazo, focado na sustentabilidade do impacto [7]. |
| **Risco** | Risco de construir algo que ninguém usa (funcionalidades não utilizadas) [1]. | Risco de não conseguir atribuir o resultado à entrega específica (problema de atribuição) [1]. |

## Aplicações Setoriais e Metodologias

O planejamento baseado em resultados transcendeu o domínio do desenvolvimento de software e se estabeleceu em diversos setores:

1.  **Desenvolvimento de Produto e Gestão Ágil:** O movimento *Outcome Over Output* ganhou força no contexto ágil e de desenvolvimento de produto. Martin Fowler argumenta que focar em *outcome* é crucial para a eficácia, pois evita o esforço desperdiçado em funcionalidades de baixa utilidade [1]. Metodologias como o **DSDM (Dynamic Systems Development Method)** adotam o planejamento baseado em resultados como um princípio central, criando um *framework* de empoderamento para as equipes [4].
2.  **Políticas Públicas e Desenvolvimento Internacional:** Organizações como o **Programa das Nações Unidas para o Desenvolvimento (UNDP)** e governos nacionais utilizam o *outcome-based planning* para garantir que os fundos públicos e as políticas gerem impacto social real. Por exemplo, o planejamento focado no aumento da alfabetização feminina (*outcome*) é preferido em relação à simples construção de uma escola (*output*) [3]. Essa abordagem foi adotada em estratégias nacionais no **Qatar** (NDS2) [10] e no setor público da **África do Sul** [9].
3.  **Setor Social e ONGs:** O modelo **Outcome-Based Planning and Evaluation (OBPE)** é amplamente utilizado em bibliotecas públicas e organizações sem fins lucrativos (ONGs) para medir o impacto de seus serviços na comunidade [5] [16].

## Cobertura Geográfica e Perspectivas Críticas

A pesquisa revelou uma ampla adoção global do conceito, com fontes originárias de diversas regiões:

*   **América do Norte/Europa:** EUA (Hanford Site, ONGs) [13] [16], Europa (Metodologia DSDM) [4].
*   **África:** África do Sul (Setor Público) [9], África Subsaariana (CAADP, política alimentar) [8].
*   **Ásia/Oriente Médio:** Qatar (Estratégia Nacional) [10], Índia (Governo de Karnataka, saúde) [11], Coreia do Sul (Educação) [12].
*   **América Latina:** Brasil (Administração Pública, EnANPAD) [17], Organização Pan-Americana da Saúde (OPAS/PAHO) [15].

Apesar da ampla aceitação, o conceito não está isento de críticas. A aplicação do planejamento baseado em resultados na educação, conhecida como **Educação Baseada em Resultados (OBE)**, foi criticada por reduzir o processo de ensino-aprendizagem a uma forma de "engenharia humana" e procedimentos de planejamento quase-científicos, ignorando a complexidade inerente à educação [14].

## Conclusão

O planejamento baseado em resultados representa uma evolução na gestão, deslocando o foco da mera atividade para o valor e o impacto gerado. Embora apresente desafios, como a dificuldade de atribuição e a necessidade de métricas mais complexas, a sua adoção em setores tão diversos quanto o desenvolvimento de produtos, políticas públicas e o setor social demonstra o reconhecimento de que o sucesso deve ser medido pela **mudança positiva** que se consegue provocar, e não apenas pela quantidade de coisas que se produz.

---

## Fontes Documentadas

[1] **Fowler, M.** (2020). *Outcome Over Output*. Disponível em: https://martinfowler.com/bliki/OutcomeOverOutput.html
[2] **Seiden, J.** (2019). *Outcomes Over Output: Why Customer Behavior Is The Key Metric For Business Success*. ISBN 978-1091173265.
[3] **UNDP.** (2018). *Evaluation Report (LADP)*. Disponível em: https://info.undp.org/docs/pdc/Documents/IRQ/Final%20_Evaluation_report_LADP_final.pdf
[4] **Agile Business Consortium.** (Contínuo). *DSDM Project Framework (Chapter 16: Project Planning and Control)*. Disponível em: https://www.agilebusiness.org/dsdm-project-framework/project-planning-and-control.html
[5] **Gross, M., Mediavilla, C., & Walter, V.A.** (2016). *Five steps of outcome-based planning and evaluation for public libraries*. Google Books / ALA Editions.
[6] **Chawla, A.** (2024). *Outcome-Based Policymaking*. Taylor & Francis (DOI: 10.4324/9781032626413-25).
[7] **Amplitude.** (2020). *Sustainable Product Strategy: How to Move from Outputs to Outcomes*. Disponível em: https://amplitude.com/blog/move-from-outputs-to-outcomes
[8] **Badiane, O., Odjo, S.P., & Ulimwengu, J.M.** (2010). *Building Capacities for Evidence and Outcome-based Food Policy Planning and Implementation*. Disponível em: https://cgspace.cgiar.org/bitstreams/5027f9c8-3569-4c32-99a3-d47107b3697b/download
[9] **Matlou, K.H.** (Estimado 2015-2018). *THE STRATEGIC PLANNING PROCESS OF GCIS (2012-...)*. Disponível em: https://wiredspace.wits.ac.za/bitstreams/72dac2ed-cea8-4431-b056-dc36bac21f75/download
[10] **National Planning Council (NPC), Qatar.** (2018). *Qatar Second National Development Strategy 2018~2022 (NDS2)*. Disponível em: https://www.npc.qa/en/planning/Documents/nds2/NDS2Final.pdf
[11] **Governo de Karnataka, Índia.** (Estimado 2019-2021). *Outcome based Planning, Monitoring and Evaluation in Karnataka*. Disponível em: https://planning.karnataka.gov.in/storage/pdf-files/Economic%20Survey/Chapter%20Eng%2019.pdf
[12] **Lee, D.** (2022). *A comparison of input- and output-based planning on the oral performance of low-proficiency EFL college students*. ScienceDirect (DOI: S0346251X22001427).
[13] **Ballard, W.W., Holten, R., Johnson, W., & Reichmuth, B., et al.** (2002). *Outcome-Based Planning-Hanford's Shift Towards Closure and Shrinking the Hanford Site*. Disponível em: archivedproceedings.econference.io/wmsym/2002/Proceedings/24/103.pdf
[14] **McKernan, J.** (1993). *Some Limitations of Outcome-Based Education*. ERIC (ID: EJ465316).
[15] **OPAS/PAHO.** (2013). *52º Conselho Diretor - Plano Estratégico*. Disponível em: https://www.paho.org/sites/default/files/CD52-FR-p.pdf
[16] **Zorloni, A.** (2011). *Designing a Strategic Framework to Assess Museum Activities*. Academia.edu / International Journal of Arts Management.
[17] **Erig, R.** (2007). *Inter-relacionamento entre planejamento estratégico e orçamento: um estudo de caso em uma organização pública*. Repositório Jesuíta (UNISINOS).

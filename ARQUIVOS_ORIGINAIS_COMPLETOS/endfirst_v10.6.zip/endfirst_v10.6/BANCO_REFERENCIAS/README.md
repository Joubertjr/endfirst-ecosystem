# 🗂️ Banco de Referências - Como Usar

**Versão:** 1.1  
**Data:** 19 de Dezembro de 2025

---

## 🎯 O Que É o Banco de Referências?

O Banco de Referências é o **"cérebro" do método ENDFIRST**. É um sistema de gestão de conhecimento que armazena:

- ✅ Especificações técnicas de projetos finalizados
- ✅ Análises de arquitetura e trade-offs
- ✅ Casos de uso documentados
- ✅ Aprendizados e retrospectivas
- ✅ Templates e frameworks reutilizáveis

**Objetivo:** Transformar aprendizados implícitos em conhecimento explícito e reutilizável entre projetos.

---

## 📁 Estrutura do Banco

```
BANCO_REFERENCIAS/
├── README.md (este arquivo)
├── INDICE.md (índice de todos os projetos)
└── projetos/
    ├── google_store_v2.1/     (Exemplo: sistema de banco de referências)
    ├── seu_projeto_1/         (Seus projetos documentados)
    └── seu_projeto_2/
```

---

## 🔄 Como Funciona o Fluxo?

### **1. Ao Iniciar um Novo Projeto:**

1. **Consulte o banco:** Leia `INDICE.md` e busque projetos similares
2. **Reutilize conhecimento:** Use especificações, análises e templates
3. **Evite erros:** Aprenda com os aprendizados documentados

**Exemplo no Cursor AI:**
```
@BANCO_REFERENCIAS/INDICE.md
"Existe algum projeto similar a um sistema de gestão de tarefas?"
```

---

### **2. Durante o Projeto:**

1. **Documente decisões importantes** (análise de arquitetura, trade-offs)
2. **Registre obstáculos e soluções**
3. **Mantenha um log de aprendizados**

**Dica:** Use `PROJETOS/` como workspace temporário.

---

### **3. Ao Finalizar o Projeto:**

1. **Crie a documentação completa** seguindo `GUIAS/COMO_DOCUMENTAR_PROJETOS.md`
2. **Mova o projeto de `PROJETOS/` para `BANCO_REFERENCIAS/projetos/`**
3. **Atualize o `INDICE.md`** com metadados do novo projeto

**Estrutura recomendada por projeto:**
```
projetos/meu_projeto/
├── README.md                      (Visão geral do projeto)
├── especificacao_tecnica.md       (Requisitos funcionais e não-funcionais)
├── analise_arquitetura.md         (Comparação de abordagens + decisão)
├── roadmap.md                     (Fases de implementação)
├── custos.md                      (Estimativa de custos)
├── testes.md                      (Estratégia de testes)
└── aprendizados.md                (O que funcionou, o que não funcionou)
```

---

## 📚 Exemplo Prático Incluído

O pacote já inclui um exemplo completo:

📂 **`projetos/google_store_v2.1/`**

**Contém:**
- ✅ Especificação técnica (12 RF + 8 RNF)
- ✅ Modelo de dados (PostgreSQL)
- ✅ Roadmap de 3 fases (MVP, Beta, Produção)
- ✅ Estimativa de custos por fase
- ✅ Estratégia de testes completa

**Use como referência para documentar seus projetos!**

---

## 🔍 Como Buscar no Banco?

### **Opção 1: Consultar o Índice**

Abra `INDICE.md` e procure por:
- **Tags:** `RAG`, `PostgreSQL`, `FastAPI`, etc.
- **Tipo de projeto:** Sistema web, API, mobile app
- **Stack tecnológico:** Next.js, Python, React

### **Opção 2: Usar o Cursor AI** ⭐

```
@BANCO_REFERENCIAS
"Quais projetos usaram PostgreSQL e FastAPI?"
```

```
@BANCO_REFERENCIAS/projetos/google_store_v2.1
"Como foi feita a análise de arquitetura neste projeto?"
```

---

## ✅ Checklist de Documentação

Ao adicionar um projeto ao banco, certifique-se de incluir:

- [ ] README.md com visão geral
- [ ] Especificação técnica (RF + RNF)
- [ ] Análise de arquitetura (matriz de decisão)
- [ ] Roadmap de implementação
- [ ] Estimativa de custos
- [ ] Estratégia de testes
- [ ] Aprendizados documentados
- [ ] Metadados no INDICE.md (tags, stack, status)

---

## 🎓 Por Que Documentar?

### **Benefícios:**

1. **Acelera projetos futuros:** Reutilize especificações e análises
2. **Evita erros repetidos:** Aprenda com o passado
3. **Melhora a qualidade:** Decisões documentadas são mais consistentes
4. **Facilita onboarding:** Novos membros entendem o contexto rapidamente
5. **Cria um ativo de conhecimento:** Seu "segundo cérebro"

### **Custo:**

- 2-4 horas de documentação ao final do projeto
- Retorno: 10-20 horas economizadas no próximo projeto similar

---

## 🚀 Comece Agora!

1. **Leia o índice:** `INDICE.md`
2. **Explore o exemplo:** `projetos/google_store_v2.1/`
3. **Documente seu próximo projeto:** Use `GUIAS/COMO_DOCUMENTAR_PROJETOS.md`

---

**O Banco de Referências cresce com cada projeto que você documenta!** 🧠  
**Quanto mais você adiciona, mais valor você extrai.** 🚀

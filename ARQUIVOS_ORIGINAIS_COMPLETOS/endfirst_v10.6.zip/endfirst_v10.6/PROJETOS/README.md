# 💼 PROJETOS - Seu Workspace

**Este é o seu espaço de trabalho para projetos ativos.**

---

## 🎯 Para Que Serve Este Diretório?

O diretório `PROJETOS/` é onde você **trabalha ativamente** em seus projetos enquanto aplica o método ENDFIRST.

**Pense nele como:**
- 📝 Rascunho (enquanto o projeto está em andamento)
- 🗂️ Workspace temporário
- 🚧 Área de construção

**Quando o projeto estiver finalizado**, você move a documentação para `BANCO_REFERENCIAS/projetos/`.

---

## 📁 Como Organizar Seus Projetos?

### **Estrutura Recomendada:**

```
PROJETOS/
├── README.md (este arquivo)
├── meu_projeto_1/
│   ├── 00_ESTADO_FINAL.md          (Pilar 0)
│   ├── 01_OBSTACULOS.md            (Pilar 1)
│   ├── 02_RECURSOS.md              (Pilar 2)
│   ├── 03_CALIBRACAO.md            (Pilar 3)
│   ├── 03.5_ANALISE_RISCOS.md      (Pilar 3.5)
│   ├── 04_CAMINHO_REVERSO.md       (Pilar 4)
│   ├── 04.5_ROADMAP.md             (Pilar 4.5)
│   ├── 05_VALIDACAO_EXTERNA.md     (Pilar 5)
│   ├── 06_EXECUCAO.md              (Pilar 6)
│   ├── 07_APRENDIZADOS.md          (Pilar 7)
│   └── assets/                     (Diagramas, imagens, etc.)
│
└── meu_projeto_2/
    └── ...
```

---

## 🔄 Fluxo de Trabalho

### **1. Criar Novo Projeto**

```bash
mkdir PROJETOS/meu_novo_projeto
cd PROJETOS/meu_novo_projeto
```

**Dica:** Use o template em `GUIAS/COMO_DOCUMENTAR_PROJETOS.md`

---

### **2. Aplicar os 7 Pilares**

Siga o guia `GUIAS/COMO_APLICAR_O_METODO.md` e documente cada pilar:

1. **Pilar 0:** Defina o estado final em `00_ESTADO_FINAL.md`
2. **Pilar 1:** Liste obstáculos em `01_OBSTACULOS.md`
3. **Pilar 2:** Inventarie recursos em `02_RECURSOS.md`
4. **Pilar 3:** Calibre com a realidade em `03_CALIBRACAO.md`
5. **Pilar 3.5:** Analise riscos em `03.5_ANALISE_RISCOS.md`
6. **Pilar 4:** Trace o caminho reverso em `04_CAMINHO_REVERSO.md`
7. **Pilar 4.5:** Crie o roadmap em `04.5_ROADMAP.md`
8. **Pilar 5:** Documente validações em `05_VALIDACAO_EXTERNA.md`
9. **Pilar 6:** Monitore execução em `06_EXECUCAO.md`
10. **Pilar 7:** Registre aprendizados em `07_APRENDIZADOS.md`

---

### **3. Usar o Cursor AI Durante o Projeto**

**Adicione o projeto ao contexto:**

```
@PROJETOS/meu_novo_projeto
"Com base no estado final e nos obstáculos, sugira 3 abordagens para resolver o obstáculo técnico X"
```

```
@PROJETOS/meu_novo_projeto/03.5_ANALISE_RISCOS.md
"Crie uma matriz de decisão comparando as 3 abordagens"
```

---

### **4. Finalizar e Mover para o Banco**

Quando o projeto estiver completo:

1. **Consolide a documentação** (seguindo `GUIAS/COMO_DOCUMENTAR_PROJETOS.md`)
2. **Mova para o banco:**
   ```bash
   mv PROJETOS/meu_projeto BANCO_REFERENCIAS/projetos/
   ```
3. **Atualize o índice:** Adicione metadados em `BANCO_REFERENCIAS/INDICE.md`

---

## 🎯 Exemplo de Projeto em Andamento

```
PROJETOS/sistema_gestao_tarefas/
├── 00_ESTADO_FINAL.md
│   "Sistema web com 100 usuários até Março/2026"
│
├── 01_OBSTACULOS.md
│   - Técnico: Autenticação multi-tenant
│   - Financeiro: Orçamento limitado ($200/mês)
│   - Tempo: Apenas 12 semanas
│
├── 02_RECURSOS.md
│   - Tempo: 15h/semana
│   - Conhecimento: React, Node.js, PostgreSQL
│   - Ferramentas: Vercel, Supabase
│
├── 03_CALIBRACAO.md
│   "Vou usar Supabase para auth e database (reduz complexidade)"
│
├── 03.5_ANALISE_RISCOS.md
│   Matriz de decisão: Supabase vs Firebase vs Custom Auth
│   Decisão: Supabase (score 4.2)
│
├── 04_CAMINHO_REVERSO.md
│   Estado Final → Beta → MVP → Protótipo → Presente
│
├── 04.5_ROADMAP.md
│   Fase 1: MVP (6 semanas) - Auth + CRUD básico
│   Fase 2: Beta (6 semanas) - Notificações + Colaboração
│
└── 06_EXECUCAO.md
│   Sprint 1: ✅ Auth implementado
│   Sprint 2: 🚧 CRUD de tarefas (em andamento)
```

---

## ✅ Checklist de Projeto

Use este checklist para garantir que você está aplicando o método corretamente:

- [ ] Estado final definido com clareza (Pilar 0)
- [ ] Todos os obstáculos identificados (Pilar 1)
- [ ] Recursos inventariados (Pilar 2)
- [ ] Plano calibrado com a realidade (Pilar 3)
- [ ] Análise de riscos com matriz de decisão (Pilar 3.5)
- [ ] Caminho reverso traçado (Pilar 4)
- [ ] Roadmap de implementação criado (Pilar 4.5)
- [ ] Validação externa realizada (Pilar 5)
- [ ] Execução monitorada (Pilar 6)
- [ ] Aprendizados documentados (Pilar 7)

---

## 🚀 Comece Seu Primeiro Projeto!

1. **Crie a pasta:** `mkdir PROJETOS/meu_primeiro_projeto`
2. **Siga o guia:** `GUIAS/COMO_APLICAR_O_METODO.md`
3. **Use o Cursor:** `@PROJETOS/meu_primeiro_projeto`
4. **Documente tudo:** Cada pilar em um arquivo separado

---

**Este diretório é seu! Use-o para transformar suas ideias em realidade.** 🚀  
**Quando finalizar, mova para `BANCO_REFERENCIAS/projetos/` e compartilhe o conhecimento!** 🧠
